from __future__ import annotations

from collections import OrderedDict
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, replace
from functools import lru_cache
import base64
import ctypes
import ctypes.util
import json  # EV6 HUD patch v17
import math
import types
import threading  # EV6 HUD patch v17
import os
import time
import zlib
from pathlib import Path

import numpy as np
import pyray as rl

from openpilot.common.transformations.camera import DEVICE_CAMERAS, view_frame_from_device_frame
from openpilot.common.transformations.orientation import rot_from_euler
from openpilot.selfdrive.carrot.deceleration_source import navigation_status_presentation
from openpilot.selfdrive.carrot.signal_display import SignalDisplayReader, project_box
from openpilot.selfdrive.carrot.lead_brake_lights import BrakeDisplayReader

from cluster_gles_dmabuf import DirectNv12DmabufError, create_tici_nv12_dmabuf_pool
from cluster_gles_readback import DirectNv12ReadbackError, create_tici_direct_readback
from cluster_display import (
    CLUSTER_LANGUAGE_KO,
    cluster_text,
    display_speed,
    format_navi_distance,
    format_radar_distance,
    format_trip_distance,
    normalize_cluster_language,
    speed_unit,
)
from cluster_config import (
    AMBER,
    BLUE,
    BLUE_SOFT,
    CLUSTER_CAMERA_VIEW_MODE_DEFAULT,
    CLUSTER_PANEL_LAYOUT_DRIVING_LEFT,
    CLUSTER_PANEL_LAYOUT_DRIVING_RIGHT,
    CLUSTER_RADAR_INFO_ALL_SPEED,
    CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
    CLUSTER_RADAR_INFO_NONE,
    CLUSTER_RADAR_INFO_VEHICLE_SPEED,
    CLUSTER_RADAR_INFO_VEHICLE_SPEED_DISTANCE,
    CLUSTER_RADAR_SOURCE_COLOR_BY_SOURCE,
    CLUSTER_SCREEN_MODE_DEBUG,
    CLUSTER_SCREEN_MODE_DEBUG_GRAPH,
    CLUSTER_SCREEN_MODE_DEBUG_GRAPH_RIGHT,
    CLUSTER_SCREEN_MODE_FULLSCREEN_3D,
    CLUSTER_SCREEN_MODE_NAVI,
    CLUSTER_SCREEN_MODE_NAV_MODEL,
    CLUSTER_SCREEN_MODE_TRIP_REPORT,
    CLUSTER_SCREEN_MODE_DEFAULT,
    CLUSTER_SCREEN_MODE_DEBUG_SYSTEM,
    ClusterTheme,
    DESIGN_HEIGHT,
    DESIGN_WIDTH,
    EGO_FORWARD_M,
    GREEN,
    MAX_ACCEL_MPS2,
    MAX_SPEED_KPH,
    RADAR_TO_CAMERA_M,
    RED,
    TEXT,
    VEHICLE_NAVI,
    VEHICLE_LENGTH_M,
    WHITE,
    cluster_camera_view_is_road_camera,
    cluster_camera_view_prefers_wide,
    cluster_wide_camera_zoom_factor,
    current_cluster_theme,
    normalize_cluster_camera_view_mode,
    normalize_cluster_screen_mode,
    normalize_cluster_panel_layout,
    normalize_cluster_theme_mode,
)
from cluster_models import (
    ClusterAlert,
    ClusterUiState,
    DebugPlotSnapshot,
    GitBranchStatus,
    NaviDebugInfo,
    NaviDashboardState,
    NaviGuidanceImage,
    NaviMediaFrame,
    NaviLaneInfo,
    NaviLiveState,
    NaviTrafficLightInfo,
    RouteOverlay,
    TripReportState,
)
from cluster_scene import (
    ClusterScene,
    MeshStrip,
    RADAR_STATIC_OBJECT_SPEED_KPH,
    RadarPointMarker,
    Vec3,
    VehicleBox,
    build_cluster_scene,
    clean_ui_enabled,
    cluster_scene_state_key,
)
from cluster_k9_lanesm import K9LaneSmoother
from cluster_system_monitor import SystemStats, SystemStatsSampler
from cluster_k9_hold import K9RoadHold
from cluster_taxi_meter import TaxiMeterPanel  # noqa: F401  (bd09c076 look, kept for its tests)
from cluster_taxi_c1 import C1MeterPanel
from cluster_lat_values import (delay_learn_text, lane_gap_text, lane_offset_text, lat_values_text, torque_applied_text,
                                learned_steer_ratio_text, torque_learned_text)
from cluster_vehicle_models import ego_model_name
from cluster_utils import blink_visible, clamp


CLUSTER_DIR = Path(__file__).resolve().parent
SELFDRIVE_DIR = CLUSTER_DIR.parents[1]
OPENPILOT_FONT_DIR = SELFDRIVE_DIR / "assets" / "fonts"
OPENPILOT_ADDON_FONT_DIR = SELFDRIVE_DIR / "assets" / "addon" / "font"
KAIGEN_GOTHIC_KR_BOLD_FONT_PATH = OPENPILOT_FONT_DIR / "KaiGenGothicKR-Bold.ttf"
JETBRAINS_MONO_FONT_PATH = OPENPILOT_FONT_DIR / "JetBrainsMono-Medium.ttf"
VEHICLE_MODEL_PATH = CLUSTER_DIR / "assets" / "models" / "cybertruck" / "cybertruck_cluster.obj"
PARK_VEHICLE_MODEL_PATH = CLUSTER_DIR / "assets" / "models" / "ev6" / "ev6_cluster.obj"
# K9 parked screen (대감님 11/11 18:24): original 2020 RJ model from make_k9_park_model.py, P screen only
PARK_K9_MODEL_PATH = CLUSTER_DIR / "assets" / "models" / "k9" / "k9_cluster.obj"
PARK_K9_SCALE_M = (1.915, 5.12, 1.49)  # K9 RJ width x length x height
# K9 parked screen photo (대감님 11/11 20:37): car cut out of his mock-up, plate blanked; drawn instead of the model
K9_PARK_CAR_SPRITE_PATH = CLUSTER_DIR / "assets" / "images" / "k9_park_car.png"
# 대감님 11/12 23:13/23:14 + 23:34: K9 R screen = top-view K9 (RJ) illustration drawn in code by make_k9_reverse_sprite.py
# (5120 x 1915 mm body, wheelbase 3105 mm, PAD m margin for mirrors / shadow / lamp glow) on the K9 P screen colours.
K9_REVERSE_CAR_SPRITE_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_car.png"
K9_REVERSE_CAR_SIZE_M = (5.12, 1.915)
K9_REVERSE_CAR_PAD_M = 0.30
# 대감님 11/12 23:56: steered front tyres drawn between the floor shadow and the body (display only: road wheel angle =
# steering angle / K9 steer ratio 14.5, the reverse path still uses reverse_geometry()). Same frame as the body image.
K9_REVERSE_CAR_SHADOW_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_car_shadow.png"
K9_REVERSE_WHEEL_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_wheel.png"
K9_REVERSE_SPRITE_PPM = 200.0  # make_k9_reverse_sprite.py PPM (wheel image px -> m)
K9_REVERSE_FRONT_AXLE_FROM_REAR_M = 1.06 + 3.105  # rear overhang + wheelbase
K9_REVERSE_FRONT_TRACK_M = 1.63
K9_REVERSE_DISPLAY_STEER_RATIO = 14.5
K9_REVERSE_WHEEL_PAD_M = 0.03  # make_k9_reverse_sprite.py WHEEL_PAD
K9_REVERSE_WHEEL_PEEK_M = 0.02  # turned front tyre: at most this much more past the fender
# 23:56: alert text on the K9 R screen goes to the right column under the blind-spot row (not over the car);
# colours and sizes are the normal alert ones
K9_REVERSE_ALERT_CENTER = (1680.0, 305.0)
K9_REVERSE_ALERT_MAX_W = 400.0
# K9 R screen display scale (대감님 11/12 23:34 차 더 크게): ~121 px/m on the 480 px high screen (EV6 27 deg = ~80 px/m)
K9_REVERSE_FOVY_DEG = 18.0
K9_REVERSE_VIEW_Y_M = -2.69
# 대감님 11/13 02:35 "골라써라" (his own K9 photos): K9 R screen car = k9_rear3.jpg cut out by make_k9_reverse_photo.py
# (plate blanked, softer reflections, new floor shadow). Path, 1/2/3 m marks and blind-spot bands are drawn on the floor
# with the photo camera reverse-solved from the photo (wheel contacts at the 3105 mm wheelbase / ~1630 mm track, rear
# bumper, lamps, plate; 5120 mm body): f px, Rodrigues rvec, tvec (m) in the car frame x right / y forward from the rear
# bumper / z up. That camera stood only ~1.3 m behind the bumper, so a 3 m path would run behind it: the floor is drawn
# from the same direction but PULLBACK m further back with the focal length scaled so the rear bumper keeps its size
# (dolly zoom about the bumper). Photo px -> design px: x * SCALE + OFFSET. The 45 deg / top-view car files stay unused.
K9_REVERSE_PHOTO_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_photo.png"
# its own P-stage floor (navy pool + thin blue rim on the photo's ground plane), same frame as the car file, drawn
# under the path; the P floor file is only the fallback (it carries the P car's mirror image)
K9_REVERSE_PHOTO_FLOOR_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_photo_floor.png"
# 대감님 11/13 15:46: ground layer made from the same photo (make_k9_reverse_ground.py) - floor reflection of the car and
# a floor light matching the photo's light direction, same frame as the car file, drawn over the floor and under the path
K9_REVERSE_PHOTO_GROUND_PATH = CLUSTER_DIR / "assets" / "images" / "k9_reverse_photo_ground.png"
K9_REVERSE_PHOTO_PATH_FADE_M = 0.45  # path fill / side lines fade in over this length from under the bumper
K9_REVERSE_PHOTO_CAMERA = (1484.13, (1.68427, -0.74313, 0.56378), (1.08057, 0.72563, 3.23045), (1600.0, 901.0))
K9_REVERSE_PHOTO_CROP = (-78.0, 92.0, 1688.0, 935.0)  # image frame in photo px (make_k9_reverse_photo.py CROP)
K9_REVERSE_PHOTO_PULLBACK_M = 12.0
# 대감님 11/13 04:02 "안다듬고?": car a little smaller and lower (roof clear of the screen top), bumper kept in place
K9_REVERSE_PHOTO_SCALE = 0.33
K9_REVERSE_PHOTO_OFFSET = (316.8, -6.3)
K9_REVERSE_PHOTO_CAR_W_PX = 1334.0  # car (no shadow) width in photo px, for the P floor disc size
K9_REVERSE_PHOTO_FLOOR_W = 1.15  # P stage floor width / car width (P: 694 / 556 = 1.25; a bit less: clear of the R text)
K9_REVERSE_PHOTO_CAR_CX_PX = 705.0  # car (no shadow) centre x in photo px: floor disc centre x
# the photo shows the bumper ~0.35 m above the floor; the path is drawn from this far under the car (hidden by the
# body) so it comes out right at the bumper. Marks / labels still count from the bumper.
K9_REVERSE_PHOTO_PATH_UNDER_M = 0.35
# blind-spot band on the K9 photo screen: drawn with the photo camera itself so it lies along the photo car's side
# (that camera stood ~1.6 m beside the left side): inner edge, strip width (6 strips), front / rear end y (R frame)
K9_REVERSE_PHOTO_BAND = (1.0, 0.06, 2.2, -2.5)


def _k9_reverse_photo_setup(back: float = K9_REVERSE_PHOTO_PULLBACK_M):
    f, (rx, ry, rz), (tx, ty, tz), (w, h) = K9_REVERSE_PHOTO_CAMERA
    theta = math.sqrt(rx * rx + ry * ry + rz * rz)
    k = np.array([rx, ry, rz]) / theta
    kx = np.array([[0.0, -k[2], k[1]], [k[2], 0.0, -k[0]], [-k[1], k[0], 0.0]])
    rot = np.eye(3) + math.sin(theta) * kx + (1.0 - math.cos(theta)) * (kx @ kx)
    return rot, np.array([tx, ty, tz + back]), f * (tz + back) / tz, w / 2.0, h / 2.0


K9_REVERSE_PHOTO_VIEW = _k9_reverse_photo_setup()
K9_REVERSE_PHOTO_VIEW_TRUE = _k9_reverse_photo_setup(0.0)  # the photo camera itself (things under the car)


def k9_reverse_photo_point(x: float, y: float, z: float = 0.0, true_camera: bool = False):
    """Design px of a point in the R screen frame (x right, y forward, EV6_REVERSE_REAR_BUMPER_Y_M = bumper); None if
    it is not in front of the floor camera."""
    rot, t, f, cx, cy = K9_REVERSE_PHOTO_VIEW_TRUE if true_camera else K9_REVERSE_PHOTO_VIEW
    p = rot @ np.array([x, y - EV6_REVERSE_REAR_BUMPER_Y_M, z]) + t
    if p[2] < 0.3:
        return None
    ox, oy = K9_REVERSE_PHOTO_OFFSET
    return ox + K9_REVERSE_PHOTO_SCALE * (f * p[0] / p[2] + cx), oy + K9_REVERSE_PHOTO_SCALE * (f * p[1] / p[2] + cy)


def k9_reverse_photo_rect() -> tuple[float, float, float, float]:
    """Design px rect of k9_reverse_photo.png."""
    x0, y0, w, h = K9_REVERSE_PHOTO_CROP
    ox, oy = K9_REVERSE_PHOTO_OFFSET
    s = K9_REVERSE_PHOTO_SCALE
    return ox + s * x0, oy + s * y0, s * w, s * h
# 대감님 11/12 04:34 "화면 너무 파란색인데 좀 더 어둡게 해봐": the blue background and the floor layer under the car get
# the same darkening (brightness x DIM, blue pulled part of the way towards grey) so their seam does not show;
# bright floor pixels (the rim light) are spared on a ramp so the rim stays visible. Car photo, text, numbers unchanged.
K9_PARK_DIM = float(os.environ.get("K9_PARK_DIM", "0.40"))
K9_PARK_SAT = float(os.environ.get("K9_PARK_SAT", "0.70"))
K9_PARK_RIM_KEEP = (120.0, 200.0)  # floor max channel: below = full darkening, above = untouched, linear in between


def k9_park_darken(rgb, keep: float = 0.0):
    r, g, b = (float(c) for c in rgb[:3])
    grey = 0.299 * r + 0.587 * g + 0.114 * b
    k = K9_PARK_DIM + (1.0 - K9_PARK_DIM) * keep
    sat = K9_PARK_SAT + (1.0 - K9_PARK_SAT) * keep
    return tuple(int(round(max(0.0, min(255.0, k * (grey + sat * (c - grey)))))) for c in (r, g, b))


K9_PARK_COLORS_DARK = {"bg_top": k9_park_darken((22, 52, 118)), "bg_bot": k9_park_darken((6, 16, 44)), "text": (240, 244, 250), "muted": (150, 172, 210),
                       "card": (20, 44, 96), "line": (60, 92, 150), "accent": (110, 180, 255)}
# 대감님 11/11 21:05 "2번째처럼 비율좀 잘맞춰보지?": mock-up panel (1860x518 px) mapped to 1920x480
K9_PARK_CAR_BOX = (856.0, 358.0, 292.0)  # car centre x, bottom y, height (photo aspect kept)
# 대감님 11/11 21:30 "차하고 아래원하고 너무 아니지않냐": the stage is placed from the car photo, not on its own.
# Measured on his mock-up, where the same photo sits 1:1 (556x276 at 468,302): rim traced every 10 px below the car
# (62 points), fitted as a slightly turned ellipse (error <= 0.7 px): centre (741.0, 555.6), radii 314.0 x 76.3,
# turned 1.86 deg (right end up) -> in photo heights from the photo bottom-centre:
K9_PARK_STAGE_REL = (-0.0180, -0.0811, 1.1377, 0.2766, -1.86)  # centre dx, dy, radius x, radius y, turn deg
K9_PARK_PROFILE_STEP = 3  # photo px per column of the thin contact shadow along the car's bottom outline
K9_PARK_WHEELS = ((310, 275), (505, 199))
# 대감님 11/11 22:59 "그림자는 1번처럼 해야지": the floor under the car (contact shadow, mirror image of body and tyres,
# darkening towards the car, rim) is lifted from his mock-up itself, in photo px, transparent under the opaque photo
# (no plate or tyre-pressure text in it) and faded out just outside the rim
K9_PARK_FLOOR_PATH = CLUSTER_DIR / "assets" / "images" / "k9_park_floor.png"
K9_PARK_FLOOR_OFFSET = (-72, 160)  # floor PNG top-left relative to the car photo top-left, photo px  # photo px: front / rear tyre contact (lowest alpha), reflection axis
K9_DTE_FULL_KM = 600.0  # carState.fuelGauge = CF_Clu_DTE / 600 km for the K9 (selfdrive/car/k9_fuel.py)
# K9 TURZX drive layout (대감님 2026-11-12 18:05, layout of GRT47/HKG_5W_TurzxMonitor photo): left car panel, middle 3D road,
# right lane / steer-learn panel. K9 only (car_fingerprint KIA_K9), default screen mode, not P / R. EV6 untouched.
# 대감님 11/12 19:55 "하단바 제거, 내 차는 신호 안 들어오잖아": climate bar and the no-signal items (fuel %, fuel economy)
# removed; the three cards run down to the bottom instead. Only values the K9 actually sends are drawn.
K9_TURZX_MARGIN = 8.0
K9_TURZX_TOP_H = 464.0                       # cards y 8 .. 472 (bottom climate bar removed 19:55)
K9_TURZX_LEFT_X = 8.0
# 대감님 11/12 23:44 "왼쪽오른쪽칸 줄일수잇으면 더줄이고 가운데 비중 늘려": each side card is its longest text + 20 px
# padding. Car card (screen right) 656 -> 480: two columns (184 px meters | "999.9 km" 228 px) x three rows, TPMS in the
# third row; lane card (screen left) 464 -> 460 (longest line "학습 조향비 13.98  학습지연 0.20초" 420 px). Middle 768 -> 948.
# 대감님 11/13 00:20 "좀더 줄여도될듯": both side cards 480 / 460 -> 352 (one item per row, same font sizes), middle 948 -> 1184.
K9_TURZX_LEFT_W = 352.0                      # car card width (drawn at x 8, moved to the right by K9C_SWAP_DX)
# 대감님 11/12 23:12 "왼쪽칸 좀 줄여도 되잖아, 메인은 가운데인데": the left card (lane position / steering learn) 656 -> 464,
# the middle road card takes the 192 px (576 -> 768), the right card stays. Road / ego car centred in the middle card.
K9_TURZX_MID_X, K9_TURZX_MID_W = 368.0, 1184.0
K9C_CX = K9_TURZX_MID_X + K9_TURZX_MID_W * 0.5   # 950: card road / ego car centre (23:12 864)
K9C_LANE_W = 352.0                           # card 1 (lane position / steering learn): 8 .. 360
K9_TURZX_RIGHT_X, K9_TURZX_RIGHT_W = 1560.0, 352.0
# 00:20 car card = one item per row: label (left) + sub (right) on one line, value under it, meter right of the value;
# rows at card top + 22 + 82 i (label centre), value centre + 36, meters from card x + 214 (widest value "+12.3°" 194 px)
K9C_ROW0, K9C_ROW_STEP, K9C_VALUE_DY = 22.0, 82.0, 36.0
K9C_BAR_X = 214.0
K9C_TPMS_Y, K9C_TPMS_SCALE = 332.0, 0.72     # TPMS row 340 .. 472, top view 56x150 -> 40x108
# lane card: 차선 위치 rows one (name, value) per row (좌 / 우 split: "좌 1.87m  우 1.63m" 390 px > 312), steering learn
# one item per line (9 lines, longest "학습 조향비 13.91" 230 px), value column right-aligned
K9C_LANE_ROW0, K9C_LANE_PITCH = 54.0, 40.0
K9C_SPLIT_DY = 162.0
K9C_LAT_ROW0, K9C_LAT_PITCH = 52.0, 28.0     # from the split line; 27 px font: 19 px box, 9 px between lines
# middle panel road (대감님 18:30 "가운데 꺼 디자인이 다른데?"): flat 2D perspective road drawn from modelV2 lane lines /
# road edges / plan path and leadOne, no 3D world, no car photo. screen y = horizon + K_Y / (forward + Z0), x = cx + K_X * lateral / (forward + Z0)
K9_TURZX_ROAD_HORIZON_Y = 170.0   # 21:44 redesign: speed floats above the horizon
# 대감님 20:41 "내 차가 왜 중앙에 가 있냐?": my car back at the bottom of the road panel (nearest the viewer, like
# the pre-692b738d5 layout), rear bumper just above the bottom pills; path band / arrows run only ahead of it
K9_TURZX_ROAD_EGO_Y = 475.0                  # forward 0 m (my rear bumper) 5 px above the panel bottom 472 (21:44 no card: 5 px above the screen bottom 480)
K9_TURZX_ROAD_Z0 = 27.5
K9_TURZX_ROAD_KY = (K9_TURZX_ROAD_EGO_Y - K9_TURZX_ROAD_HORIZON_Y) * K9_TURZX_ROAD_Z0
K9_TURZX_ROAD_KX = 1600.0                    # 52 px/m at forward 0: lane 3.6 m = 187 px
K9_TURZX_STEER_BAR_DEG = 90.0                # 조향각 bar clipped at +-90 deg
K9_TURZX_ROAD_BACK_M = 0.0                   # 20:48 차가 맨 뒤: nothing drawn behind my car
K9_TURZX_ROAD_MAX_M = 140.0
K9_TURZX_MID_TOP = (3, 7, 18)                 # night sky
K9_TURZX_MID_BOTTOM = (12, 24, 48)
K9_TURZX_ROAD = (17, 30, 56)
K9_TURZX_MID_CARD = (8, 14, 30, 214)
K9_TURZX_MID_EDGE = (206, 186, 148, 70)       # champagne hairline
K9_TURZX_LANE = (110, 200, 255)
K9_TURZX_PATH = (64, 214, 190)                # bright teal path band (photo)
K9_TURZX_PATH_ARROW = (226, 255, 244)
K9_TURZX_CHAMPAGNE = (214, 192, 150)
K9_TURZX_CHROME = (196, 206, 222)
K9_TURZX_POINT = (228, 194, 128)             # 대감님 19:56 고급스럽게: the one accent (lead car, distance tag, lane offset)
K9_TURZX_LEAD = K9_TURZX_POINT
K9_TURZX_TAG = K9_TURZX_POINT
K9_TURZX_RADIUS = 16.0                       # one corner radius for every card
K9_TURZX_SIGNAL = (80, 222, 150)             # turn signal arrows stay green
K9_TURZX_EGO_W = 120.0                       # K9 rear sprite ~2.1 m at forward 0 (52 px/m), narrower than the lane
K9_TURZX_LANE_TEXT_SIZE = 40.0               # 치우침 / 좌·우 (was 32 in the middle, not smaller)
K9_TURZX_LAT_TEXT_SIZE = 27.0                # 실험줄 5개 (was 19 in the middle, not smaller)
K9_TURZX_BG = (2, 4, 10)
K9_TURZX_BG_TOP = (11, 17, 34)
K9_TURZX_CARD = (12, 19, 36)
K9_TURZX_EDGE = (52, 64, 88)
K9_TURZX_TEXT = (242, 246, 252)
K9_TURZX_MUTED = (170, 178, 194)             # label tier 1 (silver)
K9_TURZX_DIM = (100, 114, 138)               # label tier 2 / no value
K9_TURZX_ACCENT = (84, 176, 255)
K9_TURZX_GOOD = (110, 206, 255)
K9_TURZX_LINE = (206, 186, 148, 46)          # champagne hairline separators
K9_TURZX_VALUE_TRACK = 0.06                  # number letter spacing (was 0.02)
K9_TURZX_LABEL_SIZE = 24.0
K9_TURZX_VALUE_SIZE = 60.0
K9_TURZX_UNIT_SIZE = 28.0
K9_TURZX_SUB_SIZE = 24.0

# K9 TURZX luxury scene (대감님 11/12 21:44). Fonts are SIL OFL 1.1 (Pretendard-LICENSE.txt covers Pretendard, Inter is OFL).
# 대감님 11/13 00:47 "양옆 숫자들 비율안맞잖아": both K9 D side blocks (lane / steer learn and car, both styles) use one
# three-tier type system: (a) block title, (b) item name / unit / sub, (c) value. Same tier = same size, weight and
# baseline spacing on both sides; every value right-aligned on a unit slot, units = tier (b) (unit / value = 24 / K9T_VALUE).
# K9T_VALUE = the largest size where the worst values fit (measured, see the commit); sizes never change with the values.
K9T_TITLE = 24.0
K9T_LABEL = 24.0
K9T_UNIT = K9T_LABEL
K9T_VALUE = 38.0
K9T_STACK_GAP = 8.0          # item name baseline -> value cap top
# 11/13 01:29 list (lane position + steering learn): a name sits closer to its own value than to the next item
# (was 12 px name -> value box vs 7 px value -> next name), the hairline shares one gap
K9T_LIST_STACK_GAP = 4.0
K9T_LIST_HAIR_GAPS = 1.4     # the hairline gap in list gaps (other gaps 1 each)
# card style: every gap of the left list >= 10 px (name -> its value too); the hairline gets one plain gap
K9T_LIST_STACK_GAP_CARD, K9T_LIST_HAIR_GAPS_CARD = 7.0, 1.0
K9T_HALF_GAP = 0.0           # two items on one line: halves meet at the middle (name of the 2nd item 41 px after the 1st unit slot)
K9T_VALUE_GAP = 16.0         # two values of one item
K9T_UNIT_GAP = 4.0
K9T_UNITS = ("cm", "km", "m", "초", "%", "°")
K9T_LIST_UNITS = ("cm", "m", "초", "%")
K9T_CAR_UNITS = ("km", "°")
K9T_WIDE_VALUE = "999.9"     # widest car value: meters end left of it
K9L_NUM_FONT_PATH = OPENPILOT_FONT_DIR / "Inter-Light.ttf"
K9L_KR_FONT_PATH = OPENPILOT_FONT_DIR / "Pretendard-Medium.ttf"
K9L_NUM_EXTRA = "°²·"
K9L_KR_GLYPHS = "".join((
    '°²·←↑→↓가각간감값갔거것게계고과구균그급기꺼나넣노놓놔는능니님다달대데도돌되들따띄',
    '라래럼려로른를리마만면못뭘미번변보부브비빼살서선설센속수습아안앞어에연오왔외왼용우운워웹',
    '위으은의이인잇재적정조좌주준지짐집쪽차찰찻처초치침켬콤크토트퍼페평표하학한했행향헌현화횡',
))
K9L_NUM_INK = 1.25   # Inter digits ink 62 px vs KaiGen 77 px at size 100 (measured): x1.25 keeps every number >= old
K9L_KR_INK = 1.31    # Pretendard Hangul ink 72 px vs KaiGen 94 px at size 100 (measured): x1.31
K9L_SPEED_SIZE = 100.0   # x1.25 ink = 78 px digits (old speed 66 -> 51 px)
K9L_SPEED_CY = 74.0
K9L_GEAR_SIZE = 40.0     # old 36
K9L_SIDE_DX = 140.0
# 23:44: scene 496..1310 -> 496..1444 (814 -> 948), the car block on the right 580 -> 420 (1468..1888)
# 00:20: list 32..472 -> 32..376 (344), car block 1468..1888 -> 1568..1888 (320), scene 948 -> 1160 (392..1552)
K9L_SCENE_X0, K9L_SCENE_X1 = 392.0, 1552.0   # 23:12: was 610 (left list 32..584 -> 32..472)
K9L_CX = (K9L_SCENE_X0 + K9L_SCENE_X1) * 0.5    # 970: scene road / speed / ego car centre (23:12 903)
K9L_LIST_W = 344.0                          # left list width (lane position / steering learn), was 552 / 440
K9L_LANE_GAP, K9L_PAIR_GAP = 12.0, 30.0    # lane rows: name -> value, pair -> pair
K9L_SCENE_FADE = 80.0
K9L_CAR_W = 320.0                           # 00:20 car block width, one item per row ("999.9 km" 215 px)
K9L_ROW0, K9L_ROW_STEP, K9L_ROW_VALUE_DY = 30.0, 86.0, 52.0   # label baselines 30 + 86 i, value baseline + 52
K9L_METER_X = 198.0                         # meters right of the value ("+12.3°" 182 px)
K9L_TPMS_CX = 112.0
K9L_RIGHT_X = 1336.0  # right list x0 (content to K9L_RIGHT_X1)
K9L_LAT_STEP = 50.0
K9L_PILL_Y = 150.0
K9L_BG_TOP = (7, 12, 26)
K9L_BG_BOTTOM = (1, 2, 6)
K9L_ICE = (150, 210, 255)
K9L_LANE = (140, 206, 255)
K9L_CHAMPAGNE = (218, 196, 154)
K9L_ROAD = (16, 30, 58, 178)
K9L_FOG = (40, 64, 100)   # light haze toward the glowing horizon
K9L_SIDE = (3, 5, 12)
K9L_LABEL = (196, 178, 142)
K9L_MUTED = (150, 162, 182)
K9L_DIM = (86, 98, 120)
K9L_VALUE = (238, 243, 250)
K9L_LAT = (206, 216, 230)
# 11/12 22:10 "그게 최선이야?" final pass: one baseline / margin grid for the whole screen (design px, baselines)
K9L_EDGE = 32.0                        # outer margin left and right (content 32 .. 1888)
K9L_HEAD = 62.0                        # header baseline: TPMS, the left labels row 1, MAX, 차선 위치
K9L_ROW1, K9L_ROW2 = 62.0, 206.0       # car block label baselines (23:44 third row = TPMS)
K9L_VALUE_DY = 59.0                    # label baseline -> value baseline (= speed / cruise baseline 121 on row 1)
K9L_METER_DY = 80.0                    # label baseline -> meter line
K9L_SUB_DY = 108.0                     # label baseline -> sub line baseline
K9L_TRACK = 0.10                       # wide letter spacing of the champagne headers
K9L_TPMS_X = K9L_EDGE + K9L_CAR_W * 0.5   # TPMS car centre x, name + number outside each wheel (23:44 third row)
K9L_TPMS_Y = 428.0
K9L_TPMS_SCALE = 0.5                   # 00:20 the TPMS top view 64x190 -> 32x95 under four item rows
K9L_TPMS_HEAD = 378.0
K9L_TPMS_HAIR = 354.0
K9L_SPEED_BASE = 121.0
K9L_KMH_BASE = 152.0
K9L_TOP_CY = 84.0                      # gear ring, limit sign centre
K9L_SIGN_X = K9L_SCENE_X0 + 114.0
K9L_PERC_Y = 212.0                     # lane % (left) / lead (right) beside the far road, symmetric about K9L_CX
K9L_PERC_GAP = 64.0
K9L_NAVI_BASE = 292.0
K9L_RIGHT_X1 = K9L_RIGHT_X + K9L_LIST_W
K9L_LIST_HEAD = 30.0                   # 00:20 list: 차선 위치 header, rows, hairline, 조향 학습 header, 9 one-item lines
K9L_LANE_BASES = (72.0, 115.0, 158.0)     # 치우침 / 좌 / 우 ("좌 3.50m" + "우 3.48m" 356 px > 344: one per row)
K9L_RIGHT_HAIR = 170.0
K9L_LAT_HEAD = 196.0
K9L_LAT_BASE0, K9L_LAT_PITCH = 228.0, 30.0   # 35 px glyphs (27 x ink 1.31): 25 px box, 5 px between lines, last 468
# 11/12 22:37 대감님 "두 판 모두 살려": K9 D layout chosen by the Param ClusterHudK9Style
# (0 = card layout of b03a700cc = "윗버전", 1 = one night scene of ad691fbd7.. = "아랫버전").
K9_HUD_STYLE_CARD, K9_HUD_STYLE_SCENE = 0, 1
# 23:44 the road grows with the middle (card 768 -> 948, scene 814 -> 948): KX and my car width scaled together
K9C_ROAD_K = K9_TURZX_MID_W / 768.0
K9L_ROAD_K = (K9L_SCENE_X1 - K9L_SCENE_X0) / 814.0
# 00:20 my car follows the road scale only up to 140 px (card) / 150 px (scene): 166 / 171 px reached the indicator text
K9C_EGO_MAX_W, K9L_EGO_MAX_W = 140.0, 150.0
K9C_ROAD_GEO = (108.0, 467.0, 1430.0 * K9C_ROAD_K, min(K9C_EGO_MAX_W, 108.0 * K9C_ROAD_K))  # horizon y, rear bumper y, KX, ego w
K9L_ROAD_GEO = (K9_TURZX_ROAD_HORIZON_Y, K9_TURZX_ROAD_EGO_Y, K9_TURZX_ROAD_KX * K9L_ROAD_K,
                min(K9L_EGO_MAX_W, K9_TURZX_EGO_W * K9L_ROAD_K))
# 22:41 "1칸 3칸 맞바꿔": the left content moves to the right side and the right content to the left, middle unchanged
K9C_SWAP_DX = K9_TURZX_RIGHT_X - K9_TURZX_LEFT_X   # card 1 (8..488) <-> card 3 (1432..1912)
K9L_SWAP_LEFT_DX = DESIGN_WIDTH - K9L_EDGE - K9L_CAR_W - K9L_EDGE  # 1436: car block 32..452 -> 1468..1888
K9L_SWAP_RIGHT_DX = -1304.0  # lane / steer-learn list 1336..1776 -> 32..472
K9C_IND_Y, K9L_IND_Y = 262.0, 182.0   # automatic indicator box (was y 124 = over km/h / the lane pill)
K9L_PERC_Y_IND = 274.0                # lane % / lead row while the indicator box sits on its usual row
K9L_NAVI_BASE2 = 336.0                # turn-by-turn distance baseline (scene, right of the road)
K9L_CAM_X, K9L_CAM_Y, K9L_CAM_W = K9L_SCENE_X0 + 16.0, 292.0, 244.0   # speed camera block (scene, left of the road)
K9L_LANE_Y = 412.0                    # navi lane strip top (scene, left of my car)
K9C_CAM_X, K9C_CAM_Y, K9C_CAM_W, K9C_CAM_H = K9_TURZX_MID_X + 12.0, 340.0, 236.0, 60.0
K9C_LANE_Y = 410.0
K9_LANE_CELL_H = 46.0
# carrot_serv._get_sdi_descr (ko), short enough for one line
K9_SDI_NAMES = {
    0: "신호과속", 1: "과속 (고정식)", 2: "구간단속 시작", 3: "구간단속 끝", 4: "구간단속중", 5: "꼬리물기 단속",
    6: "신호 단속", 7: "과속 (이동식)", 8: "과속위험 구간", 9: "버스전용차로", 10: "가변 차로 단속", 11: "갓길 감시",
    12: "끼어들기 금지", 13: "교통정보 수집", 14: "방범용 CCTV", 15: "과적차량 구간", 16: "적재 불량 단속",
    17: "주차단속", 20: "어린이 보호구역", 22: "과속방지턱", 75: "후면 과속 단속", 76: "후면 신호·과속",
}
K9_NAVI_GLYPHS = "".join(("신호과속고정식구간단속시작끝중꼬리물기이동위험버스전용차로가변갓길감시끼",
                  "어들금지교통정보수집방범과적재불량주차어린보호역방턱후면다음카메라제한대기",))
K9L_KR_GLYPHS = "".join(sorted(set(K9L_KR_GLYPHS + K9_NAVI_GLYPHS)))
OTHER_VEHICLE_MODELS_DIR = CLUSTER_DIR / "assets" / "models" / "others"
OTHER_VEHICLE_MODEL_PATH = CLUSTER_DIR / "assets" / "models" / "generic" / "generic_car_cluster.obj"
TPMS_CAR_ICON_PATH = CLUSTER_DIR / "assets" / "images" / "tpms_toy_car.png"
EGO_CAR_ICON_PATH = CLUSTER_DIR / "assets" / "images" / "k9_ego_car.png"
# 11/13 01:01 대감님 "당연히 d이지": Navdy grey car sprites for the cars ahead on the K9 D road (both styles).
# car_00..24 = on-screen yaw -24..+24 deg (2 deg), 12 = straight; anchor = rear bottom centre; see navdy/SOURCE.txt
K9_NAVDY_DIR = CLUSTER_DIR / "assets" / "images" / "navdy"
K9_NAVDY_YAW_STEP, K9_NAVDY_MID = 2.0, 12
K9_NAVDY_MIN_W_M = 1.9                     # same 18 px floor as the old box (w = max(18, 1.9 * px/m))
# 11/13 01:29 screen only (inputs / control untouched): radar L1 and modelV2 M1..M3 report the same car, so cars closer
# than 2 m sideways (99 % of the same-car spread + margin) and max(6 m, 25 % of the range) lengthwise are drawn once, L1 > radar > model.
# Measured on 12 K9 rlogs of 11/12 (720 s, 1238 reports): model vs L1 |d forward| 95 % 5.8 m (up to 12 m at 40-52 m),
# |d lateral| 99 % 1.76 m while |d forward| < 8 m; real cars in the next lane sit 3.3 m off (kept).
K9_ROAD_SAME_LAT_M, K9_ROAD_SAME_DF_M, K9_ROAD_SAME_DF_K = 2.0, 6.0, 0.25
K9_ROAD_EGO_OVERLAP_PX = 6.0               # a car right ahead keeps its rear above the ego roof (only this much hidden)
# 11/13 01:58 대감님 "나브디 준거파일로 자연스럽게": one grey Navdy look for the whole K9 D road (both styles) -
# my car = the straight rear sprite (car_12) in light white-grey, ~0.6 of my lane wide; other cars plain grey (no tint),
# lead a little lighter; my lane a deep blue band between white lines, other lanes dark grey with white dashes
K9_NAVDY_EGO_LANE_FRAC = 0.55             # my car width / my lane width (3.6 m) at the car's middle row
K9_NAVDY_EGO_LIFT = 26                    # additive grey on top of the sprite: lighter than the cars ahead
K9_NAVDY_OTHER_TINT = (186, 188, 194)
K9_NAVDY_LEAD_TINT = (236, 238, 242)
K9_NAVDY_ROAD = (34, 37, 44)               # dark grey asphalt
K9_NAVDY_EGO_LANE = (34, 78, 196)          # deep blue band of my lane
K9_NAVDY_LINE = (232, 235, 240)            # white lane lines / distance text
# K9HudNavdy (실험중, 11/13 05:00 대감님 "실험중에 메뉴 넣어서 고급지게 안한거랑 한거랑"): 0 = the K9 D road look
# before b7e81bbd4 (default) / 1 = the Navdy grey look. The ONLY switch point is k9_navdy_on() / k9_look().
K9_HUD_NAVDY_PARAM = "K9HudNavdy"
K9_NAVDY_EGO_BOTTOM_PAD = 28.0            # Navdy ego (1): whole car inside the screen, bottom edge this far up
K9_NAVDY_EGO_TINT_LIFT = 60               # Navdy ego (1): additive lift, clearly lighter than the grey cars ahead
# 대감님 11/13 05:46 "기본.고급판 둘다 k9으로넣어야지": Navdy ego (1) = the mode-0 K9 rear (k9_ego_car.png),
# own colours (06:17 "왜 내차를 나브디로만듬?": no Navdy grey)
# made by make_k9_navdy_ego.py as a drop-in for navdy car_12 (2x its frame, same visible box / anchor)
K9_NAVDY_EGO_PATH = CLUSTER_DIR / "assets" / "images" / "k9_navdy_ego.png"
# Rear-above photo cutout of the owner's K9; drawn in place of the 3D model for
# the ego vehicle only. Leads/cut-ins keep the shared OBJ model.
EGO_CAR_ICON_MAX_ROLL_DEG = 12.0
SPEED_BG_PATH = SELFDRIVE_DIR / "assets" / "images" / "speed_bg.png"
TRAFFIC_RED_ICON_PATH = SELFDRIVE_DIR / "assets" / "images" / "traffic_red.png"
TRAFFIC_GREEN_ICON_PATH = SELFDRIVE_DIR / "assets" / "images" / "traffic_green.png"
FOLLOW_VEHICLE_ICON_PATH = SELFDRIVE_DIR / "assets" / "icons_mici" / "carrot_cruse_gap_trimmed.png"
LFA_ICON_PATH = SELFDRIVE_DIR / "assets" / "icons_mici" / "carrot_wheel_org.png"
LFA_LANE_ICON_PATH = SELFDRIVE_DIR / "assets" / "icons_mici" / "carrot_wheel_lane.png"
WIFI_ICON_PATH = SELFDRIVE_DIR / "assets" / "icons_mici" / "settings" / "network" / "wifi_strength_full.png"
ROUTE_CONTROL_PANEL_X = 340.0
ROUTE_CONTROL_PANEL_Y = DESIGN_HEIGHT - 74.0
ROUTE_CONTROL_PANEL_W = 1040.0
ROUTE_CONTROL_PANEL_H = 34.0
ROUTE_CONTROL_SEEK_Y = ROUTE_CONTROL_PANEL_Y + 18.0
ROUTE_CONTROL_BAR_X = ROUTE_CONTROL_PANEL_X + 142.0
ROUTE_CONTROL_BAR_W = ROUTE_CONTROL_PANEL_W - 284.0
# Keep the road camera strictly left of the navigation panel. These constants are
# shared so future panel layout changes cannot reintroduce an overlap.
NAVI_LIVE_PANEL_RIGHT = DESIGN_WIDTH - 4
NAVI_LIVE_PANEL_W = 792
NAVI_LIVE_PANEL_X = NAVI_LIVE_PANEL_RIGHT - NAVI_LIVE_PANEL_W
TRIP_REPORT_PANEL_X = NAVI_LIVE_PANEL_X
TRIP_REPORT_PANEL_Y = 1.0
TRIP_REPORT_PANEL_W = NAVI_LIVE_PANEL_W
TRIP_REPORT_PANEL_H = DESIGN_HEIGHT - 2.0
TRIP_REPORT_CACHE_REFRESH_SECONDS = 1.0
CAMERA_BACKGROUND_X = 0.0
CAMERA_BACKGROUND_Y = 0.0
CAMERA_BACKGROUND_W = NAVI_LIVE_PANEL_X
CAMERA_BACKGROUND_H = DESIGN_HEIGHT
CAMERA_BACKGROUND_ALPHA = 220
CAMERA_BACKGROUND_VIGNETTE_ALPHA = 32
CLUSTER_ALERT_SIZE_SMALL = 1
CLUSTER_ALERT_SIZE_MID = 2
CLUSTER_ALERT_SIZE_FULL = 3
CLUSTER_ALERT_TEXT_COLORS = {
    0: (255, 255, 255, 255),
    1: (255, 174, 82, 255),
    2: (255, 82, 96, 255),
}
CLUSTER_ALERT_TEXT_STROKE = (0, 0, 0, 255)
CLUSTER_SYNTHETIC_ALERT_TEXT_KEYS = {
    "clusterSelfdriveStartup": ("openpilot_unavailable", "waiting_to_start"),
    "clusterSelfdriveTimeout": ("take_control_immediately", "system_unresponsive"),
    "clusterSelfdriveReboot": ("system_unresponsive", "reboot_device"),
}
# 0.5 is a centered cover crop; values toward 1.0 retain more of the road
# camera's lower edge. Keep this shared with the projected overlay transform.
CAMERA_BACKGROUND_VERTICAL_BIAS = 0.75
CAMERA_OVERLAY_VEHICLE_ROAD_HEIGHT_M = 0.025
CAMERA_OVERLAY_MIN_DEPTH_M = 0.5
CAMERA_OVERLAY_FRAME_MIN_SIZE_PX = 24.0
CAMERA_OVERLAY_FRAME_MAX_WIDTH_RATIO = 0.22
CAMERA_OVERLAY_FRAME_MAX_HEIGHT_RATIO = 0.45
CAMERA_OVERLAY_FRAME_MAX_ASPECT = 2.4
CAMERA_OVERLAY_FRAME_EDGE_PAD_PX = 3.0
CAMERA_OVERLAY_FRAME_ROUND_SEGMENTS = 4
CAMERA_OVERLAY_DEFAULT_CAMERA = DEVICE_CAMERAS["tici", "ar0231"].fcam
CAMERA_OVERLAY_DEFAULT_HEIGHT_M = 1.22
CAMERA_OVERLAY_Z_OFFSET_DEFAULT_M = 0.00
CAMERA_OVERLAY_Z_OFFSET_MIN_M = -0.80
CAMERA_OVERLAY_Z_OFFSET_MAX_M = 0.40
CAMERA_OVERLAY_Z_OFFSET_STEP_M = 0.05
CAMERA_OVERLAY_TUNE_PANEL_Y = ROUTE_CONTROL_PANEL_Y - 38.0
CAMERA_OVERLAY_PITCH_OFFSET_DEFAULT_DEG = 0.0
CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG = -3.0
CAMERA_OVERLAY_PITCH_OFFSET_MAX_DEG = 3.0
CAMERA_OVERLAY_PITCH_OFFSET_STEP_DEG = 0.2
CAMERA_OVERLAY_PITCH_TUNE_PANEL_Y = ROUTE_CONTROL_PANEL_Y - 72.0
CORNER_RADAR_COIN_HEIGHT_M = 0.10
CORNER_RADAR_COIN_SLICES = 28
CORNER_RADAR_COIN_FILL = (52, 210, 230)
CORNER_RADAR_COIN_SIDE = (20, 116, 132)
CORNER_RADAR_COIN_RING = (185, 248, 255)
CORNER_RADAR_COIN_LEAD_ONE_FILL = (255, 170, 36)
CORNER_RADAR_COIN_LEAD_ONE_SIDE = (138, 82, 18)
CORNER_RADAR_COIN_LEAD_ONE_RING = (255, 190, 54)
CORNER_RADAR_COIN_LEAD_TWO_FILL = (255, 218, 64)
CORNER_RADAR_COIN_LEAD_TWO_SIDE = (142, 96, 16)
CORNER_RADAR_COIN_LEAD_TWO_RING = (255, 242, 132)
CORNER_RADAR_COIN_CUTIN_FILL = (198, 78, 238)
CORNER_RADAR_COIN_CUTIN_SIDE = (94, 34, 122)
CORNER_RADAR_COIN_CUTIN_RING = (238, 174, 255)
CORNER_RADAR_COIN_SLOWER_FILL = (54, 136, 255)
CORNER_RADAR_COIN_SLOWER_SIDE = (24, 65, 132)
CORNER_RADAR_COIN_SLOWER_RING = (146, 198, 255)
CORNER_RADAR_COIN_STOPPED_FILL = (132, 140, 148)
CORNER_RADAR_COIN_STOPPED_SIDE = (68, 74, 80)
CORNER_RADAR_COIN_STOPPED_RING = (205, 212, 218)
CORNER_RADAR_COIN_STOPPED_MAX_SPEED_KPH = 3.0
TPMS_LOW_PRESSURE_PSI = 31.0
TURN_SIGNAL_LEFT_CENTER_X = 610
TURN_SIGNAL_RIGHT_CENTER_X = 1310
TURN_SIGNAL_CENTER_Y = 72
TURN_SIGNAL_HEAD_HALF_HEIGHT = 38
TURN_SIGNAL_MID_CENTER_X = (TURN_SIGNAL_LEFT_CENTER_X + TURN_SIGNAL_RIGHT_CENTER_X) * 0.5
LANE_TURN_SIGNAL_LEFT_CENTER_X = 760
LANE_TURN_SIGNAL_RIGHT_CENTER_X = 1160
LANE_TURN_SIGNAL_CENTER_Y = 350
DRIVE_STATUS_BASE_BOX_SIZE = 46.0
DRIVE_STATUS_ROW_HEIGHT = TURN_SIGNAL_HEAD_HALF_HEIGHT * 2.0
DRIVE_STATUS_SCALE = DRIVE_STATUS_ROW_HEIGHT / DRIVE_STATUS_BASE_BOX_SIZE
GEAR_STATUS_CENTER_X = 900
GEAR_STATUS_CENTER_Y = TURN_SIGNAL_CENTER_Y
GEAR_STATUS_BOX_SIZE = DRIVE_STATUS_ROW_HEIGHT * 0.82
GEAR_STATUS_FONT_SIZE = 34.0 * DRIVE_STATUS_SCALE * 0.82
GEAR_STATUS_OUTLINE_WIDTH = 2.0 * DRIVE_STATUS_SCALE
FOLLOW_STATUS_CENTER_X = 1020
FOLLOW_STATUS_W = 160
FOLLOW_STATUS_H = 42.0 * DRIVE_STATUS_SCALE
FOLLOW_STATUS_GAP_BARS = 4
FOLLOW_GAP_ACTIVE = (103, 255, 78, 255)
FOLLOW_GAP_INACTIVE = (118, 122, 128, 150)
FOLLOW_GAP_BAR_W = 5.4
FOLLOW_GAP_BAR_H = 7.7
FOLLOW_GAP_BAR_R = 1.3
FOLLOW_GAP_BAR_SCALE = 1.75 * DRIVE_STATUS_SCALE
FOLLOW_GAP_BAR_STEP_X = 6.3
FOLLOW_GAP_ICON_ASPECT = 44.0 / 27.5
FOLLOW_GAP_ICON_H = 32.0 * DRIVE_STATUS_SCALE
FOLLOW_GAP_ICON_W = FOLLOW_GAP_ICON_H * FOLLOW_GAP_ICON_ASPECT
TOP_CRUISE_CENTER_X = FOLLOW_STATUS_CENTER_X + 202
TOP_CRUISE_FONT_SIZE = 27.0 * DRIVE_STATUS_SCALE
TOP_CRUISE_UNIT_FONT_SIZE = TOP_CRUISE_FONT_SIZE
WIFI_STATUS_CENTER_X = 160
WIFI_STATUS_ICON_SIZE = 48.0
# Keep the badge to the right of the clock, clear of its text and stroke.
EGPU_STATUS_CENTER_X = 474.0
EGPU_STATUS_W = 76.0
EGPU_STATUS_H = 34.0
EGPU_STATUS_FONT_SIZE = 19.0
NAV_STATUS_CENTER_X = WIFI_STATUS_CENTER_X - 22.0
NAV_STATUS_CENTER_Y = 99.0
NAV_STATUS_FONT_SIZE = 22.0
LFA_STATUS_CENTER_X = 70
LFA_STATUS_ICON_SIZE = 34.0 * DRIVE_STATUS_SCALE
LFA_LANE_ICON_WIDTH_SCALE = 2.0
LFA_LANE_ICON_TOP_OFFSET = 3.0
TOP_STATUS_CENTER_Y = 55.0
TOP_CLOCK_CENTER_X = 315.0
TOP_ICON_SIZE = 34.0 * DRIVE_STATUS_SCALE
DRIVE_STATUS_BOX_RADIUS = 8.0 * DRIVE_STATUS_SCALE
SPEED_HUD_SCALE = 0.8
SPEED_PANEL_X = 18
SPEED_PANEL_Y = 295
SPEED_PANEL_W = 380 * SPEED_HUD_SCALE
SPEED_PANEL_H = 142 * SPEED_HUD_SCALE
SPEED_VALUE_CENTER_X = SPEED_PANEL_X + 84 * SPEED_HUD_SCALE
SPEED_VALUE_CENTER_Y = SPEED_PANEL_Y + 70 * SPEED_HUD_SCALE
SPEED_VALUE_FONT_SIZE = 112 * SPEED_HUD_SCALE
CRUISE_SPEED_CENTER_Y = SPEED_PANEL_Y + 55 * SPEED_HUD_SCALE
CRUISE_SET_SPEED_CENTER_X = SPEED_PANEL_X + 289 * SPEED_HUD_SCALE
CRUISE_SET_SPEED_FONT_SIZE = 58 * SPEED_HUD_SCALE
CRUISE_OVERRIDE_SPEED_CENTER_X = SPEED_PANEL_X + 392 * SPEED_HUD_SCALE
CRUISE_OVERRIDE_SPEED_CENTER_Y = SPEED_PANEL_Y + 30 * SPEED_HUD_SCALE
CRUISE_OVERRIDE_LABEL_CENTER_Y = SPEED_PANEL_Y - 4 * SPEED_HUD_SCALE
CRUISE_OVERRIDE_LABEL_FONT_SIZE = 25 * SPEED_HUD_SCALE
CRUISE_OVERRIDE_SPEED_FONT_SIZE = 52 * SPEED_HUD_SCALE
# Center the gap number in the hollow of speed_bg.png's right curl.
SPEED_GAP_CENTER_X = SPEED_PANEL_X + SPEED_PANEL_W * 0.92
SPEED_GAP_CENTER_Y = SPEED_PANEL_Y + SPEED_PANEL_H * 0.835
SPEED_GAP_FONT_SIZE = 28.0
SPEED_GEAR_CENTER_X = SPEED_PANEL_X + SPEED_PANEL_W + 34.0
SPEED_GEAR_W = 45.0
SPEED_GEAR_H = 58.0
SPEED_GEAR_CENTER_Y = SPEED_PANEL_Y + SPEED_PANEL_H - SPEED_GEAR_H * 0.5
SPEED_GEAR_FONT_SIZE = 48.0
# Model lane-line confidence (not accuracy) hugs the centre ego car, one label against each of its
# sides at the car's own height. A small opaque box sized from the measured text keeps it readable
# over the lane lines that run past the car there.
# Default HUD only: briefly keep an inner detected lane line drawn through a short
# confidence dip (below the parser's 0.4 visibility threshold) while its current
# geometry stays valid and inside the road edges. Expires by monotonic render
# time; missing/stale confidence, invalid geometry or a mode change drop it at once.
LANE_CONFIDENCE_HOLD_MAX_S = 0.3
LANE_CONFIDENCE_HOLD_PROBABILITY_MIN = 0.4
LANE_CONFIDENCE_FONT_SIZE = 28.0
LANE_CONFIDENCE_BOX_PAD_X = 4.0
LANE_CONFIDENCE_BOX_H = LANE_CONFIDENCE_FONT_SIZE + 4.0
# 2026-10-29 18:12 (보노보노 "외부hud 차선% 가운대 내차 옆에 딱붙여서 나오게만들어"): the two labels left the turn-signal
# arrows (x 760 / 1160, below the gear badge) and now sit against the centre ego-car sprite, left % on the car's left,
# right % on its right. The sprite is 3D-projected, but the chase camera holds it still: measured x 495..628 (133 px
# wide), y 318..452 in the unshifted design frame, unmoved by lane offset or steering angle (out/anchor_base.json,
# 11 render cases, within 0.5 px). Only the panel / driving-view shift moves it, so the draw call passes the sprite's
# current centre x (_ego_car_center_design_x) instead of the arrow offset it used before.
# 18:18 ("차모양 양옆으로 차선확률 더 바짝 붙이라고") the gap went 6.0 -> 2.0 px, measured against the sprite's outline with a
# faint-edge threshold: its drawn pixels end at x 495 / 628, and the badge box edge lands on 492 / 631 with 0 overlap for the
# narrowest and widest text in both panel layouts (out/gap_sweep.json). 1.0 and 0.0 still measure 0 overlap at 1:1, so 2.0 is a
# chosen floor, not a collision: what the box would touch first is the car's own outline pixel, 2 px further in.
LANE_CONFIDENCE_EGO_CAR_HALF_W = 67.0
LANE_CONFIDENCE_EGO_CAR_GAP_X = 2.0
LANE_CONFIDENCE_CENTER_Y = 385.0
LANE_CONFIDENCE_BOX_COLOR = (8, 10, 12, 255)
LANE_CONFIDENCE_UNKNOWN_COLOR = (170, 180, 188, 255)
# A compact EV telltale fits between three-digit vehicle and cruise-set speeds.
SPEED_EV_CENTER_X = 181.0
SPEED_EV_CENTER_Y = SPEED_VALUE_CENTER_Y
SPEED_EV_FONT_SIZE = 28.0
SPEED_MODEL_TRAFFIC_CENTER_X = SPEED_VALUE_CENTER_X - 38.0
SPEED_MODEL_TRAFFIC_CENTER_Y = SPEED_PANEL_Y - 9.0
SPEED_MODEL_TRAFFIC_ICON_SIZE = 34.0
SPEED_DRIVING_MODE_GAP = 5.0
SPEED_DRIVING_MODE_BASE_CENTER_OFFSET_X = SPEED_DRIVING_MODE_GAP + 36.0
SPEED_DRIVING_MODE_CENTER_X = (
    SPEED_MODEL_TRAFFIC_CENTER_X
    + SPEED_MODEL_TRAFFIC_ICON_SIZE * 0.5
    + SPEED_DRIVING_MODE_BASE_CENTER_OFFSET_X
)
SPEED_DRIVING_MODE_CENTER_Y = SPEED_MODEL_TRAFFIC_CENTER_Y
SPEED_DRIVING_MODE_FONT_SIZE = 27.0
SPEED_DRIVING_MODE_STYLES = {
    1: ("driving_mode_eco", (0, 255, 0, 200)),
    2: ("driving_mode_safe", (255, 165, 0, 200)),
    3: ("driving_mode_normal", (255, 255, 255, 200)),
    4: ("driving_mode_sport", (255, 0, 0, 200)),
}
SIDE_GAUGE_TOP = 88
SIDE_GAUGE_BOTTOM = 186
SIDE_GAUGE_LOWER_TOP = 248
SIDE_GAUGE_LOWER_BOTTOM = 346
SIDE_GAUGE_WIDTH = 62
SIDE_GAUGE_VALUE_Y = 64
SIDE_GAUGE_LABEL_OFFSET = 15
SIDE_GAUGE_LEFT_CENTER_X = 968
SIDE_GAUGE_COLUMN_GAP = 78
SIDE_GAUGE_OUTLINE = (240, 244, 248, 190)
SPEED_LIMIT_SIGN_CENTER_X = 80
SPEED_LIMIT_SIGN_CENTER_Y = 160
SPEED_LIMIT_SIGN_RADIUS = 42.0
SPEED_LIMIT_SIGN_RING_WIDTH = 6.0
CRUISE_OVERRIDE_APPLY_COLOR = (184, 112, 24)
SYSTEM_PANEL_X = 1416
SYSTEM_PANEL_Y = 118
SYSTEM_PANEL_W = 476
NAVI_LIVE_PANEL_Y = 1
NAVI_LIVE_PANEL_H = DESIGN_HEIGHT - 2
NAVI_WORLD_VIEW_SHIFT_X = (DESIGN_WIDTH - NAVI_LIVE_PANEL_X) * 0.5
# Preserve each right-side widget's distance from the driving-view edge when
# expanding the 1124 px driving region to the full 1920 px display.
FULLSCREEN_3D_SIDE_WIDGET_OFFSET_X = DESIGN_WIDTH - CAMERA_BACKGROUND_W
FULLSCREEN_3D_CLOCK_CENTER_X = DESIGN_WIDTH * 0.5
FULLSCREEN_3D_TRAFFIC_PANEL_RIGHT = DESIGN_WIDTH - 28.0
NAVI_MAP_BACKGROUND = (0, 0, 0, 255)
TPMS_STATUS_CENTER_X = NAVI_LIVE_PANEL_X - 62.0
TPMS_STATUS_VALUE_CENTER_Y = 429.5
TPMS_STATUS_CAR_CENTER_Y = 429.5
TPMS_STATUS_COLUMN_OFFSET = 29.5
TPMS_STATUS_ROW_OFFSET = 24.0
TPMS_STATUS_CAR_W = 38.0
TPMS_STATUS_CAR_H = 72.0
TPMS_STATUS_WHEEL_W = 32.0
TPMS_STATUS_WHEEL_H = 30.0
TPMS_STATUS_ICON_W = 104.0
TPMS_STATUS_ICON_H = 78.0
FULLSCREEN_3D_CORE_USAGE_RIGHT_X = (
    TPMS_STATUS_CENTER_X
    + FULLSCREEN_3D_SIDE_WIDGET_OFFSET_X
    - TPMS_STATUS_ICON_W * 0.5
    - 18.0
)
TPMS_STATUS_FONT_SIZE = 21.0
# SR / SAD line above the TPMS car (보노보노 2026-10-24): right edge = car icon right edge,
# so it never crosses into the right panel; baseline just above the front wheel badges.
LAT_VALUES_RIGHT_X = TPMS_STATUS_CENTER_X + TPMS_STATUS_ICON_W * 0.5 - 2.0
# 2026-10-30 05:07 (보노보노 "외부uhd 치우침 위에잇는3줄도 글씨크기키워") 17.0 -> 25.0 (+47 %), line step 20.0 -> 28.0 (the same
# 3 px between lines). The widest line 3 ('토크학습 100%  횡가속 8.88  마찰 8.88') grows left past the right lane-probability
# badge (widest '100%' box x 631..717, y 369..400), so line 3's bottom moved up from 4.5 px above the TPMS icon box to 2 px
# above that badge's top (render px 385 -> 366: 2 px over the badge, 26 px over the TPMS car, 29 px over line 4) and the
# three lines grow upward from there. Left on the TPMS car the ceiling was 22.0 (the badge: 8 px of air at 22.0, overlap
# from 23.0). Up here 25.0 is the ceiling, set by the right lane line: measured in render pixels in both panel layouts
# (out/sweep_lat_lift19*.json) line 3's left end stays 6 px right of the lane line's pixels at 25.0 and runs onto them at
# 25.5 (4 px) / 26.0 (70 px).
# 2026-10-30 (보노보노 18:10 / 18:24 / 18:27): the torque line became three, '학습 횡가속 2745  마찰 105' / '적용 횡가속 2500
# 마찰 130' / '토크학습 61%' (the last one only while calPerc < 100), so five lines share the room the three had: from the
# top limit of test_k9_ext_hud_sr_sad.py (TPMS car centre - 150) down to the TPMS car icon top, 111 px. Five lines at 25.0
# need about 132 px, and keeping lines 1 / 2 at 25.0 leaves about 15 px a line for the other three, so all five are
# LAT_VALUES_FONT_SIZE with an HUD_LINE_STEP step in fixed slots (the % slot just stays empty at 100 %, nothing moves); the
# bottom slot ends 2 px above the TPMS car icon top. 19.0 / 22 px: at 20.0 / 22 the outline of the % line (습 is the tallest
# glyph) touched line 4 by a row (test_k9_ext_hud_torque_lines.py); at 19.0 every line keeps an empty row.
# The new lines are narrower than the old line 3, so lines 4 / 5 sit
# beside the right lane-probability badge, far to its right, instead of above it (render px in the commit report).
LAT_VALUES_FONT_SIZE = 19.0
LAT_VALUES_COLOR = (214, 224, 231, 255)
# 2026-10-26 (k9-hud-ld-lt, 보노보노 2026-10-25 20:28~20:53): five Korean lines (since 18:04 lines 1..3 above the TPMS car,
# line 3 where SR / SAD was (4a44e564), lines 4 / 5 left of the car, see below):
#   1 '조향비 12.90  지연설정 0.20초'  2 '지연학습 63%  0.24초'  3 '토크학습 61%  횡가속 3.16  마찰 0.09'   (_draw_lat_values)
#   4 '치우침 → 12cm'  5 '좌 1.87m   우 1.63m'                                          (_draw_lane_values)
HUD_LINE_STEP = LAT_VALUES_FONT_SIZE + 3.0
# 2026-10-26 18:04 (보노보노 "외부hud에 차선치우침.현재차선좌우간격 아래 tpms보여주는 차모양 왼쪽으로 옮겨놔"): lines 4 / 5 moved
# to the left of the TPMS car (right edge LANE_VALUES_GAP_X left of the icon incl. the left pressure badges, the two lines
# centred on the car's height); lines 1..3 moved down so that line 3 sits right above the car (where line 5 was).
LAT_VALUES_SLOT_Y = tuple(TPMS_STATUS_CAR_CENTER_Y - TPMS_STATUS_ICON_H * 0.5 - 2.0 - LAT_VALUES_FONT_SIZE * 0.5
                          - HUD_LINE_STEP * (4 - i) for i in range(5))
LAT_VALUES_LINE_Y = LAT_VALUES_SLOT_Y[:3]       # lines 1..3: 조향비 / 지연학습 / 학습
LAT_VALUES_CENTER_Y = LAT_VALUES_LINE_Y[2]
TORQUE_LINE_Y = LAT_VALUES_SLOT_Y[3:]           # 적용 / 토크학습 % (fixed slots below line 3)
LANE_VALUES_GAP_X = 8.0
LANE_VALUES_RIGHT_X = TPMS_STATUS_CENTER_X - TPMS_STATUS_ICON_W * 0.5 - LANE_VALUES_GAP_X
# 2026-10-29 07:08 (보노보노 "차선좌우 글씨작던데 더키워") 17.0 -> 22.0, then 18:12 ("차선치우침 / 좌.우 글씨크기 더크게만들어")
# 22.0 -> 32.0 (+45 %, near double the original 17.0): the lane-probability % badges that used to cap this at 22.0 moved onto
# the centre ego car, which freed the room to their right. 32.0 is the new ceiling, set by the dark background these two lines
# need rather than by a collision: at 33.0 the widest line reaches the right lane line's pixels and
# test_k9_ext_hud_lane.py::test_lane_line_in_its_own_box_above_sr_sad fails its "nothing bright under the line" budget.
# At 32.0, measured in render pixels with the widest "100%" badges in both panel layouts (out/sweep3_wt.json,
# out/overlap_wt.json): 0 overlap with lines 1..3 / the % badges / the TPMS car, 10 px of air to lines 1..3 and 17 px to the
# screen bottom. Lines 1..3 keep LAT_VALUES_FONT_SIZE / HUD_LINE_STEP.
LANE_VALUES_FONT_SIZE = 32.0
LANE_VALUES_LINE_STEP = LANE_VALUES_FONT_SIZE + 4.0
LANE_VALUES_LINE_Y = (TPMS_STATUS_CAR_CENTER_Y - LANE_VALUES_LINE_STEP * 0.5,
                      TPMS_STATUS_CAR_CENTER_Y + LANE_VALUES_LINE_STEP * 0.5)                  # lines 4, 5
LANE_VALUES_CENTER_Y = TPMS_STATUS_CAR_CENTER_Y
LANE_OFFSET_COLOR = (255, 214, 92, 255)      # 치우침 (mock out/hud_ld_lt/mock_preview.png)
LANE_GAP_COLOR = (120, 220, 255, 255)        # 좌 / 우 차선
NAVI_LIVE_ICON_X = NAVI_LIVE_PANEL_X + 72
NAVI_LIVE_ICON_Y = NAVI_LIVE_PANEL_Y + 99
NAVI_LIVE_ICON_SIZE = 78.0
NAVI_LIVE_CONTENT_X = NAVI_LIVE_PANEL_X + 136
NAVI_LIVE_CONTENT_W = NAVI_LIVE_PANEL_W - 158
NAVI_LIVE_NEXT_Y = NAVI_LIVE_PANEL_Y + 184
NAVI_LIVE_LANE_Y = NAVI_LIVE_PANEL_Y + 258
NAVI_LIVE_FOOTER_Y = NAVI_LIVE_PANEL_Y + 328
NAVI_LIVE_GUIDANCE_MEDIA_SCALE = 1.2
NAVI_TURN_LEFT_TYPES = frozenset((7, 12, 16, 17, 44, 75, 76, 102, 105, 112, 115, 118, 1000, 1002, 1006))
NAVI_TURN_RIGHT_TYPES = frozenset((6, 13, 19, 43, 73, 74, 101, 104, 111, 114, 117, 123, 124, 1001, 1003, 1007))
NAVI_TURN_ROUNDABOUT_TYPES = frozenset(range(131, 143))
NAVI_TRAFFIC_PANEL_RIGHT = TURN_SIGNAL_RIGHT_CENTER_X + 96
NAVI_TRAFFIC_PANEL_H = 90
NAVI_TRAFFIC_PANEL_Y = TURN_SIGNAL_CENTER_Y + TURN_SIGNAL_HEAD_HALF_HEIGHT + 10
NAVI_TRAFFIC_SIGNAL_SIZE = 58.0
NAVI_TRAFFIC_SIGNAL_GAP = 10.0
NAVI_TRAFFIC_TEXT_GAP = 14.0
NAVI_TRAFFIC_PANEL_PAD_X = 16.0
NAVI_TRAFFIC_BG_LIGHT = (62, 68, 81)
NAVI_TRAFFIC_BG_DARK = (18, 21, 27)
NAVI_TRAFFIC_BG_OUTLINE = (238, 241, 246)
NAVI_TRAFFIC_OFF_LIGHT = (40, 43, 51)
NAVI_TRAFFIC_OFF_DARK = (36, 39, 47)
NAVI_TRAFFIC_OFF_ARROW = (58, 61, 70)
NAVI_TRAFFIC_RED = (255, 111, 111)
NAVI_TRAFFIC_GREEN = (103, 255, 78)
NAVI_GUIDANCE_IMAGE_X = SYSTEM_PANEL_X + 24
NAVI_GUIDANCE_IMAGE_Y = SYSTEM_PANEL_Y + 210
NAVI_GUIDANCE_IMAGE_W = SYSTEM_PANEL_W - 48
NAVI_GUIDANCE_IMAGE_H = 270
NAVI_MODE_LEFT_W = 520.0
NAVI_MODE_MAP_X = NAVI_MODE_LEFT_W
NAVI_MODE_MAP_W = 880.0
NAVI_MODE_RIGHT_X = NAVI_MODE_MAP_X + NAVI_MODE_MAP_W
NAVI_MODE_RIGHT_W = DESIGN_WIDTH - NAVI_MODE_RIGHT_X
KOREAN_FONT_BASE_SIZE = 32
SYSTEM_STATS_REFRESH_SECONDS = 1.0
TEXT_MEASURE_CACHE_LIMIT = 1024
STROKED_TEXT_TEXTURE_CACHE_LIMIT = 384
STROKED_TEXT_TEXTURE_PADDING_PX = 2
TRIANGLE_STRIP_POINT_CACHE_LIMIT = 256
DEBUG_PLOT_MAX_SAMPLES = 360
DEBUG_PLOT_SAMPLE_SECONDS = 0.05
DEBUG_PLOT_MARGIN = 18.0
DEBUG_PLOT_FULL_X = 500.0
DEBUG_PLOT_FULL_Y = DEBUG_PLOT_MARGIN
DEBUG_PLOT_FULL_W = 1392.0
DEBUG_PLOT_FULL_H = DESIGN_HEIGHT - DEBUG_PLOT_MARGIN * 2.0
DEBUG_PLOT_RIGHT_X = NAVI_LIVE_PANEL_X
DEBUG_PLOT_RIGHT_Y = NAVI_LIVE_PANEL_Y
DEBUG_PLOT_RIGHT_W = NAVI_LIVE_PANEL_W
DEBUG_PLOT_RIGHT_H = NAVI_LIVE_PANEL_H
GIT_STATUS_MARGIN = 2
GIT_STATUS_BOTTOM_MARGIN = 12
GIT_STATUS_DOT_RADIUS = 7
GIT_STATUS_DOT_TEXT_GAP = 6
GIT_STATUS_MAX_TEXT_W = 610
FPS_STATUS_MARGIN = 4
FPS_STATUS_DOT_RADIUS = 7
FPS_STATUS_DOT_TEXT_GAP = 6
FPS_STATUS_MAX_TEXT_W = 220
CLUSTER_CORE_USAGE_MARGIN = 2
CLUSTER_CORE_USAGE_MAX_TEXT_W = 760
RADAR_LABEL_DISTANCE_FONT_SIZE = 16
RADAR_LABEL_SPEED_FONT_SIZE = 14
VEHICLE_BADGE_DISTANCE_FONT_SIZE = 17
VEHICLE_BADGE_SPEED_FONT_SIZE = 15
LEAD_ONE_DISTANCE_FONT_SIZE = 24
LEAD_ONE_SPEED_FONT_SIZE = 22
RADAR_LABEL_ANCHOR_Z_OFFSET_M = 0.30
VEHICLE_BADGE_ANCHOR_Z_OFFSET_M = 0.32
WORLD_LABEL_NEAR_M = 18.0
WORLD_LABEL_FAR_M = 180.0
WORLD_LABEL_MIN_SCALE = 0.56
WORLD_LABEL_TEXTURE_CACHE_LIMIT = 512
WORLD_LABEL_TEXTURE_SIZE_GRID = 0.25
WORLD_LABEL_TEXTURE_PADDING_PX = 4
VEHICLE_MATERIAL_COLORS: dict[str, tuple[int, int, int, int]] = {
    "body": (156, 166, 172, 255),
    "wheel": (18, 20, 22, 255),
    "besi_roda": (36, 38, 42, 255),
    "light": (184, 222, 255, 255),
    "stop_light": (226, 34, 28, 255),
    "riting": (255, 146, 20, 255),
    "Material": (136, 142, 148, 255),
    "Material.002": (68, 72, 78, 255),
    "Material.003": (18, 20, 22, 255),
    "Material.004": (18, 20, 22, 255),
    "Material.005": (18, 20, 22, 255),
    "Material.006": (18, 20, 22, 255),
    "other_body": (128, 136, 146, 255),  # EV6 HUD patch v4: generic fallback car (gunmetal)
    "cabin": (24, 27, 31, 255),
}
DEFAULT_VEHICLE_MATERIAL_COLOR = (142, 150, 156, 255)
VEHICLE_OTHER_TINT = (172, 178, 184)  # EV6 HUD patch v3: fallback grey
CLEAN_SPEED_OVER_RED_KPH = 10.0  # EV6 HUD patch v6: speed turns amber above the limit, red 10+ above
CLEAN_GHOST_TINT = (112, 118, 126)  # EV6 HUD patch v6: low-confidence side vehicles (dimmed)
CLEAN_CUTIN_HOLD_S = 1.5  # EV6 HUD patch v6: keep a cut-in car orange this long after the flag drops
CLEAN_CUTIN_MODEL_HOLD_S = 6.0  # ...and keep showing it with the same car model this long
CLEAN_TTC_AMBER_S = 4.0  # EV6 HUD patch v6: lead label turns amber / red while closing in
CLEAN_TTC_RED_S = 2.5
# EV6 HUD patch v8: clean planned path, see cluster_scene.clean_planned_path_strips
# The imported driving layout stays dormant; device-display sleep is not selected.
# EV6 HUD patch v10: upstream H.264 bitrate, no navigation turn card
# EV6 HUD patch v13: parked screen, see ClusterUiRenderer._ev6_draw_park_screen
# EV6 HUD patch v14: ego EV6 at real size, see cluster_scene.EV6_EGO_LENGTH_M
# EV6 HUD patch v16: parked screen polish (dark shadow, top-view car for the tyre pressures)
# EV6 HUD patch v17: parked-screen weather, see Ev6Weather
# EV6 HUD patch v19: weather falls back to the last known position
# EV6 HUD patch v21: v12 freeze watchdog removed
# EV6 HUD patch v22: signal assist chip, see ClusterUiRenderer._ev6_draw_signal_assist_chip
CLEAN_CAMERA_SHOW_M = 1000  # speed camera chip appears this far before the camera
CLEAN_SLOWDOWN_LABELS_KO = {
    "turn": "커브", "vturn": "커브", "atc": "커브", "atc2": "커브", "cam": "카메라", "section": "구간단속",
    "bump": "방지턱", "school": "어린이", "police": "경찰", "road": "도로제한", "route": "경로",
    "model": "모델", "gas": "가속", "eco": "에코", "apply": "감속", "waze": "waze",
}
VEHICLE_CUTIN_TINT = (255, 150, 30)  # EV6 HUD patch v4: cut-in vehicle paint
GROUND_DARK_RGB = (40, 43, 48)  # EV6 HUD patch v5: charcoal grey road (dark theme)
GROUND_LIGHT_RGB = (200, 205, 211)  # EV6 HUD patch v5: silver grey road (light theme)
GROUND_HALF_WIDTH_M = 160.0
GROUND_Z_M = -0.03
GROUND_ROWS_M = (-60.0, 0.0, 20.0, 40.0, 55.0, 70.0, 82.0, 92.0)
GROUND_FADE = (0.0, 0.0, 0.0, 0.18, 0.42, 0.70, 0.90, 1.0)
OTHER_VEHICLE_PAINT_RGB = (128, 136, 146)  # EV6 HUD patch v4: gunmetal grey body (assets/models/others)
SIDE_VEHICLE_MODEL_SOURCES = ("liveTracks", "cornerRadar")
SIDE_VEHICLE_MODEL_MIN_CONFIDENCE = 0.80  # below this the original small marker box is kept
SIDE_VEHICLE_MODEL_SCALE = 0.94


def vehicle_material_color(name: str) -> tuple[int, int, int, int]:
    if name == "body":
        return (238, 239, 235, 255)  # P/R EV6: Snow White Pearl
    color = VEHICLE_MATERIAL_COLORS.get(name)
    if color is not None:
        return color
    if name.startswith("rgb_") and len(name) == 10:
        try:
            return int(name[4:6], 16), int(name[6:8], 16), int(name[8:10], 16), 255
        except ValueError:
            pass
    return DEFAULT_VEHICLE_MATERIAL_COLOR
# EV6 HUD patch: simple Lambert + Blinn-Phong + fresnel shading for the 3D vehicle model.
VEHICLE_LIGHT_DIR = (-0.35, -0.45, 0.82)  # towards the light (x=right, y=forward, z=up)
VEHICLE_SHADER_VS_BODY = """
IN vec3 vertexPosition;
IN vec3 vertexNormal;
IN vec4 vertexColor;
uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 matNormal;
OUT vec3 fragPos;
OUT vec3 fragNormal;
OUT vec4 fragColor;
void main() {
    fragPos = vec3(matModel * vec4(vertexPosition, 1.0));
    fragNormal = vec3(matNormal * vec4(vertexNormal, 0.0));
    fragColor = vertexColor;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
"""
VEHICLE_SHADER_FS_BODY = """
IN vec3 fragPos;
IN vec3 fragNormal;
IN vec4 fragColor;
uniform vec4 colDiffuse;
uniform vec3 lightDir;
uniform vec3 viewPos;
uniform vec4 paintKey;
uniform vec4 paintOverride;
uniform float gloss;
uniform vec3 glossPaint;
uniform vec3 glossGlass;
uniform vec3 glossChrome;
uniform vec3 glossChrome2;
uniform vec3 glossRim;
bool glossKey(vec3 c, vec3 k) { return all(lessThan(abs(c - k), vec3(0.006))); }
vec3 glossEnv(vec3 r) {
    // studio sky over a dark floor with a bright horizon band (reflections of the K9 clear coat / chrome)
    float e = r.z;
    vec3 sky = mix(vec3(0.62, 0.68, 0.76), vec3(0.24, 0.34, 0.52), clamp(e * 1.4, 0.0, 1.0));
    vec3 c = e > 0.0 ? sky : mix(vec3(0.36, 0.35, 0.34), vec3(0.10, 0.10, 0.10), clamp(-e * 2.0, 0.0, 1.0));
    c += vec3(0.85) * exp(-pow((e - 0.05) / 0.035, 2.0));
    c += vec3(0.9) * exp(-pow((e - 0.55) / 0.05, 2.0)) * smoothstep(0.2, 0.6, abs(r.y));
    return c;
}
void main() {
    vec4 src = fragColor;
    if (paintOverride.a > 0.5 && all(lessThan(abs(src.rgb - paintKey.rgb), vec3(0.012)))) {
        src.rgb = paintOverride.rgb;  // warning colour replaces the body paint only
    }
    vec4 base = src * colDiffuse;
    vec3 n = normalize(fragNormal);
    vec3 v = normalize(viewPos - fragPos);
    if (dot(n, v) < 0.0) n = -n;
    vec3 l = normalize(lightDir);
    float diff = max(dot(n, l), 0.0);
    float fill = max(dot(n, normalize(vec3(0.6, 0.2, 0.4))), 0.0);
    vec3 h = normalize(l + v);
    float spec = pow(max(dot(n, h), 0.0), 40.0);
    float fres = pow(1.0 - max(dot(n, v), 0.0), 3.0);
    float lum = dot(base.rgb, vec3(0.299, 0.587, 0.114));
    vec3 col = base.rgb * (0.46 + 0.50 * diff + 0.12 * fill);
    col += vec3(1.0, 0.99, 0.97) * spec * (0.10 + 0.30 * lum);
    col += vec3(0.96, 0.97, 1.0) * fres * 0.10 * lum;
    if (gloss > 0.5) {
        vec3 r = reflect(-v, n);
        float ndv = max(dot(n, v), 0.0);
        float f5 = pow(1.0 - ndv, 5.0);
        vec3 c0 = src.rgb;
        float hl = pow(max(dot(n, h), 0.0), 400.0);
        if (glossKey(c0, glossPaint) || glossKey(c0, glossGlass)) {
            float f0 = glossKey(c0, glossGlass) ? 0.08 : 0.12;
            col = base.rgb * (0.30 + 0.45 * diff) + glossEnv(r) * (f0 + (1.0 - f0) * f5) * 1.15 + vec3(1.0) * hl * 0.35;
        } else if (glossKey(c0, glossChrome) || glossKey(c0, glossChrome2) || glossKey(c0, glossRim)) {
            col = mix(base.rgb * (0.5 + 0.5 * diff), base.rgb * glossEnv(r) * 1.45, 0.75) + vec3(1.0) * hl * 0.5;
        }
    }
    OUTCOLOR = vec4(min(col, vec3(1.0)), base.a);
}
"""


def vehicle_shader_sources(gl_version: int) -> tuple[str, str]:
    if gl_version in (getattr(rl, "RL_OPENGL_33", 3), getattr(rl, "RL_OPENGL_43", 4)):
        vs = "#version 330\n#define IN in\n#define OUT out\n" + VEHICLE_SHADER_VS_BODY
        fs = ("#version 330\n#define IN in\nout vec4 finalColor;\n#define OUTCOLOR finalColor\n"
              + VEHICLE_SHADER_FS_BODY)
    else:
        vs = "#define IN attribute\n#define OUT varying\n" + VEHICLE_SHADER_VS_BODY
        fs = ("#ifdef GL_ES\nprecision mediump float;\n#endif\n#define IN varying\n#define OUTCOLOR gl_FragColor\n"
              + VEHICLE_SHADER_FS_BODY)
    return vs, fs


NV12_PACK_VERTEX_SHADER = """
attribute vec3 vertexPosition;
attribute vec2 vertexTexCoord;
attribute vec4 vertexColor;

varying vec2 fragTexCoord;
varying vec4 fragColor;

uniform mat4 mvp;

void main() {
    fragTexCoord = vertexTexCoord;
    fragColor = vertexColor;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
"""
NV12_PACK_FRAGMENT_SHADER = """
#ifdef GL_ES
precision mediump float;
#endif

varying vec2 fragTexCoord;
varying vec4 fragColor;

uniform sampler2D texture0;
uniform vec2 srcSize;
uniform vec2 packedSize;
uniform int plane;
uniform int flipX;

const float Y_PAD = 0.062745;
const float UV_PAD = 0.501961;

vec3 sampleRgb(float x, float y) {
    if (flipX != 0) {
        // The portrait upload transform maps screen horizontal correction to source Y.
        y = srcSize.y - 1.0 - y;
    }
    vec2 clamped = clamp(vec2(x, y), vec2(0.0), srcSize - vec2(1.0));
    return texture2D(texture0, (clamped + vec2(0.5)) / srcSize).rgb;
}

float y601(vec3 rgb) {
    return clamp(0.062745 + 0.256788 * rgb.r + 0.504129 * rgb.g + 0.097906 * rgb.b, 0.0, 1.0);
}

float u601(vec3 rgb) {
    return clamp(0.501961 - 0.148223 * rgb.r - 0.290993 * rgb.g + 0.439216 * rgb.b, 0.0, 1.0);
}

float v601(vec3 rgb) {
    return clamp(0.501961 + 0.439216 * rgb.r - 0.367788 * rgb.g - 0.071427 * rgb.b, 0.0, 1.0);
}

vec3 sample2x2(float x, float y) {
    return (
        sampleRgb(x, y) +
        sampleRgb(x + 1.0, y) +
        sampleRgb(x, y + 1.0) +
        sampleRgb(x + 1.0, y + 1.0)
    ) * 0.25;
}

float packedY(float x, float y) {
    if (x >= srcSize.x || y >= srcSize.y) {
        return Y_PAD;
    }
    return y601(sampleRgb(x, y));
}

vec2 packedUV(float x, float y) {
    if (x >= srcSize.x || y >= srcSize.y) {
        return vec2(UV_PAD, UV_PAD);
    }
    vec3 rgb = sample2x2(x, y);
    return vec2(u601(rgb), v601(rgb));
}

void main() {
    vec2 packedCoord = min(floor(fragTexCoord * packedSize), packedSize - vec2(1.0));
    float baseX = packedCoord.x * 4.0;
    if (plane == 0) {
        float y = packedCoord.y;
        gl_FragColor = vec4(
            packedY(baseX, y),
            packedY(baseX + 1.0, y),
            packedY(baseX + 2.0, y),
            packedY(baseX + 3.0, y)
        );
    } else {
        float y = packedCoord.y * 2.0;
        vec2 left = packedUV(baseX, y);
        vec2 right = packedUV(baseX + 2.0, y);
        gl_FragColor = vec4(left.x, left.y, right.x, right.y);
    }
}
"""
NAVI_YUV420_FRAGMENT_SHADER = """
#ifdef GL_ES
precision mediump float;
#endif

varying vec2 fragTexCoord;

uniform sampler2D texture0;
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform vec2 uvScaleU;
uniform vec2 uvScaleV;

void main() {
    float y = 1.164383 * (texture2D(texture0, fragTexCoord).r - 0.062745);
    float u = texture2D(texture1, fragTexCoord * uvScaleU).r - 0.501961;
    float v = texture2D(texture2, fragTexCoord * uvScaleV).r - 0.501961;
    vec3 rgb = vec3(
        y + 1.596027 * v,
        y - 0.391762 * u - 0.812968 * v,
        y + 2.017232 * u
    );
    gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
"""
NAVI_EXTERNAL_VERTEX_SHADER = """
#version 300 es
precision mediump float;
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec4 vertexColor;
uniform mat4 mvp;
out vec2 fragTexCoord;
void main() {
    fragTexCoord = vertexTexCoord;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
"""
NAVI_EXTERNAL_FRAGMENT_SHADER = """
#version 300 es
#extension GL_OES_EGL_image_external_essl3 : enable
precision mediump float;
in vec2 fragTexCoord;
uniform samplerExternalOES texture0;
out vec4 fragColor;
void main() {
    fragColor = texture(texture0, fragTexCoord);
}
"""
NAVI_EGL_IMAGE_CACHE_LIMIT = 10


@dataclass(slots=True)
class CachedTextTexture:
    texture: object
    text_width: float
    text_height: float
    texture_width: int
    texture_height: int
    padding_px: float


StrokedTextTextureCacheKey = tuple[
    int,
    str,
    float,
    float,
    tuple[int, int, int, int],
    tuple[int, int, int, int],
    int,
]


@dataclass(frozen=True, slots=True)
class PendingStrokedTextTexture:
    font: object
    text: str
    render_size: float
    spacing: float
    fill_color: tuple[int, int, int, int]
    stroke_color: tuple[int, int, int, int]
    stroke_width: int


@dataclass(slots=True)
class CachedNaviMediaTexture:
    sequence: int
    size: tuple[int, int]
    mime: str
    texture: object
    u_texture: object | None = None
    v_texture: object | None = None
    uv_scale_u: object | None = None
    uv_scale_v: object | None = None
    hardware_token: tuple[int, int] | None = None


@dataclass(frozen=True, slots=True)
class CameraOverlayProjection:
    dest: rl.Rectangle
    source: rl.Rectangle
    video_dest: rl.Rectangle
    camera_width: float
    camera_height: float
    focal_length: float
    zoom: float
    video_tx: float
    video_ty: float
    view_from_road: tuple[tuple[float, float, float], ...]
    camera_height_m: float
    wide_camera: bool = False


@dataclass(frozen=True, slots=True)
class VehicleMetricLine:
    text: str
    x: float
    y: float
    size: float


@dataclass(frozen=True, slots=True)
class VehicleMetricLabel:
    vehicle: VehicleBox
    lines: tuple[VehicleMetricLine, ...]
    color: tuple[int, ...]
    shadow_offset: float = 0.0


@lru_cache(maxsize=256)
def _cached_rl_color(r: int, g: int, b: int, a: int) -> rl.Color:
    return rl.Color(r, g, b, a)


def rgba_key(color: tuple[int, int, int] | tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    if len(color) == 4:
        r, g, b, a = color
    else:
        r, g, b = color
        a = 255
    return int(r), int(g), int(b), int(a)


def _buffer_address(buffer: bytearray) -> int:
    """Address of a bytearray's storage (it is never resized while in use)."""
    return ctypes.addressof((ctypes.c_char * len(buffer)).from_buffer(buffer))


_LIBC = None


def _memequal(a: int, b: int, n: int) -> bool:
    """memcmp(a, b, n) == 0 (stops at the first differing byte)."""
    global _LIBC
    if _LIBC is None:
        _LIBC = ctypes.CDLL(ctypes.util.find_library("c") or None)
        _LIBC.memcmp.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
        _LIBC.memcmp.restype = ctypes.c_int
    return a != b and _LIBC.memcmp(a, b, n) == 0


def rl_color(color: tuple[int, int, int] | tuple[int, int, int, int], alpha: int | None = None) -> rl.Color:
    r, g, b, a = rgba_key(color)
    if alpha is not None:
        a = alpha
    return _cached_rl_color(int(r), int(g), int(b), int(a))


def radar_point_distance_label(point: RadarPointMarker, is_metric: bool = True) -> str:
    if point.absolute_speed_kph is not None and abs(point.absolute_speed_kph) <= RADAR_STATIC_OBJECT_SPEED_KPH:
        return ""
    return format_radar_distance(point.longitudinal_m, is_metric)


def radar_point_speed_label(point: RadarPointMarker, is_metric: bool = True) -> str:
    if point.absolute_speed_kph is None:
        return ""
    if abs(point.absolute_speed_kph) <= RADAR_STATIC_OBJECT_SPEED_KPH:
        return ""
    return f"{display_speed(point.absolute_speed_kph, is_metric):.0f} {speed_unit(is_metric)}"


def vehicle_distance_label(vehicle: VehicleBox, is_metric: bool = True) -> str:
    if (
        vehicle.absolute_speed_kph is not None
        and abs(vehicle.absolute_speed_kph) <= RADAR_STATIC_OBJECT_SPEED_KPH
        and not vehicle.primary
        and not vehicle.cut_in
    ):
        return ""
    distance = format_radar_distance(vehicle_distance_m(vehicle), is_metric)
    if vehicle.cut_in:
        return f"CUT-IN {distance}"
    if (vehicle.primary or vehicle.cut_in) and vehicle.label:
        label = vehicle.label.upper()
        if label.startswith("L1") or label.startswith("L2"):
            return distance
        return f"{vehicle.label} {distance}"
    return distance


def vehicle_distance_m(vehicle: VehicleBox) -> float:
    if vehicle.longitudinal_m is not None:
        return vehicle.longitudinal_m
    return vehicle.center.y - EGO_FORWARD_M


def vehicle_has_lead_one_metrics(vehicle: VehicleBox) -> bool:
    # primary also marks L2 and CUT-IN. Only the existing leadOne gets large
    # metrics; never infer a new lead from proximity or a raw radar point.
    return vehicle.primary and vehicle.label.upper() == "L1" and vehicle_distance_m(vehicle) > 0.0


def vehicle_speed_label(vehicle: VehicleBox, is_metric: bool = True) -> str:
    if vehicle.absolute_speed_kph is None:
        return ""
    if abs(vehicle.absolute_speed_kph) <= RADAR_STATIC_OBJECT_SPEED_KPH:
        return ""
    return f"{display_speed(vehicle.absolute_speed_kph, is_metric):.0f} {speed_unit(is_metric)}"


def radar_info_shows_vehicle(mode: int) -> bool:
    return mode in (
        CLUSTER_RADAR_INFO_VEHICLE_SPEED,
        CLUSTER_RADAR_INFO_VEHICLE_SPEED_DISTANCE,
        CLUSTER_RADAR_INFO_ALL_SPEED,
        CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
    )


def radar_info_shows_radar_points(mode: int) -> bool:
    return mode in (
        CLUSTER_RADAR_INFO_ALL_SPEED,
        CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
    )


def radar_info_shows_speed(mode: int) -> bool:
    return mode != CLUSTER_RADAR_INFO_NONE


def radar_info_shows_distance(mode: int) -> bool:
    return mode in (
        CLUSTER_RADAR_INFO_VEHICLE_SPEED_DISTANCE,
        CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
    )


def camera_overlay_vehicle_coin_colors(
    vehicle: VehicleBox,
    lead_one: bool,
    lead_two: bool,
) -> tuple[tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]]:
    if vehicle.cut_in or "CUT-IN" in vehicle.label.upper():
        return CORNER_RADAR_COIN_CUTIN_FILL, CORNER_RADAR_COIN_CUTIN_SIDE, CORNER_RADAR_COIN_CUTIN_RING
    if lead_one:
        return CORNER_RADAR_COIN_LEAD_ONE_FILL, CORNER_RADAR_COIN_LEAD_ONE_SIDE, CORNER_RADAR_COIN_LEAD_ONE_RING
    if lead_two:
        return CORNER_RADAR_COIN_LEAD_TWO_FILL, CORNER_RADAR_COIN_LEAD_TWO_SIDE, CORNER_RADAR_COIN_LEAD_TWO_RING
    if camera_overlay_vehicle_is_stopped(vehicle):
        return CORNER_RADAR_COIN_STOPPED_FILL, CORNER_RADAR_COIN_STOPPED_SIDE, CORNER_RADAR_COIN_STOPPED_RING
    if vehicle.absolute_speed_kph is not None and vehicle.absolute_speed_kph < 0.0:
        return RED, (116, 28, 32), RED
    if vehicle.relative_speed_mps is not None and vehicle.relative_speed_mps < 0.0:
        return CORNER_RADAR_COIN_SLOWER_FILL, CORNER_RADAR_COIN_SLOWER_SIDE, CORNER_RADAR_COIN_SLOWER_RING
    return CORNER_RADAR_COIN_FILL, CORNER_RADAR_COIN_SIDE, CORNER_RADAR_COIN_RING


def camera_overlay_vehicle_is_stopped(vehicle: VehicleBox) -> bool:
    return (
        vehicle.absolute_speed_kph is not None
        and abs(vehicle.absolute_speed_kph) <= CORNER_RADAR_COIN_STOPPED_MAX_SPEED_KPH
    )


def vehicle_metric_color(vehicle: VehicleBox, theme: ClusterTheme, source_color_mode: int) -> tuple[int, int, int]:
    if vehicle.cut_in:
        return AMBER
    if vehicle.primary:
        return theme.primary_vehicle
    if source_color_mode != CLUSTER_RADAR_SOURCE_COLOR_BY_SOURCE:
        return theme.world_label_text
    if vehicle_source_is_adas(vehicle.source):
        return GREEN
    if vehicle_source_is_front_radar(vehicle.source):
        return RED
    if vehicle_source_is_radar_track(vehicle.source):
        return AMBER
    if vehicle_source_is_camera(vehicle.source):
        return BLUE_SOFT
    if vehicle.source.startswith("modelV2"):
        return BLUE
    return theme.world_label_text


def vehicle_source_base(source: str) -> str:
    return source.split("+radar:", 1)[0]


def vehicle_source_is_adas(source: str) -> bool:
    base_source = vehicle_source_base(source)
    return base_source == "carState" or base_source in ("CAN 0x162", "CAN 0x1ea")


def vehicle_source_is_camera(source: str) -> bool:
    return vehicle_source_base(source).startswith("camera")


def vehicle_source_is_front_radar(source: str) -> bool:
    return vehicle_source_base(source) == "radarState"


def vehicle_source_is_radar_track(source: str) -> bool:
    return source in ("radarPoint", "liveTracks", "cornerRadar") or "+radar:" in source


def world_label_scale(distance_m: float) -> float:
    far_amount = clamp((abs(distance_m) - WORLD_LABEL_NEAR_M) / (WORLD_LABEL_FAR_M - WORLD_LABEL_NEAR_M), 0.0, 1.0)
    return 1.0 - far_amount * (1.0 - WORLD_LABEL_MIN_SCALE)


def vec3(point: Vec3) -> rl.Vector3:
    return rl.Vector3(point.x, point.y, point.z)


def rectangles_overlap(
    left: tuple[float, float, float, float],
    right: tuple[float, float, float, float],
) -> bool:
    lx, ly, lw, lh = left
    rx, ry, rw, rh = right
    return lx < rx + rw and lx + lw > rx and ly < ry + rh and ly + lh > ry


def camera_forward(camera) -> tuple[float, float, float] | None:
    dx = float(camera.target.x - camera.position.x)
    dy = float(camera.target.y - camera.position.y)
    dz = float(camera.target.z - camera.position.z)
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length <= 0.0001 or not all(math.isfinite(value) for value in (dx, dy, dz, length)):
        return None
    return dx / length, dy / length, dz / length


def camera_depth_m(point, camera) -> float | None:
    forward = camera_forward(camera)
    if forward is None:
        return None
    px = float(point.x - camera.position.x)
    py = float(point.y - camera.position.y)
    pz = float(point.z - camera.position.z)
    if not all(math.isfinite(value) for value in (px, py, pz)):
        return None
    fx, fy, fz = forward
    return px * fx + py * fy + pz * fz


def world_to_screen_label_anchor(point, camera, width: int, height: int):
    depth_m = camera_depth_m(point, camera)
    if depth_m is None or depth_m <= 0.05:
        return None
    screen = rl.get_world_to_screen_ex(point, camera, width, height)
    if not math.isfinite(screen.x) or not math.isfinite(screen.y):
        return None
    return screen


def label_rect_inside_bounds(
    rect: tuple[float, float, float, float],
    bounds: tuple[float, float, float, float],
) -> bool:
    x, y, width, height = rect
    left, top, right, bottom = bounds
    values = (x, y, width, height, left, top, right, bottom)
    if not all(math.isfinite(value) for value in values):
        return False
    return x >= left and y >= top and x + width <= right and y + height <= bottom


# EV6 HUD patch v13: parked screen (gear P). The car photo stays on the device, it is not part of the patch.
EV6_PARK_CAR_IMAGE = "/data/ev6_park_car.png"
EV6_PARK_SCREEN_OFF_FLAG = "/data/ev6_park_screen_off"
EV6_PARK_IMAGE_RETRY_S = 5.0
EV6_PARK_DARK_SHADOW_FROM = 0.72  # dark theme: drop translucent pixels below this share of the photo height (ground shadow)
EV6_PARK_WEEKDAYS_KO = ("월", "화", "수", "목", "금", "토", "일")
EV6_PARK_COLORS_LIGHT = {"bg_top": (246, 247, 249), "bg_bot": (222, 225, 230), "text": (28, 31, 36), "muted": (118, 124, 133),
                         "card": (255, 255, 255), "line": (214, 218, 224), "accent": (0, 122, 255)}
EV6_PARK_COLORS_DARK = {"bg_top": (30, 33, 38), "bg_bot": (10, 11, 13), "text": (236, 238, 241), "muted": (140, 146, 155),
                        "card": (30, 33, 38), "line": (54, 58, 65), "accent": (80, 160, 255)}

# EV6 HUD patch v15: reverse screen (gear R). Kia EV6: wheelbase 2.90 m, steer ratio 16 (opendbc CarSpecs),
# rear axle 1.44 m and rear bumper 2.34 m behind the body centre.
EV6_REVERSE_SCREEN_OFF_FLAG = "/data/ev6_reverse_screen_off"
EV6_REVERSE_CAR_IMAGE = "/data/ev6_reverse_car.png"  # optional replacement for the generated car image (same angle)
EV6_REVERSE_SPRITE_SUPERSAMPLE = 2
EV6_REVERSE_STEER_RATIO = 16.0
EV6_REVERSE_WHEELBASE_M = 2.90
# Reverse path geometry per car (노비 11/11 18:46): K9 uses its own CarParams values (opendbc KIA_K9 CarSpecs
# wheelbase 3.105 m, steerRatio 14.5), never the EV6 numbers; unknown cars keep the upstream EV6 values.
REVERSE_GEOMETRY_FALLBACK = {"KIA_K9": (3.105, 14.5)}


def reverse_geometry(car_fingerprint: str = "") -> tuple[float, float]:
    """(wheelbase_m, steer_ratio) for the reverse path: opendbc CarSpecs (= CarParams wheelbase/steerRatio)."""
    if car_fingerprint and car_fingerprint != "KIA_EV6":
        try:
            from opendbc.car.hyundai.values import CAR as _HYUNDAI_CAR
            specs = getattr(_HYUNDAI_CAR, car_fingerprint).config.specs
            return float(specs.wheelbase), float(specs.steerRatio)
        except Exception:
            if car_fingerprint in REVERSE_GEOMETRY_FALLBACK:
                return REVERSE_GEOMETRY_FALLBACK[car_fingerprint]
    return EV6_REVERSE_WHEELBASE_M, EV6_REVERSE_STEER_RATIO
EV6_REVERSE_REAR_AXLE_Y_M = -1.44
EV6_REVERSE_REAR_BUMPER_Y_M = -2.34
EV6_REVERSE_HALF_WIDTH_M = 0.95
EV6_REVERSE_PATH_LENGTH_M = 5.0
EV6_REVERSE_PATH_STEPS = 60
EV6_REVERSE_MARKS = ((1.0, (255, 59, 48)), (2.0, (255, 159, 10)), (3.0, (52, 199, 89)))
EV6_REVERSE_WARN = (255, 149, 0)

# EV6 HUD patch v17: weather on the parked screen from Open-Meteo (free, no API key). A daemon thread fetches while the
# parked screen is in use (at most every 10 min), never in the render loop; the last result is cached in /data so it
# survives restarts and garages without signal. Location: openpilot's LastGPSPosition, rounded to ~1 km.
EV6_WEATHER_OFF_FLAG = "/data/ev6_weather_off"
EV6_WEATHER_CACHE = "/data/ev6_weather_cache.json"
EV6_WEATHER_REFRESH_S = 600.0
EV6_WEATHER_RETRY_S = 120.0
EV6_WEATHER_MAX_AGE_S = 3600.0
EV6_WEATHER_IDLE_S = 900.0  # stop fetching this long after the parked screen was last shown
EV6_DUST_GRADES = (("좋음", (38, 166, 91)), ("보통", (255, 159, 10)), ("나쁨", (255, 59, 48)), ("매우나쁨", (175, 82, 222)))


def ev6_weather_kind(code: int) -> tuple[str, str]:
    # WMO weather codes -> (icon, Korean label)
    if code == 0:
        return "clear", "맑음"
    if code in (1, 2):
        return "partly", "구름조금"
    if code in (45, 48):
        return "cloudy", "안개"
    if code in (71, 73, 75, 77, 85, 86):
        return "snow", "눈"
    if 51 <= code <= 67 or 80 <= code <= 82:
        return "rain", "비"
    if code >= 95:
        return "rain", "뇌우"
    return "cloudy", "흐림"


def ev6_dust_grade(pm10: float | None, pm25: float | None) -> int | None:
    # Korean grades (Ministry of Environment): the worse of PM10 and PM2.5
    grades = []
    if pm10 is not None:
        grades.append(0 if pm10 <= 30 else 1 if pm10 <= 80 else 2 if pm10 <= 150 else 3)
    if pm25 is not None:
        grades.append(0 if pm25 <= 15 else 1 if pm25 <= 35 else 2 if pm25 <= 75 else 3)
    return max(grades) if grades else None


def ev6_weather_from_response(forecast: dict, air: dict | None) -> dict:
    current, daily = forecast.get("current", {}), forecast.get("daily", {})
    kind, label = ev6_weather_kind(int(current.get("weather_code", 3)))
    first = lambda key: (daily.get(key) or [None])[0]  # noqa: E731
    day_kind, day_label = ev6_weather_kind(int(first("weather_code") or 0))
    chance = first("precipitation_probability_max")
    # rain / snow chance only when it is raining or snowing, or forecast for today
    if kind in ("rain", "snow") and chance is not None:
        label = f"{label} {chance:.0f}%"
    elif day_kind in ("rain", "snow") and chance is not None and chance >= 30:
        label = f"오늘 {day_label} {chance:.0f}%"  # the icon still shows the current sky
    air_now = (air or {}).get("current", {})
    return {"kind": kind, "label": label, "temp": float(current.get("temperature_2m", 0.0)), "max": first("temperature_2m_max"),
            "min": first("temperature_2m_min"), "dust": ev6_dust_grade(air_now.get("pm10"), air_now.get("pm2_5"))}


class Ev6Weather:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data: dict | None = None
        self._data_time = 0.0  # unix time of the last successful fetch
        self._wanted_until = 0.0
        self._thread = None
        self._loaded_cache = False

    def snapshot(self) -> dict | None:
        if os.path.exists(EV6_WEATHER_OFF_FLAG):
            return None
        self._wanted_until = time.monotonic() + EV6_WEATHER_IDLE_S
        if not self._loaded_cache:
            self._loaded_cache = True
            self._load_cache()
        if self._thread is None and not os.environ.get("EV6_WEATHER_NO_FETCH"):
            self._thread = threading.Thread(target=self._run, name="ev6-weather", daemon=True)
            self._thread.start()
        with self._lock:
            if self._data is None or time.time() - self._data_time > EV6_WEATHER_MAX_AGE_S:  # noqa: TID251 - persisted cache spans reboots
                return None
            return self._data

    def set(self, data: dict, data_time: float | None = None) -> None:
        with self._lock:
            self._data, self._data_time = data, time.time() if data_time is None else data_time  # noqa: TID251 - persisted UTC time

    def _load_cache(self) -> None:
        try:
            with open(EV6_WEATHER_CACHE, encoding="utf-8") as f:
                cached = json.load(f)
            if cached.get("pos"):
                self._last_pos = tuple(cached["pos"])  # EV6 HUD patch v19
            self.set(cached["data"], float(cached["time"]))
        except Exception:
            pass

    def _position(self) -> tuple[float, float] | None:
        # LastGPSPosition lives in /dev/shm: it is cleared at boot and only set once GPS has a fix, so in a garage
        # right after starting the car there is none. The car has not moved since the last fix, so fall back to the
        # last known position (kept in the weather cache across restarts). EV6 HUD patch v19
        try:
            from openpilot.common.params import Params
            for params in (Params("/dev/shm/params"), Params()):
                raw = params.get("LastGPSPosition")
                if raw:
                    pos = json.loads(raw)
                    self._last_pos = (round(float(pos["latitude"]), 2), round(float(pos["longitude"]), 2))
                    break
        except Exception:
            pass
        return getattr(self, "_last_pos", None)

    @staticmethod
    def _get_json(url: str) -> dict:
        import urllib.request
        with urllib.request.urlopen(url, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))

    def _run(self) -> None:
        next_fetch = 0.0
        while True:
            time.sleep(5.0)
            now = time.monotonic()
            if now > self._wanted_until or now < next_fetch or os.path.exists(EV6_WEATHER_OFF_FLAG):
                continue
            position = self._position()
            if position is None:
                if now >= getattr(self, "_no_pos_log_t", 0.0):
                    self._no_pos_log_t = now + 600.0
                    print("EV6 weather: no GPS position yet", flush=True)
                next_fetch = now + 30.0
                continue
            lat, lon = position
            try:
                forecast = self._get_json(
                    "https://api.open-meteo.com/v1/forecast" +
                    f"?latitude={lat}&longitude={lon}&timezone=auto&forecast_days=1" +
                    "&current=temperature_2m,weather_code" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max")
                try:
                    air = self._get_json("https://air-quality-api.open-meteo.com/v1/air-quality" +
                                         f"?latitude={lat}&longitude={lon}&current=pm10,pm2_5")
                except Exception:
                    air = None
                data = ev6_weather_from_response(forecast, air)
                self.set(data)
                try:
                    with open(EV6_WEATHER_CACHE, "w", encoding="utf-8") as f:
                        json.dump({"time": time.time(), "pos": [lat, lon], "data": data}, f)  # noqa: TID251 - persisted UTC time
                except OSError:
                    pass
                next_fetch = now + EV6_WEATHER_REFRESH_S
            except Exception as exc:
                print(f"EV6 weather: fetch failed: {exc}", flush=True)
                next_fetch = now + EV6_WEATHER_RETRY_S


EV6_WEATHER = Ev6Weather()

K9_LOOK_OLD = types.SimpleNamespace(
    lead_tint=K9_TURZX_LEAD, other_tint=None, road=K9_TURZX_ROAD, kerb=K9_TURZX_CHROME, kerb_w=0.08, kerb_a=0.55,
    haze=K9_TURZX_LANE, haze_a=26, adj=(200, 214, 236), arrow=K9_TURZX_PATH_ARROW, arrow_a=190,
    l_lead_tint=K9L_CHAMPAGNE, l_other_tint=(130, 150, 186), l_road=K9L_ROAD, l_kerb=K9L_CHAMPAGNE, l_kerb_a=0.6,
    l_adj=(176, 196, 224), l_adj_a=0.55, l_arrow=(236, 246, 255), l_arrow_a=150, l_fog_a=150, l_tag=K9L_CHAMPAGNE)
K9_LOOK_NAVDY = types.SimpleNamespace(
    lead_tint=K9_NAVDY_LEAD_TINT, other_tint=K9_NAVDY_OTHER_TINT, road=K9_NAVDY_ROAD, kerb=K9_NAVDY_LINE, kerb_w=0.06,
    kerb_a=0.3, haze=K9_NAVDY_LINE, haze_a=14, adj=K9_NAVDY_LINE, arrow=K9_NAVDY_LINE, arrow_a=70,
    l_lead_tint=K9_NAVDY_LEAD_TINT, l_other_tint=K9_NAVDY_OTHER_TINT, l_road=(*K9_NAVDY_ROAD, 235), l_kerb=K9_NAVDY_LINE,
    l_kerb_a=0.3, l_adj=K9_NAVDY_LINE, l_adj_a=0.65, l_arrow=K9_NAVDY_LINE, l_arrow_a=70, l_fog_a=110, l_tag=K9_NAVDY_LINE)


class ClusterUiRenderer:
    # Class defaults also keep lightweight object.__new__ render probes on the
    # original Korean/metric presentation without running the GPU-heavy init.
    language = CLUSTER_LANGUAGE_KO
    is_metric = True
    _other_vehicle_models = ()
    _other_vehicle_names = ()
    _other_vehicle_paint = ()
    _vehicle_shaders = ()
    _cutin_hold = None
    panel_layout = CLUSTER_PANEL_LAYOUT_DRIVING_LEFT

    def __init__(
        self,
        width: int = DESIGN_WIDTH,
        height: int = DESIGN_HEIGHT,
        title: str = "carrotpilot cluster",
        target_fps: int = 0,
        theme_mode: str = "auto",
        screen_mode: int = 0,
        panel_layout: int = CLUSTER_PANEL_LAYOUT_DRIVING_LEFT,
        language: str = CLUSTER_LANGUAGE_KO,
        is_metric: bool = True,
    ) -> None:
        self.width = width
        self.height = height
        self.title = title
        self.target_fps = target_fps
        self.theme_mode = normalize_cluster_theme_mode(theme_mode)
        self.screen_mode = normalize_cluster_screen_mode(screen_mode)
        self.panel_layout = normalize_cluster_panel_layout(panel_layout)
        self.language = normalize_cluster_language(language, default=CLUSTER_LANGUAGE_KO)
        self.is_metric = bool(is_metric)
        self._theme = current_cluster_theme(self.theme_mode)
        self.hidden = False
        self._nav_model_texture = None
        self._nav_model_checked = 0.
        self._nav_model_mtime = 0
        self._nav_model_fresh = False
        self._window_open = False
        self._font = None
        self._owns_font = False
        self._korean_font = None
        self._owns_korean_font = False
        self._capture_target = None
        self._trip_report_target = None
        self._trip_report_cache_key: tuple[object, ...] | None = None
        self._trip_report_cache_valid = False
        self._trip_report_cache_visible = False
        self._trip_report_cache_next_refresh = 0.0
        self._portrait_upload_target = None
        self._portrait_upload_target_size: tuple[int, int] | None = None
        self._nv12_pack_y_target = None
        self._nv12_pack_y_size: tuple[int, int] | None = None
        self._nv12_pack_uv_target = None
        self._nv12_pack_uv_size: tuple[int, int] | None = None
        self._nv12_pack_full_target = None
        self._nv12_pack_full_size: tuple[int, int] | None = None
        self._nv12_pack_shader = None
        self._nv12_pack_shader_locations: dict[str, int] = {}
        self._direct_nv12_readback = None
        self._direct_nv12_readback_checked = False
        self._direct_nv12_readback_disabled = False
        # meter_improve: JPEG USB path (render_to_rgba_frame) - two reused readback buffers (TICI) or the previous
        # raylib image (PC), so a frame can be compared with the previous one without a copy
        self._rgba_frame_ring: list[bytearray] | None = None
        self._rgba_frame_ring_index = 0
        self._rgba_frame_prev: tuple[int, tuple[int, int]] | None = None
        self._rgba_frame_prev_image = None
        self._rgba_diff_hint: int | None = None
        self._nv12_dmabuf_pool = None
        self._nv12_dmabuf_pool_checked = False
        self._nv12_dmabuf_pool_disabled = False
        self._vehicle_model = None
        self._vehicle_model_load_attempted = False
        self._ego_car_texture = None
        self._park_vehicle_model = None
        self._park_k9_model = None
        self._park_vehicle_models_loaded = False
        self._other_vehicle_models: list[object] = []
        self._other_vehicle_names: list[str] = []
        self._park_model_texture = None
        self._park_model_key = None
        self._ev6_reverse_sprite = None
        self._ev6_reverse_sprite_key = None
        self._ev6_park_textures = None
        self._k9_reverse_layers = None  # (shadow texture, front wheel texture) for the K9 R image
        self._ev6_park_retry_t = 0.0
        self._cutin_hold: list[float] | None = None  # EV6 HUD patch v6: [colour until, x, long_m, model idx, model until]
        self._other_vehicle_paint: list[tuple[object, int] | None] = []
        self._vehicle_shaders: list[tuple[object, int]] = []
        self._scene_cache_key: tuple[object, ...] | None = None
        self._scene_cache: ClusterScene | None = None
        self._speed_bg_texture = None
        self._traffic_red_texture = None
        self._traffic_green_texture = None
        self._follow_vehicle_texture = None
        self._lfa_texture = None
        self._lfa_active_texture = None
        self._lfa_lane_texture = None
        self._wifi_texture = None
        self._tpms_car_texture = None
        self._navi_guidance_texture = None
        self._navi_guidance_hash = ""
        self._navi_guidance_size: tuple[int, int] | None = None
        self._navi_media_textures: dict[str, CachedNaviMediaTexture] = {}
        self._navi_yuv_shader = None
        self._navi_yuv_shader_locations: dict[str, int] = {}
        self._navi_external_shader = None
        self._navi_egl_images: OrderedDict[tuple[int, int], object] = OrderedDict()
        self._route_video_texture = None
        self._route_video_size: tuple[int, int] | None = None
        self._route_video_frame_id: str | None = None
        self._live_road_camera = None
        self._live_road_camera_failed = False
        self._signal_display_reader = SignalDisplayReader()
        self._brake_display_reader = BrakeDisplayReader()
        self._camera_overlay_wide = False
        self._left_turn_signal_started_at: float | None = None
        self._right_turn_signal_started_at: float | None = None
        self._hazard_signal_started_at: float | None = None
        self._lane_highlight_side: str | None = None
        self._lane_highlight_started_at: float | None = None
        self._lane_confidence_last_visible_at: dict[str, float | None] = {"left": None, "right": None}
        self._lane_confidence_held_indices: frozenset[int] = frozenset()
        self._road_edge_last_visible_at: dict[str, float | None] = {"left": None, "right": None}
        self._road_edge_held_sides: frozenset[str] = frozenset()
        self._triangle_strip_point_cache: OrderedDict[
            tuple[int, int],
            tuple[tuple[Vec3, ...], tuple[Vec3, ...], object, int],
        ] = OrderedDict()
        self._camera_overlay_strip_points = None
        self._camera_overlay_strip_point_capacity = 0
        self._camera_overlay_strip_pair_visibility = bytearray()
        self._raw_draw_triangle_strip_2d = getattr(getattr(rl, "rl", None), "DrawTriangleStrip", None)
        self._world_label_texture_cache: OrderedDict[
            tuple[int, str, float, float, tuple[int, int, int, int]],
            CachedTextTexture,
        ] = OrderedDict()
        self._world_label_texture_cache_enabled = os.environ.get("CLUSTER_WORLD_LABEL_TEXTURE_CACHE", "0") == "1"
        self._stroked_text_texture_cache: OrderedDict[StrokedTextTextureCacheKey, CachedTextTexture] = OrderedDict()
        self._pending_stroked_text_textures: OrderedDict[
            StrokedTextTextureCacheKey,
            PendingStrokedTextTexture,
        ] = OrderedDict()
        self._stroked_text_texture_cache_enabled = os.environ.get("CLUSTER_STROKED_TEXT_TEXTURE_CACHE", "1") != "0"
        self._raw_draw_text_ex = getattr(getattr(rl, "rl", None), "DrawTextEx", None)
        self._raw_stroked_text_enabled = (
            os.environ.get("CLUSTER_RAW_STROKED_TEXT", "1") != "0"
            and self._raw_draw_text_ex is not None
        )
        self._text_measure_cache: dict[tuple[int, str, float, float], tuple[float, float]] = {}
        self._system_stats = SystemStatsSampler(SYSTEM_STATS_REFRESH_SECONDS)
        self._debug_plot_mode_prev = -1
        self._debug_plot_size = 0
        self._debug_plot_index = -1
        self._debug_plot_values = [[0.0] * DEBUG_PLOT_MAX_SAMPLES for _ in range(3)]
        self._debug_plot_min = -2.0
        self._debug_plot_max = 2.0
        self._debug_plot_last_sample_time: float | None = None
        self.camera_overlay_z_offset_m = CAMERA_OVERLAY_Z_OFFSET_DEFAULT_M
        self.camera_overlay_pitch_offset_deg = CAMERA_OVERLAY_PITCH_OFFSET_DEFAULT_DEG
        self.route_camera_tuning_visible = os.environ.get("CLUSTER_ROUTE_CAMERA_TUNING") == "1"
        self.profile_enabled = os.environ.get("CLUSTER_PROFILE_RENDER") == "1"
        self._profile_samples: list[tuple[str, float]] = []

    def set_profile_enabled(self, enabled: bool) -> None:
        self.profile_enabled = enabled

    def set_theme_mode(self, theme_mode: str) -> None:
        self.theme_mode = normalize_cluster_theme_mode(theme_mode)
        self._theme = current_cluster_theme(self.theme_mode)
        self._invalidate_trip_report_cache()

    def set_screen_mode(self, screen_mode: int) -> None:
        self.screen_mode = normalize_cluster_screen_mode(screen_mode)
        self._invalidate_trip_report_cache()

    def set_panel_layout(self, panel_layout: int) -> None:
        self.panel_layout = normalize_cluster_panel_layout(panel_layout)
        self._invalidate_trip_report_cache()

    # K9ExtHud=1: the right information panel shows the taxi meter. Off (the
    # default, K9ExtHud -1/0) leaves every draw call exactly as before.
    taxi_meter_enabled = False
    k9_hud_style = K9_HUD_STYLE_CARD   # ClusterHudK9Style (0 cards / 1 one scene), K9 D screen only
    _taxi_meter_panel: C1MeterPanel | None = None
    _taxi_meter_season = 0   # K9MeterSeason (0 auto / 1 봄 / 2 여름 / 3 가을 / 4 겨울)

    def set_taxi_meter_enabled(self, enabled: bool) -> None:
        was_enabled = self.taxi_meter_enabled
        self.taxi_meter_enabled = bool(enabled)
        if self.taxi_meter_enabled and self._taxi_meter_panel is None:
            self._taxi_meter_panel = C1MeterPanel()  # fresh meter (process start / first 1), C1 look
            self._taxi_meter_panel.set_season_setting(self._taxi_meter_season)
        elif self.taxi_meter_enabled != was_enabled and self._taxi_meter_panel is not None:
            # K9ExtHud non-1 -> 1 always starts the meter over; 1 -> non-1 drops the count at once
            self._taxi_meter_panel.restart()
        self._invalidate_trip_report_cache()

    def feed_taxi_meter_speed_samples(self, samples) -> None:
        """Live carState samples [(t_s, vEgo_mps), ...] for the taxi meter (K9ExtHud=1 only)."""
        if self.taxi_meter_enabled and self._taxi_meter_panel is not None:
            self._taxi_meter_panel.feed_speed_samples(samples)

    def set_taxi_meter_season(self, value) -> None:
        """K9MeterSeason (read only by the HUD): 0 auto (month) / 1 spring / 2 summer / 3 autumn / 4 winter."""
        from cluster_taxi_c1 import normalize_meter_season
        self._taxi_meter_season = normalize_meter_season(value)
        if self._taxi_meter_panel is not None:
            self._taxi_meter_panel.set_season_setting(self._taxi_meter_season)

    def feed_taxi_meter_occupant(self, present, t_s=None) -> None:
        """Latest passenger-seat occupant flag (CAN 0x500 bus0 bits 2-3) for the C1 meter (K9ExtHud=1 only)."""
        if self.taxi_meter_enabled and self._taxi_meter_panel is not None:
            self._taxi_meter_panel.feed_occupant(present, t_s)

    def taxi_meter_command(self, cmd: str) -> None:
        """Meter remote command (K9MeterCmd: start / pause / settle / empty) for the C1 meter (K9ExtHud=1 only)."""
        if self.taxi_meter_enabled and self._taxi_meter_panel is not None:
            self._taxi_meter_panel.command(cmd)

    def taxi_meter_state(self) -> dict | None:
        """K9MeterState for the remote app (None while the meter is off)."""
        if self.taxi_meter_enabled and self._taxi_meter_panel is not None:
            return self._taxi_meter_panel.meter_status()
        return None

    def taxi_meter_toggle(self) -> None:
        """Screen toggle of the C1 meter (always wins over the occupant sensor)."""
        if self.taxi_meter_enabled and self._taxi_meter_panel is not None:
            self._taxi_meter_panel.toggle()

    def _carrot_wheel_hidden(self, state: ClusterUiState) -> bool:
        """K9ExtHud=1 with the C1 meter on screen: the clam is the only steering display (no carrot wheel)."""
        return self.taxi_meter_enabled and self._taxi_meter_panel_active(self._effective_screen_mode(state))

    def _taxi_meter_panel_active(self, screen_mode: int) -> bool:
        return self.taxi_meter_enabled and self._taxi_meter_panel is not None and screen_mode not in (
            CLUSTER_SCREEN_MODE_NAVI,
            CLUSTER_SCREEN_MODE_DEBUG_GRAPH,
            CLUSTER_SCREEN_MODE_FULLSCREEN_3D,
        )

    def _prepare_taxi_meter_cache(self, state: ClusterUiState) -> None:
        """Outside the frame target: meter update + static layer cache."""
        if not self.taxi_meter_enabled or self._taxi_meter_panel is None:
            return
        self._taxi_meter_panel.update(state)
        self._taxi_meter_panel.prepare_static_layer(self, rl)

    def _draw_taxi_meter_panel(self) -> None:
        self._taxi_meter_panel.draw(self, rl, self._information_panel_x(NAVI_LIVE_PANEL_X), NAVI_LIVE_PANEL_Y)

    def set_display_preferences(self, language: str, is_metric: bool) -> None:
        self.language = normalize_cluster_language(language, default=CLUSTER_LANGUAGE_KO)
        self.is_metric = bool(is_metric)
        self._invalidate_trip_report_cache()

    def _invalidate_trip_report_cache(self) -> None:
        self._trip_report_cache_valid = False
        self._trip_report_cache_next_refresh = 0.0

    def _text(self, key: str) -> str:
        return cluster_text(self.language, key)

    def _panel_swap_active(self) -> bool:
        if self.panel_layout != CLUSTER_PANEL_LAYOUT_DRIVING_RIGHT:
            return False
        return getattr(self, "screen_mode", CLUSTER_SCREEN_MODE_DEFAULT) not in (
            CLUSTER_SCREEN_MODE_DEBUG_GRAPH,
            CLUSTER_SCREEN_MODE_NAVI,
            CLUSTER_SCREEN_MODE_NAV_MODEL,
        )

    def _driving_panel_offset_design_x(self) -> float:
        return NAVI_LIVE_PANEL_W if self._panel_swap_active() else 0.0

    def _information_panel_offset_design_x(self) -> float:
        return -NAVI_LIVE_PANEL_X if self._panel_swap_active() else 0.0

    def _information_panel_x(self, x: float) -> float:
        return x + self._information_panel_offset_design_x()

    def _driving_hud_offset_design_x(self, screen_mode: int) -> float:
        if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
            return 0.0
        return self._driving_panel_offset_design_x()

    @staticmethod
    def _tpms_offset_design_x(screen_mode: int) -> float:
        return FULLSCREEN_3D_SIDE_WIDGET_OFFSET_X if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D else 0.0

    def _side_gauge_offset_design_x(self, screen_mode: int) -> float:
        if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
            return FULLSCREEN_3D_SIDE_WIDGET_OFFSET_X
        return 0.0

    @staticmethod
    def _center_clock_x(screen_mode: int) -> float:
        return FULLSCREEN_3D_CLOCK_CENTER_X if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D else TOP_CLOCK_CENTER_X

    def _traffic_panel_right(self, screen_mode: int) -> float:
        if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
            return FULLSCREEN_3D_TRAFFIC_PANEL_RIGHT
        right = NAVI_TRAFFIC_PANEL_RIGHT
        if self._panel_swap_active():
            right -= NAVI_WORLD_VIEW_SHIFT_X
        return right

    def _core_usage_right_x(self, screen_mode: int) -> float:
        if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
            return FULLSCREEN_3D_CORE_USAGE_RIGHT_X
        return DESIGN_WIDTH + self._information_panel_offset_design_x()

    def set_target_fps(self, target_fps: int) -> None:
        self.target_fps = max(0, int(target_fps))
        if self._window_open:
            profile_stage = self._profile_start()
            rl.set_target_fps(self.target_fps)
            self._profile_add("renderer.set_target_fps", profile_stage)

    def _current_theme(self) -> ClusterTheme:
        self._theme = current_cluster_theme(self.theme_mode)
        return self._theme

    def clear_profile_samples(self) -> None:
        self._profile_samples.clear()

    def direct_nv12_readback_available(self) -> bool:
        if self._direct_nv12_readback_disabled:
            return False
        if not self._direct_nv12_readback_checked:
            self._direct_nv12_readback_checked = True
            try:
                self._direct_nv12_readback = create_tici_direct_readback()
            except DirectNv12ReadbackError:
                self._direct_nv12_readback_disabled = True
        return self._direct_nv12_readback is not None

    def nv12_dmabuf_output_available(self) -> bool:
        if self._nv12_dmabuf_pool_disabled:
            return False
        if not self._nv12_dmabuf_pool_checked:
            self._nv12_dmabuf_pool_checked = True
            try:
                self._nv12_dmabuf_pool = create_tici_nv12_dmabuf_pool()
            except DirectNv12DmabufError:
                self._nv12_dmabuf_pool_disabled = True
        return self._nv12_dmabuf_pool is not None

    def async_nv12_readback_available(self) -> bool:
        if not self.direct_nv12_readback_available():
            return False
        return bool(self._direct_nv12_readback.async_supported)

    def async_nv12_readback_can_enqueue(self) -> bool:
        readback = self._direct_nv12_readback
        return readback is not None and readback.async_can_enqueue()

    def async_nv12_readback_ready(self) -> bool:
        readback = self._direct_nv12_readback
        return readback is not None and readback.async_ready()

    def copy_async_nv12_readback(self, destination_address: int, destination_size: int) -> bool:
        readback = self._direct_nv12_readback
        if readback is None:
            raise DirectNv12ReadbackError("TICI GLES asynchronous NV12 readback is not available")
        profile_stage = self._profile_start()
        copied = readback.copy_ready(destination_address, destination_size)
        self._profile_add("render_to_nv12.readback_pbo_copy", profile_stage)
        return copied

    def disable_async_nv12_readback(self) -> None:
        if self._direct_nv12_readback is not None:
            self._direct_nv12_readback.disable_async()

    def disable_direct_nv12_readback(self) -> None:
        if self._direct_nv12_readback is not None:
            self._direct_nv12_readback.close()
        self._direct_nv12_readback = None
        self._direct_nv12_readback_disabled = True

    def disable_nv12_dmabuf_output(self) -> None:
        self.release_nv12_dmabuf_output()
        self._nv12_dmabuf_pool_disabled = True

    def release_nv12_dmabuf_output(self) -> None:
        if self._nv12_dmabuf_pool is not None:
            self._nv12_dmabuf_pool.close()
        self._nv12_dmabuf_pool = None
        self._nv12_dmabuf_pool_checked = False

    def profile_samples(self) -> list[tuple[str, float]]:
        return self._profile_samples

    def _profile_start(self) -> float:
        return time.perf_counter() if self.profile_enabled else 0.0

    def _profile_add(self, name: str, start_time: float) -> None:
        if self.profile_enabled:
            self._profile_samples.append((name, (time.perf_counter() - start_time) * 1000.0))

    def _profile_add_elapsed(self, name: str, elapsed_ms: float) -> None:
        if self.profile_enabled:
            self._profile_samples.append((name, elapsed_ms))

    def open(self, hidden: bool = False) -> None:
        if self._window_open:
            return
        profile_total = self._profile_start()
        self.hidden = hidden
        rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
        flags = 0
        if hidden:
            flags |= rl.ConfigFlags.FLAG_WINDOW_HIDDEN
        if flags:
            rl.set_config_flags(flags)
        profile_stage = self._profile_start()
        rl.init_window(self.width, self.height, self.title)
        # Own the context before font/model setup can fail or be interrupted.
        self._window_open = rl.is_window_ready()
        if not self._window_open:
            raise RuntimeError("HUD graphics window initialization failed")
        self._profile_add("renderer.open.init_window", profile_stage)
        if self.target_fps > 0:
            profile_stage = self._profile_start()
            rl.set_target_fps(self.target_fps)
            self._profile_add("renderer.open.set_target_fps", profile_stage)
        profile_stage = self._profile_start()
        self._font = self._load_font()
        self._korean_font = self._load_korean_font()
        self._profile_add("renderer.open.load_font", profile_stage)
        profile_stage = self._profile_start()
        self._load_vehicle_model()
        self._profile_add("renderer.open.load_vehicle_model", profile_stage)
        profile_stage = self._profile_start()
        self._load_follow_vehicle_texture()
        self._profile_add("renderer.open.load_follow_vehicle_texture", profile_stage)
        profile_stage = self._profile_start()
        self._load_drive_status_textures()
        self._profile_add("renderer.open.load_drive_status_textures", profile_stage)
        self._window_open = True
        self._profile_add("renderer.open.total", profile_total)

    def close(self) -> None:
        try:
            self._close_resources()
        finally:
            if self._window_open:
                try:
                    rl.close_window()
                finally:
                    self._window_open = False

    def _close_resources(self) -> None:
        if self._nav_model_texture is not None:
            rl.unload_texture(self._nav_model_texture)
            self._nav_model_texture = None
        self._system_stats.close()
        self._release_rgba_frames()
        if not self._window_open:
            return
        self._close_park_textures()
        if self._direct_nv12_readback is not None:
            self._direct_nv12_readback.close()
            self._direct_nv12_readback = None
            self._direct_nv12_readback_checked = False
        self.release_nv12_dmabuf_output()
        if self._capture_target is not None:
            rl.unload_render_texture(self._capture_target)
            self._capture_target = None
        if self._taxi_meter_panel is not None:
            self._taxi_meter_panel.close(rl)
        if self._trip_report_target is not None:
            rl.unload_render_texture(self._trip_report_target)
            self._trip_report_target = None
            self._trip_report_cache_key = None
            self._trip_report_cache_valid = False
            self._trip_report_cache_visible = False
            self._trip_report_cache_next_refresh = 0.0
        if self._portrait_upload_target is not None:
            rl.unload_render_texture(self._portrait_upload_target)
            self._portrait_upload_target = None
            self._portrait_upload_target_size = None
        if self._nv12_pack_y_target is not None:
            rl.unload_render_texture(self._nv12_pack_y_target)
            self._nv12_pack_y_target = None
            self._nv12_pack_y_size = None
        if self._nv12_pack_uv_target is not None:
            rl.unload_render_texture(self._nv12_pack_uv_target)
            self._nv12_pack_uv_target = None
            self._nv12_pack_uv_size = None
        if self._nv12_pack_full_target is not None:
            rl.unload_render_texture(self._nv12_pack_full_target)
            self._nv12_pack_full_target = None
            self._nv12_pack_full_size = None
        if self._nv12_pack_shader is not None:
            rl.unload_shader(self._nv12_pack_shader)
            self._nv12_pack_shader = None
            self._nv12_pack_shader_locations = {}
        for cached_text in self._world_label_texture_cache.values():
            rl.unload_texture(cached_text.texture)
        self._world_label_texture_cache.clear()
        for cached_text in self._stroked_text_texture_cache.values():
            rl.unload_texture(cached_text.texture)
        self._stroked_text_texture_cache.clear()
        self._pending_stroked_text_textures.clear()
        if self._route_video_texture is not None:
            rl.unload_texture(self._route_video_texture)
            self._route_video_texture = None
        self._close_live_road_camera()
        if self._speed_bg_texture is not None:
            rl.unload_texture(self._speed_bg_texture)
            self._speed_bg_texture = None
        if self._traffic_red_texture is not None:
            rl.unload_texture(self._traffic_red_texture)
            self._traffic_red_texture = None
        if self._traffic_green_texture is not None:
            rl.unload_texture(self._traffic_green_texture)
            self._traffic_green_texture = None
        if self._follow_vehicle_texture is not None:
            rl.unload_texture(self._follow_vehicle_texture)
            self._follow_vehicle_texture = None
        if self._lfa_texture is not None:
            rl.unload_texture(self._lfa_texture)
            self._lfa_texture = None
        if self._lfa_active_texture is not None:
            rl.unload_texture(self._lfa_active_texture)
            self._lfa_active_texture = None
        if self._lfa_lane_texture is not None:
            rl.unload_texture(self._lfa_lane_texture)
            self._lfa_lane_texture = None
        if self._wifi_texture is not None:
            rl.unload_texture(self._wifi_texture)
            self._wifi_texture = None
        if self._tpms_car_texture is not None:
            rl.unload_texture(self._tpms_car_texture)
            self._tpms_car_texture = None
        if getattr(self, "_ego_car_texture", None) is not None:
            rl.unload_texture(self._ego_car_texture)
            self._ego_car_texture = None
        if self._navi_guidance_texture is not None:
            rl.unload_texture(self._navi_guidance_texture)
            self._navi_guidance_texture = None
            self._navi_guidance_hash = ""
            self._navi_guidance_size = None
        for cached_media in self._navi_media_textures.values():
            self._unload_navi_media_texture(cached_media)
        self._navi_media_textures.clear()
        if self._navi_egl_images:
            from openpilot.system.ui.lib.egl import destroy_egl_image

            for egl_image in self._navi_egl_images.values():
                destroy_egl_image(egl_image)
            self._navi_egl_images.clear()
        if self._navi_external_shader is not None:
            rl.unload_shader(self._navi_external_shader)
            self._navi_external_shader = None
        if self._navi_yuv_shader is not None:
            rl.unload_shader(self._navi_yuv_shader)
            self._navi_yuv_shader = None
            self._navi_yuv_shader_locations = {}
        if self._owns_font and self._font is not None:
            rl.unload_font(self._font)
        if self._owns_korean_font and self._korean_font is not None:
            rl.unload_font(self._korean_font)
        self._k9l_unload()
        self._k9_navdy_unload()
        self._font = None
        self._owns_font = False
        self._korean_font = None
        self._owns_korean_font = False
        if self._vehicle_model is not None:
            rl.unload_model(self._vehicle_model)
            self._vehicle_model = None
        if self._park_vehicle_model is not None:
            rl.unload_model(self._park_vehicle_model)
            self._park_vehicle_model = None
        if getattr(self, "_park_k9_model", None) is not None:
            rl.unload_model(self._park_k9_model)
            self._park_k9_model = None
        self._park_vehicle_models_loaded = False
        for other_model in self._other_vehicle_models:
            rl.unload_model(other_model)
        self._other_vehicle_models = []
        self._other_vehicle_names = []
        self._other_vehicle_paint = []
        self._vehicle_shaders = []
        self._cutin_hold = None
        self._vehicle_model_load_attempted = False
        self._scene_cache_key = None
        self._scene_cache = None
        self._camera_overlay_strip_points = None
        self._camera_overlay_strip_point_capacity = 0
        self._camera_overlay_strip_pair_visibility = bytearray()
        self._route_video_size = None
        self._route_video_frame_id = None

    def should_close(self) -> bool:
        return bool(self._window_open and rl.window_should_close())

    def render_frame(self, state: ClusterUiState) -> None:
        self.open()
        self._prepare_taxi_meter_cache(state)
        self._prepare_trip_report_cache(state)
        profile_stage = self._profile_start()
        rl.begin_drawing()
        self._profile_add("render_frame.begin_drawing", profile_stage)
        profile_stage = self._profile_start()
        self.render(state)
        self._profile_add("render_frame.render", profile_stage)
        profile_stage = self._profile_start()
        rl.end_drawing()
        self._profile_add("render_frame.end_drawing", profile_stage)
        self._flush_pending_stroked_text_textures()

    def render_route_replay_frame(
        self,
        state: ClusterUiState,
        playback_s: float,
        duration_s: float,
        corner_lateral_offset_m: float,
        paused: bool = False,
    ) -> None:
        self.open()
        self._prepare_taxi_meter_cache(state)
        self._prepare_trip_report_cache(state)
        profile_stage = self._profile_start()
        rl.begin_drawing()
        self._profile_add("render_route_frame.begin_drawing", profile_stage)
        try:
            profile_stage = self._profile_start()
            self.render(state)
            self._profile_add("render_route_frame.render", profile_stage)
            profile_stage = self._profile_start()
            self._draw_route_replay_controls(
                playback_s,
                duration_s,
                corner_lateral_offset_m,
                paused,
                self.route_camera_tuning_visible
                and cluster_camera_view_is_road_camera(state.camera_view_mode),
            )
            self._profile_add("render_route_frame.controls", profile_stage)
        finally:
            profile_stage = self._profile_start()
            rl.end_drawing()
            self._profile_add("render_route_frame.end_drawing", profile_stage)
            self._flush_pending_stroked_text_textures()

    def route_replay_control_input(
        self,
        playback_s: float,
        duration_s: float,
        corner_lateral_offset_m: float,
    ) -> tuple[float | None, float, bool]:
        if not self._window_open or duration_s <= 0.0:
            return None, corner_lateral_offset_m, False

        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        mouse = rl.get_mouse_position()
        mx = float(mouse.x) / max(0.001, sx)
        my = float(mouse.y) / max(0.001, sy)
        control_active = self._camera_overlay_tuning_input(mx, my) if self.route_camera_tuning_visible else False
        if not rl.is_mouse_button_down(rl.MOUSE_BUTTON_LEFT):
            return None, corner_lateral_offset_m, control_active

        seek_rect = rl.Rectangle(ROUTE_CONTROL_BAR_X, ROUTE_CONTROL_SEEK_Y - 8.0, ROUTE_CONTROL_BAR_W, 16.0)
        if self._point_in_rect(mx, my, seek_rect):
            ratio = clamp((mx - ROUTE_CONTROL_BAR_X) / max(1.0, ROUTE_CONTROL_BAR_W), 0.0, 1.0)
            return ratio * duration_s, corner_lateral_offset_m, True
        return None, corner_lateral_offset_m, control_active

    def _camera_overlay_tuning_input(self, mx: float, my: float) -> bool:
        left_key = getattr(rl, "KEY_LEFT_BRACKET", 91)
        right_key = getattr(rl, "KEY_RIGHT_BRACKET", 93)
        pitch_down_key = getattr(rl, "KEY_SEMICOLON", 59)
        pitch_up_key = getattr(rl, "KEY_APOSTROPHE", 39)
        reset_key = getattr(rl, "KEY_ZERO", 48)
        changed = False
        if rl.is_key_pressed(left_key):
            self.camera_overlay_z_offset_m -= CAMERA_OVERLAY_Z_OFFSET_STEP_M
            changed = True
        if rl.is_key_pressed(right_key):
            self.camera_overlay_z_offset_m += CAMERA_OVERLAY_Z_OFFSET_STEP_M
            changed = True
        if rl.is_key_pressed(pitch_down_key):
            self.camera_overlay_pitch_offset_deg -= CAMERA_OVERLAY_PITCH_OFFSET_STEP_DEG
            changed = True
        if rl.is_key_pressed(pitch_up_key):
            self.camera_overlay_pitch_offset_deg += CAMERA_OVERLAY_PITCH_OFFSET_STEP_DEG
            changed = True
        if rl.is_key_pressed(reset_key):
            self.camera_overlay_z_offset_m = CAMERA_OVERLAY_Z_OFFSET_DEFAULT_M
            self.camera_overlay_pitch_offset_deg = CAMERA_OVERLAY_PITCH_OFFSET_DEFAULT_DEG
            changed = True

        z_tune_rect = rl.Rectangle(ROUTE_CONTROL_BAR_X, CAMERA_OVERLAY_TUNE_PANEL_Y - 8.0, ROUTE_CONTROL_BAR_W, 16.0)
        pitch_tune_rect = rl.Rectangle(ROUTE_CONTROL_BAR_X, CAMERA_OVERLAY_PITCH_TUNE_PANEL_Y - 8.0, ROUTE_CONTROL_BAR_W, 16.0)
        mouse_z_tuning = rl.is_mouse_button_down(rl.MOUSE_BUTTON_LEFT) and self._point_in_rect(mx, my, z_tune_rect)
        mouse_pitch_tuning = rl.is_mouse_button_down(rl.MOUSE_BUTTON_LEFT) and self._point_in_rect(mx, my, pitch_tune_rect)
        if mouse_z_tuning:
            ratio = clamp((mx - ROUTE_CONTROL_BAR_X) / max(1.0, ROUTE_CONTROL_BAR_W), 0.0, 1.0)
            self.camera_overlay_z_offset_m = (
                CAMERA_OVERLAY_Z_OFFSET_MIN_M
                + ratio * (CAMERA_OVERLAY_Z_OFFSET_MAX_M - CAMERA_OVERLAY_Z_OFFSET_MIN_M)
            )
            changed = True
        if mouse_pitch_tuning:
            ratio = clamp((mx - ROUTE_CONTROL_BAR_X) / max(1.0, ROUTE_CONTROL_BAR_W), 0.0, 1.0)
            self.camera_overlay_pitch_offset_deg = (
                CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG
                + ratio * (CAMERA_OVERLAY_PITCH_OFFSET_MAX_DEG - CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG)
            )
            changed = True

        if changed:
            self.camera_overlay_z_offset_m = clamp(
                self.camera_overlay_z_offset_m,
                CAMERA_OVERLAY_Z_OFFSET_MIN_M,
                CAMERA_OVERLAY_Z_OFFSET_MAX_M,
            )
            self.camera_overlay_pitch_offset_deg = clamp(
                self.camera_overlay_pitch_offset_deg,
                CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG,
                CAMERA_OVERLAY_PITCH_OFFSET_MAX_DEG,
            )
        return changed or mouse_z_tuning or mouse_pitch_tuning

    def route_replay_mouse_down(self) -> bool:
        if not self._window_open:
            return False
        return bool(rl.is_mouse_button_down(rl.MOUSE_BUTTON_LEFT))

    @staticmethod
    def _point_in_rect(x: float, y: float, rect: "rl.Rectangle") -> bool:
        return rect.x <= x <= rect.x + rect.width and rect.y <= y <= rect.y + rect.height

    def render(self, state: ClusterUiState, signal_lights: tuple[bool, bool] | None = None) -> None:
        """Draw one frame into the currently active raylib render target."""
        # Indices only: the incoming state is not modified, so radar/object
        # decisions, sprites and the HUD see the original lane visibility.
        self._lane_confidence_held_indices = self._lane_confidence_hold_indices(state)
        self._road_edge_held_sides = self._road_edge_hold_sides(state)
        k9_road = self._k9_turzx_active(state)
        if not k9_road:
            self._k9_road_hold = None  # back in D later: start fresh, nothing held from before
        alert_slot = {}
        if self._ev6_park_screen_active(state):  # EV6 HUD patch v13: parked screen replaces the road view in P
            self._ev6_draw_park_screen(state)
        elif self._ev6_reverse_screen_active(state):
            self._ev6_draw_reverse_screen(state)
            if ego_model_name(str(getattr(state, "car_fingerprint", "") or "")) == "k9":
                alert_slot = {"center": K9_REVERSE_ALERT_CENTER, "max_w": K9_REVERSE_ALERT_MAX_W}
        elif k9_road:
            state = self._k9_hold_state(state)  # 11/13 01:59 screen-only hold / fade of lane lines and cars
            if signal_lights is None:
                signal_lights = self._turn_signal_lights(state)
            profile_stage = self._profile_start()
            self._k9_turzx_draw_hud(state, signal_lights)
            self._profile_add("render.hud", profile_stage)
            profile_stage = self._profile_start()
            from openpilot.common.indicator_display import draw as draw_indicator
            # inside the middle panel under the speed box (was x 530 = over the left panel)
            # 22:41: off the km/h line (scene) / the lane pill (cards); see K9C_IND_Y / K9L_IND_Y
            draw_indicator(int(getattr(self, "_k9_cx", K9C_CX) - 230.0), int(self.k9_indicator_y()), 460,
                           self._korean_font or self._font, 24)
            self._k9_turzx_draw_alert(getattr(state, "alert", None))
            self._profile_add("render.alert", profile_stage)
            return
        else:
            if signal_lights is None:
                signal_lights = self._turn_signal_lights(state)
            profile_stage = self._profile_start()
            if self.screen_mode in (CLUSTER_SCREEN_MODE_DEBUG_GRAPH, CLUSTER_SCREEN_MODE_NAVI):
                self._clear_world()
            else:
                self._render_world(state, signal_lights)
            self._profile_add("render.world", profile_stage)
            profile_stage = self._profile_start()
            self._draw_hud(state, signal_lights)
            self._profile_add("render.hud", profile_stage)
        profile_stage = self._profile_start()
        from openpilot.common.indicator_display import draw as draw_indicator
        draw_indicator(530, 78, 460, self._korean_font or self._font, 24)
        self._draw_alert_overlay(getattr(state, "alert", None), **alert_slot)
        self._profile_add("render.alert", profile_stage)

    def _draw_nav_model_map(self):
        from openpilot.selfdrive.navigation.preview import PREVIEW_PATH, preview_fresh
        # Mode 7 keeps the normal driving view/HUD on the left. The map uses
        # only the existing right information panel, including in 3D views.
        rl.draw_rectangle(NAVI_LIVE_PANEL_X, 0, NAVI_LIVE_PANEL_W, DESIGN_HEIGHT, rl.BLACK)
        center_x = NAVI_LIVE_PANEL_X + NAVI_LIVE_PANEL_W / 2
        now = time.monotonic()
        if now >= self._nav_model_checked:
            self._nav_model_checked = now + .5
            self._nav_model_fresh = preview_fresh()
            if self._nav_model_fresh:
                try:
                    mtime = PREVIEW_PATH.stat().st_mtime_ns
                    if mtime != self._nav_model_mtime:
                        texture = rl.load_texture(str(PREVIEW_PATH))
                        if texture.id:
                            if self._nav_model_texture is not None:
                                rl.unload_texture(self._nav_model_texture)
                            self._nav_model_texture = texture
                            self._nav_model_mtime = mtime
                        else:
                            self._nav_model_fresh = False
                except OSError:
                    self._nav_model_fresh = False
        if self._nav_model_fresh and self._nav_model_texture is not None:
            size = min(DESIGN_HEIGHT - 80, NAVI_LIVE_PANEL_W - 32)
            rl.draw_texture_pro(self._nav_model_texture, rl.Rectangle(0, 0, 256, 256),
                                rl.Rectangle(center_x - size / 2, 20, size, size),
                                rl.Vector2(0, 0), 0, rl.WHITE)
            self._draw_text("Mapbox / Protomaps | (c) OpenStreetMap", center_x,
                            DESIGN_HEIGHT - 40, 14, (180, 180, 180), "center")
        else:
            self._draw_text("NAV MAP: waiting for route / GPS / tiles", center_x,
                            DESIGN_HEIGHT / 2, 24, (255, 255, 255), "center")

    def _ego_model(self, name: str):
        names = getattr(self, "_other_vehicle_names", ())
        if name in names:
            index = names.index(name)
            self._set_other_paint(index, None)
            return self._other_vehicle_models[index], name
        if name == "k9" and getattr(self, "_park_k9_model", None) is not None:
            return self._park_k9_model, "k9"
        return self._park_vehicle_model, "ev6"

    def _close_park_textures(self) -> None:
        textures = list(self._ev6_park_textures or ())
        if self._park_model_texture is not None:
            textures.append(self._park_model_texture)
        if self._ev6_reverse_sprite:
            textures.append(self._ev6_reverse_sprite[0])
        textures.extend(getattr(self, "_k9_reverse_layers", None) or ())
        self._k9_reverse_layers = None
        self._ev6_reverse_sprite = None
        self._ev6_reverse_sprite_key = None
        # Detach handles first: close is idempotent, including after an interrupted unload.
        self._ev6_park_textures = None
        self._ev6_park_retry_t = 0.0
        self._park_model_texture = None
        self._park_model_key = None
        self._park_model_retry_t = 0.0
        if getattr(self, "_k9_park_sprite", None):
            rl.unload_texture(self._k9_park_sprite)
        self._k9_park_sprite = None
        failure = None
        for texture in textures:
            try:
                rl.unload_texture(texture)
            except BaseException as exc:
                failure = failure or exc
        if failure is not None:
            raise failure

    def _prepare_park_model_texture(self, state: ClusterUiState) -> None:
        """Cache the selected car before binding the main frame's render target."""
        if not self._ev6_park_screen_active(state):
            return
        model, key = self._ego_model(ego_model_name(state.car_fingerprint))
        if model is None or key == self._park_model_key:
            return
        now = time.monotonic()
        if now < getattr(self, "_park_model_retry_t", 0.0):
            return
        self._park_model_retry_t = now + EV6_PARK_IMAGE_RETRY_S
        if self._park_model_texture is not None:
            rl.unload_texture(self._park_model_texture)
            self._park_model_texture = None
        self._park_model_key = None
        target = image = texture = None
        try:
            from cluster_scene import EV6_EGO_HEIGHT_M, EV6_EGO_LENGTH_M, EV6_EGO_WIDTH_M

            camera = rl.Camera3D(rl.Vector3(-6.5, 7.5, 4.0), rl.Vector3(0.0, 0.0, 0.75),
                                 rl.Vector3(0.0, 0.0, 1.0), 32.0, rl.CameraProjection.CAMERA_PERSPECTIVE)
            view = rl.ffi.new("float[]", [camera.position.x, camera.position.y, camera.position.z])
            for shader, loc in self._vehicle_shaders:
                if loc >= 0:
                    rl.set_shader_value(shader, loc, view, rl.ShaderUniformDataType.SHADER_UNIFORM_VEC3)
            scale = ((EV6_EGO_WIDTH_M, EV6_EGO_LENGTH_M, EV6_EGO_HEIGHT_M) if key == "ev6"
                     else PARK_K9_SCALE_M if key == "k9" else (1.82, 4.35, 1.35))
            target = rl.load_render_texture(1000 if key == "k9" else 800, 480)  # K9: long car, roof fits
            rl.begin_texture_mode(target)
            try:
                rl.clear_background(rl.BLANK)
                rl.begin_mode_3d(camera)
                try:
                    rl.rl_disable_backface_culling()
                    rl.draw_model_ex(model, rl.Vector3(0.0, 0.0, 0.0), rl.Vector3(0.0, 0.0, 1.0),
                                     0.0, rl.Vector3(*scale), rl.WHITE)
                finally:
                    rl.rl_enable_backface_culling()
                    rl.end_mode_3d()
            finally:
                rl.end_texture_mode()
            image = rl.load_image_from_texture(target.texture)
            rl.image_flip_vertical(image)
            if not self._crop_car_image(image):
                return
            texture = rl.load_texture_from_image(image)
            rl.gen_texture_mipmaps(texture)
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            self._park_model_texture, texture = texture, None
            self._park_model_key = key
            self._park_model_retry_t = 0.0
        except Exception as exc:
            print(f"Parked car preview unavailable: {exc}", flush=True)
        finally:
            if texture is not None:
                rl.unload_texture(texture)
            if image is not None:
                rl.unload_image(image)
            if target is not None:
                rl.unload_render_texture(target)

    @staticmethod
    def _crop_car_image(image) -> bool:
        rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
        alpha = np.frombuffer(rl.ffi.buffer(image.data, image.width * image.height * 4),
                              dtype=np.uint8).reshape(image.height, image.width, 4)[..., 3]
        rows, cols = np.nonzero(alpha.max(axis=1))[0], np.nonzero(alpha.max(axis=0))[0]
        if not len(rows):
            return False
        rl.image_crop(image, rl.Rectangle(int(cols[0]), int(rows[0]),
                                         int(cols[-1] - cols[0] + 1), int(rows[-1] - rows[0] + 1)))
        return True

    # ---- EV6 HUD patch v13: parked screen ----
    def _ev6_park_screen_active(self, state: ClusterUiState) -> bool:
        if not getattr(state, "onroad", False):
            return False
        if str(getattr(state, "gear_text", "") or "").strip().upper() != "P":
            return False
        now = time.monotonic()
        if now >= getattr(self, "_ev6_park_flag_check_t", 0.0):
            self._ev6_park_flag_check_t = now + 1.0
            self._ev6_park_off = os.path.exists(EV6_PARK_SCREEN_OFF_FLAG)
        return not self._ev6_park_off

    def _ev6_park_car_texture(self, dark: bool):
        # Loaded lazily from the device; a missing file is retried every few seconds so a copied photo shows up
        # without restarting the HUD. Dark theme drops the photo's grey ground shadow (it reads as a haze on black).
        textures = getattr(self, "_ev6_park_textures", None)
        if textures is None:
            now = time.monotonic()
            if now < getattr(self, "_ev6_park_retry_t", 0.0):
                return None
            self._ev6_park_retry_t = now + EV6_PARK_IMAGE_RETRY_S
            path = os.environ.get("EV6_PARK_CAR_IMAGE", EV6_PARK_CAR_IMAGE)
            if not os.path.isfile(path):
                return None
            image = dark_image = None
            textures = []
            try:
                image = rl.load_image(path)
                if image.width <= 0 or image.height <= 0:
                    return None
                rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                dark_image = rl.image_copy(image)
                pixels = np.frombuffer(rl.ffi.buffer(dark_image.data, dark_image.width * dark_image.height * 4),
                                       dtype=np.uint8).reshape(dark_image.height, dark_image.width, 4)
                # EV6 HUD patch v16: keep the photo's ground shadow but make it black (grey reads as haze on black)
                floor = pixels[int(dark_image.height * EV6_PARK_DARK_SHADOW_FROM):]
                shadow = floor[..., 3] < 250
                floor[shadow, :3] = 0
                floor[shadow, 3] = (floor[shadow, 3] * 0.85).astype(np.uint8)
                for img in (image, dark_image):
                    texture = rl.load_texture_from_image(img)
                    textures.append(texture)
                    rl.gen_texture_mipmaps(texture)
                    rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
                self._ev6_park_textures = textures
            except Exception as exc:
                print(f"EV6 parked screen: could not load {path}: {exc}", flush=True)
                return None
            finally:
                if image is not None:
                    rl.unload_image(image)
                if dark_image is not None:
                    rl.unload_image(dark_image)
                if self._ev6_park_textures is None:
                    for texture in textures:
                        rl.unload_texture(texture)
        return textures[1 if dark else 0]

    def _k9_park_sprite_texture(self):
        # Loaded once per GL context; False = tried and failed (falls back to the rendered model).
        sprite = getattr(self, "_k9_park_sprite", None)
        if sprite is None:
            self._k9_park_sprite = False
            try:
                if K9_PARK_CAR_SPRITE_PATH.is_file():
                    texture = rl.load_texture(str(K9_PARK_CAR_SPRITE_PATH))
                    if texture is not None and getattr(texture, "id", 0) > 0:
                        rl.gen_texture_mipmaps(texture)
                        rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
                        self._k9_park_sprite = texture
            except Exception as exc:
                print(f"K9 parked screen: could not load {K9_PARK_CAR_SPRITE_PATH}: {exc}", flush=True)
            sprite = self._k9_park_sprite
        return sprite or None

    def _k9_park_floor_texture(self):
        floor = getattr(self, "_k9_park_floor", None)
        if floor is None:
            self._k9_park_floor = False
            try:
                if K9_PARK_FLOOR_PATH.is_file():
                    image = rl.load_image(str(K9_PARK_FLOOR_PATH))
                    try:  # same darkening as the background (k9_park_darken), rim light spared
                        rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                        px = np.frombuffer(rl.ffi.buffer(image.data, image.width * image.height * 4),
                                           dtype=np.uint8).reshape(image.height, image.width, 4)
                        rgb = px[..., :3].astype(np.float32)
                        lo, hi = K9_PARK_RIM_KEEP
                        keep = np.clip((rgb.max(axis=2, keepdims=True) - lo) / (hi - lo), 0.0, 1.0)
                        grey = (rgb * np.array([0.299, 0.587, 0.114], np.float32)).sum(axis=2, keepdims=True)
                        k = K9_PARK_DIM + (1.0 - K9_PARK_DIM) * keep
                        sat = K9_PARK_SAT + (1.0 - K9_PARK_SAT) * keep
                        px[..., :3] = np.clip(np.rint(k * (grey + sat * (rgb - grey))), 0, 255).astype(np.uint8)
                        texture = rl.load_texture_from_image(image)
                    finally:
                        rl.unload_image(image)
                    if texture is not None and getattr(texture, "id", 0) > 0:
                        rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
                        self._k9_park_floor = texture
            except Exception as exc:
                print(f"K9 parked screen: could not load {K9_PARK_FLOOR_PATH}: {exc}", flush=True)
            floor = self._k9_park_floor
        return floor or None

    def _k9_park_bottom_profile(self) -> list:
        # photo px (column centre x, lowest opaque y) along the car's bottom outline; read once from the PNG
        prof = getattr(self, "_k9_park_profile", None)
        if prof is None:
            prof = []
            try:
                from PIL import Image
                alpha = np.asarray(Image.open(K9_PARK_CAR_SPRITE_PATH).convert("RGBA"))[..., 3]
                step = K9_PARK_PROFILE_STEP
                for x0 in range(0, alpha.shape[1] - step + 1, step):
                    rows = np.nonzero((alpha[:, x0:x0 + step] > 160).any(axis=1))[0]
                    if rows.size:
                        prof.append((x0 + step / 2, float(rows[-1])))
            except Exception as exc:
                print(f"K9 parked screen: no bottom outline for the contact shadow: {exc}", flush=True)
            self._k9_park_profile = prof
        return prof

    @staticmethod
    def k9_park_stage_geometry(car_cx: float, car_bottom: float, car_h: float) -> tuple[float, float, float, float, float]:
        dx, dy, rx, ry, turn = K9_PARK_STAGE_REL
        return car_cx + dx * car_h, car_bottom + dy * car_h, rx * car_h, ry * car_h, turn

    def _k9_draw_park_stage(self, sprite, car_cx: float, car_bottom: float, car_h: float, dark: bool) -> None:
        # K9 (대감님 11/11 21:30): round stage the car stands on, like the mock-up: soft blue floor inside a thin
        # bright rim, dark contact shadow under the tyres and a faint mirror image, all drawn before the photo.
        sx, sy, srx, sry, turn = self.k9_park_stage_geometry(car_cx, car_bottom, car_h)
        floor = self._k9_park_floor_texture()
        if floor is not None:
            scale = car_h / max(1, sprite.height)
            left, top = car_cx - sprite.width * scale / 2, car_bottom - car_h
            ox, oy = K9_PARK_FLOOR_OFFSET
            rl.draw_texture_pro(floor, rl.Rectangle(0, 0, floor.width, floor.height),
                                rl.Rectangle(left + ox * scale, top + oy * scale, floor.width * scale, floor.height * scale),
                                rl.Vector2(0, 0), 0.0, rl.WHITE)
            return
        rl.rl_push_matrix()  # floor in the stage frame (centre, turned like the mock-up rim)
        rl.rl_translatef(sx, sy, 0.0)
        rl.rl_rotatef(turn, 0.0, 0.0, 1.0)
        try:
            for i in range(8):  # floor: faint blue, a little brighter towards the rim
                f = 1.0 - i * 0.03
                rl.draw_ellipse(0, 0, srx * f, sry * f, rl.Color(70, 120, 230, 11 if dark else 7))
        finally:
            rl.rl_pop_matrix()
        scale = car_h / max(1, sprite.height)
        car_w = sprite.width * scale
        left, top = car_cx - car_w / 2, car_bottom - car_h
        (fx, fy), (bx, by) = K9_PARK_WHEELS
        # mirror image: the photo flipped about the ground line through the tyre contacts, fading downwards. Drawn as
        # one textured strip (no columns) so the sloped tyre line has no steps.
        cols, bands, depth = 139, 10, 92.0
        cw = sprite.width / cols
        sw, sh = float(sprite.width), float(sprite.height)
        def axis_at(x: float) -> float:
            return fy if x < fx else (by if x > bx else fy + (by - fy) * (x - fx) / (bx - fx))
        def strength_at(x: float) -> float:  # mock-up: tyres mirror clearly, the bumper in front only faintly
            return 0.3 + 0.7 * max(0.0, min(1.0, (x - (fx - 75.0)) / 40.0))
        rl.rl_set_texture(sprite.id)
        rl.rl_begin(rl.RL_TRIANGLES)
        for c in range(cols):
            xa, xb = c * cw, (c + 1) * cw
            for b in range(bands):
                d0, d1 = depth * b / bands, depth * (b + 1) / bands
                corners = []
                for x in (xa, xb):
                    ax, st = axis_at(x), strength_at(x)
                    for d in (d0, d1):
                        al = int(72 * st * max(0.0, 1.0 - d / depth) ** 1.5)
                        corners.append((left + x * scale, top + (ax + d) * scale, x / sw, max(0.0, ax - d) / sh, al))
                p00, p01, p10, p11 = corners  # (x a/b) x (depth near/far)
                for vx, vy, u, v, al in (p00, p01, p11, p00, p11, p10):
                    rl.rl_color4ub(150, 175, 225, al)
                    rl.rl_tex_coord2f(u, v)
                    rl.rl_vertex2f(vx, vy)
        rl.rl_end()
        rl.rl_set_texture(rl.rl_get_texture_id_default())  # back to the plain white texture for the shapes below
        # 대감님 11/11 22:07 "옆면아래 동그란그림자 이질적이야": no round blobs under the doors/sill any more; only a
        # thin contact shadow hugging the photo's bottom outline, darkest where the tyres touch the floor
        prof = self._k9_park_bottom_profile()
        strip = []  # (x, top y, bottom y, alpha) per outline column, smoothed so the edge does not step
        for k, (px, _py) in enumerate(prof):
            py = sorted(q for _x, q in prof[max(0, k - 2):k + 3])[len(prof[max(0, k - 2):k + 3]) // 2]
            ground = fy if px < fx else (by if px > bx else fy + (by - fy) * (px - fx) / (bx - fx))
            near = max(math.exp(-((px - fx) / 38.0) ** 2), math.exp(-((px - bx) / 34.0) ** 2))
            # mock-up: dark floor right under the sill down to the tyre line, the bumper in front only faintly
            # 대감님 11/11 22:39 "그림자는왜빼ㅁ?": the 22:07 strip (7 px, fading straight to 0) was hidden under the photo
            # and too faint to see; keep its shape (darkest at the tyres, 35 % under the front bumper) but darker,
            # deeper below the outline and holding its darkness for the first part before it fades
            # 대감님 11/11 22:48 "여전히 안 보여 차가 떠 보인다": the mock-up is the reference = solid black right under
            # the whole bottom (front bumper too, no 35 % cut), tyres the blackest, soft fade outwards; the two ends
            # of the outline taper in x so there is no hard vertical edge
            end = min(1.0, (px - prof[0][0]) / 18.0, (prof[-1][0] - px) / 18.0)
            a = 255.0 * max(0.0, end)
            strip.append((left + px * scale, top + (py - 3) * scale,
                          top + (max(py, ground) + 34.0 + 12.0 * near) * scale, a))
        if len(strip) > 1:
            rl.rl_begin(rl.RL_TRIANGLES)
            for (x0, t0, b0, a0), (x1, t1, b1, a1) in zip(strip, strip[1:]):
                m0, m1 = t0 + (b0 - t0) * 0.68, t1 + (b1 - t1) * 0.68  # black core, then soft fade
                for (ya0, aa0, ya1, aa1, yb0, ab0, yb1, ab1) in ((t0, a0, t1, a1, m0, a0 * 0.92, m1, a1 * 0.92),
                                                                (m0, a0 * 0.92, m1, a1 * 0.92, b0, 0, b1, 0)):
                    for x, y, al in ((x0, ya0, aa0), (x0, yb0, ab0), (x1, yb1, ab1),
                                     (x0, ya0, aa0), (x1, yb1, ab1), (x1, ya1, aa1)):
                        rl.rl_color4ub(0, 2, 10, int(al))
                        rl.rl_vertex2f(x, y)
            rl.rl_end()
        n = 120
        tc, ts = math.cos(math.radians(turn)), math.sin(math.radians(turn))
        def at(f: float, i: int):
            ex, ey = srx * f * math.cos(2 * math.pi * i / n), sry * f * math.sin(2 * math.pi * i / n)
            return rl.Vector2(sx + ex * tc - ey * ts, sy + ex * ts + ey * tc)
        pts = [at(1.0, i) for i in range(n + 1)]
        def light(i: int) -> float:  # rim brightness traced on the mock-up: even, a bit brighter in front, gone at the left end
            deg = 360.0 * (i + 0.5) / n  # 0 right end, 90 front, 180 left end
            fade = min(1.0, max(0.0, (186.0 - deg) / 14.0) + max(0.0, (deg - 236.0) / 14.0))
            front = math.exp(-(((deg - 107.0 + 180.0) % 360.0 - 180.0) / 35.0) ** 2)
            right = math.exp(-(((deg - 5.0 + 180.0) % 360.0 - 180.0) / 25.0) ** 2)
            return fade * min(1.0, 0.62 + 0.25 * front + 0.12 * right)
        inner = [at(0.88, i) for i in range(n + 1)]
        for i in range(n):  # soft light band just inside the rim (front-right), as on the mock-up floor
            rl.draw_line_ex(inner[i], inner[i + 1], 0.12 * sry * 2, rl.Color(90, 130, 230, int(16 * light(i) ** 2)))
        for width, color in ((9.0, (70, 140, 255, 14)), (5.0, (90, 160, 255, 34)), (2.2, (125, 185, 245, 185))):
            for i in range(n):
                rl.draw_line_ex(pts[i], pts[i + 1], width, rl.Color(color[0], color[1], color[2], int(color[3] * light(i))))

    @staticmethod
    def k9_range_text(fraction) -> str:
        if fraction is None or not 0.0 < fraction <= 1.0:
            return ""
        return f"{int(round(fraction * K9_DTE_FULL_KM))} km"

    def _ev6_draw_top_view_car(self, cx: float, cy: float, dark: bool, colors: dict, scale: float = 1.0) -> None:
        # EV6 HUD patch v16: small top-view car (front up) for the tyre pressures, instead of a plain box
        if scale != 1.0:
            rl.rl_push_matrix()
            rl.rl_translatef(cx, cy, 0.0)
            rl.rl_scalef(scale, scale, 1.0)
            try:
                self._ev6_draw_top_view_car(0.0, 0.0, dark, colors)
            finally:
                rl.rl_pop_matrix()
            return
        tyre = rl_color((88, 92, 100) if dark else (70, 74, 82))
        glass = rl_color((70, 76, 86) if dark else (92, 100, 112))
        body = rl_color(colors["card"])
        for sx in (-1, 1):
            for sy in (-1, 1):  # wheels peek out at the four corners, next to their pressure value
                rl.draw_rectangle_rounded(rl.Rectangle(cx + sx * 25 - 5, cy + sy * 31 - 11, 10, 22), 0.6, 6, tyre)
            rl.draw_ellipse(int(cx + sx * 27), int(cy - 15), 5, 3, body)  # mirrors
        self._rounded_rect(cx - 24, cy - 54, 48, 108, 22, colors["card"], colors["line"], 2)
        # windscreen, roof and rear window
        rl.draw_triangle(rl.Vector2(cx - 18, cy - 24), rl.Vector2(cx - 15, cy - 9), rl.Vector2(cx + 18, cy - 24), glass)
        rl.draw_triangle(rl.Vector2(cx + 18, cy - 24), rl.Vector2(cx - 15, cy - 9), rl.Vector2(cx + 15, cy - 9), glass)
        rl.draw_rectangle_rounded(rl.Rectangle(cx - 15, cy - 6, 30, 30), 0.25, 6, rl_color(colors["line"]))
        rl.draw_triangle(rl.Vector2(cx - 15, cy + 27), rl.Vector2(cx - 17, cy + 37), rl.Vector2(cx + 15, cy + 27), glass)
        rl.draw_triangle(rl.Vector2(cx + 15, cy + 27), rl.Vector2(cx - 17, cy + 37), rl.Vector2(cx + 17, cy + 37), glass)

    def _ev6_draw_weather(self, weather: dict, colors: dict, dark: bool, text) -> None:
        # EV6 HUD patch v17: [icon] 18°  맑음 / 최고 21°  최저 12°  ● 미세먼지 좋음
        self._ev6_draw_weather_icon(weather["kind"], 100, 272, 62, dark)
        text(f"{weather['temp']:.0f}°", 150, 272, 52, "text")
        text(weather["label"], 262, 276, 30, "text")
        line = []
        if weather.get("max") is not None and weather.get("min") is not None:
            line.append(f"최고 {weather['max']:.0f}°  최저 {weather['min']:.0f}°")
        text("  ".join(line), 70, 330, 22, "muted")
        if weather.get("dust") is not None:
            label, color = EV6_DUST_GRADES[weather["dust"]]
            rl.draw_circle(262, 330, 7, rl_color(color))
            text(f"미세먼지 {label}", 278, 330, 22, "muted")

    @staticmethod
    def _ev6_draw_weather_icon(kind: str, cx: float, cy: float, s: float, dark: bool) -> None:
        sun = rl.Color(255, 184, 0, 255)
        cloud = rl.Color(*((208, 213, 220) if dark else (176, 184, 194)), 255)
        cloud_hi = rl.Color(*((236, 238, 241) if dark else (214, 219, 226)), 255)

        def cloud_at(x, y, k, color):
            rl.draw_circle(int(x - 0.30 * k), int(y + 0.05 * k), 0.26 * k, color)
            rl.draw_circle(int(x + 0.02 * k), int(y - 0.12 * k), 0.34 * k, color)
            rl.draw_circle(int(x + 0.34 * k), int(y + 0.06 * k), 0.24 * k, color)
            rl.draw_rectangle_rounded(rl.Rectangle(x - 0.56 * k, y + 0.02 * k, 1.14 * k, 0.30 * k), 1.0, 8, color)

        if kind in ("clear", "partly"):
            sx, sy, r = (cx, cy, 0.36 * s) if kind == "clear" else (cx - 0.18 * s, cy - 0.16 * s, 0.26 * s)
            for i in range(8):
                a = i * math.pi / 4
                rl.draw_line_ex(rl.Vector2(sx + math.cos(a) * r * 1.35, sy + math.sin(a) * r * 1.35),
                                rl.Vector2(sx + math.cos(a) * r * 1.75, sy + math.sin(a) * r * 1.75), 0.07 * s, sun)
            rl.draw_circle(int(sx), int(sy), r, sun)
            if kind == "partly":
                cloud_at(cx + 0.10 * s, cy + 0.12 * s, s * 0.85, cloud_hi)
            return
        cloud_at(cx, cy - 0.08 * s, s, cloud)
        if kind == "rain":
            for i in range(3):
                x = cx - 0.30 * s + i * 0.30 * s
                rl.draw_line_ex(rl.Vector2(x + 0.06 * s, cy + 0.36 * s), rl.Vector2(x - 0.04 * s, cy + 0.56 * s), 0.07 * s,
                                rl.Color(64, 156, 255, 255))
        elif kind == "snow":
            for i in range(3):
                rl.draw_circle(int(cx - 0.30 * s + i * 0.30 * s), int(cy + 0.48 * s), 0.07 * s, rl.Color(170, 205, 255, 255))

    def _ev6_draw_battery(self, soc: float, x: float, cy: float, colors: dict, text) -> None:
        # ClusterUiState uses the existing carState.fuelGauge fraction (0..1).
        level = clamp(soc, 0.0, 1.0) * 100.0
        color = (255, 59, 48) if level < 15 else (255, 159, 10) if level < 30 else (52, 199, 89)
        w, h = 50.0, 24.0
        self._rounded_rect(x, cy - h / 2, w, h, 6, colors["card"], colors["muted"], 2)
        rl.draw_rectangle_rounded(rl.Rectangle(x + w + 1, cy - 5, 4, 10), 0.5, 4, rl_color(colors["muted"]))
        if level > 0:
            rl.draw_rectangle_rounded(rl.Rectangle(x + 4, cy - h / 2 + 4, max(3.0, (w - 8) * level / 100.0), h - 8), 0.3, 4,
                                      rl_color(color))
        text(f"{int(level)}%", x + w + 16, cy, 34, "text")

    @staticmethod
    def k9_fuel_text(fraction) -> str:
        # carState.fuelGauge (0..1]; cluster_live passes None when the car does not report it (K9 CAN: not decoded).
        if fraction is None or not 0.0 < fraction <= 1.0:
            return "--"
        return f"{int(round(fraction * 100.0))}%"

    def _k9_draw_fuel(self, fraction, x: float, cy: float, colors: dict, text) -> None:
        # Fuel pump icon in the battery's place, same 34 px value text (no smaller text, 대감님 11/11 18:33).
        muted = rl_color(colors["muted"])
        self._rounded_rect(x, cy - 15, 22, 30, 3, colors["card"], colors["muted"], 2)
        rl.draw_rectangle_rounded(rl.Rectangle(x + 5, cy - 10, 12, 8), 0.3, 4, muted)
        rl.draw_line_ex(rl.Vector2(x + 22, cy - 8), rl.Vector2(x + 30, cy - 2), 3, muted)
        rl.draw_line_ex(rl.Vector2(x + 30, cy - 2), rl.Vector2(x + 30, cy + 10), 3, muted)
        value = self.k9_fuel_text(fraction)
        if value != "--":
            level = float(value[:-1])
            color = (255, 59, 48) if level < 15 else (255, 159, 10) if level < 30 else (52, 199, 89)
            rl.draw_rectangle_rounded(rl.Rectangle(x + 3, cy + 15 - 28 * level / 100.0 + 1, 16, 28 * level / 100.0 - 2),
                                      0.2, 4, rl_color(color))
        text(value, x + 46, cy, 34, "text")

    @staticmethod
    def _ev6_park_duration_text(seconds: float, korean: bool = True) -> str:
        minutes = int(round(max(0.0, seconds) / 60.0))
        if korean:
            return f"{minutes // 60}시간 {minutes % 60:02d}분" if minutes >= 60 else f"{minutes}분"
        return f"{minutes // 60}h {minutes % 60:02d}m" if minutes >= 60 else f"{minutes}m"

    def _ev6_draw_park_screen(self, state: ClusterUiState) -> None:
        theme = self._current_theme()
        korean = self.language == CLUSTER_LANGUAGE_KO
        colors = EV6_PARK_COLORS_DARK if theme.is_dark else EV6_PARK_COLORS_LIGHT
        is_k9 = ego_model_name(getattr(state, "car_fingerprint", "")) == "k9"
        if is_k9 and theme.is_dark:
            colors = K9_PARK_COLORS_DARK
        rl.clear_background(rl_color(colors["bg_bot"]))
        rl.rl_push_matrix()
        rl.rl_scalef(self.width / DESIGN_WIDTH, self.height / DESIGN_HEIGHT, 1.0)
        try:
            rl.draw_rectangle_gradient_v(0, 0, DESIGN_WIDTH, DESIGN_HEIGHT, rl_color(colors["bg_top"]),
                                         rl_color(colors["bg_bot"]))

            def text(value, x, y, size, color, anchor="left"):
                self._draw_text(value, x, y, size, colors[color], anchor)

            # left: date, clock, gear
            now = time.localtime()
            if self.language == CLUSTER_LANGUAGE_KO:
                date_text = f"{now.tm_mon}월 {now.tm_mday}일 {EV6_PARK_WEEKDAYS_KO[now.tm_wday]}요일"
            else:
                date_text = time.strftime("%a, %b %d", now)
            weather = EV6_WEATHER.snapshot()  # EV6 HUD patch v17: Open-Meteo weather, fetched in the background
            fuel_x, fuel_y = 236, None
            if is_k9:  # K9 (대감님 11/11 21:05): positions measured off his mock-up panel, scaled to 1920x480
                text(date_text, 62, 76, 38, "muted")
                text(time.strftime("%H:%M", now), 58, 160, 118, "text")
                if weather is not None:
                    self._ev6_draw_weather(weather, colors, theme.is_dark, text)
                    gear_y = 400
                else:  # mock-up rows: weather row -> P, divider, fuel row
                    gear_y, fuel_x, fuel_y = 262, 72, 400
                rl.draw_line_ex(rl.Vector2(62, 358), rl.Vector2(250, 358), 2, rl_color(colors["line"]))
            else:
                text(date_text, 70, 92, 34, "muted")
                text(time.strftime("%H:%M", now), 64, 170, 108, "text")
                gear_y = 300
                if weather is not None:
                    self._ev6_draw_weather(weather, colors, theme.is_dark, text)
                    gear_y = 400
            text("P", 70, gear_y, 64, "accent")
            text("주차" if self.language == CLUSTER_LANGUAGE_KO else "Park", 130, gear_y + 4, 30, "muted")
            if fuel_y is None:
                fuel_y = gear_y + 2
            # Use the existing vehicle decoder, never infer EV6 CAN layout from the fallback picture.
            soc = state.fuel_gauge if state.energy_gauge_label == "battery" else None
            if soc is not None:
                self._ev6_draw_battery(soc, 236, gear_y + 2, colors, text)
            elif state.energy_gauge_label == "fuel":  # K9 (대감님 11/11 18:24): fuel level instead of the battery
                self._k9_draw_fuel(state.fuel_gauge, fuel_x, fuel_y, colors, text)
                range_text = self.k9_range_text(state.fuel_gauge) if is_k9 else ""
                if range_text:  # km to empty from the cluster (CF_Clu_DTE), same source as the %
                    text(range_text, fuel_x + 46 + 104, fuel_y, 34, "muted")

            # centre: car photo on a soft floor shadow
            car_cx, car_bottom, car_h = 790.0, 412.0, 350.0
            sprite = self._k9_park_sprite_texture() if is_k9 else None
            if sprite is not None:  # photo car on a round stage, like the mock-up
                car_cx, car_bottom, car_h = K9_PARK_CAR_BOX
                self._k9_draw_park_stage(sprite, car_cx, car_bottom, car_h, theme.is_dark)
            for i in range(12 if sprite is None else 0):  # K9 photo: its own contact shadow on the stage
                k = 1.0 - i * 0.045
                rl.draw_ellipse(int(car_cx), int(car_bottom - 10), int(330 * k), int(30 * k),
                                rl.Color(0, 0, 0, 8 if theme.is_dark else 7))
            texture = self._park_model_texture
            if ego_model_name(state.car_fingerprint) == "ev6":
                texture = self._ev6_park_car_texture(theme.is_dark) or texture
            elif sprite is not None:
                texture = sprite
            if texture is not None:
                car_w = car_h * texture.width / max(1, texture.height)
                rl.draw_texture_pro(texture, rl.Rectangle(0, 0, texture.width, texture.height),
                                    rl.Rectangle(car_cx - car_w / 2, car_bottom - car_h, car_w, car_h),
                                    rl.Vector2(0, 0), 0.0, rl.WHITE)

            # tyre pressures, top view
            tpms = getattr(state, "tpms", None)
            if is_k9:  # mock-up: bigger top view, value with "psi" under it at each corner
                cx, cy = 1373, 318
                self._ev6_draw_top_view_car(cx, cy, theme.is_dark, colors, 1.45)
                for key, dx, dy in (("fl", -88, -58), ("fr", 88, -58), ("rl", -88, 60), ("rr", 88, 60)):
                    value = getattr(tpms, key, None) if tpms is not None else None
                    text("--" if value is None or value <= 0 else f"{value:.0f}", cx + dx, cy + dy, 34, "text", "center")
                    text("psi", cx + dx, cy + dy + 27, 22, "muted", "center")
            else:
                cx, cy = 1290, 290
                self._ev6_draw_top_view_car(cx, cy, theme.is_dark, colors)
                for key, dx, dy in (("fl", -70, -34), ("fr", 70, -34), ("rl", -70, 34), ("rr", 70, 34)):
                    value = getattr(tpms, key, None) if tpms is not None else None
                    text("--" if value is None or value <= 0 else f"{value:.0f}", cx + dx, cy + dy, 30, "text", "center")
                text("공기압 (psi)" if korean else "Tyres (psi)", cx, cy + 86, 22, "muted", "center")

            # right: this trip
            trip = getattr(state, "trip_report", None)
            x0, x1 = (1540, 1876) if is_k9 else (1420, 1860)
            title = ("주행 정보" if is_k9 else "이번 주행") if korean else ("Trip info" if is_k9 else "This trip")
            if is_k9:
                text(title, x0, 74, 34, "text")
                rl.draw_line_ex(rl.Vector2(x0, 109), rl.Vector2(x1, 109), 2, rl_color(colors["line"]))
            else:
                text(title, x0, 70, 30, "muted")
            rows = (
                ("거리" if korean else "Distance", format_trip_distance(trip.distance_m, self.is_metric) if trip else "--"),
                ("시간" if korean else "Time", self._ev6_park_duration_text(trip.duration_s, korean) if trip else "--"),
                ("평균" if korean else "Average",
                 f"{display_speed(trip.average_speed_kph, self.is_metric):.1f} {speed_unit(self.is_metric)}" if trip else "--"),
                ("자동주행" if korean else "Automatic", f"{trip.auto_ratio_percent:.0f} %" if trip else "--"),
            )
            for i, (label, value) in enumerate(rows):
                if is_k9:  # mock-up rows 147/218/298/374, lines under every row
                    y = (147, 220, 296, 372)[i]
                    text(label, x0, y, 31, "text")
                    text(value, x1, y, 42, "text", "right")
                    rl.draw_line_ex(rl.Vector2(x0, y + 37), rl.Vector2(x1, y + 37), 2, rl_color(colors["line"]))
                    continue
                y = 135 + i * 78
                text(label, x0, y, 28, "muted")
                text(value, x1, y, 40, "text", "right")
                if i < len(rows) - 1:
                    rl.draw_line_ex(rl.Vector2(x0, y + 39), rl.Vector2(x1, y + 39), 2, rl_color(colors["line"]))
            if trip:
                summary = (f"급가속 {trip.hard_accel_count} · 급감속 {trip.hard_brake_count} · 급코너 {trip.hard_corner_count}" if korean
                           else f"Hard accel {trip.hard_accel_count} · brake {trip.hard_brake_count} · corner {trip.hard_corner_count}")
                text(summary, x0, 445, 24, "muted")
        finally:
            rl.rl_pop_matrix()

    # ---- EV6 HUD patch v15: reverse screen ----
    def _ev6_reverse_screen_active(self, state: ClusterUiState) -> bool:
        if not getattr(state, "onroad", False):
            return False
        if str(getattr(state, "gear_text", "") or "").strip().upper() != "R":
            return False
        now = time.monotonic()
        if now >= getattr(self, "_ev6_reverse_flag_check_t", 0.0):
            self._ev6_reverse_flag_check_t = now + 1.0
            self._ev6_reverse_off = os.path.exists(EV6_REVERSE_SCREEN_OFF_FLAG)
        return not self._ev6_reverse_off

    @staticmethod
    def ev6_reverse_path(steering_angle_deg: float, car_fingerprint: str = "") -> list[tuple[float, float, float]]:
        # Rear-axle path while reversing (kinematic bicycle model): x right, y forward, heading clockwise from +y.
        # Positive steering angle = wheel turned left, which swings the rear to the car's left.
        wheelbase_m, steer_ratio = reverse_geometry(car_fingerprint)
        curvature = math.tan(math.radians(steering_angle_deg / steer_ratio)) / wheelbase_m
        step = EV6_REVERSE_PATH_LENGTH_M / EV6_REVERSE_PATH_STEPS
        x, y, heading = 0.0, EV6_REVERSE_REAR_AXLE_Y_M, 0.0
        points = []
        for _ in range(EV6_REVERSE_PATH_STEPS + 1):
            points.append((x, y, heading))
            x -= math.sin(heading) * step
            y -= math.cos(heading) * step
            heading += curvature * step
        return points

    def _ev6_reverse_camera(self, k9: bool = False):
        # top view, car front to the left: screen up = the car's right side
        if k9:
            # 대감님 11/12 23:34: K9 car larger on screen - display scale only (narrower view, same camera height),
            # so the reverse path, marks and blind-spot bands are drawn at the same scale as the car.
            camera = rl.Camera3D(rl.Vector3(-2.6, K9_REVERSE_VIEW_Y_M, 12.5), rl.Vector3(0.0, K9_REVERSE_VIEW_Y_M, 0.0),
                                 rl.Vector3(1.0, 0.0, 0.0), K9_REVERSE_FOVY_DEG, rl.CameraProjection.CAMERA_PERSPECTIVE)
        else:
            camera = rl.Camera3D(rl.Vector3(-2.6, -3.3, 12.5), rl.Vector3(0.0, -3.3, 0.0), rl.Vector3(1.0, 0.0, 0.0),
                                 27.0, rl.CameraProjection.CAMERA_PERSPECTIVE)
        if self._vehicle_shaders:
            view_pos = rl.ffi.new("float[]", [camera.position.x, camera.position.y, camera.position.z])
            for vehicle_shader, view_loc in self._vehicle_shaders:
                if view_loc >= 0:
                    rl.set_shader_value(vehicle_shader, view_loc, view_pos, rl.ShaderUniformDataType.SHADER_UNIFORM_VEC3)
        return camera

    def _ev6_draw_reverse_car_model(self, state: ClusterUiState) -> None:
        from cluster_scene import EV6_EGO_HEIGHT_M, EV6_EGO_LENGTH_M, EV6_EGO_WIDTH_M

        model, key = self._ego_model(ego_model_name(state.car_fingerprint))
        if model is None:
            return
        scale = ((EV6_EGO_WIDTH_M, EV6_EGO_LENGTH_M, EV6_EGO_HEIGHT_M) if key == "ev6" else (1.82, 4.35, 1.35))
        rl.rl_disable_backface_culling()
        try:
            rl.draw_model_ex(model, rl.Vector3(0.0, 0.0, 0.035), rl.Vector3(0.0, 0.0, 1.0), 0.0,
                             rl.Vector3(*scale), rl.WHITE)
        finally:
            rl.rl_enable_backface_culling()

    def _ev6_prepare_reverse_sprite(self, state: ClusterUiState) -> None:
        """Build the selected car sprite outside the frame target; own every temporary GPU object."""
        if not self._ev6_reverse_screen_active(state):
            return
        model, name = self._ego_model(ego_model_name(state.car_fingerprint))
        key = (name, self.width, self.height)
        if model is None or self._ev6_reverse_sprite_key == key:
            return
        if self._ev6_reverse_sprite:
            rl.unload_texture(self._ev6_reverse_sprite[0])
        for layer in getattr(self, "_k9_reverse_layers", None) or ():
            rl.unload_texture(layer)
        self._k9_reverse_layers = None
        self._ev6_reverse_sprite_key = key
        self._ev6_reverse_sprite = False  # Failure falls back to the live 3D model until the next context/model.
        self._k9_reverse_photo = False
        if name == "k9" and K9_REVERSE_PHOTO_PATH.is_file() and self._k9_prepare_reverse_photo():
            return
        if name == "k9" and K9_REVERSE_CAR_SPRITE_PATH.is_file() and self._k9_prepare_reverse_sprite():
            return
        target = image = texture = None
        try:
            scale = EV6_REVERSE_SPRITE_SUPERSAMPLE
            width, height = int(self.width * scale), int(self.height * scale)
            target = rl.load_render_texture(width, height)
            rl.begin_texture_mode(target)
            try:
                rl.clear_background(rl.Color(214, 216, 220, 0))
                rl.begin_mode_3d(self._ev6_reverse_camera(name == "k9"))
                try:
                    self._ev6_draw_reverse_car_model(state)
                finally:
                    rl.end_mode_3d()
            finally:
                rl.end_texture_mode()
            image = rl.load_image_from_texture(target.texture)
            rl.image_flip_vertical(image)
            rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
            alpha = np.frombuffer(rl.ffi.buffer(image.data, image.width * image.height * 4),
                                  dtype=np.uint8).reshape(image.height, image.width, 4)[..., 3]
            rows = np.nonzero(alpha.max(axis=1))[0]
            cols = np.nonzero(alpha.max(axis=0))[0]
            if len(rows) == 0:
                return
            x0, y0 = int(cols[0]), int(rows[0])
            crop_w, crop_h = int(cols[-1]) - x0 + 1, int(rows[-1]) - y0 + 1
            rl.image_crop(image, rl.Rectangle(x0, y0, crop_w, crop_h))
            if name == "ev6" and os.path.isfile(EV6_REVERSE_CAR_IMAGE):
                rl.unload_image(image)
                image = None
                image = rl.load_image(EV6_REVERSE_CAR_IMAGE)
            texture = rl.load_texture_from_image(image)
            rl.gen_texture_mipmaps(texture)
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            self._ev6_reverse_sprite = (texture, (x0 / scale, y0 / scale, crop_w / scale, crop_h / scale))
            texture = None
        except Exception as exc:
            print(f"Reverse car preview unavailable, using the 3D model: {exc}", flush=True)
        finally:
            if texture is not None:
                rl.unload_texture(texture)
            if image is not None:
                rl.unload_image(image)
            if target is not None:
                rl.unload_render_texture(target)

    @staticmethod
    def _k9_reverse_car_rect(camera, width: int, height: int) -> tuple[float, float, float, float]:
        """Screen rect (px) of the K9 R sprite: body rear bumper on EV6_REVERSE_REAR_BUMPER_Y_M (path start)."""
        length, body_w = K9_REVERSE_CAR_SIZE_M
        pad = K9_REVERSE_CAR_PAD_M
        xs, ys = [], []
        for x in (-body_w / 2 - pad, body_w / 2 + pad):
            for y in (EV6_REVERSE_REAR_BUMPER_Y_M - pad, EV6_REVERSE_REAR_BUMPER_Y_M + length + pad):
                point = rl.get_world_to_screen_ex(rl.Vector3(x, y, 0.0), camera, width, height)
                xs.append(point.x)
                ys.append(point.y)
        return min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)

    def _k9_prepare_reverse_photo(self) -> bool:
        texture = None
        try:
            texture = rl.load_texture(str(K9_REVERSE_PHOTO_PATH))
            if texture.id == 0:
                return False
            rl.gen_texture_mipmaps(texture)
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            sx, sy = self.width / DESIGN_WIDTH, self.height / DESIGN_HEIGHT
            x, y, w, h = k9_reverse_photo_rect()
            self._ev6_reverse_sprite = (texture, (x * sx, y * sy, w * sx, h * sy))
            self._k9_reverse_photo = True
            texture = None
            return True
        except Exception as exc:
            print(f"K9 reverse photo unavailable: {exc}", flush=True)
            return False
        finally:
            if texture is not None:
                rl.unload_texture(texture)

    def _k9_draw_reverse_photo_floor(self, points, steering_deg: float, left_bsd: bool, right_bsd: bool,
                                     accent, warn, dark: bool) -> list:
        """K9 photo R screen, design px: P stage floor disc, path from the rear bumper, 1/2/3 m marks, blind-spot
        bands, all on the floor of the photo camera; returns the distance labels (text, x, y)."""
        own = getattr(self, "_k9_reverse_photo_floor", None)
        if own is None:
            own = False
            try:
                if K9_REVERSE_PHOTO_FLOOR_PATH.is_file():
                    texture = rl.load_texture(str(K9_REVERSE_PHOTO_FLOOR_PATH))
                    if getattr(texture, "id", 0) > 0:
                        rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
                        own = texture
            except Exception as exc:
                print(f"K9 reverse photo floor unavailable: {exc}", flush=True)
            self._k9_reverse_photo_floor = own
        floor = None if own else self._k9_park_floor_texture()
        centre = k9_reverse_photo_point(0.0, EV6_REVERSE_REAR_BUMPER_Y_M + 2.56, true_camera=True)
        if own:
            x, y, w, h = k9_reverse_photo_rect()
            rl.draw_texture_pro(own, rl.Rectangle(0, 0, own.width, own.height), rl.Rectangle(x, y, w, h),
                                rl.Vector2(0, 0), 0.0, rl.WHITE)
            ground = getattr(self, "_k9_reverse_photo_ground", None)
            if ground is None:
                ground = False
                try:
                    if K9_REVERSE_PHOTO_GROUND_PATH.is_file():
                        texture = rl.load_texture(str(K9_REVERSE_PHOTO_GROUND_PATH))
                        if getattr(texture, "id", 0) > 0:
                            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
                            ground = texture
                except Exception as exc:
                    print(f"K9 reverse photo ground unavailable: {exc}", flush=True)
                self._k9_reverse_photo_ground = ground
            if ground:
                rl.draw_texture_pro(ground, rl.Rectangle(0, 0, ground.width, ground.height), rl.Rectangle(x, y, w, h),
                                    rl.Vector2(0, 0), 0.0, rl.WHITE)
        elif floor is not None and centre is not None:
            centre = (K9_REVERSE_PHOTO_OFFSET[0] + K9_REVERSE_PHOTO_SCALE * K9_REVERSE_PHOTO_CAR_CX_PX, centre[1])
            fw = K9_REVERSE_PHOTO_CAR_W_PX * K9_REVERSE_PHOTO_SCALE * K9_REVERSE_PHOTO_FLOOR_W
            fh = fw * floor.height / floor.width
            rl.draw_texture_pro(floor, rl.Rectangle(0, 0, floor.width, floor.height),
                                rl.Rectangle(centre[0] - fw / 2, centre[1] - fh * 0.55, fw, fh), rl.Vector2(0, 0), 0.0,
                                rl.WHITE)

        bumper = EV6_REVERSE_REAR_BUMPER_Y_M + K9_REVERSE_PHOTO_PATH_UNDER_M
        path = []  # from just under the rear bumper
        for a, b in zip(points, points[1:], strict=False):
            if b[1] > bumper:
                continue
            if a[1] > bumper:
                u = (a[1] - bumper) / (a[1] - b[1])
                a = (a[0] + (b[0] - a[0]) * u, bumper, a[2] + (b[2] - a[2]) * u)
            if not path:
                path.append(a)
            path.append(b)

        def side(point, offset):
            px, py, heading = point
            return k9_reverse_photo_point(px + math.cos(heading) * offset, py - math.sin(heading) * offset)

        def quad(a, b, c, d, color):
            if None in (a, b, c, d):
                return
            va, vb, vc, vd = (rl.Vector2(*p) for p in (a, b, c, d))
            for tri in ((va, vb, vc), (va, vc, vd), (va, vc, vb), (va, vd, vc)):  # both windings
                rl.draw_triangle(*tri, color)

        half_w = EV6_REVERSE_HALF_WIDTH_M
        for active, sign in ((right_bsd, 1.0), (left_bsd, -1.0)):
            if not active:
                continue
            inner0, step, front, rear = K9_REVERSE_PHOTO_BAND
            for i in range(6):  # amber band fading outward along that side of the car
                inner, outer = sign * (inner0 + i * step), sign * (inner0 + (i + 1) * step)
                corners = [k9_reverse_photo_point(xx, yy, true_camera=True)
                           for xx, yy in ((inner, front), (outer, front), (outer, rear), (inner, rear))]
                quad(*corners, rl.Color(*warn, int(170 * (1 - i / 6))))
        def fade(a, b):  # soft start under the bumper instead of a hard edge
            return min(1.0, max(0.0, (bumper - (a[1] + b[1]) / 2.0) / K9_REVERSE_PHOTO_PATH_FADE_M))

        steps = []  # fade zone cut into short pieces so the ramp is smooth
        for a, b in zip(path, path[1:], strict=False):
            n = 1 if fade(a, b) >= 1.0 else 8
            for i in range(n):
                u0, u1 = i / n, (i + 1) / n
                steps.append((tuple(a[k] + (b[k] - a[k]) * u0 for k in range(3)),
                              tuple(a[k] + (b[k] - a[k]) * u1 for k in range(3))))

        fill_a = 46 if dark else 34
        for a, b in steps:
            quad(side(a, -half_w), side(a, half_w), side(b, half_w), side(b, -half_w),
                 rl.Color(*accent, int(round(fill_a * fade(a, b)))))
        for offset in (-half_w, half_w):
            for a, b in steps:
                quad(side(a, offset - 0.07), side(a, offset + 0.07), side(b, offset + 0.07), side(b, offset - 0.07),
                     rl.Color(*accent, int(round(230 * fade(a, b)))))
        label_offset = half_w + 0.45 if steering_deg > 0.0 else -half_w - 0.45
        labels = []
        for distance_m, color in EV6_REVERSE_MARKS:
            point = points[self._ev6_reverse_mark_index(distance_m)]
            ax, ay = -math.sin(point[2]) * 0.12, -math.cos(point[2]) * 0.12
            a_, b_ = (point[0], point[1], point[2]), (point[0] + ax, point[1] + ay, point[2])
            quad(side(a_, -half_w - 0.05), side(a_, half_w + 0.05), side(b_, half_w + 0.05), side(b_, -half_w - 0.05),
                 rl.Color(*color, 235))
            label = side(point, label_offset)
            if label is not None:
                labels.append((f"{distance_m:.0f}m", label[0], label[1]))
        return labels

    def _k9_prepare_reverse_sprite(self) -> bool:
        texture = None
        try:
            texture = rl.load_texture(str(K9_REVERSE_CAR_SPRITE_PATH))
            if texture.id == 0:
                return False
            rl.gen_texture_mipmaps(texture)
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            rect = self._k9_reverse_car_rect(self._ev6_reverse_camera(True), int(self.width), int(self.height))
            self._ev6_reverse_sprite = (texture, rect)
            texture = None
            self._k9_reverse_layers = self._k9_load_reverse_layers()
            return True
        except Exception as exc:
            print(f"K9 reverse car image unavailable, using the 3D model: {exc}", flush=True)
            return False
        finally:
            if texture is not None:
                rl.unload_texture(texture)

    @staticmethod
    def _k9_load_reverse_layers():
        """Shadow and front wheel images of the K9 R car; None (body image only) if either is missing."""
        layers = []
        try:
            for path in (K9_REVERSE_CAR_SHADOW_PATH, K9_REVERSE_WHEEL_PATH):
                if not path.is_file():
                    return None
                layer = rl.load_texture(str(path))
                if layer.id == 0:
                    return None
                layers.append(layer)
                rl.gen_texture_mipmaps(layer)
                rl.set_texture_filter(layer, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            result, layers = tuple(layers), []
            return result
        except Exception as exc:
            print(f"K9 reverse car layers unavailable: {exc}", flush=True)
            return None
        finally:
            for layer in layers:
                rl.unload_texture(layer)

    def _k9_draw_reverse_car(self, sprite, camera, steering_deg: float) -> None:
        """K9 R car: floor shadow, the two front tyres turned by steering / 14.5 (display only), then the body."""
        texture, (car_x, car_y, car_w, car_h) = sprite
        layers = getattr(self, "_k9_reverse_layers", None)
        if layers:
            shadow, wheel = layers
            rl.draw_texture_pro(shadow, rl.Rectangle(0, 0, shadow.width, shadow.height),
                                rl.Rectangle(car_x, car_y, car_w, car_h), rl.Vector2(0, 0), 0.0, rl.WHITE)
            ppm = car_w / (K9_REVERSE_CAR_SIZE_M[0] + 2 * K9_REVERSE_CAR_PAD_M)  # screen px per metre
            w_px, h_px = wheel.width / K9_REVERSE_SPRITE_PPM * ppm, wheel.height / K9_REVERSE_SPRITE_PPM * ppm
            # positive steering = wheels to the left: the tyre front (screen left) turns to the car's left (screen down)
            angle = -steering_deg / K9_REVERSE_DISPLAY_STEER_RATIO
            axle_y = EV6_REVERSE_REAR_BUMPER_Y_M + K9_REVERSE_FRONT_AXLE_FROM_REAR_M
            # 대감님 11/13 00:20: a turned tyre stays under the fender - its centre moves inward by the extra width the
            # turned corners would stick out (display only), so only K9_REVERSE_WHEEL_PEEK_M more shows past the body
            half_len = wheel.width / K9_REVERSE_SPRITE_PPM / 2 - K9_REVERSE_WHEEL_PAD_M
            half_w = wheel.height / K9_REVERSE_SPRITE_PPM / 2 - K9_REVERSE_WHEEL_PAD_M
            turn = math.radians(abs(angle))
            inward = max(0.0, half_w * math.cos(turn) + half_len * math.sin(turn) - half_w - K9_REVERSE_WHEEL_PEEK_M)
            for x in (-K9_REVERSE_FRONT_TRACK_M / 2 + inward, K9_REVERSE_FRONT_TRACK_M / 2 - inward):
                c = rl.get_world_to_screen_ex(rl.Vector3(x, axle_y, 0.0), camera, int(self.width), int(self.height))
                rl.draw_texture_pro(wheel, rl.Rectangle(0, 0, wheel.width, wheel.height),
                                    rl.Rectangle(c.x, c.y, w_px, h_px), rl.Vector2(w_px / 2, h_px / 2), angle, rl.WHITE)
        rl.draw_texture_pro(texture, rl.Rectangle(0, 0, texture.width, texture.height),
                            rl.Rectangle(car_x, car_y, car_w, car_h), rl.Vector2(0, 0), 0.0, rl.WHITE)

    def _ev6_draw_reverse_screen(self, state: ClusterUiState) -> None:
        theme = self._current_theme()
        dark = theme.is_dark
        colors = EV6_PARK_COLORS_DARK if dark else EV6_PARK_COLORS_LIGHT
        path_accent = colors["accent"]  # reverse path colour stays the same for every car
        is_k9 = ego_model_name(str(getattr(state, "car_fingerprint", "") or "")) == "k9"
        k9_look = dark and is_k9
        if k9_look:
            colors = K9_PARK_COLORS_DARK  # K9 P and R are one pair: same blue background, text and lines
        rl.clear_background(rl_color(colors["bg_bot"]))
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        rl.draw_rectangle_gradient_v(0, 0, DESIGN_WIDTH, DESIGN_HEIGHT, rl_color(colors["bg_top"]), rl_color(colors["bg_bot"]))
        rl.rl_pop_matrix()
        photo = is_k9 and bool(getattr(self, "_k9_reverse_photo", False)) and bool(getattr(self, "_ev6_reverse_sprite", None))
        if k9_look and not photo:
            # floor under the car like the P stage: soft lighter pool and a thin rim, below path and car
            fx, fy, fw, fh = self._k9_reverse_car_rect(self._ev6_reverse_camera(True), int(self.width), int(self.height))
            cx, cy = int(fx + fw / 2), int(fy + fh / 2)
            pool = k9_park_darken((70, 120, 210))
            for i in range(10):
                k = 1.0 - i / 10.0
                rl.draw_ellipse(cx, cy, fw * (0.34 + 0.16 * k), fh * (0.50 + 0.22 * k), rl.Color(*pool, 18))
            rl.draw_ellipse_lines(cx, cy, fw * 0.52, fh * 0.74, rl.Color(*K9_PARK_COLORS_DARK["accent"], 60))

        steering_deg = float(getattr(state, "steering_angle_deg", None) or 0.0)
        left_bsd = bool(getattr(state, "left_blindspot", False))
        right_bsd = bool(getattr(state, "right_blindspot", False))
        points = self.ev6_reverse_path(steering_deg, str(getattr(state, "car_fingerprint", "") or ""))
        accent = path_accent
        warn = EV6_REVERSE_WARN

        camera = self._ev6_reverse_camera(is_k9)
        sprite = getattr(self, "_ev6_reverse_sprite", None)

        def side(point, offset, z):
            px, py, heading = point
            return rl.Vector3(px + math.cos(heading) * offset, py - math.sin(heading) * offset, z)

        def quad(a, b, c, d, color):
            for tri in ((a, b, c), (a, c, d), (a, c, b), (a, d, c)):  # both windings: no culling surprises
                rl.draw_triangle_3d(*tri, color)

        half_w = EV6_REVERSE_HALF_WIDTH_M
        photo_labels = None
        if photo:
            rl.rl_push_matrix()
            rl.rl_scalef(sx, sy, 1.0)
            try:
                photo_labels = self._k9_draw_reverse_photo_floor(points, steering_deg, left_bsd, right_bsd, accent, warn,
                                                                 dark)
            finally:
                rl.rl_pop_matrix()
            texture, (car_x, car_y, car_w, car_h) = sprite
            rl.draw_texture_pro(texture, rl.Rectangle(0, 0, texture.width, texture.height),
                                rl.Rectangle(car_x, car_y, car_w, car_h), rl.Vector2(0, 0), 0.0, rl.WHITE)
        else:
            self._ev6_draw_reverse_floor_3d(state, camera, sprite, points, half_w, accent, warn, dark, left_bsd,
                                            right_bsd, steering_deg, is_k9)
        mark_labels = photo_labels if photo else self._ev6_reverse_mark_labels(points, camera, steering_deg, is_k9, sx, sy)

        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        try:
            def text(value, x, y, size, color, anchor="left"):
                self._draw_text(value, x, y, size, colors[color] if isinstance(color, str) else color, anchor)

            for label, x, y in mark_labels:
                text(label, x, y, 24, "muted", "center")
            self._ev6_draw_reverse_texts(state, colors, steering_deg, left_bsd, right_bsd, warn, text)
        finally:
            rl.rl_pop_matrix()

    def _ev6_draw_reverse_floor_3d(self, state, camera, sprite, points, half_w, accent, warn, dark, left_bsd, right_bsd,
                                   steering_deg, is_k9) -> None:
        def side(point, offset, z):
            px, py, heading = point
            return rl.Vector3(px + math.cos(heading) * offset, py - math.sin(heading) * offset, z)

        def quad(a, b, c, d, color):
            for tri in ((a, b, c), (a, c, d), (a, c, b), (a, d, c)):  # both windings: no culling surprises
                rl.draw_triangle_3d(*tri, color)

        rl.begin_mode_3d(camera)
        try:
            fill = rl.Color(*accent, 46 if dark else 34)
            for a, b in zip(points, points[1:], strict=False):
                quad(side(a, -half_w, 0.01), side(a, half_w, 0.01), side(b, half_w, 0.01), side(b, -half_w, 0.01), fill)
            line = rl.Color(*accent, 230)
            for offset in (-half_w, half_w):
                for a, b in zip(points, points[1:], strict=False):
                    quad(side(a, offset - 0.07, 0.02), side(a, offset + 0.07, 0.02),
                         side(b, offset + 0.07, 0.02), side(b, offset - 0.07, 0.02), line)
            for distance_m, color in EV6_REVERSE_MARKS:
                point = points[self._ev6_reverse_mark_index(distance_m)]
                ahead_x, ahead_y = -math.sin(point[2]) * 0.12, -math.cos(point[2]) * 0.12
                a, b = side(point, -half_w - 0.05, 0.03), side(point, half_w + 0.05, 0.03)
                quad(a, b, rl.Vector3(b.x + ahead_x, b.y + ahead_y, 0.03), rl.Vector3(a.x + ahead_x, a.y + ahead_y, 0.03),
                     rl.Color(*color, 235))
            for active, sign in ((right_bsd, 1.0), (left_bsd, -1.0)):
                if not active:
                    continue
                for i in range(6):  # amber band fading outward along that side of the car
                    inner = sign * (1.15 + i * 0.12)
                    outer = sign * (1.27 + i * 0.12)
                    quad(rl.Vector3(inner, 2.2, 0.01), rl.Vector3(outer, 2.2, 0.01), rl.Vector3(outer, -2.5, 0.01),
                         rl.Vector3(inner, -2.5, 0.01), rl.Color(*warn, int(170 * (1 - i / 6))))
            if not sprite:
                self._ev6_draw_reverse_car_model(state)  # fallback until the car image exists
        finally:
            rl.end_mode_3d()
        if sprite and is_k9:
            self._k9_draw_reverse_car(sprite, camera, steering_deg)
        elif sprite:
            texture, (car_x, car_y, car_w, car_h) = sprite
            rl.draw_texture_pro(texture, rl.Rectangle(0, 0, texture.width, texture.height),
                                rl.Rectangle(car_x, car_y, car_w, car_h), rl.Vector2(0, 0), 0.0, rl.WHITE)

    def _ev6_reverse_mark_labels(self, points, camera, steering_deg, is_k9, sx, sy) -> list:
        half_w = EV6_REVERSE_HALF_WIDTH_M

        def side(point, offset, z):
            px, py, heading = point
            return rl.Vector3(px + math.cos(heading) * offset, py - math.sin(heading) * offset, z)

        # 대감님 23:56 (K9): distance labels on the outer side of the bend (path turning to the car's left = screen
        # down puts them above the path), so 1m/2m/3m stay inside the screen at any steering angle
        label_offset = -half_w - 0.45
        if is_k9 and steering_deg > 0.0:
            label_offset = half_w + 0.45
        mark_labels = []
        for distance_m, _color in EV6_REVERSE_MARKS:
            point = points[self._ev6_reverse_mark_index(distance_m)]
            screen = rl.get_world_to_screen_ex(side(point, label_offset, 0.0), camera, int(self.width), int(self.height))
            mark_labels.append((f"{distance_m:.0f}m", screen.x / sx, screen.y / sy))
        return mark_labels

    def _ev6_draw_reverse_texts(self, state, colors, steering_deg, left_bsd, right_bsd, warn, text) -> None:
        if True:
            korean = self.language == CLUSTER_LANGUAGE_KO
            text("R", 70, 150, 140, "text")
            text("후진" if korean else "Reverse", 190, 180, 34, "muted")
            speed = display_speed(abs(state.speed_kph), self.is_metric)
            text(f"{speed:.0f}", 70, 330, 84, "text")
            text(speed_unit(self.is_metric), 150 if speed < 9.5 else 190, 350, 30, "muted")

            x0, x1 = 1500, 1860
            if abs(steering_deg) < 5.0:
                steer_text = "가운데" if korean else "Centre"
            elif korean:
                steer_text = f"{'왼쪽' if steering_deg > 0 else '오른쪽'} {abs(steering_deg):.0f}°"
            else:
                steer_text = f"{'Left' if steering_deg > 0 else 'Right'} {abs(steering_deg):.0f}°"
            text("핸들" if korean else "Wheel", x0, 110, 28, "muted")
            text(steer_text, x1, 110, 40, "text", "right")
            rl.draw_line_ex(rl.Vector2(x0, 150), rl.Vector2(x1, 150), 2, rl_color(colors["line"]))
            text("후측방" if korean else "Blind spot", x0, 200, 28, "muted")
            for i, (label, active) in enumerate((("좌" if korean else "L", left_bsd), ("우" if korean else "R", right_bsd))):
                cx = 1700 + i * 130
                rl.draw_circle(cx, 200, 14, rl_color(warn if active else colors["line"]))
                text(label, cx + 26, 200, 28, "text" if active else "muted")
            text("후방 카메라와 주변을 함께 확인하세요" if korean else "Check the rear camera and surroundings",
                 x0, 420, 24, "muted")

    @staticmethod
    def _ev6_reverse_mark_index(distance_m: float) -> int:
        travelled = distance_m + EV6_REVERSE_REAR_AXLE_Y_M - EV6_REVERSE_REAR_BUMPER_Y_M  # metres behind the bumper
        return max(0, min(EV6_REVERSE_PATH_STEPS, int(round(travelled / EV6_REVERSE_PATH_LENGTH_M * EV6_REVERSE_PATH_STEPS))))

    def _prepare_trip_report_cache(self, state: ClusterUiState, now: float | None = None) -> None:
        """Refresh the expensive trip-report panel outside the active frame target."""
        if self._ev6_park_screen_active(state) or self._ev6_reverse_screen_active(state):
            self._load_park_vehicle_models()
            self._prepare_park_model_texture(state)
            self._ev6_prepare_reverse_sprite(state)
            self._trip_report_cache_visible = False
            return
        if self.taxi_meter_enabled and self._taxi_meter_panel_active(self._effective_screen_mode(state)):
            self._trip_report_cache_visible = False
            return
        if self._effective_screen_mode(state) != CLUSTER_SCREEN_MODE_TRIP_REPORT:
            self._trip_report_cache_visible = False
            return

        refresh_time = time.monotonic() if now is None else float(now)
        theme = self._current_theme()
        cache_key = (
            theme,
            self.language,
            self.is_metric,
            self.panel_layout,
            int(self.width),
            int(self.height),
        )
        needs_refresh = (
            not self._trip_report_cache_visible
            or not self._trip_report_cache_valid
            or self._trip_report_target is None
            or self._trip_report_cache_key != cache_key
            or refresh_time >= self._trip_report_cache_next_refresh
        )
        if needs_refresh:
            profile_stage = self._profile_start()
            self._refresh_trip_report_cache(state)
            self._trip_report_cache_key = cache_key
            self._trip_report_cache_valid = True
            self._trip_report_cache_next_refresh = refresh_time + TRIP_REPORT_CACHE_REFRESH_SECONDS
            self._profile_add("trip_report_cache.refresh", profile_stage)
        self._trip_report_cache_visible = True

    def _refresh_trip_report_cache(self, state: ClusterUiState) -> None:
        target_width = int(round(TRIP_REPORT_PANEL_W))
        target_height = int(round(TRIP_REPORT_PANEL_H))
        if self._trip_report_target is None:
            self._trip_report_target = rl.load_render_texture(target_width, target_height)
            rl.set_texture_filter(
                self._trip_report_target.texture,
                rl.TextureFilter.TEXTURE_FILTER_BILINEAR,
            )

        panel_x = self._information_panel_x(TRIP_REPORT_PANEL_X)
        rl.begin_texture_mode(self._trip_report_target)
        try:
            rl.clear_background(rl_color((0, 0, 0, 0)))
            rl.rl_push_matrix()
            rl.rl_translatef(-panel_x, -TRIP_REPORT_PANEL_Y, 0.0)
            try:
                self._draw_trip_report_panel_contents(state)
            finally:
                rl.rl_pop_matrix()
        finally:
            rl.end_texture_mode()

    def _clear_world(self) -> None:
        theme = self._current_theme()
        profile_stage = self._profile_start()
        rl.clear_background(rl_color(theme.bg))
        self._profile_add("render_world.clear_background", profile_stage)

    def _render_world(self, state: ClusterUiState, signal_lights: tuple[bool, bool] | None = None) -> None:
        if signal_lights is None:
            signal_lights = self._turn_signal_lights(state)
        if not cluster_camera_view_is_road_camera(state.camera_view_mode) or not state.onroad:
            self._close_live_road_camera()
        theme = self._current_theme()
        profile_stage = self._profile_start()
        scene = self._scene_for_state(
            state,
            self._highlight_lane_lit(state, signal_lights),
            theme,
            getattr(self, "_lane_confidence_held_indices", frozenset()),
            getattr(self, "_road_edge_held_sides", frozenset()),
        )
        self._profile_add("render_world.build_scene", profile_stage)
        profile_stage = self._profile_start()
        rl.clear_background(rl_color(theme.bg))
        self._profile_add("render_world.clear_background", profile_stage)
        if cluster_camera_view_is_road_camera(state.camera_view_mode):
            self._camera_overlay_wide = self._select_camera_overlay_stream(state)
            projection = self._camera_overlay_projection(state)
            profile_stage = self._profile_start()
            self._draw_camera_background(state, projection)
            self._profile_add("render_world.camera_background", profile_stage)
            profile_stage = self._profile_start()
            self._draw_camera_projected_overlay(scene, state, projection)
            self._profile_add("render_world.camera_projected_overlay", profile_stage)
        else:
            self._camera_overlay_wide = False
            profile_stage = self._profile_start()
            self._draw_scene(scene, state)
            self._profile_add("render_world.draw_scene", profile_stage)

    def _scene_for_state(
        self,
        state: ClusterUiState,
        highlight_lane_lit: bool,
        theme: ClusterTheme,
        held_lane_indices: frozenset[int] = frozenset(),
        held_road_edge_sides: frozenset[str] = frozenset(),
    ) -> ClusterScene:
        cache_key = (
            *cluster_scene_state_key(state),
            highlight_lane_lit,
            theme,
            held_lane_indices,
            held_road_edge_sides,
            clean_ui_enabled(),
        )
        if self._scene_cache is not None and cache_key == self._scene_cache_key:
            return self._scene_cache
        scene = build_cluster_scene(
            state,
            self._profile_add_elapsed if self.profile_enabled else None,
            highlight_lane_lit=highlight_lane_lit,
            theme=theme,
            held_lane_indices=held_lane_indices,
            held_road_edge_sides=held_road_edge_sides,
        )
        self._scene_cache_key = cache_key
        self._scene_cache = scene
        return scene

    def _draw_camera_background(
        self,
        state: ClusterUiState,
        projection: CameraOverlayProjection | None = None,
    ) -> None:
        if not cluster_camera_view_is_road_camera(state.camera_view_mode):
            return
        overlay = state.route_overlay
        if projection is None:
            projection = self._camera_overlay_projection(state)
        if projection is None:
            return
        texture = None
        if overlay is not None and overlay.video_rgba is not None:
            texture = self._route_video_texture_for_overlay(overlay)
        rl.begin_scissor_mode(
            int(round(projection.dest.x)),
            int(round(projection.dest.y)),
            int(round(projection.dest.width)),
            int(round(projection.dest.height)),
        )
        try:
            drew_camera = False
            if texture is not None:
                rl.draw_texture_pro(
                    texture,
                    projection.source,
                    projection.video_dest,
                    rl.Vector2(0.0, 0.0),
                    0.0,
                    rl_color(WHITE, CAMERA_BACKGROUND_ALPHA),
                )
                drew_camera = True
            else:
                live_camera = self._live_road_camera_view() if state.onroad else None
                if live_camera is not None:
                    try:
                        drew_camera = live_camera.draw(projection.video_dest)
                    except Exception as exc:
                        print(f"Cluster live road camera failed: {exc}", flush=True)
                        self._close_live_road_camera()
            if drew_camera:
                rl.draw_rectangle_rec(projection.dest, rl_color((0, 0, 0), CAMERA_BACKGROUND_VIGNETTE_ALPHA))
                if texture is None and live_camera is not None:
                    self._draw_signal_detections(projection, live_camera)
        finally:
            rl.end_scissor_mode()

    def _draw_signal_detections(self, projection, live_camera) -> None:
        brake = self._brake_display_reader.read(live_camera.display_frame)
        if brake is not None:
            video = projection.video_dest
            if brake.get('box') is not None:
                x, y, w, h = project_box(brake['box'], (video.x, video.y, video.width, video.height))
                color = (255, 100, 40) if brake['state'] == 'candidate' else (180, 180, 180)
                rl.draw_rectangle_lines_ex(rl.Rectangle(x-2, y-2, w+4, h+4), 2., rl_color(color))
                label = 'BRAKE?' if brake['state'] == 'candidate' else 'BRK?'
                self._draw_text_with_stroke(label, x, max(projection.dest.y+20, y-15),
                                            max(14., self.height / DESIGN_HEIGHT * 17.), color, (0, 0, 0), 2)
        reader = self._signal_display_reader
        tracks = reader.read(live_camera.display_frame)
        if not reader.enabled:
            return
        dest = projection.dest
        video = projection.video_dest
        font_size = max(14., self.height / DESIGN_HEIGHT * 17.)
        colors = {'red': (255, 65, 65), 'green': (50, 255, 120), 'unknown': (255, 210, 65)}
        letters = {'red': 'R', 'green': 'G', 'unknown': '?'}
        visible = 0
        for track in tracks:
            x, y, w, h = project_box(track['box'], (video.x, video.y, video.width, video.height))
            if x+w < dest.x or y+h < dest.y or x > dest.x+dest.width or y > dest.y+dest.height:
                continue
            visible += 1
            color = colors[track['state']]
            if track.get('held'):
                color = tuple(int(c * .65) for c in color)
            # Padding improves visibility without hiding the tiny lamp itself.
            rect = rl.Rectangle(x-2, y-2, w+4, h+4)
            rl.draw_rectangle_lines_ex(rect, 4., rl_color((0, 0, 0)))
            rl.draw_rectangle_lines_ex(rect, 2., rl_color(color))
            label_x = max(dest.x+4, min(x, dest.x+dest.width-90))
            label_y = max(dest.y+font_size*2, y-font_size*.7)
            qualifier = '~' if track.get('held') else '?' if track['state'] != 'unknown' and not track['confirmed'] else ''
            self._draw_text_with_stroke(f"{letters[track['state']]}{qualifier}", label_x, label_y,
                                        font_size, color, (0, 0, 0), 2)
        caption = f"신호 후보 {visible}" if self.language == CLUSTER_LANGUAGE_KO else f"SIGNAL CANDIDATES {visible}"
        if any(t.get('held') for t in tracks):
            caption += " · ~ 이전 판독" if self.language == CLUSTER_LANGUAGE_KO else ' · ~ PREVIOUS'
        if live_camera.is_wide:
            caption = "신호 관찰: 일반 카메라에서 표시" if self.language == CLUSTER_LANGUAGE_KO else 'SIGNAL VIEW: ROAD CAMERA ONLY'
        from openpilot.selfdrive.carrot.signal_display import signal_display_status
        color, held, online = signal_display_status()
        result = ('?', 'R', 'G', 'R+G')[color]
        status = ('이전 판독' if held else '판독 중' if online else '입력 대기') if self.language == CLUSTER_LANGUAGE_KO else ('PREVIOUS' if held else 'LIVE' if online else 'WAITING')
        caption += f' | {result} {status}'
        if brake is not None:
            caption += ' | BRAKE?' if brake['state'] == 'candidate' else ' | BRK ?'
        self._draw_text_with_stroke(caption, dest.x+12, dest.y+font_size, font_size,
                                    (230, 230, 230), (0, 0, 0), 2)
        reader.record_draw(live_camera.display_frame, visible)

    def _live_road_camera_view(self):
        live_camera = getattr(self, "_live_road_camera", None)
        if live_camera is not None:
            return live_camera
        if getattr(self, "_live_road_camera_failed", False) or os.name != "posix":
            return None
        try:
            from cluster_live_camera import LiveRoadCamera

            self._live_road_camera = LiveRoadCamera()
        except Exception as exc:
            print(f"Cluster live road camera disabled: {exc}", flush=True)
            self._live_road_camera_failed = True
        return self._live_road_camera

    def _select_camera_overlay_stream(self, state: ClusterUiState) -> bool:
        overlay = getattr(state, "route_overlay", None)
        if overlay is not None and overlay.video_rgba is not None:
            return overlay.camera_stream == "wide"
        live_camera = self._live_road_camera_view() if state.onroad else None
        if live_camera is None:
            return False
        prefer_wide = cluster_camera_view_prefers_wide(
            state.camera_view_mode,
            state.speed_kph,
            live_camera.is_wide,
        )
        try:
            return bool(live_camera.select_stream(prefer_wide))
        except Exception as exc:
            print(f"Cluster live camera stream selection failed: {exc}", flush=True)
            self._close_live_road_camera()
            return False

    def _close_live_road_camera(self) -> None:
        live_camera = getattr(self, "_live_road_camera", None)
        if live_camera is not None:
            live_camera.close()
            self._live_road_camera = None

    def _camera_overlay_content_rect(self) -> rl.Rectangle:
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        return rl.Rectangle(
            (CAMERA_BACKGROUND_X + self._driving_panel_offset_design_x()) * sx,
            CAMERA_BACKGROUND_Y * sy,
            CAMERA_BACKGROUND_W * sx,
            CAMERA_BACKGROUND_H * sy,
        )

    @staticmethod
    def _camera_overlay_camera(state: ClusterUiState, wide_camera: bool = False):
        device_type = (state.camera_device_type or "").strip().lower()
        sensor = (state.camera_sensor or "").strip().lower()
        for key in ((device_type, sensor), ("unknown", sensor), (device_type, "unknown")):
            device_camera = DEVICE_CAMERAS.get(key)
            if device_camera is not None:
                camera = device_camera.ecam if wide_camera else device_camera.fcam
                return camera if camera.width > 0 and camera.height > 0 else device_camera.fcam
        if sensor:
            for (_, known_sensor), device_camera in DEVICE_CAMERAS.items():
                if known_sensor == sensor:
                    camera = device_camera.ecam if wide_camera else device_camera.fcam
                    return camera if camera.width > 0 and camera.height > 0 else device_camera.fcam
        default_device_camera = DEVICE_CAMERAS["tici", "ar0231"]
        return default_device_camera.ecam if wide_camera else CAMERA_OVERLAY_DEFAULT_CAMERA

    def _camera_overlay_projection(self, state: ClusterUiState) -> CameraOverlayProjection | None:
        overlay = state.route_overlay
        dest = self._camera_overlay_content_rect()
        roll = pitch = yaw = 0.0
        if state.camera_calibration_euler is not None and len(state.camera_calibration_euler) >= 3:
            roll, pitch, yaw = state.camera_calibration_euler
        pitch += math.radians(self.camera_overlay_pitch_offset_deg)

        device_from_road = rot_from_euler([roll, pitch, yaw]).dot(np.diag([1.0, -1.0, -1.0]))
        wide_camera = bool(getattr(self, "_camera_overlay_wide", False))
        if wide_camera and state.wide_camera_from_device_euler is not None:
            wide_from_device = rot_from_euler(state.wide_camera_from_device_euler)
            view_from_road = view_frame_from_device_frame.dot(wide_from_device).dot(device_from_road)
        else:
            view_from_road = view_frame_from_device_frame.dot(device_from_road)
        camera = self._camera_overlay_camera(state, wide_camera)
        source_width = (
            float(overlay.video_width)
            if overlay is not None and overlay.video_width > 0
            else float(camera.width)
        )
        source_height = (
            float(overlay.video_height)
            if overlay is not None and overlay.video_height > 0
            else float(camera.height)
        )
        intrinsic = camera.intrinsics
        calib_transform = intrinsic @ view_from_road
        kep = calib_transform @ np.array([1000.0, 0.0, 0.0])
        zoom = max(dest.width / float(camera.width), dest.height / float(camera.height))
        if wide_camera:
            zoom *= cluster_wide_camera_zoom_factor(state.speed_kph)
        cx = float(intrinsic[0, 2])
        cy = float(intrinsic[1, 2])
        max_x_offset = max(0.0, cx * zoom - dest.width * 0.5)
        max_y_offset = max(0.0, cy * zoom - dest.height * 0.5)
        x_offset = 0.0
        y_offset = 0.0
        if abs(float(kep[2])) > 1e-6:
            x_offset = clamp((float(kep[0]) / float(kep[2]) - cx) * zoom, -max_x_offset, max_x_offset)
            y_offset = clamp((float(kep[1]) / float(kep[2]) - cy) * zoom, -max_y_offset, max_y_offset)
        video_tx = (dest.width * 0.5 + dest.x - x_offset) - cx * zoom
        rendered_height = float(camera.height) * zoom
        vertical_crop = max(0.0, rendered_height - dest.height)
        video_ty = dest.y - y_offset - vertical_crop * CAMERA_BACKGROUND_VERTICAL_BIAS
        video_dest = rl.Rectangle(
            video_tx,
            video_ty,
            float(camera.width) * zoom,
            rendered_height,
        )
        camera_height_m = CAMERA_OVERLAY_DEFAULT_HEIGHT_M
        if state.road_transform_trans is not None and len(state.road_transform_trans) >= 3:
            height_m = float(state.road_transform_trans[2])
            if math.isfinite(height_m):
                camera_height_m = clamp(height_m, 0.5, 3.0)
        return CameraOverlayProjection(
            dest=dest,
            source=rl.Rectangle(0.0, 0.0, source_width, source_height),
            video_dest=video_dest,
            camera_width=float(camera.width),
            camera_height=float(camera.height),
            focal_length=float(camera.focal_length),
            zoom=zoom,
            video_tx=video_tx,
            video_ty=video_ty,
            view_from_road=tuple(tuple(float(value) for value in row) for row in view_from_road),
            camera_height_m=camera_height_m,
            wide_camera=wide_camera,
        )

    def _camera_overlay_screen_xy(
        self,
        point: Vec3,
        projection: CameraOverlayProjection,
        scene_shift_x_m: float = 0.0,
    ) -> tuple[float, float] | None:
        # Scene geometry is shifted forward for the synthetic 3D camera. Camera
        # projection uses the physical road coordinate whose origin is the ego.
        road_forward = float(point.y) - EGO_FORWARD_M
        road_left = -float(point.x + scene_shift_x_m)
        road_up = float(point.z) + self.camera_overlay_z_offset_m
        if road_forward <= CAMERA_OVERLAY_MIN_DEPTH_M:
            return None

        row_x, row_y, row_z = projection.view_from_road
        view_x = row_x[0] * road_forward + row_x[1] * road_left + row_x[2] * road_up
        view_y = (
            row_y[0] * road_forward
            + row_y[1] * road_left
            + row_y[2] * road_up
            + projection.camera_height_m
        )
        view_z = row_z[0] * road_forward + row_z[1] * road_left + row_z[2] * road_up
        if view_z <= CAMERA_OVERLAY_MIN_DEPTH_M or not (
            math.isfinite(view_x) and math.isfinite(view_y) and math.isfinite(view_z)
        ):
            return None

        camera_x = projection.focal_length * view_x / view_z + projection.camera_width * 0.5
        camera_y = projection.focal_length * view_y / view_z + projection.camera_height * 0.5
        screen_x = projection.zoom * camera_x + projection.video_tx
        screen_y = projection.zoom * camera_y + projection.video_ty
        clip_margin = 60.0
        if (
            screen_x < projection.dest.x - clip_margin
            or screen_x > projection.dest.x + projection.dest.width + clip_margin
            or screen_y < projection.dest.y - clip_margin
            or screen_y > projection.dest.y + projection.dest.height + clip_margin
        ):
            return None
        return screen_x, screen_y

    def _draw_camera_projected_overlay(
        self,
        scene: ClusterScene,
        state: ClusterUiState,
        projection: CameraOverlayProjection | None = None,
    ) -> None:
        if projection is None:
            projection = self._camera_overlay_projection(state)
        if projection is None:
            return

        rl.begin_scissor_mode(
            int(round(projection.dest.x)),
            int(round(projection.dest.y)),
            int(round(projection.dest.width)),
            int(round(projection.dest.height)),
        )
        try:
            profile_stage = self._profile_start()
            for strip in scene.highlight_lanes:
                self._draw_camera_overlay_strip(strip, projection, scene.scene_shift_x_m)
            for strip in scene.road_edges:
                self._draw_camera_overlay_strip(strip, projection, scene.scene_shift_x_m)
            for strip in scene.lane_markings:
                self._draw_camera_overlay_strip(strip, projection, scene.scene_shift_x_m)
            for strip in scene.planned_path:
                self._draw_camera_overlay_strip(strip, projection, scene.scene_shift_x_m)
            self._profile_add("render_world.camera_projected_overlay.strips", profile_stage)
            profile_stage = self._profile_start()
            for point in scene.radar_points:
                self._draw_camera_overlay_radar_point(point, projection, scene.scene_shift_x_m, state.radar_info_mode)
            self._profile_add("render_world.camera_projected_overlay.radar", profile_stage)
            profile_stage = self._profile_start()
            metric_labels: list[VehicleMetricLabel] = []
            for vehicle in sorted(scene.vehicles, key=self._camera_overlay_vehicle_draw_key):
                self._draw_camera_overlay_vehicle(vehicle, projection, scene.scene_shift_x_m, state.radar_info_mode, metric_labels)
            self._draw_vehicle_metric_labels(metric_labels, (
                projection.dest.x, projection.dest.y,
                projection.dest.x + projection.dest.width, projection.dest.y + projection.dest.height,
            ))
            self._profile_add("render_world.camera_projected_overlay.vehicles", profile_stage)
        finally:
            rl.end_scissor_mode()

    def _draw_camera_overlay_strip(
        self,
        strip: MeshStrip,
        projection: CameraOverlayProjection,
        scene_shift_x_m: float,
    ) -> None:
        count = min(len(strip.left), len(strip.right))
        if count < 2:
            return
        color = rl_color(strip.color)
        points = self._camera_overlay_strip_point_buffer(count * 2)
        pair_visible = self._camera_overlay_strip_visibility_buffer(count)
        x_offset_m = scene_shift_x_m + strip.x_offset_m
        project_point = self._camera_overlay_screen_xy
        left_points = strip.left
        right_points = strip.right
        for index in range(count):
            pair_visible[index] = 0
            left = project_point(left_points[index], projection, x_offset_m)
            right = project_point(right_points[index], projection, x_offset_m)
            if left is None or right is None:
                continue
            left_point = points[index * 2]
            left_point.x, left_point.y = left
            right_point = points[index * 2 + 1]
            right_point.x, right_point.y = right
            pair_visible[index] = 1

        draw_triangle_strip = getattr(self, "_raw_draw_triangle_strip_2d", None)
        if draw_triangle_strip is not None:
            point_ptr = rl.ffi.cast("struct Vector2 *", points)
            index = 0
            while index < count:
                # Split at rejected endpoint pairs so batching cannot bridge a
                # gap that the legacy per-segment clipping left empty.
                while index < count and not pair_visible[index]:
                    index += 1
                start = index
                while index < count and pair_visible[index]:
                    index += 1
                pair_count = index - start
                if pair_count >= 2:
                    # L0,R0,L1,R1 expands to the same two triangles and
                    # winding as the legacy DrawTriangle pair below.
                    draw_triangle_strip(point_ptr + start * 2, pair_count * 2, color)
            return

        for index in range(count - 1):
            if not pair_visible[index] or not pair_visible[index + 1]:
                continue
            left0 = points[index * 2]
            right0 = points[index * 2 + 1]
            left1 = points[(index + 1) * 2]
            right1 = points[(index + 1) * 2 + 1]
            rl.draw_triangle(left0, right0, right1, color)
            rl.draw_triangle(left0, right1, left1, color)

    def _camera_overlay_strip_point_buffer(self, point_count: int):
        capacity = getattr(self, "_camera_overlay_strip_point_capacity", 0)
        points = getattr(self, "_camera_overlay_strip_points", None)
        if points is not None and capacity >= point_count:
            return points

        capacity = 1 << max(0, point_count - 1).bit_length()
        points = rl.ffi.new("struct Vector2[]", capacity)
        self._camera_overlay_strip_points = points
        self._camera_overlay_strip_point_capacity = capacity
        return points

    def _camera_overlay_strip_visibility_buffer(self, pair_count: int) -> bytearray:
        pair_visible = getattr(self, "_camera_overlay_strip_pair_visibility", None)
        if pair_visible is None:
            pair_visible = bytearray()
        if len(pair_visible) < pair_count:
            capacity = 1 << max(0, pair_count - 1).bit_length()
            pair_visible.extend(bytes(capacity - len(pair_visible)))
        self._camera_overlay_strip_pair_visibility = pair_visible
        return pair_visible

    def _draw_camera_overlay_vehicle(
        self,
        vehicle: VehicleBox,
        projection: CameraOverlayProjection,
        scene_shift_x_m: float,
        radar_info_mode: int,
        metric_labels: list[VehicleMetricLabel] | None = None,
    ) -> None:
        self._draw_camera_overlay_vehicle_frame(vehicle, projection, scene_shift_x_m, radar_info_mode, metric_labels)

    @staticmethod
    def _camera_overlay_vehicle_draw_key(vehicle: VehicleBox) -> tuple[int, float]:
        label = vehicle.label.upper()
        if vehicle.primary or label.startswith("L1"):
            priority = 5
        elif vehicle.cut_in or label.startswith("L2") or "CUT-IN" in label:
            priority = 4
        elif vehicle.source == "cornerRadar":
            priority = 3
        else:
            priority = 2
        return priority, -vehicle_distance_m(vehicle)

    def _draw_camera_overlay_vehicle_frame(
        self,
        vehicle: VehicleBox,
        projection: CameraOverlayProjection,
        scene_shift_x_m: float,
        radar_info_mode: int,
        metric_labels: list[VehicleMetricLabel] | None = None,
    ) -> None:
        center_y_m = vehicle.center.y + RADAR_TO_CAMERA_M + VEHICLE_LENGTH_M
        base_z = CAMERA_OVERLAY_VEHICLE_ROAD_HEIGHT_M
        center = self._camera_overlay_screen_xy(
            Vec3(vehicle.center.x, center_y_m, base_z),
            projection,
            scene_shift_x_m,
        )
        if center is None:
            return

        label = vehicle.label.upper()
        lead_two = label.startswith("L2") or "CUT-IN" in label
        lead_one = label.startswith("L1") or (vehicle.primary and not lead_two)
        emphasized = vehicle.primary or vehicle.cut_in
        half_width_m = max(0.6, vehicle.width_m * 0.58)
        frame_height_m = max(0.8, vehicle.height_m * 1.12)
        left_base = self._camera_overlay_screen_xy(
            Vec3(
                vehicle.center.x - half_width_m,
                center_y_m,
                base_z,
            ),
            projection,
            scene_shift_x_m,
        )
        right_base = self._camera_overlay_screen_xy(
            Vec3(
                vehicle.center.x + half_width_m,
                center_y_m,
                base_z,
            ),
            projection,
            scene_shift_x_m,
        )
        left_top = self._camera_overlay_screen_xy(
            Vec3(
                vehicle.center.x - half_width_m,
                center_y_m,
                base_z + frame_height_m,
            ),
            projection,
            scene_shift_x_m,
        )
        right_top = self._camera_overlay_screen_xy(
            Vec3(
                vehicle.center.x + half_width_m,
                center_y_m,
                base_z + frame_height_m,
            ),
            projection,
            scene_shift_x_m,
        )
        if left_base is None or right_base is None or left_top is None or right_top is None:
            return

        min_x = min(left_base[0], right_base[0], left_top[0], right_top[0])
        max_x = max(left_base[0], right_base[0], left_top[0], right_top[0])
        min_y = min(left_base[1], right_base[1], left_top[1], right_top[1])
        max_y = max(left_base[1], right_base[1], left_top[1], right_top[1])
        width = max_x - min_x
        height = max_y - min_y
        if not (math.isfinite(width) and math.isfinite(height)) or width <= 0.0 or height <= 0.0:
            return
        pad_x = max(4.0, width * 0.08)
        pad_y = max(4.0, height * 0.08)
        frame_width = clamp(
            width + pad_x * 2.0,
            CAMERA_OVERLAY_FRAME_MIN_SIZE_PX,
            projection.dest.width * CAMERA_OVERLAY_FRAME_MAX_WIDTH_RATIO,
        )
        frame_height = clamp(
            height + pad_y * 2.0,
            CAMERA_OVERLAY_FRAME_MIN_SIZE_PX,
            projection.dest.height * CAMERA_OVERLAY_FRAME_MAX_HEIGHT_RATIO,
        )
        if frame_width > frame_height * CAMERA_OVERLAY_FRAME_MAX_ASPECT:
            frame_width = frame_height * CAMERA_OVERLAY_FRAME_MAX_ASPECT
        elif frame_height > frame_width * CAMERA_OVERLAY_FRAME_MAX_ASPECT:
            frame_height = frame_width * CAMERA_OVERLAY_FRAME_MAX_ASPECT
        frame_center_x = (min_x + max_x) * 0.5
        frame_center_y = (min_y + max_y) * 0.5
        available_half_width = min(
            frame_center_x - projection.dest.x - CAMERA_OVERLAY_FRAME_EDGE_PAD_PX,
            projection.dest.x + projection.dest.width - frame_center_x - CAMERA_OVERLAY_FRAME_EDGE_PAD_PX,
        )
        available_half_height = min(
            frame_center_y - projection.dest.y - CAMERA_OVERLAY_FRAME_EDGE_PAD_PX,
            projection.dest.y + projection.dest.height - frame_center_y - CAMERA_OVERLAY_FRAME_EDGE_PAD_PX,
        )
        minimum_half_size = CAMERA_OVERLAY_FRAME_MIN_SIZE_PX * 0.5
        if available_half_width < minimum_half_size or available_half_height < minimum_half_size:
            return
        frame_width = min(frame_width, available_half_width * 2.0)
        frame_height = min(frame_height, available_half_height * 2.0)
        marker = rl.Rectangle(
            frame_center_x - frame_width * 0.5,
            frame_center_y - frame_height * 0.5,
            frame_width,
            frame_height,
        )

        confidence = clamp(vehicle.confidence, 0.0, 1.0)
        _fill_base, _side_base, ring_base = camera_overlay_vehicle_coin_colors(vehicle, lead_one, lead_two)
        ring_alpha = int(180 + 65 * confidence)
        rl.draw_rectangle_rounded_lines_ex(
            marker,
            0.20,
            CAMERA_OVERLAY_FRAME_ROUND_SEGMENTS,
            3.5 if emphasized else 3.0,
            rl_color(ring_base, ring_alpha),
        )

        label = self._vehicle_overlay_label(vehicle, radar_info_mode)
        if label:
            label_size = LEAD_ONE_DISTANCE_FONT_SIZE if vehicle_has_lead_one_metrics(vehicle) else 17 if emphasized else 15
            label_color = (*ring_base[:3], 255 if vehicle.primary or vehicle.cut_in else 230)
            label_y = marker.y - 12.0
            if lead_one:
                label_y = marker.y - 18.0
            elif lead_two:
                label_y = marker.y + marker.height + 16.0
            metric = VehicleMetricLabel(
                vehicle,
                (VehicleMetricLine(label, marker.x + marker.width * 0.5, max(14.0, label_y), label_size),),
                label_color,
            )
            if metric_labels is None:
                self._draw_vehicle_metric_labels([metric], (
                    projection.dest.x, projection.dest.y,
                    projection.dest.x + projection.dest.width, projection.dest.y + projection.dest.height,
                ))
            else:
                metric_labels.append(metric)

    def _vehicle_overlay_label(self, vehicle: VehicleBox, radar_info_mode: int) -> str:
        parts: list[str] = []
        stopped = camera_overlay_vehicle_is_stopped(vehicle)
        if vehicle.label and (vehicle.primary or vehicle.cut_in):
            label = vehicle.label.upper()
            if not (label.startswith("L1") or label.startswith("L2") or "CUT-IN" in label):
                parts.append(vehicle.label)
        if (stopped or radar_info_shows_distance(radar_info_mode)) and vehicle.longitudinal_m is not None:
            parts.append(format_radar_distance(vehicle.longitudinal_m, self.is_metric))
        if not stopped and radar_info_shows_speed(radar_info_mode) and vehicle.absolute_speed_kph is not None:
            parts.append(f"{display_speed(vehicle.absolute_speed_kph, self.is_metric):.0f} {speed_unit(self.is_metric)}")
        return " ".join(parts)

    def _draw_camera_overlay_radar_point(
        self,
        point: RadarPointMarker,
        projection: CameraOverlayProjection,
        scene_shift_x_m: float,
        radar_info_mode: int,
    ) -> None:
        camera_point = Vec3(point.center.x, point.center.y + RADAR_TO_CAMERA_M, point.center.z)
        screen = self._camera_overlay_screen_xy(camera_point, projection, scene_shift_x_m)
        if screen is None:
            return
        radius = max(2.5, min(5.0, 40.0 / max(6.0, abs(point.longitudinal_m))))
        marker = rl.Rectangle(
            screen[0] - radius,
            screen[1] - radius,
            radius * 2.0,
            radius * 2.0,
        )
        rl.draw_rectangle_rec(marker, rl_color(point.color, 225))
        if not radar_info_shows_radar_points(radar_info_mode):
            return
        label_parts = []
        if radar_info_shows_distance(radar_info_mode):
            label_parts.append(format_radar_distance(point.longitudinal_m, self.is_metric))
        if point.absolute_speed_kph is not None:
            label_parts.append(f"{display_speed(point.absolute_speed_kph, self.is_metric):.0f} {speed_unit(self.is_metric)}")
        if label_parts:
            self._draw_world_label_text(
                " ".join(label_parts),
                screen[0],
                screen[1] - 16.0,
                15,
                (*WHITE[:3], 220),
                anchor="center",
            )

    def render_to_file(self, state: ClusterUiState, output_path: str | Path) -> None:
        image = self._render_to_image(state)
        try:
            rl.export_image(image, str(output_path))
        finally:
            rl.unload_image(image)

    def render_to_png_bytes(self, state: ClusterUiState, portrait_upload: bool = False) -> bytes:
        profile_stage = self._profile_start()
        image = self._render_to_image(state, portrait_upload=portrait_upload)
        self._profile_add("render_to_png.render_to_image", profile_stage)
        try:
            size = rl.ffi.new("int *")
            profile_stage = self._profile_start()
            data = rl.export_image_to_memory(image, ".png", size)
            self._profile_add("render_to_png.export_png", profile_stage)
            try:
                if size[0] <= 0:
                    raise RuntimeError("raylib failed to encode frame as PNG")
                return bytes(rl.ffi.buffer(data, size[0]))
            finally:
                rl.mem_free(data)
        finally:
            profile_stage = self._profile_start()
            rl.unload_image(image)
            self._profile_add("render_to_png.unload_image", profile_stage)

    def render_to_rgba_bytes(
        self,
        state: ClusterUiState,
        portrait_upload: bool = False,
        output_width: int | None = None,
        output_height: int | None = None,
    ) -> tuple[bytes, int, int]:
        with self.render_to_rgba_buffer(
            state,
            portrait_upload=portrait_upload,
            output_width=output_width,
            output_height=output_height,
        ) as (
            rgba_buffer,
            image_width,
            image_height,
        ):
            profile_stage = self._profile_start()
            rgba = bytes(rgba_buffer)
            self._profile_add("render_to_rgba.copy_bytes", profile_stage)
            return rgba, image_width, image_height

    @contextmanager
    def render_to_rgba_buffer(
        self,
        state: ClusterUiState,
        portrait_upload: bool = False,
        output_width: int | None = None,
        output_height: int | None = None,
    ) -> Iterator[tuple[object, int, int]]:
        profile_stage = self._profile_start()
        image = self._render_to_image(
            state,
            portrait_upload=portrait_upload,
            output_width=output_width,
            output_height=output_height,
        )
        self._profile_add("render_to_rgba.render_to_image", profile_stage)

        try:
            if image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                profile_stage = self._profile_start()
                rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                self._profile_add("render_to_rgba.image_format", profile_stage)

            byte_count = image.width * image.height * 4
            profile_stage = self._profile_start()
            rgba_buffer = rl.ffi.buffer(image.data, byte_count)
            self._profile_add("render_to_rgba.buffer_view", profile_stage)
            yield rgba_buffer, image.width, image.height
        finally:
            profile_stage = self._profile_start()
            rl.unload_image(image)
            self._profile_add("render_to_rgba.unload_image", profile_stage)

    @contextmanager
    def render_to_rgba_frame(
        self,
        state: ClusterUiState,
        portrait_upload: bool = False,
    ) -> Iterator[tuple[object, int, int, bool]]:
        """render_to_rgba_buffer for the JPEG USB path, plus `unchanged` = the pixels equal the previous frame's
        (then the encoder can reuse the previous JPEG: same input, same bytes).

        Same pixels as render_to_rgba_buffer. The readback lands in one of two reused buffers (TICI: glReadPixels of
        the upload target's framebuffer, no per-frame FBO / 3.5 MB malloc), so the previous frame stays readable
        and the comparison is one memcmp that stops at the first differing byte. Elsewhere (PC) the raylib image
        of the previous frame is kept until the next frame instead of a copy."""
        if portrait_upload and self.direct_nv12_readback_available():
            target = None
            try:
                target = self._render_to_target(state, portrait_upload=True)
                width, height = int(target.texture.width), int(target.texture.height)
                byte_count = width * height * 4
                ring = self._rgba_frame_ring
                if ring is None or len(ring[0]) != byte_count:
                    ring = self._rgba_frame_ring = [bytearray(byte_count), bytearray(byte_count)]
                    self._rgba_frame_ring_index = 0
                    self._rgba_frame_prev = None
                index = self._rgba_frame_ring_index
                buffer = ring[index]
                address = _buffer_address(buffer)
                profile_stage = self._profile_start()
                self._direct_nv12_readback.read_rgba(int(target.id), width, height, address, byte_count)
                self._profile_add("render_to_rgba_frame.readback_direct", profile_stage)
            except DirectNv12ReadbackError as exc:
                print(f"Direct RGBA readback failed ({exc}); raylib readback from now on", flush=True)
                self.disable_direct_nv12_readback()
                self._rgba_frame_ring = None
                self._rgba_frame_prev = None
                if target is None:
                    raise
                image = rl.load_image_from_texture(target.texture)
                try:
                    yield rl.ffi.buffer(image.data, image.width * image.height * 4), image.width, image.height, False
                finally:
                    rl.unload_image(image)
                return
            profile_stage = self._profile_start()
            prev = self._rgba_frame_prev
            unchanged = prev is not None and prev[1] == (width, height) and self._rgba_frames_equal(address, prev[0], byte_count)
            self._profile_add("render_to_rgba_frame.compare", profile_stage)
            self._rgba_frame_prev = (address, (width, height))
            self._rgba_frame_ring_index = 1 - index
            yield buffer, width, height, unchanged
            return

        profile_stage = self._profile_start()
        image = self._render_to_image(state, portrait_upload=portrait_upload)
        self._profile_add("render_to_rgba.render_to_image", profile_stage)
        keep = False
        try:
            if image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
            byte_count = image.width * image.height * 4
            address = int(rl.ffi.cast("uintptr_t", image.data))
            profile_stage = self._profile_start()
            prev = self._rgba_frame_prev_image
            unchanged = (prev is not None and (prev.width, prev.height, prev.format) == (image.width, image.height, image.format)
                         and self._rgba_frames_equal(address, int(rl.ffi.cast("uintptr_t", prev.data)), byte_count))
            self._profile_add("render_to_rgba_frame.compare", profile_stage)
            yield rl.ffi.buffer(image.data, byte_count), image.width, image.height, unchanged
            keep = True
        finally:
            if keep:
                if self._rgba_frame_prev_image is not None:
                    rl.unload_image(self._rgba_frame_prev_image)
                self._rgba_frame_prev_image = image
            else:
                rl.unload_image(image)

    RGBA_DIFF_WINDOW = 65536

    def _rgba_frames_equal(self, a: int, b: int, n: int) -> bool:
        """Two frames equal? A moving frame usually differs where it differed last time, so that 64 KB window is
        compared first (one short memcmp); the whole frame only when the window is equal (then the window moves to
        the first differing 64 KB, found by halving)."""
        hint = self._rgba_diff_hint
        win = self.RGBA_DIFF_WINDOW
        if hint is not None and hint + win <= n and not _memequal(a + hint, b + hint, win):
            return False
        if _memequal(a, b, n):
            return True
        lo, hi = 0, n
        while hi - lo > win:
            mid = (lo + hi) // 2
            if _memequal(a + lo, b + lo, mid - lo):
                lo = mid
            else:
                hi = mid
        self._rgba_diff_hint = min(lo, max(0, n - win))
        return False

    def _release_rgba_frames(self) -> None:
        if self._rgba_frame_prev_image is not None:
            rl.unload_image(self._rgba_frame_prev_image)
            self._rgba_frame_prev_image = None
        self._rgba_frame_ring = None
        self._rgba_frame_prev = None

    @contextmanager
    def render_to_nv12_buffer(
        self,
        state: ClusterUiState,
        output_width: int,
        output_height: int,
        stride: int,
        y_scanlines: int,
        uv_scanlines: int,
        uv_offset: int,
        byte_count: int,
        buffer: bytearray | None = None,
        flip_x: bool = False,
        destination_address: int | None = None,
        destination_size: int = 0,
        async_readback: bool = False,
        destination_dmabuf_fd: int | None = None,
    ) -> Iterator[object]:
        self.open(hidden=self.hidden)
        output_width = int(output_width)
        output_height = int(output_height)
        stride = int(stride)
        y_scanlines = int(y_scanlines)
        uv_scanlines = int(uv_scanlines)
        uv_offset = int(uv_offset)
        byte_count = int(byte_count)
        if output_width <= 0 or output_height <= 0 or stride <= 0 or byte_count <= 0:
            raise RuntimeError("NV12 render target layout is invalid")
        if stride < output_width or y_scanlines < output_height or uv_scanlines < (output_height + 1) // 2:
            raise RuntimeError("NV12 render target layout is smaller than the rendered frame")
        if uv_offset < stride * y_scanlines or byte_count < uv_offset + stride * uv_scanlines:
            raise RuntimeError("NV12 render target byte layout is inconsistent")

        self._prepare_taxi_meter_cache(state)
        self._prepare_trip_report_cache(state)
        profile_stage = self._profile_start()
        target = self._get_capture_target()
        self._profile_add("render_to_nv12.get_capture_target", profile_stage)

        profile_stage = self._profile_start()
        rl.begin_texture_mode(target)
        self.render(state)
        rl.end_texture_mode()
        self._profile_add("render_to_nv12.draw_to_target", profile_stage)
        self._flush_pending_stroked_text_textures()

        profile_stage = self._profile_start()
        upload_target = self._get_portrait_upload_target(output_width, output_height)
        self._profile_add("render_to_nv12.get_portrait_upload_target", profile_stage)

        profile_stage = self._profile_start()
        rl.begin_texture_mode(upload_target)
        rl.clear_background(rl_color(self._current_theme().bg))
        source = rl.Rectangle(
            0.0,
            0.0,
            float(target.texture.width),
            float(target.texture.height),
        )
        dest = rl.Rectangle(
            0.0,
            float(self.width),
            float(self.width),
            float(self.height),
        )
        rl.draw_texture_pro(
            target.texture,
            source,
            dest,
            rl.Vector2(0.0, 0.0),
            -90.0,
            rl_color(WHITE),
        )
        rl.end_texture_mode()
        self._profile_add("render_to_nv12.gpu_upload_transform", profile_stage)

        pack_direct_input = stride % 4 == 0 and byte_count % stride == 0 and uv_offset % stride == 0
        if (destination_address is not None or async_readback or destination_dmabuf_fd is not None) and not pack_direct_input:
            raise DirectNv12ReadbackError("direct NV12 readback requires a four-byte packed Venus layout")
        if destination_address is not None and async_readback:
            raise DirectNv12ReadbackError("asynchronous NV12 readback cannot use a direct destination")
        if destination_dmabuf_fd is not None and (destination_address is not None or async_readback):
            raise DirectNv12DmabufError("encoder DMA-BUF output cannot use a readback destination")
        if pack_direct_input:
            full_pack_w = stride // 4
            full_pack_h = byte_count // stride
            tail_pack_h = max(0, full_pack_h - y_scanlines - uv_scanlines)
            uv_pack_y = tail_pack_h
            y_pack_y = tail_pack_h + uv_scanlines

            profile_stage = self._profile_start()
            if destination_dmabuf_fd is None:
                full_target = self._get_nv12_pack_target("full", full_pack_w, full_pack_h)
            else:
                dmabuf_pool = self._nv12_dmabuf_pool
                if dmabuf_pool is None:
                    raise DirectNv12DmabufError("encoder DMA-BUF render targets are unavailable")
                full_target = dmabuf_pool.target_for(destination_dmabuf_fd, stride, byte_count)
            self._profile_add("render_to_nv12.get_pack_targets", profile_stage)

            profile_stage = self._profile_start()
            self._render_nv12_pack_plane(
                upload_target.texture,
                full_target,
                output_width,
                output_height,
                0,
                flip_x,
                packed_width=full_pack_w,
                packed_height=y_scanlines,
                dest_y=y_pack_y,
                clear_target=True,
                clear_color=(128, 128, 128, 128),
            )
            self._profile_add("render_to_nv12.pack_y_shader", profile_stage)

            profile_stage = self._profile_start()
            self._render_nv12_pack_plane(
                upload_target.texture,
                full_target,
                output_width,
                output_height,
                1,
                flip_x,
                packed_width=full_pack_w,
                packed_height=uv_scanlines,
                dest_y=uv_pack_y,
                clear_target=False,
            )
            self._profile_add("render_to_nv12.pack_uv_shader", profile_stage)

            if destination_dmabuf_fd is not None:
                profile_stage = self._profile_start()
                dmabuf_pool.wait_for_gpu()
                self._profile_add("render_to_nv12.dmabuf_fence_wait", profile_stage)
                yield destination_dmabuf_fd
                return

            if async_readback:
                readback = self._direct_nv12_readback
                if readback is None or not readback.async_supported:
                    raise DirectNv12ReadbackError("TICI GLES asynchronous NV12 readback is not available")
                profile_stage = self._profile_start()
                enqueued = readback.enqueue_rgba(
                    full_target.id,
                    full_target.texture.width,
                    full_target.texture.height,
                )
                self._profile_add("render_to_nv12.readback_pbo_enqueue", profile_stage)
                yield enqueued
                return

            if destination_address is not None:
                readback = self._direct_nv12_readback
                if readback is None:
                    raise DirectNv12ReadbackError("TICI GLES direct NV12 readback is not available")
                profile_stage = self._profile_start()
                readback.read_rgba(
                    full_target.id,
                    full_target.texture.width,
                    full_target.texture.height,
                    destination_address,
                    destination_size,
                )
                self._profile_add("render_to_nv12.readback_direct_ion", profile_stage)
                yield destination_address
                return

            profile_stage = self._profile_start()
            image = rl.load_image_from_texture(full_target.texture)
            self._profile_add("render_to_nv12.readback_packed", profile_stage)

            try:
                if image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                    profile_stage = self._profile_start()
                    rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                    self._profile_add("render_to_nv12.packed_image_format", profile_stage)

                profile_stage = self._profile_start()
                nv12_buffer = rl.ffi.buffer(image.data, byte_count)
                self._profile_add("render_to_nv12.buffer_view", profile_stage)
                yield nv12_buffer
            finally:
                profile_stage = self._profile_start()
                rl.unload_image(image)
                self._profile_add("render_to_nv12.unload_image", profile_stage)
            return

        pack_full_stride = stride % 4 == 0
        if pack_full_stride:
            y_pack_w = stride // 4
            y_pack_h = y_scanlines
            uv_pack_w = stride // 4
            uv_pack_h = uv_scanlines
        else:
            y_pack_w = (output_width + 3) // 4
            y_pack_h = output_height
            uv_pack_w = (output_width + 3) // 4
            uv_pack_h = (output_height + 1) // 2
        profile_stage = self._profile_start()
        y_target = self._get_nv12_pack_target("y", y_pack_w, y_pack_h)
        uv_target = self._get_nv12_pack_target("uv", uv_pack_w, uv_pack_h)
        self._profile_add("render_to_nv12.get_pack_targets", profile_stage)

        profile_stage = self._profile_start()
        self._render_nv12_pack_plane(upload_target.texture, y_target, output_width, output_height, 0, flip_x)
        self._profile_add("render_to_nv12.pack_y_shader", profile_stage)

        profile_stage = self._profile_start()
        y_image = rl.load_image_from_texture(y_target.texture)
        self._profile_add("render_to_nv12.readback_y", profile_stage)

        profile_stage = self._profile_start()
        self._render_nv12_pack_plane(upload_target.texture, uv_target, output_width, output_height, 1, flip_x)
        self._profile_add("render_to_nv12.pack_uv_shader", profile_stage)

        profile_stage = self._profile_start()
        uv_image = rl.load_image_from_texture(uv_target.texture)
        self._profile_add("render_to_nv12.readback_uv", profile_stage)

        try:
            if y_image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                profile_stage = self._profile_start()
                rl.image_format(y_image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                self._profile_add("render_to_nv12.y_image_format", profile_stage)
            if uv_image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                profile_stage = self._profile_start()
                rl.image_format(uv_image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
                self._profile_add("render_to_nv12.uv_image_format", profile_stage)

            if buffer is None or len(buffer) != byte_count:
                buffer = bytearray(byte_count)
                buffer[:min(uv_offset, byte_count)] = b"\x10" * min(uv_offset, byte_count)
                if uv_offset < byte_count:
                    buffer[uv_offset:] = b"\x80" * (byte_count - uv_offset)

            y_row_bytes = y_pack_w * 4
            uv_row_bytes = uv_pack_w * 4
            y_data = rl.ffi.buffer(y_image.data, y_row_bytes * y_pack_h)
            uv_data = rl.ffi.buffer(uv_image.data, uv_row_bytes * uv_pack_h)

            if pack_full_stride:
                y_plane_bytes = stride * y_scanlines
                uv_plane_bytes = stride * uv_scanlines
                profile_stage = self._profile_start()
                buffer[:y_plane_bytes] = y_data[:y_plane_bytes]
                self._profile_add("render_to_nv12.copy_y", profile_stage)

                profile_stage = self._profile_start()
                buffer[uv_offset:uv_offset + uv_plane_bytes] = uv_data[:uv_plane_bytes]
                self._profile_add("render_to_nv12.copy_uv", profile_stage)
            else:
                profile_stage = self._profile_start()
                for row in range(output_height):
                    src_start = row * y_row_bytes
                    dst_start = row * stride
                    buffer[dst_start:dst_start + output_width] = y_data[src_start:src_start + output_width]
                self._profile_add("render_to_nv12.copy_y", profile_stage)

                profile_stage = self._profile_start()
                for row in range(uv_pack_h):
                    src_start = row * uv_row_bytes
                    dst_start = uv_offset + row * stride
                    buffer[dst_start:dst_start + output_width] = uv_data[src_start:src_start + output_width]
                self._profile_add("render_to_nv12.copy_uv", profile_stage)
            yield buffer
        finally:
            profile_stage = self._profile_start()
            rl.unload_image(y_image)
            rl.unload_image(uv_image)
            self._profile_add("render_to_nv12.unload_images", profile_stage)

    def _render_to_image(
        self,
        state: ClusterUiState,
        portrait_upload: bool = False,
        output_width: int | None = None,
        output_height: int | None = None,
    ):
        upload_target = self._render_to_target(state, portrait_upload, output_width, output_height)
        if portrait_upload:
            profile_stage = self._profile_start()
            image = rl.load_image_from_texture(upload_target.texture)
            self._profile_add("render_to_image.readback_upload_texture", profile_stage)
        else:
            profile_stage = self._profile_start()
            image = rl.load_image_from_texture(upload_target.texture)
            self._profile_add("render_to_image.readback_texture", profile_stage)

            profile_stage = self._profile_start()
            rl.image_flip_vertical(image)
            self._profile_add("render_to_image.flip_vertical", profile_stage)

        return image

    def _render_to_target(
        self,
        state: ClusterUiState,
        portrait_upload: bool = False,
        output_width: int | None = None,
        output_height: int | None = None,
    ):
        """Draw the frame; returns the render texture to read back (portrait upload target or the capture target)."""
        self.open(hidden=self.hidden)
        self._prepare_taxi_meter_cache(state)
        self._prepare_trip_report_cache(state)
        profile_stage = self._profile_start()
        target = self._get_capture_target()
        self._profile_add("render_to_image.get_capture_target", profile_stage)

        profile_stage = self._profile_start()
        rl.begin_texture_mode(target)
        self.render(state)
        rl.end_texture_mode()
        self._profile_add("render_to_image.draw_to_target", profile_stage)
        self._flush_pending_stroked_text_textures()

        if portrait_upload:
            profile_stage = self._profile_start()
            upload_target = self._get_portrait_upload_target(output_width, output_height)
            self._profile_add("render_to_image.get_portrait_upload_target", profile_stage)

            profile_stage = self._profile_start()
            rl.begin_texture_mode(upload_target)
            rl.clear_background(rl_color(self._current_theme().bg))
            source = rl.Rectangle(
                0.0,
                0.0,
                float(target.texture.width),
                float(target.texture.height),
            )
            dest = rl.Rectangle(
                0.0,
                float(self.width),
                float(self.width),
                float(self.height),
            )
            origin = rl.Vector2(0.0, 0.0)
            rl.draw_texture_pro(
                target.texture,
                source,
                dest,
                origin,
                -90.0,
                rl_color(WHITE),
            )
            rl.end_texture_mode()
            self._profile_add("render_to_image.gpu_upload_transform", profile_stage)
            return upload_target
        return target

    def _get_capture_target(self):
        if self._capture_target is None:
            profile_stage = self._profile_start()
            self._capture_target = rl.load_render_texture(self.width, self.height)
            self._profile_add("render_target.alloc_capture", profile_stage)
            profile_stage = self._profile_start()
            rl.set_texture_filter(self._capture_target.texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            self._profile_add("render_target.filter_capture", profile_stage)
        return self._capture_target

    def _get_portrait_upload_target(self, width: int | None = None, height: int | None = None):
        target_width = int(width or self.height)
        target_height = int(height or self.width)
        target_size = (target_width, target_height)
        if self._portrait_upload_target is not None and self._portrait_upload_target_size != target_size:
            rl.unload_render_texture(self._portrait_upload_target)
            self._portrait_upload_target = None
            self._portrait_upload_target_size = None
        if self._portrait_upload_target is None:
            profile_stage = self._profile_start()
            self._portrait_upload_target = rl.load_render_texture(target_width, target_height)
            self._portrait_upload_target_size = target_size
            self._profile_add("render_target.alloc_portrait_upload", profile_stage)
            profile_stage = self._profile_start()
            rl.set_texture_filter(self._portrait_upload_target.texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            self._profile_add("render_target.filter_portrait_upload", profile_stage)
        return self._portrait_upload_target

    def _get_nv12_pack_target(self, plane: str, width: int, height: int):
        target_size = (int(width), int(height))
        if plane == "y":
            current = self._nv12_pack_y_target
            current_size = self._nv12_pack_y_size
        elif plane == "uv":
            current = self._nv12_pack_uv_target
            current_size = self._nv12_pack_uv_size
        elif plane == "full":
            current = self._nv12_pack_full_target
            current_size = self._nv12_pack_full_size
        else:
            raise RuntimeError(f"unknown NV12 pack plane: {plane}")

        if current is not None and current_size != target_size:
            rl.unload_render_texture(current)
            current = None
            current_size = None
        if current is None:
            profile_stage = self._profile_start()
            current = rl.load_render_texture(target_size[0], target_size[1])
            self._profile_add(f"render_target.alloc_nv12_{plane}", profile_stage)
            profile_stage = self._profile_start()
            rl.set_texture_filter(current.texture, rl.TextureFilter.TEXTURE_FILTER_POINT)
            self._profile_add(f"render_target.filter_nv12_{plane}", profile_stage)
            current_size = target_size

        if plane == "y":
            self._nv12_pack_y_target = current
            self._nv12_pack_y_size = current_size
        elif plane == "uv":
            self._nv12_pack_uv_target = current
            self._nv12_pack_uv_size = current_size
        else:
            self._nv12_pack_full_target = current
            self._nv12_pack_full_size = current_size
        return current

    def _get_nv12_pack_shader(self):
        if self._nv12_pack_shader is None:
            profile_stage = self._profile_start()
            self._nv12_pack_shader = rl.load_shader_from_memory(NV12_PACK_VERTEX_SHADER, NV12_PACK_FRAGMENT_SHADER)
            self._profile_add("render_to_nv12.load_pack_shader", profile_stage)
            if not rl.is_shader_valid(self._nv12_pack_shader):
                raise RuntimeError("failed to load NV12 pack shader")
            self._nv12_pack_shader_locations = {
                "srcSize": rl.get_shader_location(self._nv12_pack_shader, "srcSize"),
                "packedSize": rl.get_shader_location(self._nv12_pack_shader, "packedSize"),
                "plane": rl.get_shader_location(self._nv12_pack_shader, "plane"),
                "flipX": rl.get_shader_location(self._nv12_pack_shader, "flipX"),
            }
        return self._nv12_pack_shader

    def _render_nv12_pack_plane(
        self,
        source_texture,
        target,
        source_width: int,
        source_height: int,
        plane: int,
        flip_x: bool,
        packed_width: int | None = None,
        packed_height: int | None = None,
        dest_y: int = 0,
        clear_target: bool = True,
        clear_color: tuple[int, int, int, int] = (0, 0, 0, 0),
    ) -> None:
        shader = self._get_nv12_pack_shader()
        locations = self._nv12_pack_shader_locations
        pack_width = int(packed_width) if packed_width is not None else int(target.texture.width)
        pack_height = int(packed_height) if packed_height is not None else int(target.texture.height)
        src_size = rl.ffi.new("float[]", [float(source_width), float(source_height)])
        packed_size = rl.ffi.new("float[]", [float(pack_width), float(pack_height)])
        plane_value = rl.ffi.new("int[]", [int(plane)])
        flip_x_value = rl.ffi.new("int[]", [1 if flip_x else 0])
        rl.set_shader_value(shader, locations["srcSize"], src_size, rl.ShaderUniformDataType.SHADER_UNIFORM_VEC2)
        rl.set_shader_value(shader, locations["packedSize"], packed_size, rl.ShaderUniformDataType.SHADER_UNIFORM_VEC2)
        rl.set_shader_value(shader, locations["plane"], plane_value, rl.ShaderUniformDataType.SHADER_UNIFORM_INT)
        rl.set_shader_value(shader, locations["flipX"], flip_x_value, rl.ShaderUniformDataType.SHADER_UNIFORM_INT)

        rl.begin_texture_mode(target)
        if clear_target:
            rl.clear_background(rl_color(clear_color))
        rl.begin_shader_mode(shader)
        rl.rl_set_blend_factors(rl.RL_ONE, rl.RL_ZERO, rl.RL_FUNC_ADD)
        rl.begin_blend_mode(rl.BlendMode.BLEND_CUSTOM)
        try:
            rl.draw_texture_pro(
                source_texture,
                rl.Rectangle(0.0, 0.0, float(source_width), float(source_height)),
                rl.Rectangle(0.0, float(dest_y), float(pack_width), float(pack_height)),
                rl.Vector2(0.0, 0.0),
                0.0,
                rl_color(WHITE),
            )
        finally:
            rl.end_blend_mode()
            rl.end_shader_mode()
            rl.end_texture_mode()

    def _load_font(self):
        glyphs = None
        glyph_count = 0
        base_size = 160
        for candidate in self._font_candidates():
            if candidate.exists():
                try:
                    # Some TTFs have glyph bounds slightly taller than the requested
                    # size, which makes raylib print harmless FONT warnings at startup.
                    rl.set_trace_log_level(rl.TraceLogLevel.LOG_ERROR)
                    font = rl.load_font_ex(str(candidate), base_size, glyphs, glyph_count)
                    rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
                    if font.texture.id > 0:
                        rl.set_texture_filter(font.texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
                        self._owns_font = True
                        return font
                except Exception as exc:
                    rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
                    print(f"Cluster font load failed for {candidate}: {exc}")
        self._owns_font = False
        return rl.get_font_default()

    def _load_korean_font(self):
        codepoints = self._navi_font_codepoints()
        glyph_buffer = rl.ffi.new("int[]", codepoints)
        glyphs = rl.ffi.cast("int *", glyph_buffer)
        for candidate in self._font_candidates():
            if not candidate.exists():
                continue
            try:
                rl.set_trace_log_level(rl.TraceLogLevel.LOG_ERROR)
                font = rl.load_font_ex(str(candidate), KOREAN_FONT_BASE_SIZE, glyphs, len(codepoints))
                rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
                if font.texture.id > 0:
                    rl.set_texture_filter(font.texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
                    self._owns_korean_font = True
                    return font
            except Exception as exc:
                rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
                print(f"Cluster Korean font load failed for {candidate}: {exc}")
        self._owns_korean_font = False
        return None

    def _font_candidates(self) -> list[Path]:
        return [
            KAIGEN_GOTHIC_KR_BOLD_FONT_PATH,
            OPENPILOT_ADDON_FONT_DIR / "KaiGenGothicKR-Bold.ttf",
            Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "malgun.ttf",
            JETBRAINS_MONO_FONT_PATH,
            OPENPILOT_FONT_DIR / "JetBrainsMono-Bold.ttf",
            Path("/data/openpilot/openpilot/selfdrive/assets/fonts/KaiGenGothicKR-Bold.ttf"),
            Path("/usr/share/fonts/truetype/jetbrains-mono/JetBrainsMono-Medium.ttf"),
            Path("/usr/share/fonts/TTF/JetBrainsMono-Medium.ttf"),
            Path("/usr/local/share/fonts/JetBrainsMono-Medium.ttf"),
        ]

    @staticmethod
    @lru_cache(maxsize=1)
    def _navi_font_codepoints() -> tuple[int, ...]:
        return (
            *range(0x20, 0x0250),
            *range(0x2000, 0x2070),
            0x20A9,
            0x2190, 0x2192,  # ← → for HUD line 4 치우침 (보노보노 2026-10-26 20:37)
            *range(0x3131, 0x3190),
            *range(0xAC00, 0xD7A4),
        )

    def _load_vehicle_model(self) -> None:
        if self._vehicle_model_load_attempted:
            return
        self._vehicle_model_load_attempted = True
        if getattr(self, "_ego_car_texture", None) is None:
            self._ego_car_texture = self._load_icon_texture(EGO_CAR_ICON_PATH, "K9 ego car")
        if not VEHICLE_MODEL_PATH.exists():
            return
        try:
            profile_stage = self._profile_start()
            mesh = self._load_obj_mesh(VEHICLE_MODEL_PATH)
            self._profile_add("vehicle_model.parse_obj", profile_stage)
            profile_stage = self._profile_start()
            rl.upload_mesh(rl.ffi.addressof(mesh), False)
            self._profile_add("vehicle_model.upload_mesh", profile_stage)
            profile_stage = self._profile_start()
            model = rl.load_model_from_mesh(mesh)
            self._profile_add("vehicle_model.load_from_mesh", profile_stage)
            if not rl.is_model_valid(model):
                rl.unload_model(model)
                return
            self._vehicle_model = model
        except Exception as exc:
            print(f"Cybertruck vehicle model load failed: {exc}")
            self._vehicle_model = None

    def _load_park_vehicle_models(self) -> None:
        """P/R resources never replace the normal driving model or its material."""
        if self._park_vehicle_models_loaded:
            return
        self._park_vehicle_models_loaded = True
        if PARK_VEHICLE_MODEL_PATH.exists():
            try:
                mesh = self._load_obj_mesh(PARK_VEHICLE_MODEL_PATH, park_materials=True)
                rl.upload_mesh(rl.ffi.addressof(mesh), False)
                model = rl.load_model_from_mesh(mesh)
                if rl.is_model_valid(model):
                    self._park_vehicle_model = model
                    self._attach_vehicle_shader(model)
                else:
                    rl.unload_model(model)
            except Exception as exc:
                print(f"Parked EV6 fallback model load failed: {exc}")
        if PARK_K9_MODEL_PATH.exists():  # K9: own model, never added to the lead / side vehicle list
            try:
                mesh = self._load_obj_mesh(PARK_K9_MODEL_PATH, park_materials=True)
                rl.upload_mesh(rl.ffi.addressof(mesh), False)
                model = rl.load_model_from_mesh(mesh)
                if rl.is_model_valid(model):
                    self._park_k9_model = model
                    self._set_k9_gloss(self._attach_vehicle_shader(model))
                else:
                    rl.unload_model(model)
            except Exception as exc:
                print(f"Parked K9 model load failed: {exc}")
        self._other_vehicle_models = self._load_other_vehicle_models()

    def _load_other_vehicle_models(self) -> list[object]:
        # Lead / cut-in / confident side vehicles: every OBJ in assets/models/others (sorted), else the
        # generic car. Any file that fails is skipped; with none loaded the original marker boxes stay.
        paths = sorted(OTHER_VEHICLE_MODELS_DIR.glob("*.obj")) if OTHER_VEHICLE_MODELS_DIR.is_dir() else []
        if not paths and OTHER_VEHICLE_MODEL_PATH.exists():
            paths = [OTHER_VEHICLE_MODEL_PATH]
        models = []
        self._other_vehicle_paint = []
        self._other_vehicle_names = []
        for path in paths:
            try:
                mesh = self._load_obj_mesh(path, park_materials=True)
                rl.upload_mesh(rl.ffi.addressof(mesh), False)
                model = rl.load_model_from_mesh(mesh)
                if not rl.is_model_valid(model):
                    rl.unload_model(model)
                    continue
                shader = self._attach_vehicle_shader(model)
                paint = None
                if shader is not None:
                    key = rl.ffi.new("float[]", [c / 255.0 for c in OTHER_VEHICLE_PAINT_RGB] + [1.0])
                    rl.set_shader_value(shader, rl.get_shader_location(shader, "paintKey"), key,
                                        rl.ShaderUniformDataType.SHADER_UNIFORM_VEC4)
                    override_loc = rl.get_shader_location(shader, "paintOverride")
                    if override_loc >= 0:
                        paint = (shader, override_loc)
                models.append(model)
                self._other_vehicle_names.append(path.stem.removesuffix("_cluster"))
                self._other_vehicle_paint.append(paint)
            except Exception as exc:
                print(f"Other vehicle model {path.name} load failed: {exc}")
        if models:
            print(f"Other vehicle models loaded: {len(models)}")
        return models

    def _other_model_index(self, vehicle: VehicleBox) -> int:
        key = vehicle.model_key if vehicle.model_key >= 0 else zlib.crc32((vehicle.label or vehicle.source).encode())
        return int(key) % len(self._other_vehicle_models)

    def _set_other_paint(self, index: int, color) -> bool:
        paint = self._other_vehicle_paint[index] if index < len(self._other_vehicle_paint) else None
        if paint is None:
            return False
        shader, loc = paint
        value = [0.0, 0.0, 0.0, 0.0] if color is None else [c / 255.0 for c in color[:3]] + [1.0]
        rl.set_shader_value(shader, loc, rl.ffi.new("float[]", value), rl.ShaderUniformDataType.SHADER_UNIFORM_VEC4)
        return True

    def _uses_other_model(self, vehicle: VehicleBox) -> bool:
        if not clean_ui_enabled():
            return False
        if not self._other_vehicle_models or vehicle.source == "radarPoint":
            return False
        if vehicle.primary or vehicle.cut_in:
            return True
        if clean_ui_enabled() and (vehicle.source in SIDE_VEHICLE_MODEL_SOURCES or vehicle.source == "carState"):
            return True  # EV6 HUD patch v6 (carState = blind-spot car reported by the car itself)
        return vehicle.source in SIDE_VEHICLE_MODEL_SOURCES and vehicle.confidence >= SIDE_VEHICLE_MODEL_MIN_CONFIDENCE

    @staticmethod
    def _set_k9_gloss(shader) -> None:
        # Clear-coat / chrome reflection for the K9 model only (paint, glass and chrome colours of
        # make_k9_park_model.py); every other model keeps gloss = 0, i.e. the original shading.
        if shader is None:
            return
        vec3 = rl.ShaderUniformDataType.SHADER_UNIFORM_VEC3
        for name, rgb in (("glossPaint", "1c1f24"), ("glossGlass", "0a0c10"), ("glossChrome", "dfe2e6"),
                          ("glossChrome2", "9ea3a9"), ("glossRim", "c2c6cb")):
            value = [int(rgb[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
            rl.set_shader_value(shader, rl.get_shader_location(shader, name), rl.ffi.new("float[]", value), vec3)
        rl.set_shader_value(shader, rl.get_shader_location(shader, "gloss"), rl.ffi.new("float[]", [1.0]),
                            rl.ShaderUniformDataType.SHADER_UNIFORM_FLOAT)

    def _attach_vehicle_shader(self, model):
        # One shader instance per model (UnloadModel frees its material shader).
        # Any failure keeps raylib's default (unlit) shader, i.e. the original look.
        try:
            vs, fs = vehicle_shader_sources(int(rl.rl_get_version()))
            shader = rl.load_shader_from_memory(vs, fs)
            if not rl.is_shader_valid(shader):
                return None
            light = rl.ffi.new("float[]", list(VEHICLE_LIGHT_DIR))
            rl.set_shader_value(shader, rl.get_shader_location(shader, "lightDir"), light,
                                rl.ShaderUniformDataType.SHADER_UNIFORM_VEC3)
            for index in range(int(model.materialCount)):
                model.materials[index].shader = shader
            self._vehicle_shaders.append((shader, rl.get_shader_location(shader, "viewPos")))
            return shader
        except Exception as exc:
            print(f"Vehicle shader setup failed, using unlit model: {exc}")
            return None

    def _load_follow_vehicle_texture(self) -> None:
        if self._follow_vehicle_texture is not None:
            return
        self._follow_vehicle_texture = self._load_icon_texture(FOLLOW_VEHICLE_ICON_PATH, "Follow gap vehicle")

    def _load_drive_status_textures(self) -> None:
        if self._speed_bg_texture is None:
            self._speed_bg_texture = self._load_icon_texture(SPEED_BG_PATH, "Speed background")
        if self._traffic_red_texture is None:
            self._traffic_red_texture = self._load_alpha_cropped_icon_texture(TRAFFIC_RED_ICON_PATH, "Red traffic light")
        if self._traffic_green_texture is None:
            self._traffic_green_texture = self._load_alpha_cropped_icon_texture(
                TRAFFIC_GREEN_ICON_PATH,
                "Green traffic light",
            )
        if self._lfa_texture is None:
            self._lfa_texture = self._load_icon_texture(LFA_ICON_PATH, "LFA")
        if self._lfa_active_texture is None:
            self._lfa_active_texture = self._load_lfa_active_texture()
        if self._lfa_lane_texture is None:
            self._lfa_lane_texture = self._load_icon_texture(LFA_LANE_ICON_PATH, "LFA lane mode")
        if self._wifi_texture is None:
            self._wifi_texture = self._load_icon_texture(WIFI_ICON_PATH, "Wi-Fi")
        if self._tpms_car_texture is None:
            self._tpms_car_texture = self._load_icon_texture(TPMS_CAR_ICON_PATH, "TPMS toy car")

    def _load_icon_texture(self, path: Path, label: str):
        if not path.exists():
            return None
        try:
            texture = rl.load_texture(str(path))
            if texture.id <= 0:
                return None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            return texture
        except Exception as exc:
            print(f"{label} icon load failed: {exc}")
            return None

    def _load_alpha_cropped_icon_texture(self, path: Path, label: str):
        if not path.exists():
            return None
        image = None
        try:
            image = rl.load_image(str(path))
            if not rl.is_image_valid(image):
                return None
            if image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)

            data = rl.ffi.cast("unsigned char *", image.data)
            min_x, min_y = image.width, image.height
            max_x = max_y = -1
            for y in range(image.height):
                for x in range(image.width):
                    if int(data[(y * image.width + x) * 4 + 3]) <= 8:
                        continue
                    min_x = min(min_x, x)
                    min_y = min(min_y, y)
                    max_x = max(max_x, x)
                    max_y = max(max_y, y)
            if max_x < min_x or max_y < min_y:
                return None

            padding = 2
            min_x = max(0, min_x - padding)
            min_y = max(0, min_y - padding)
            max_x = min(image.width - 1, max_x + padding)
            max_y = min(image.height - 1, max_y + padding)
            rl.image_crop(image, rl.Rectangle(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1))

            texture = rl.load_texture_from_image(image)
            if texture.id <= 0:
                return None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            return texture
        except Exception as exc:
            print(f"{label} icon load failed: {exc}")
            return None
        finally:
            if image is not None and rl.is_image_valid(image):
                rl.unload_image(image)

    def _load_lfa_active_texture(self):
        if not LFA_ICON_PATH.exists():
            return None
        image = None
        try:
            image = rl.load_image(str(LFA_ICON_PATH))
            if not rl.is_image_valid(image):
                return None
            if image.format != rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8:
                rl.image_format(image, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)

            data = rl.ffi.cast("unsigned char *", image.data)
            byte_count = image.width * image.height * 4
            green_r, green_g, green_b = GREEN
            for offset in range(0, byte_count, 4):
                alpha = int(data[offset + 3])
                if alpha == 0:
                    continue
                red = int(data[offset])
                green = int(data[offset + 1])
                blue = int(data[offset + 2])
                if red >= 220 and green >= 220 and blue >= 220:
                    data[offset] = green_r
                    data[offset + 1] = green_g
                    data[offset + 2] = green_b

            texture = rl.load_texture_from_image(image)
            if texture.id <= 0:
                return None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            return texture
        except Exception as exc:
            print(f"LFA active icon load failed: {exc}")
            return None
        finally:
            if image is not None and rl.is_image_valid(image):
                rl.unload_image(image)

    def _load_obj_mesh(self, path: Path, *, park_materials: bool = False):
        vertices: list[tuple[float, float, float]] = []
        normals: list[tuple[float, float, float]] = []
        mesh_vertices: list[float] = []
        mesh_normals: list[float] = []
        mesh_colors: list[int] = []
        material_color = DEFAULT_VEHICLE_MATERIAL_COLOR

        def resolve_index(index_text: str, count: int) -> int:
            index = int(index_text)
            if index < 0:
                index = count + index + 1
            return index - 1

        def parse_face_token(token: str) -> tuple[int, int | None]:
            parts = token.split("/")
            vertex_index = resolve_index(parts[0], len(vertices))
            normal_index = None
            if len(parts) >= 3 and parts[2]:
                normal_index = resolve_index(parts[2], len(normals))
            return vertex_index, normal_index

        def face_normal(points: tuple[tuple[float, float, float], ...]) -> tuple[float, float, float]:
            ax, ay, az = points[0]
            bx, by, bz = points[1]
            cx, cy, cz = points[2]
            ux, uy, uz = bx - ax, by - ay, bz - az
            vx, vy, vz = cx - ax, cy - ay, cz - az
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            length = math.sqrt(nx * nx + ny * ny + nz * nz)
            if length <= 0.000001:
                return 0.0, 0.0, 1.0
            return nx / length, ny / length, nz / length

        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            parts = raw.split()
            if not parts or parts[0].startswith("#"):
                continue
            tag = parts[0]
            if tag == "v" and len(parts) >= 4:
                vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif tag == "vn" and len(parts) >= 4:
                normals.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif tag == "usemtl" and len(parts) >= 2:
                material_color = (vehicle_material_color(parts[1]) if park_materials
                                  else VEHICLE_MATERIAL_COLORS.get(parts[1], DEFAULT_VEHICLE_MATERIAL_COLOR))
            elif tag == "f" and len(parts) >= 4:
                face = [parse_face_token(token) for token in parts[1:]]
                for index in range(1, len(face) - 1):
                    triangle = (face[0], face[index], face[index + 1])
                    points = tuple(vertices[vertex_index] for vertex_index, _ in triangle)
                    fallback_normal = face_normal(points)
                    for vertex_index, normal_index in triangle:
                        vertex = vertices[vertex_index]
                        normal = normals[normal_index] if normal_index is not None else fallback_normal
                        mesh_vertices.extend(vertex)
                        mesh_normals.extend(normal)
                        mesh_colors.extend(material_color)

        vertex_count = len(mesh_vertices) // 3
        if vertex_count < 3 or vertex_count % 3 != 0:
            raise RuntimeError(f"invalid vehicle mesh vertex count: {vertex_count}")

        mesh = rl.Mesh()
        mesh.vertexCount = vertex_count
        mesh.triangleCount = vertex_count // 3
        mesh.vertices = self._alloc_float_array(mesh_vertices)
        mesh.normals = self._alloc_float_array(mesh_normals)
        mesh.colors = self._alloc_uchar_array(mesh_colors)
        return mesh

    def _alloc_float_array(self, values: list[float]):
        raw = np.asarray(values, dtype=np.float32).tobytes()
        data = rl.ffi.cast("float *", rl.mem_alloc(len(raw)))
        rl.ffi.memmove(data, raw, len(raw))
        return data

    def _alloc_uchar_array(self, values: list[int]):
        raw = np.asarray(values, dtype=np.uint8).tobytes()
        data = rl.ffi.cast("unsigned char *", rl.mem_alloc(len(raw)))
        rl.ffi.memmove(data, raw, len(raw))
        return data

    def _draw_scene(self, scene: ClusterScene, state: ClusterUiState) -> None:
        camera = rl.Camera3D(
            vec3(scene.camera.position),
            vec3(scene.camera.target),
            rl.Vector3(0.0, 0.0, 1.0),
            scene.camera.fovy_deg,
            rl.CameraProjection.CAMERA_PERSPECTIVE,
        )
        view_shift_x = self._world_view_shift_x(state)
        driving_offset_x = 0.0
        if abs(view_shift_x) > 0.001:
            driving_offset_x = self._driving_panel_offset_design_x() * self.width / DESIGN_WIDTH
        scene_offset_x = driving_offset_x - view_shift_x
        if abs(scene_offset_x) > 0.001:
            rl.rl_viewport(int(round(scene_offset_x)), 0, self.width, self.height)
        if clean_ui_enabled() and self._vehicle_shaders:
            view_pos = rl.ffi.new("float[]", [float(camera.position.x), float(camera.position.y), float(camera.position.z)])
            for vehicle_shader, view_loc in self._vehicle_shaders:
                if view_loc >= 0:
                    rl.set_shader_value(vehicle_shader, view_loc, view_pos, rl.ShaderUniformDataType.SHADER_UNIFORM_VEC3)
        profile_stage = self._profile_start()
        rl.begin_mode_3d(camera)
        self._profile_add("draw_scene.begin_mode_3d", profile_stage)
        rl.rl_push_matrix()
        if abs(scene.scene_shift_x_m) > 0.0001:
            rl.rl_translatef(scene.scene_shift_x_m, 0.0, 0.0)
        try:
            if clean_ui_enabled():
                self._draw_ground()  # EV6 HUD patch v5
            profile_stage = self._profile_start()
            for strip in scene.highlight_lanes:
                self._draw_strip(strip)
            self._profile_add("draw_scene.highlight_lanes", profile_stage)
            profile_stage = self._profile_start()
            for strip in scene.road_edges:
                self._draw_strip(strip)
            self._profile_add("draw_scene.road_edges", profile_stage)
            profile_stage = self._profile_start()
            for strip in scene.lane_markings:
                self._draw_strip(strip)
            self._profile_add("draw_scene.lane_markings", profile_stage)
            profile_stage = self._profile_start()
            path_grey = clean_ui_enabled() and state.lfa_active is False  # EV6 HUD patch v6
            for strip in scene.planned_path:
                if path_grey:
                    r, g, b = strip.color[:3]
                    lum = int(0.30 * r + 0.59 * g + 0.11 * b)
                    lum = int(lum * 0.55 + 70)
                    strip = replace(strip, color=(lum, lum, lum, strip.color[3] if len(strip.color) > 3 else 255))
                self._draw_strip(strip)
            self._profile_add("draw_scene.planned_path", profile_stage)
            profile_stage = self._profile_start()
            if not clean_ui_enabled():  # EV6 HUD patch v6
                for point in scene.radar_points:
                    self._draw_radar_point(point)
            self._profile_add("draw_scene.radar_points", profile_stage)
            profile_stage = self._profile_start()
            ego_sprite_vehicle = None
            for vehicle in scene.vehicles:
                if vehicle.ego and getattr(self, "_ego_car_texture", None) is not None:
                    self._draw_vehicle_shadow(vehicle)
                    ego_sprite_vehicle = vehicle
                    continue
                self._draw_vehicle(vehicle)
            self._profile_add("draw_scene.vehicles", profile_stage)
        finally:
            rl.rl_pop_matrix()
        profile_stage = self._profile_start()
        rl.end_mode_3d()
        self._profile_add("draw_scene.end_mode_3d", profile_stage)
        if abs(scene_offset_x) > 0.001:
            rl.rl_viewport(0, 0, self.width, self.height)
            rl.rl_push_matrix()
            rl.rl_translatef(scene_offset_x, 0.0, 0.0)
        try:
            if ego_sprite_vehicle is not None:
                self._draw_ego_car_sprite(ego_sprite_vehicle, camera, scene.scene_shift_x_m)
            profile_stage = self._profile_start()
            self._draw_radar_point_labels(
                () if clean_ui_enabled() else scene.radar_points,  # EV6 HUD patch v6
                camera,
                scene.scene_shift_x_m,
                state.radar_info_mode,
            )
            self._profile_add("draw_scene.radar_labels", profile_stage)
            profile_stage = self._profile_start()
            self._draw_vehicle_badges(
                scene.vehicles,
                camera,
                scene.scene_shift_x_m,
                state.radar_info_mode,
                state.radar_source_color_mode,
            )
            self._profile_add("draw_scene.vehicle_badges", profile_stage)
        finally:
            if abs(scene_offset_x) > 0.001:
                rl.rl_pop_matrix()

    def _draw_ground(self) -> None:
        # Flat ground plane that fades into the background colour towards the horizon.
        theme = self._current_theme()
        near = GROUND_DARK_RGB if theme.is_dark else GROUND_LIGHT_RGB
        far = tuple(theme.bg[:3])
        half_w = GROUND_HALF_WIDTH_M
        rl.rl_begin(rl.RL_TRIANGLES)
        for index in range(len(GROUND_ROWS_M) - 1):
            y0, y1 = GROUND_ROWS_M[index], GROUND_ROWS_M[index + 1]
            c0 = [int(round(n + (f - n) * GROUND_FADE[index])) for n, f in zip(near, far, strict=True)]
            c1 = [int(round(n + (f - n) * GROUND_FADE[index + 1])) for n, f in zip(near, far, strict=True)]
            for x, y, c in ((-half_w, y0, c0), (half_w, y0, c0), (half_w, y1, c1),
                            (-half_w, y0, c0), (half_w, y1, c1), (-half_w, y1, c1)):
                rl.rl_color4ub(c[0], c[1], c[2], 255)
                rl.rl_vertex3f(x, y, GROUND_Z_M)
        rl.rl_end()

    def _world_view_shift_x(self, state: ClusterUiState) -> float:
        screen_mode = self._effective_screen_mode(state)
        if cluster_camera_view_is_road_camera(state.camera_view_mode):
            return 0.0
        if screen_mode in (
            CLUSTER_SCREEN_MODE_DEBUG,
            CLUSTER_SCREEN_MODE_DEBUG_SYSTEM,
            CLUSTER_SCREEN_MODE_DEBUG_GRAPH_RIGHT,
            CLUSTER_SCREEN_MODE_TRIP_REPORT,
            CLUSTER_SCREEN_MODE_NAV_MODEL,
        ):
            return NAVI_WORLD_VIEW_SHIFT_X * self.width / DESIGN_WIDTH
        if screen_mode != CLUSTER_SCREEN_MODE_DEFAULT:
            return 0.0
        navi_panel_visible = bool(
            self._navi_live_panel_visible(state.navi_live)
            or self._navi_map_frame_present(state.navi_dashboard)
            or state.navi_dashboard is not None
        )
        if not navi_panel_visible:
            return 0.0
        return NAVI_WORLD_VIEW_SHIFT_X * self.width / DESIGN_WIDTH

    def _world_view_shift_design_x(self, state: ClusterUiState) -> float:
        if self.width <= 0:
            return 0.0
        return self._world_view_shift_x(state) * DESIGN_WIDTH / self.width

    def _ego_car_center_design_x(self, state: ClusterUiState) -> float:
        """Design x of the centre ego-car sprite: its fixed projected centre plus the 3D viewport shift.

        Same expression _draw_scene translates the scene viewport by (driving-panel offset less the
        world-view shift); the camera keeps the sprite centred in that viewport.
        """
        view_shift_x = self._world_view_shift_design_x(state)
        scene_offset_x = (
            self._driving_panel_offset_design_x() - view_shift_x if abs(view_shift_x) > 0.001 else 0.0
        )
        return DESIGN_WIDTH * 0.5 + scene_offset_x

    def _turn_signal_center_x_offset(self, state: ClusterUiState, side: str) -> float:
        signal_center_x = (
            LANE_TURN_SIGNAL_LEFT_CENTER_X if side == "left" else LANE_TURN_SIGNAL_RIGHT_CENTER_X
        )
        if self._effective_screen_mode(state) == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
            return 0.0
        if cluster_camera_view_is_road_camera(state.camera_view_mode):
            camera_signal_center_x = CAMERA_BACKGROUND_X + signal_center_x * CAMERA_BACKGROUND_W / DESIGN_WIDTH
            return camera_signal_center_x - signal_center_x
        view_shift_x = self._world_view_shift_design_x(state)
        if self._panel_swap_active() and abs(view_shift_x) <= 0.001:
            view_shift_x = NAVI_WORLD_VIEW_SHIFT_X
        return -view_shift_x

    def _draw_tpms_status(self, state: ClusterUiState) -> None:
        if clean_ui_enabled():
            self._draw_clean_tpms(state)  # EV6 HUD patch v6
            return
        tpms = state.tpms
        pressures = (tpms.fl, tpms.fr, tpms.rl, tpms.rr)
        if not any(value is not None for value in pressures):
            return

        if not self._draw_tpms_car_icon():
            self._draw_tpms_car_fallback()

        badge_positions = (
            (
                TPMS_STATUS_CENTER_X - TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y - TPMS_STATUS_ROW_OFFSET,
                tpms.fl,
            ),
            (
                TPMS_STATUS_CENTER_X + TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y - TPMS_STATUS_ROW_OFFSET,
                tpms.fr,
            ),
            (
                TPMS_STATUS_CENTER_X - TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y + TPMS_STATUS_ROW_OFFSET,
                tpms.rl,
            ),
            (
                TPMS_STATUS_CENTER_X + TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y + TPMS_STATUS_ROW_OFFSET,
                tpms.rr,
            ),
        )
        for center_x, center_y, pressure in badge_positions:
            self._draw_compact_tpms_value(pressure, center_x, center_y)

    def _draw_lat_values(self, state: ClusterUiState) -> None:
        texts = (
            lat_values_text(getattr(state, "applied_steer_ratio", None), getattr(state, "applied_steer_delay_s", None)),
            delay_learn_text(getattr(state, "delay_learn_perc", None), getattr(state, "delay_learn_s", None)),
            torque_learned_text(getattr(state, "torque_filtered_lat_accel_factor", None),
                                getattr(state, "torque_filtered_friction", None)),
            torque_applied_text(getattr(state, "torque_learn_lat_accel_factor", None),
                                getattr(state, "torque_learn_friction", None)),
            learned_steer_ratio_text(getattr(state, "learned_steer_ratio", None), getattr(state, "delay_learn_s", None)),
        )
        for text, y in zip(texts, LAT_VALUES_SLOT_Y):
            if text is None:
                continue
            self._draw_text_with_stroke(text, LAT_VALUES_RIGHT_X, y, LAT_VALUES_FONT_SIZE, LAT_VALUES_COLOR, (0, 0, 0), 2,
                                        anchor="right", cache=True)

    def _draw_lane_values(self, state: ClusterUiState) -> None:
        texts = (
            (lane_offset_text(getattr(state, "k9_lane_offset_m", None)), LANE_OFFSET_COLOR),
            (lane_gap_text(getattr(state, "k9_lane_gap_left_m", None), getattr(state, "k9_lane_gap_right_m", None)), LANE_GAP_COLOR),
        )
        for (text, color), y in zip(texts, LANE_VALUES_LINE_Y):
            self._draw_text_with_stroke(text, LANE_VALUES_RIGHT_X, y, LANE_VALUES_FONT_SIZE, color, (0, 0, 0), 2,
                                        anchor="right", cache=True)

    def _draw_tpms_car_icon(self) -> bool:
        texture = getattr(self, "_tpms_car_texture", None)
        if texture is None:
            return False
        source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
        destination = rl.Rectangle(
            TPMS_STATUS_CENTER_X - TPMS_STATUS_ICON_W * 0.5,
            TPMS_STATUS_CAR_CENTER_Y - TPMS_STATUS_ICON_H * 0.5,
            TPMS_STATUS_ICON_W,
            TPMS_STATUS_ICON_H,
        )
        rl.draw_texture_pro(
            texture,
            source,
            destination,
            rl.Vector2(0.0, 0.0),
            0.0,
            rl_color(WHITE),
        )
        return True

    def _draw_tpms_car_fallback(self) -> None:
        theme = self._current_theme()
        if theme.is_dark:
            body_fill = (0, 0, 0, 255)
            body_outline = (214, 224, 231, 237)
            glass_fill = (70, 190, 224, 220)
        else:
            body_fill = (245, 248, 252, 255)
            body_outline = (112, 124, 134, 237)
            glass_fill = (75, 185, 216, 220)
        wheel_fill = (5, 9, 12, 247)
        wheel_outline = (180, 192, 201, 235)

        car_x = TPMS_STATUS_CENTER_X - TPMS_STATUS_CAR_W * 0.5
        car_y = TPMS_STATUS_CAR_CENTER_Y - TPMS_STATUS_CAR_H * 0.5
        wheel_centers = (
            (
                TPMS_STATUS_CENTER_X - TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y - TPMS_STATUS_ROW_OFFSET,
            ),
            (
                TPMS_STATUS_CENTER_X + TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y - TPMS_STATUS_ROW_OFFSET,
            ),
            (
                TPMS_STATUS_CENTER_X - TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y + TPMS_STATUS_ROW_OFFSET,
            ),
            (
                TPMS_STATUS_CENTER_X + TPMS_STATUS_COLUMN_OFFSET,
                TPMS_STATUS_VALUE_CENTER_Y + TPMS_STATUS_ROW_OFFSET,
            ),
        )
        for wheel_center_x, wheel_center_y in wheel_centers:
            self._rounded_rect(
                wheel_center_x - TPMS_STATUS_WHEEL_W * 0.5,
                wheel_center_y - TPMS_STATUS_WHEEL_H * 0.5,
                TPMS_STATUS_WHEEL_W,
                TPMS_STATUS_WHEEL_H,
                7.0,
                wheel_fill,
                wheel_outline,
                1.4,
            )

        self._rounded_rect(
            car_x,
            car_y,
            TPMS_STATUS_CAR_W,
            TPMS_STATUS_CAR_H,
            6.5,
            body_fill,
            body_outline,
            2.0,
        )
        self._rounded_rect(
            car_x + 6.0,
            car_y + 10.0,
            TPMS_STATUS_CAR_W - 12.0,
            21.0,
            5.0,
            glass_fill,
            body_outline,
            1.2,
        )
        rl.draw_line_ex(
            rl.Vector2(car_x + 6.0, car_y + 56.0),
            rl.Vector2(car_x + TPMS_STATUS_CAR_W - 6.0, car_y + 56.0),
            1.5,
            rl_color(body_outline),
        )

    def _draw_compact_tpms_value(self, pressure: float | None, center_x: float, center_y: float) -> None:
        low = pressure is not None and pressure < TPMS_LOW_PRESSURE_PSI
        text = "--" if pressure is None else f"{pressure:.0f}"
        color = RED if low else WHITE
        if pressure is None:
            color = (170, 180, 188, 255)
        self._draw_text_with_stroke(
            text,
            center_x,
            center_y,
            TPMS_STATUS_FONT_SIZE,
            color,
            (0, 0, 0, 255),
            2,
            anchor="center",
        )

    def _draw_strip(self, strip: MeshStrip) -> None:
        count = min(len(strip.left), len(strip.right))
        if count < 2:
            return

        color = rl_color(strip.color)
        x_offset_m = strip.x_offset_m

        if hasattr(rl, "draw_triangle_strip_3d"):
            points, point_count = self._triangle_strip_points_for(strip, count)
            point_ptr = rl.ffi.cast("struct Vector3 *", points)
            if x_offset_m != 0.0:
                rl.rl_push_matrix()
                try:
                    rl.rl_translatef(x_offset_m, 0.0, 0.0)
                    rl.draw_triangle_strip_3d(point_ptr, point_count, color)
                finally:
                    rl.rl_pop_matrix()
            else:
                rl.draw_triangle_strip_3d(point_ptr, point_count, color)
            return

        for index in range(count - 1):
            left = strip.left[index]
            right = strip.right[index]
            next_left = strip.left[index + 1]
            next_right = strip.right[index + 1]
            left_near = rl.Vector3(left.x + x_offset_m, left.y, left.z)
            right_near = rl.Vector3(right.x + x_offset_m, right.y, right.z)
            left_far = rl.Vector3(next_left.x + x_offset_m, next_left.y, next_left.z)
            right_far = rl.Vector3(next_right.x + x_offset_m, next_right.y, next_right.z)
            rl.draw_triangle_3d(left_near, right_near, right_far, color)
            rl.draw_triangle_3d(left_near, right_far, left_far, color)

    def _triangle_strip_points_for(self, strip: MeshStrip, count: int):
        key = (id(strip.left), id(strip.right))
        cached = self._triangle_strip_point_cache.get(key)
        if cached is not None:
            left_ref, right_ref, points, point_count = cached
            if left_ref is strip.left and right_ref is strip.right:
                self._triangle_strip_point_cache.move_to_end(key)
                return points, point_count

        point_count = count * 2
        points = rl.ffi.new("struct Vector3[]", point_count)
        for index in range(count):
            left = strip.left[index]
            right = strip.right[index]

            points[index * 2].x = left.x
            points[index * 2].y = left.y
            points[index * 2].z = left.z

            points[index * 2 + 1].x = right.x
            points[index * 2 + 1].y = right.y
            points[index * 2 + 1].z = right.z

        self._triangle_strip_point_cache[key] = (
            strip.left,
            strip.right,
            points,
            point_count,
        )
        while len(self._triangle_strip_point_cache) > TRIANGLE_STRIP_POINT_CACHE_LIMIT:
            self._triangle_strip_point_cache.popitem(last=False)
        return points, point_count

    def _draw_vehicle(self, vehicle: VehicleBox) -> None:
        source_marker = vehicle.source.startswith("modelV2") or vehicle.source in ("radarState", "radarPoint", "cornerRadar")
        use_model = (
            self._vehicle_model is not None
            and not source_marker
            and (not vehicle.source or vehicle.primary or vehicle.cut_in)
        )
        if use_model or self._uses_other_model(vehicle):  # EV6 HUD patch v3: realistic 3D cars
            self._draw_vehicle_shadow(vehicle)
            self._draw_vehicle_model(vehicle)
            return
        if vehicle.source and (source_marker or (not vehicle.primary and not vehicle.cut_in)):
            self._draw_vehicle_marker(vehicle)
            return
        self._draw_vehicle_box(vehicle)

    def _ego_car_sprite_rect(
        self,
        vehicle: VehicleBox,
        camera,
        scene_shift_x_m: float,
        texture_width: int,
        texture_height: int,
    ) -> tuple[float, float, float, float, float] | None:
        """Screen (anchor_x, anchor_y, width, height, roll_deg) for the ego cutout.

        The sprite spans the projected width of the ego box and sits on its
        projected rear-bottom edge, so it keeps the 3D model's position and scale.
        """
        if texture_width <= 0 or texture_height <= 0:
            return None
        half_width = vehicle.width_m * 0.5
        half_length = vehicle.length_m * 0.5
        base_z = max(0.0, vehicle.center.z - vehicle.height_m * 0.5)
        points = []
        for local_x in (-half_width, half_width):
            for local_y in (-half_length, half_length):
                for z in (base_z, base_z + vehicle.height_m):
                    world = rl.Vector3(
                        vehicle.center.x + scene_shift_x_m + vehicle.right_x * local_x + vehicle.forward_x * local_y,
                        vehicle.center.y + vehicle.right_y * local_x + vehicle.forward_y * local_y,
                        z,
                    )
                    screen = world_to_screen_label_anchor(world, camera, self.width, self.height)
                    if screen is None:
                        return None
                    points.append((float(screen.x), float(screen.y)))
        xs = [point[0] for point in points]
        ys = [point[1] for point in points]
        width = max(xs) - min(xs)
        if width < 1.0:
            return None
        height = width * texture_height / texture_width
        rear = world_to_screen_label_anchor(
            rl.Vector3(vehicle.center.x + scene_shift_x_m - vehicle.forward_x * half_length,
                       vehicle.center.y - vehicle.forward_y * half_length, base_z),
            camera, self.width, self.height,
        )
        front = world_to_screen_label_anchor(
            rl.Vector3(vehicle.center.x + scene_shift_x_m + vehicle.forward_x * half_length,
                       vehicle.center.y + vehicle.forward_y * half_length, base_z),
            camera, self.width, self.height,
        )
        roll_deg = 0.0
        if rear is not None and front is not None and rear.y - front.y > 1.0:
            roll_deg = clamp(math.degrees(math.atan2(front.x - rear.x, rear.y - front.y)),
                             -EGO_CAR_ICON_MAX_ROLL_DEG, EGO_CAR_ICON_MAX_ROLL_DEG)
        return (min(xs) + max(xs)) * 0.5, max(ys), width, height, roll_deg

    def _draw_ego_car_sprite(self, vehicle: VehicleBox, camera, scene_shift_x_m: float) -> None:
        texture = getattr(self, "_ego_car_texture", None)
        if texture is None:
            return
        rect = self._ego_car_sprite_rect(vehicle, camera, scene_shift_x_m, texture.width, texture.height)
        if rect is None:
            return
        anchor_x, anchor_y, width, height, roll_deg = rect
        alpha = int(92 + 163 * clamp(vehicle.confidence, 0.0, 1.0))
        rl.draw_texture_pro(
            texture,
            rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height)),
            rl.Rectangle(anchor_x, anchor_y, width, height),
            rl.Vector2(width * 0.5, height),
            roll_deg,
            rl_color(WHITE, alpha),
        )

    def _draw_vehicle_marker(self, vehicle: VehicleBox) -> None:
        alpha = int(80 + 150 * clamp(vehicle.confidence, 0.0, 1.0))

        def with_alpha(color: tuple[int, int, int] | tuple[int, int, int, int]) -> tuple[int, int, int, int]:
            return color[0], color[1], color[2], alpha

        marker_height_m = max(0.42, vehicle.height_m * 0.45)
        marker_base_z = max(0.0, vehicle.center.z - vehicle.height_m * 0.5)

        marker_vehicle = replace(
            vehicle,
            center=Vec3(vehicle.center.x, vehicle.center.y, marker_base_z + marker_height_m * 0.5),
            width_m=max(0.55, vehicle.width_m * 0.68),
            length_m=max(1.05, vehicle.length_m * 0.64),
            height_m=marker_height_m,
            body_color=with_alpha(vehicle.body_color),
            side_color=with_alpha(vehicle.side_color),
            rear_color=with_alpha(vehicle.rear_color),
            top_highlight=with_alpha(vehicle.top_highlight),
            outline_color=with_alpha(vehicle.outline_color),
        )
        self._draw_vehicle_box(marker_vehicle)

    def _draw_radar_point(self, point: RadarPointMarker) -> None:
        side_m = max(0.16, point.radius_m * 1.75)
        height_m = max(0.12, point.radius_m * 1.15)
        marker_center = rl.Vector3(point.center.x, point.center.y, point.center.z)
        marker_size = rl.Vector3(side_m, side_m, height_m)
        rl.draw_cube_v(marker_center, marker_size, rl_color(point.color))

    def _draw_radar_point_labels(
        self,
        points: tuple[RadarPointMarker, ...],
        camera,
        scene_shift_x_m: float = 0.0,
        radar_info_mode: int = CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
    ) -> None:
        if not radar_info_shows_radar_points(radar_info_mode):
            return
        theme = self._current_theme()
        profile_enabled = self.profile_enabled
        profile_stage = self._profile_start()
        ordered = sorted(
            points,
            key=lambda point: (point.longitudinal_m, abs(point.lateral_m), point.label),
            reverse=True,
        )
        self._profile_add("draw_scene.radar_labels.sort", profile_stage)

        project_ms = 0.0
        layout_ms = 0.0
        text_ms = 0.0

        def draw_label_text(label, x, y, size, color) -> None:
            nonlocal text_ms
            if profile_enabled:
                text_stage = time.perf_counter()
                self._draw_world_label_text(label, x, y, size, color, anchor="center")
                text_ms += (time.perf_counter() - text_stage) * 1000.0
                return
            self._draw_world_label_text(label, x, y, size, color, anchor="center")

        for point in ordered:
            anchor = rl.Vector3(
                point.center.x + scene_shift_x_m,
                point.center.y,
                point.center.z + RADAR_LABEL_ANCHOR_Z_OFFSET_M,
            )
            if profile_enabled:
                project_stage = time.perf_counter()
            screen = world_to_screen_label_anchor(anchor, camera, self.width, self.height)
            if profile_enabled:
                project_ms += (time.perf_counter() - project_stage) * 1000.0
            if screen is None:
                continue
            if profile_enabled:
                layout_stage = time.perf_counter()
            distance = (
                radar_point_distance_label(point, self.is_metric)
                if radar_info_shows_distance(radar_info_mode)
                else ""
            )
            speed = (
                radar_point_speed_label(point, self.is_metric)
                if radar_info_shows_speed(radar_info_mode)
                else ""
            )
            if not distance and not speed:
                if profile_enabled:
                    layout_ms += (time.perf_counter() - layout_stage) * 1000.0
                continue
            scale = world_label_scale(point.longitudinal_m)
            distance_size = max(9.0, RADAR_LABEL_DISTANCE_FONT_SIZE * scale)
            speed_size = max(8.0, RADAR_LABEL_SPEED_FONT_SIZE * scale)
            shadow_offset = max(1.0, 1.2 * scale)
            gap = max(2.0, 4.0 * scale)
            if speed and distance:
                speed_y = screen.y - speed_size * 0.5
                distance_y = speed_y - (speed_size + distance_size) * 0.5 - gap
            elif speed:
                speed_y = screen.y - speed_size * 0.5
                distance_y = 0.0
            else:
                distance_y = screen.y - distance_size * 0.5
            center_x = screen.x
            shadow = theme.world_label_shadow
            text = theme.world_label_text
            if profile_enabled:
                layout_ms += (time.perf_counter() - layout_stage) * 1000.0
            if distance:
                draw_label_text(
                    distance,
                    center_x + shadow_offset,
                    distance_y + shadow_offset,
                    distance_size,
                    shadow,
                )
                draw_label_text(
                    distance,
                    center_x,
                    distance_y,
                    distance_size,
                    text,
                )
            if speed:
                draw_label_text(
                    speed,
                    center_x + shadow_offset,
                    speed_y + shadow_offset,
                    speed_size,
                    shadow,
                )
                draw_label_text(
                    speed,
                    center_x,
                    speed_y,
                    speed_size,
                    text,
                )
        self._profile_add_elapsed("draw_scene.radar_labels.project", project_ms)
        self._profile_add_elapsed("draw_scene.radar_labels.layout", layout_ms)
        self._profile_add_elapsed("draw_scene.radar_labels.text", text_ms)

    def _draw_vehicle_shadow(self, vehicle: VehicleBox) -> None:
        half_width = vehicle.width_m * 0.5
        half_length = vehicle.length_m * 0.5

        def corner(local_x: float, local_y: float, z: float) -> Vec3:
            return Vec3(
                vehicle.center.x + vehicle.right_x * local_x + vehicle.forward_x * local_y,
                vehicle.center.y + vehicle.right_y * local_x + vehicle.forward_y * local_y,
                z,
            )

        shadow = (
            corner(-half_width * 1.12, -half_length * 1.08, 0.018),
            corner(half_width * 1.12, -half_length * 1.08, 0.018),
            corner(half_width * 1.12, half_length * 1.08, 0.018),
            corner(-half_width * 1.12, half_length * 1.08, 0.018),
        )
        self._draw_quad(
            shadow[0],
            shadow[1],
            shadow[2],
            shadow[3],
            (0, 0, 0, int(18 + 34 * clamp(vehicle.confidence, 0.0, 1.0))),
        )

    def _draw_vehicle_model(self, vehicle: VehicleBox) -> None:
        if self._vehicle_model is None:
            return
        yaw_deg = math.degrees(math.atan2(-vehicle.forward_x, vehicle.forward_y))
        position = rl.Vector3(vehicle.center.x, vehicle.center.y, 0.035)
        rotation_axis = rl.Vector3(0.0, 0.0, 1.0)
        scale = rl.Vector3(vehicle.width_m, vehicle.length_m, vehicle.height_m)
        is_ego = not vehicle.source and not vehicle.primary and not vehicle.cut_in
        if not is_ego and not vehicle.primary and not vehicle.cut_in and self._uses_other_model(vehicle):
            # side-lane vehicles: slightly smaller than lead vehicles (radar-only position)
            scale = rl.Vector3(vehicle.width_m * SIDE_VEHICLE_MODEL_SCALE, vehicle.length_m * SIDE_VEHICLE_MODEL_SCALE,
                               vehicle.height_m * SIDE_VEHICLE_MODEL_SCALE)
        try:
            rl.rl_disable_backface_culling()
            alpha = int(92 + 163 * clamp(vehicle.confidence, 0.0, 1.0))
            model = self._vehicle_model
            if not clean_ui_enabled():
                tint = rl_color(vehicle.body_color) if vehicle.source == "radarPoint" else rl_color(WHITE, alpha)
            elif vehicle.source == "radarPoint":
                tint = rl_color(vehicle.body_color)
            elif is_ego:
                model, _ = self._ego_model(vehicle.model_name)
                tint = rl_color(WHITE, alpha)
            elif self._uses_other_model(vehicle):
                index = self._other_model_index(vehicle)
                held = False
                if clean_ui_enabled():
                    # The cut-in flag often lasts only a few frames and the same car then comes back under a
                    # different track id: follow it by position for CLEAN_CUTIN_HOLD_S (colour and model).
                    now = time.monotonic()
                    hold = self._cutin_hold
                    if vehicle.cut_in:
                        if hold is not None and hold[4] > now and abs(hold[1] - vehicle.center.x) < 1.6:
                            index = int(hold[3]) % len(self._other_vehicle_models)
                        self._cutin_hold = [now + CLEAN_CUTIN_HOLD_S, vehicle.center.x, vehicle.longitudinal_m, index,
                                            now + CLEAN_CUTIN_MODEL_HOLD_S]
                    elif (hold is not None and hold[4] > now and (vehicle.primary or vehicle.longitudinal_m > 0.0)
                          and abs(hold[1] - vehicle.center.x) < 1.6 and abs(hold[2] - vehicle.longitudinal_m) < 4.0):
                        index = int(hold[3]) % len(self._other_vehicle_models)
                        hold[1], hold[2] = vehicle.center.x, vehicle.longitudinal_m
                        held = hold[0] > now
                model = self._other_vehicle_models[index]
                body_rgb = tuple(vehicle.body_color[:3])
                warning = VEHICLE_CUTIN_TINT if held else None
                if vehicle.cut_in:
                    warning = VEHICLE_CUTIN_TINT
                elif body_rgb in (tuple(RED), tuple(AMBER)):
                    warning = body_rgb  # oncoming / crossing traffic keeps its warning colour
                ghost = (warning is None and not vehicle.primary and not vehicle.cut_in
                         and vehicle.confidence < SIDE_VEHICLE_MODEL_MIN_CONFIDENCE)
                if self._set_other_paint(index, warning) or warning is None:
                    tint = rl_color(CLEAN_GHOST_TINT if ghost else WHITE)  # warning colour repaints the body in the shader
                else:
                    tint = rl_color(warning)  # unlit fallback: multiply
            else:
                tint = rl_color(VEHICLE_OTHER_TINT, alpha)
            rl.draw_model_ex(model, position, rotation_axis, yaw_deg, scale, tint)
        finally:
            rl.rl_enable_backface_culling()

    def _draw_vehicle_badges(
        self,
        vehicles: tuple[VehicleBox, ...],
        camera,
        scene_shift_x_m: float = 0.0,
        radar_info_mode: int = CLUSTER_RADAR_INFO_ALL_SPEED_DISTANCE,
        radar_source_color_mode: int = 0,
    ) -> None:
        clean = clean_ui_enabled()
        if clean:  # EV6 HUD patch v6: only the lead (L1) and cut-in vehicles get a label
            vehicles = tuple(v for v in vehicles if v.cut_in or vehicle_has_lead_one_metrics(v))
        show_vehicle_info = radar_info_shows_vehicle(radar_info_mode)
        if not show_vehicle_info and not any(vehicle.primary or vehicle.cut_in for vehicle in vehicles):
            return
        theme = self._current_theme()
        profile_enabled = self.profile_enabled
        profile_stage = self._profile_start()
        ordered = sorted(
            (
                vehicle
                for vehicle in vehicles
                if vehicle.label and (show_vehicle_info or vehicle.primary or vehicle.cut_in)
            ),
            key=lambda vehicle: (
                0 if vehicle.primary else 1 if vehicle.cut_in else 2,
                max(0.0, vehicle.center.y - EGO_FORWARD_M),
                -vehicle.confidence,
            ),
        )
        self._profile_add("draw_scene.vehicle_badges.sort", profile_stage)

        project_ms = 0.0
        layout_ms = 0.0
        metric_labels: list[VehicleMetricLabel] = []

        for vehicle in ordered:
            anchor = rl.Vector3(
                vehicle.center.x + scene_shift_x_m,
                vehicle.center.y,
                vehicle.height_m + VEHICLE_BADGE_ANCHOR_Z_OFFSET_M,
            )
            if profile_enabled:
                project_stage = time.perf_counter()
            screen = world_to_screen_label_anchor(anchor, camera, self.width, self.height)
            if profile_enabled:
                project_ms += (time.perf_counter() - project_stage) * 1000.0
            if screen is None:
                continue

            if profile_enabled:
                layout_stage = time.perf_counter()
            show_important_label = vehicle.primary or vehicle.cut_in
            distance = (
                vehicle_distance_label(vehicle, self.is_metric)
                if radar_info_shows_distance(radar_info_mode) or show_important_label
                else ""
            )
            speed = (
                vehicle_speed_label(vehicle, self.is_metric)
                if radar_info_shows_speed(radar_info_mode)
                else ""
            )
            if not distance and not speed:
                if profile_enabled:
                    layout_ms += (time.perf_counter() - layout_stage) * 1000.0
                continue
            distance_m = vehicle_distance_m(vehicle)
            lead_one = vehicle_has_lead_one_metrics(vehicle)
            scale = 1.0 if lead_one else world_label_scale(distance_m)
            distance_size = LEAD_ONE_DISTANCE_FONT_SIZE if lead_one else max(9.0, VEHICLE_BADGE_DISTANCE_FONT_SIZE * scale)
            speed_size = LEAD_ONE_SPEED_FONT_SIZE if lead_one else max(8.0, VEHICLE_BADGE_SPEED_FONT_SIZE * scale)
            shadow_offset = max(1.0, 1.2 * scale)
            gap = max(2.0, 4.0 * scale)
            if speed and distance:
                speed_y = screen.y - speed_size * 0.5
                distance_y = speed_y - (speed_size + distance_size) * 0.5 - gap
            elif speed:
                speed_y = screen.y - speed_size * 0.5
                distance_y = 0.0
            else:
                distance_y = screen.y - distance_size * 0.5
            center_x = screen.x
            text_color = vehicle_metric_color(vehicle, theme, radar_source_color_mode)
            if clean:
                text = "  ".join(part for part in (distance, speed) if part)
                text_color = AMBER if vehicle.cut_in else (WHITE if theme.is_dark else (26, 30, 36))
                closing = vehicle.relative_speed_mps is not None and vehicle.relative_speed_mps < -0.5
                if closing and vehicle.ttc_s is not None and 0.0 < vehicle.ttc_s < CLEAN_TTC_AMBER_S:
                    text_color = RED if vehicle.ttc_s < CLEAN_TTC_RED_S else AMBER
                metric_labels.append(VehicleMetricLabel(
                    vehicle, (VehicleMetricLine(text, center_x, screen.y - 16.0, 20.0),), text_color, 0.0))
                continue
            lines = []
            if distance:
                lines.append(VehicleMetricLine(distance, center_x, distance_y, distance_size))
            if speed:
                lines.append(VehicleMetricLine(speed, center_x, speed_y, speed_size))
            metric_labels.append(VehicleMetricLabel(vehicle, tuple(lines), text_color, shadow_offset))
            if profile_enabled:
                layout_ms += (time.perf_counter() - layout_stage) * 1000.0
        profile_stage = self._profile_start()
        self._draw_vehicle_metric_labels(metric_labels)
        self._profile_add("draw_scene.vehicle_badges.text", profile_stage)
        self._profile_add_elapsed("draw_scene.vehicle_badges.project", project_ms)
        self._profile_add_elapsed("draw_scene.vehicle_badges.layout", layout_ms)

    def _vehicle_metric_label_rect(self, label: VehicleMetricLabel) -> tuple[float, float, float, float]:
        rects = []
        for line in label.lines:
            width, height = self._measure_text(line.text, line.size, max(1.0, line.size * 0.02), self._font_for_text(line.text))
            rects.append((line.x - width * 0.5, line.y - height * 0.5, line.x + width * 0.5, line.y + height * 0.5))
        left, top = min(rect[0] for rect in rects), min(rect[1] for rect in rects)
        right, bottom = max(rect[2] for rect in rects), max(rect[3] for rect in rects)
        return left, top, right - left + label.shadow_offset, bottom - top + label.shadow_offset

    def _draw_vehicle_metric_labels(
        self,
        labels: list[VehicleMetricLabel],
        bounds: tuple[float, float, float, float] | None = None,
    ) -> None:
        lead = next((label for label in labels if vehicle_has_lead_one_metrics(label.vehicle)), None)
        protected = None
        if lead is not None:
            left, top, right, bottom = bounds if bounds is not None else (0.0, 0.0, float(self.width), float(self.height))
            x, y, width, height = self._vehicle_metric_label_rect(lead)
            # Keep the full-size L1 group inside the viewport even at the horizon.
            dx = clamp(x, left + 4.0, max(left + 4.0, right - width - 4.0)) - x
            dy = clamp(y, top + 4.0, max(top + 4.0, bottom - height - 4.0)) - y
            lead = replace(lead, lines=tuple(replace(line, x=line.x + dx, y=line.y + dy) for line in lead.lines))
            protected = (x + dx - 4.0, y + dy - 4.0, width + 8.0, height + 8.0)

        # Reserve L1's space first, but paint it last. Only overlapping secondary
        # vehicle text is omitted; their geometry and the radar/control state stay intact.
        visible = []
        for label in labels:
            if lead is not None and label.vehicle is lead.vehicle:
                continue
            if protected is not None and rectangles_overlap(self._vehicle_metric_label_rect(label), protected):
                continue
            visible.append(label)
        if lead is not None:
            visible.append(lead)
        shadow = self._current_theme().world_label_shadow if any(label.shadow_offset for label in visible) else None
        if clean_ui_enabled():  # EV6 HUD patch v6: chip behind the label
            dark = self._current_theme().is_dark
            for label in visible:
                x, y, width, height = self._vehicle_metric_label_rect(label)
                self._rounded_rect(x - 10.0, y - 4.0, width + 20.0, height + 8.0, (height + 8.0) * 0.5,
                                   (12, 14, 18, 175) if dark else (255, 255, 255, 215),
                                   (*label.color[:3], 120), 1.5)
        for label in visible:
            for line in label.lines:
                if label.shadow_offset:
                    self._draw_world_label_text(
                        line.text, line.x + label.shadow_offset, line.y + label.shadow_offset,
                        line.size, shadow, anchor="center",
                    )
                self._draw_world_label_text(line.text, line.x, line.y, line.size, label.color, anchor="center")

    def _world_label_bounds(
        self,
        left: float,
        top: float,
        right: float,
        bottom: float,
    ) -> tuple[float, float, float, float]:
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        return (
            left * sx,
            top * sy,
            self.width - right * sx,
            self.height - bottom * sy,
        )

    def _draw_vehicle_box(self, vehicle: VehicleBox) -> None:
        half_width = vehicle.width_m * 0.5
        half_length = vehicle.length_m * 0.5
        z0 = 0.035
        z1 = vehicle.height_m + z0

        def corner(local_x: float, local_y: float, z: float) -> Vec3:
            return Vec3(
                vehicle.center.x + vehicle.right_x * local_x + vehicle.forward_x * local_y,
                vehicle.center.y + vehicle.right_y * local_x + vehicle.forward_y * local_y,
                z,
            )

        base = (
            corner(-half_width, -half_length, z0),
            corner(half_width, -half_length, z0),
            corner(half_width, half_length, z0),
            corner(-half_width, half_length, z0),
        )
        top = (
            corner(-half_width, -half_length, z1),
            corner(half_width, -half_length, z1),
            corner(half_width, half_length, z1),
            corner(-half_width, half_length, z1),
        )
        self._draw_vehicle_shadow(vehicle)
        self._draw_quad(base[0], base[1], top[1], top[0], vehicle.rear_color)
        self._draw_quad(base[1], base[2], top[2], top[1], vehicle.side_color)
        self._draw_quad(base[2], base[3], top[3], top[2], vehicle.body_color)
        self._draw_quad(base[3], base[0], top[0], top[3], vehicle.side_color)
        self._draw_quad(top[0], top[1], top[2], top[3], vehicle.body_color)

        inset = 0.22
        highlight = tuple(
            Vec3(
                point.x + (vehicle.center.x - point.x) * inset,
                point.y + (vehicle.center.y - point.y) * inset,
                point.z + 0.006,
            )
            for point in top
        )
        self._draw_quad(highlight[0], highlight[1], highlight[2], highlight[3], vehicle.top_highlight)

        outline = rl_color(vehicle.outline_color)
        edge_points = base + top
        edges = (
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 0),
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4),
            (0, 4),
            (1, 5),
            (2, 6),
            (3, 7),
        )
        for start, end in edges:
            rl.draw_line_3d(vec3(edge_points[start]), vec3(edge_points[end]), outline)
        if vehicle.primary or vehicle.cut_in:
            self._draw_selected_vehicle_outline(vehicle, corner, half_width, half_length, z0, z1)

    def _draw_selected_vehicle_outline(
        self,
        vehicle: VehicleBox,
        corner,
        half_width: float,
        half_length: float,
        z0: float,
        z1: float,
    ) -> None:
        outline_color = AMBER if vehicle.cut_in else WHITE
        outline = rl_color(outline_color, 255)
        halo_width = half_width + 0.12
        halo_length = half_length + 0.16
        halo_z0 = z0 + 0.015
        halo_z1 = z1 + 0.065
        halo_base = (
            corner(-halo_width, -halo_length, halo_z0),
            corner(halo_width, -halo_length, halo_z0),
            corner(halo_width, halo_length, halo_z0),
            corner(-halo_width, halo_length, halo_z0),
        )
        halo_top = (
            corner(-halo_width, -halo_length, halo_z1),
            corner(halo_width, -halo_length, halo_z1),
            corner(halo_width, halo_length, halo_z1),
            corner(-halo_width, halo_length, halo_z1),
        )
        halo_edges = (
            (halo_top[0], halo_top[1]),
            (halo_top[1], halo_top[2]),
            (halo_top[2], halo_top[3]),
            (halo_top[3], halo_top[0]),
            (halo_base[0], halo_base[1]),
            (halo_base[1], halo_base[2]),
            (halo_base[2], halo_base[3]),
            (halo_base[3], halo_base[0]),
            (halo_base[0], halo_top[0]),
            (halo_base[1], halo_top[1]),
            (halo_base[2], halo_top[2]),
            (halo_base[3], halo_top[3]),
        )
        for start, end in halo_edges:
            rl.draw_line_3d(vec3(start), vec3(end), outline)

    def _draw_quad(
        self,
        p0: Vec3,
        p1: Vec3,
        p2: Vec3,
        p3: Vec3,
        color: tuple[int, int, int, int],
    ) -> None:
        draw_color = rl_color(color)
        rl.draw_triangle_3d(vec3(p0), vec3(p1), vec3(p2), draw_color)
        rl.draw_triangle_3d(vec3(p0), vec3(p2), vec3(p3), draw_color)

    def _draw_hud(self, state: ClusterUiState, signal_lights: tuple[bool, bool] | None = None) -> None:
        if signal_lights is None:
            signal_lights = self._turn_signal_lights(state)
        left_signal_lit, right_signal_lit = signal_lights
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        profile_stage = self._profile_start()
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        self._profile_add("hud.push_scale", profile_stage)
        try:
            screen_mode = self._effective_screen_mode(state)
            if screen_mode == CLUSTER_SCREEN_MODE_NAV_MODEL:
                self._draw_driving_hud_content(state, screen_mode, left_signal_lit, right_signal_lit)
                self._draw_nav_model_map()
                self._draw_status_footer(state)
                return
            if screen_mode == CLUSTER_SCREEN_MODE_NAVI:
                self._draw_navi_dashboard(state)
                self._draw_status_footer(state)
                return
            navi_debug_active = state.navi_debug is not None
            navi_live_active = (
                self._navi_live_panel_visible(state.navi_live)
                or self._navi_map_frame_present(state.navi_dashboard)
                or (screen_mode == CLUSTER_SCREEN_MODE_DEFAULT and state.navi_dashboard is not None)
            )
            if screen_mode == CLUSTER_SCREEN_MODE_DEBUG_GRAPH:
                profile_stage = self._profile_start()
                self._draw_speed_block(state)
                self._profile_add("hud.speed_block", profile_stage)
                profile_stage = self._profile_start()
                self._draw_accel_block(state)
                self._profile_add("hud.accel_block", profile_stage)
                self._draw_steering_output_block(state)
                profile_stage = self._profile_start()
                self._draw_debug_plot(
                    state.debug_plot,
                    DEBUG_PLOT_FULL_X,
                    DEBUG_PLOT_FULL_Y,
                    DEBUG_PLOT_FULL_W,
                    DEBUG_PLOT_FULL_H,
                )
                self._profile_add("hud.debug_plot_full", profile_stage)
                self._draw_status_footer(state)
                return

            self._draw_driving_hud_content(
                state,
                screen_mode,
                left_signal_lit,
                right_signal_lit,
            )
            if screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D:
                self._draw_status_footer(state)
                return
            if self.taxi_meter_enabled and self._taxi_meter_panel_active(screen_mode):
                profile_stage = self._profile_start()
                self._draw_taxi_meter_panel()
                self._profile_add("hud.taxi_meter", profile_stage)
                self._draw_status_footer(state)
                return
            if screen_mode == CLUSTER_SCREEN_MODE_DEBUG_SYSTEM:
                profile_stage = self._profile_start()
                self._draw_system_dashboard_panel(state)
                self._profile_add("hud.system_dashboard", profile_stage)
                self._draw_status_footer(state)
                return
            if screen_mode == CLUSTER_SCREEN_MODE_DEBUG:
                profile_stage = self._profile_start()
                self._draw_live_debug_panel(state)
                self._profile_add("hud.live_debug", profile_stage)
            if screen_mode == CLUSTER_SCREEN_MODE_DEBUG_GRAPH_RIGHT:
                profile_stage = self._profile_start()
                self._draw_debug_plot(
                    state.debug_plot,
                    self._information_panel_x(DEBUG_PLOT_RIGHT_X),
                    DEBUG_PLOT_RIGHT_Y,
                    DEBUG_PLOT_RIGHT_W,
                    DEBUG_PLOT_RIGHT_H,
                )
                self._profile_add("hud.debug_plot_right", profile_stage)
            if screen_mode == CLUSTER_SCREEN_MODE_TRIP_REPORT:
                profile_stage = self._profile_start()
                self._draw_trip_report_panel(state)
                self._profile_add("hud.trip_report", profile_stage)
            elif navi_debug_active:
                profile_stage = self._profile_start()
                self._draw_navi_debug_panel(state.navi_debug)
                self._profile_add("hud.navi_debug", profile_stage)
            elif screen_mode == CLUSTER_SCREEN_MODE_DEFAULT and navi_live_active:
                profile_stage = self._profile_start()
                self._draw_navi_live_panel(state)
                self._profile_add("hud.navi_live", profile_stage)
            if screen_mode not in (
                CLUSTER_SCREEN_MODE_DEBUG,
                CLUSTER_SCREEN_MODE_DEBUG_GRAPH,
                CLUSTER_SCREEN_MODE_DEBUG_GRAPH_RIGHT,
                CLUSTER_SCREEN_MODE_TRIP_REPORT,
            ) and not navi_debug_active and not navi_live_active:
                profile_stage = self._profile_start()
                self._draw_route_overlay(state.route_overlay)
                self._profile_add("hud.route_overlay", profile_stage)
            self._draw_status_footer(
                state,
                include_core_usage=screen_mode != CLUSTER_SCREEN_MODE_TRIP_REPORT,
            )
        finally:
            profile_stage = self._profile_start()
            rl.rl_pop_matrix()
            self._profile_add("hud.pop_matrix", profile_stage)

    # ---- K9 TURZX drive layout (대감님 2026-11-12 18:05) ------------------------------------------------------------
    def _k9_turzx_active(self, state: ClusterUiState) -> bool:
        if not str(getattr(state, "car_fingerprint", "") or "").startswith("KIA_K9"):
            return False
        if not getattr(state, "onroad", False) or clean_ui_enabled():
            return False
        if getattr(self, "screen_mode", CLUSTER_SCREEN_MODE_DEFAULT) != CLUSTER_SCREEN_MODE_DEFAULT:
            return False
        return str(getattr(state, "gear_text", "") or "").strip().upper() not in ("P", "R")

    @staticmethod
    def k9_turzx_range_km(fraction) -> int | None:
        # carState.fuelGauge on the K9 = CLU13 CF_Clu_DTE / 600 km (selfdrive/car/k9_fuel.py), so this is the cluster's km.
        if fraction is None or not 0.0 < fraction <= 1.0:
            return None
        return int(round(fraction * K9_DTE_FULL_KM))

    @staticmethod
    def k9_turzx_lead(state: ClusterUiState) -> tuple[float, float] | None:
        """(distance m, bearing deg, right positive) of leadOne, None without one."""
        for vehicle in getattr(state, "detected_vehicles", ()) or ():
            if vehicle.primary and str(vehicle.label).upper() == "L1" and vehicle.longitudinal_m > 0.0:
                return vehicle.longitudinal_m, math.degrees(math.atan2(vehicle.lateral_m, vehicle.longitudinal_m))
        return None

    @staticmethod
    def _k9_is_lead(vehicle) -> bool:
        return bool(vehicle.primary) and str(vehicle.label).upper() == "L1" and vehicle.longitudinal_m > 0.0

    def _k9_hold_state(self, state: ClusterUiState) -> ClusterUiState:
        """K9 D road: lane lines / kerbs / cars kept briefly and faded (cluster_k9_hold), clock = k9_hold_clock
        (log time in replay) else monotonic. Screen copy only; a still or jumping clock draws the state as given."""
        hold = getattr(self, "_k9_road_hold", None)
        if hold is None:
            hold = self._k9_road_hold = K9RoadHold()
        clock = getattr(self, "k9_hold_clock", None) or time.monotonic
        state, self._k9_alpha = hold.update(state, float(clock()), self.k9_road_others, self._k9_is_lead)
        return state

    def _k9_fade(self, obj) -> float:
        return getattr(self, "_k9_alpha", {}).get(id(obj), 1.0) if obj is not None else 1.0

    def _k9_lead_fade(self, state: ClusterUiState) -> float:
        return self._k9_fade(next((v for v in getattr(state, "detected_vehicles", ()) or () if self._k9_is_lead(v)), None))

    @staticmethod
    def k9_road_others(state: ClusterUiState) -> list:
        """cars to draw besides the lead (L1), one per real car: reports of the same car merged, L1 > radar > model"""
        vs = [v for v in (getattr(state, "detected_vehicles", ()) or ()) if v.longitudinal_m > 0.0]

        def rank(v) -> int:
            if v.primary and str(v.label).upper() == "L1":
                return 0
            return 1 if "radar" in str(v.source).lower() else 2
        kept: list = []
        for v in sorted(vs, key=lambda v: (rank(v), v.longitudinal_m)):
            if not any(abs(v.lateral_m - k.lateral_m) < K9_ROAD_SAME_LAT_M and abs(v.longitudinal_m - k.longitudinal_m) <
                       max(K9_ROAD_SAME_DF_M, K9_ROAD_SAME_DF_K * max(v.longitudinal_m, k.longitudinal_m)) for k in kept):
                kept.append(v)
        return [v for v in kept if rank(v) > 0 and v.longitudinal_m <= K9_TURZX_ROAD_MAX_M]

    def k9_road_heading_deg(self, state: ClusterUiState, forward_m: float) -> float:
        """direction of the road (mean of the lane lines, right positive) at that distance, 0 without lane lines"""
        hs = []
        for lane in getattr(state, "lanes", ()) or ():
            pts = self._k9_turzx_points(lane.model_points)
            a = self._k9_turzx_lat_at(pts, forward_m - 2.0)
            b = self._k9_turzx_lat_at(pts, forward_m + 2.0)
            if a is not None and b is not None:
                hs.append(math.degrees(math.atan2(b - a, 4.0)))
        return sum(hs) / len(hs) if hs else 0.0

    def k9_road_clear_of_ego(self, forward_m: float, lateral_m: float) -> float:
        """drawn distance of a car: a car in front of the ego car is moved up until its rear clears the ego roof"""
        geo = getattr(self, "_k9_geo", K9L_ROAD_GEO)
        hy, ego_y, _, ego_w = geo
        if getattr(self, "_ego_car_texture", None) is None and not getattr(self, "_k9_turzx_ego_load_tried", False):
            self._k9_turzx_ego_load_tried = True
            self._ego_car_texture = self._load_icon_texture(EGO_CAR_ICON_PATH, "K9 ego car")
        tex = getattr(self, "_ego_car_texture", None)
        ego_h = 38.0 if tex is None else ego_w * tex.height / max(1, tex.width)
        x, y, scale = self.k9_turzx_road_project(forward_m, lateral_m)
        half = max(18.0, 1.9 * scale) * 0.5
        cx = getattr(self, "_k9_cx", K9C_CX)
        target = ego_y - ego_h + K9_ROAD_EGO_OVERLAP_PX
        if abs(x - cx) >= ego_w * 0.5 + half or y <= target or target <= hy + 1.0:
            return forward_m
        return max(forward_m, (ego_y - hy) * K9_TURZX_ROAD_Z0 / (target - hy) - K9_TURZX_ROAD_Z0)

    @staticmethod
    def _k9_turzx_shadow(x: float, y: float, w: float, h: float, radius: float) -> None:
        # soft shadow as rings outside the card only (no full-card fills: keeps the frame time)
        roundness = max(0.0, min(1.0, radius / max(1.0, min(w, h))))
        for grow, dy, a in ((10.0, 5.0, 22), (5.0, 3.0, 34), (2.0, 2.0, 52)):
            rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x, y + dy, w, h), roundness, 12, grow, rl.Color(0, 0, 0, a))

    def _k9_turzx_glass(self, x: float, y: float, w: float, h: float, radius: float = K9_TURZX_RADIUS,
                        fill=(12, 19, 36, 232), shadow: bool = True) -> None:
        """night card (대감님 20:27 마이바흐급): soft shadow, deep fill with a faint top sheen, champagne hairline edge,
        chrome highlight fading out from the middle of the top edge."""
        if shadow:
            self._k9_turzx_shadow(x, y, w, h, radius)
        self._rounded_rect(x, y, w, h, radius, fill)
        sheen = min(h * 0.45, 110.0)
        rl.draw_rectangle_gradient_v(int(x + radius * 0.5), int(y + 2), int(w - radius), int(sheen),
                                     rl.Color(150, 175, 220, 16), rl.Color(150, 175, 220, 0))
        roundness = max(0.0, min(1.0, radius / max(1.0, min(w, h))))
        # 20:47 깊이: inner shadow rings (darker at the edge), bottom inner dark, faint gloss on the top-left
        for inset, a in (((1.0, 70), (4.0, 30)) if shadow else ()):
            r_in = max(2.0, radius - inset)
            rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x + inset, y + inset, w - 2 * inset, h - 2 * inset),
                                               max(0.0, min(1.0, r_in / max(1.0, min(w, h) - 2 * inset))), 12, 2.0,
                                               rl.Color(0, 0, 0, a))
        rl.draw_rectangle_gradient_v(int(x + radius * 0.5), int(y + h - min(h * 0.3, 60.0)), int(w - radius),
                                     int(min(h * 0.3, 60.0) - 3), rl.Color(0, 0, 0, 0), rl.Color(0, 0, 0, 46))
        gw = min(w * 0.42, 260.0)
        rl.draw_rectangle_gradient_ex(rl.Rectangle(x + radius, y + 3, gw, min(sheen, 46.0)), rl.Color(255, 244, 222, 20),
                                      rl.Color(255, 244, 222, 0), rl.Color(255, 244, 222, 0), rl.Color(255, 244, 222, 0))
        rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x, y, w, h), roundness, 12, 1.0, rl.Color(*K9_TURZX_CHAMPAGNE, 70))
        half = (w - 2.0 * radius) * 0.5
        mid = x + w * 0.5
        self._k9_turzx_metal_h(mid - half, y, half * 2.0, 220)

    @staticmethod
    def _k9_turzx_metal_h(x: float, y: float, w: float, a: int = 150, thick: int = 1) -> None:
        # champagne metal hairline: dark gold -> bright champagne -> dark gold, ends fade out
        q = w * 0.25
        stops = ((0, (150, 124, 82, 0)), (1, (190, 160, 112, a)), (2, (255, 240, 206, a)), (3, (190, 160, 112, a)),
                 (4, (150, 124, 82, 0)))
        for (i0, c0), (_, c1) in zip(stops, stops[1:], strict=False):
            rl.draw_rectangle_gradient_h(int(x + q * i0), int(y), int(q + 1), thick, rl.Color(*c0), rl.Color(*c1))

    @staticmethod
    def _k9_turzx_metal_v(x: float, y: float, h: float, a: int = 120) -> None:
        half = h * 0.5
        rl.draw_rectangle_gradient_v(int(x), int(y), 1, int(half), rl.Color(214, 192, 150, 0), rl.Color(240, 222, 184, a))
        rl.draw_rectangle_gradient_v(int(x), int(y + half), 1, int(half), rl.Color(240, 222, 184, a), rl.Color(214, 192, 150, 0))

    def _k9_turzx_value_width(self, text: str, size: float) -> float:
        w, _ = self._measure_text(text, size, size * K9_TURZX_VALUE_TRACK, self._font_for_text(text))
        return w

    def _k9_turzx_value_text(self, text: str, x: float, y: float, size: float, color, anchor: str = "left") -> None:
        # numbers with generous letter spacing (same font / size), soft drop shadow
        if not text:
            return
        font = self._font_for_text(text)
        spacing = size * K9_TURZX_VALUE_TRACK
        tw, th = self._measure_text(text, size, spacing, font)
        dx = x - tw * 0.5 if anchor == "center" else (x - tw if anchor == "right" else x)
        dy = y - th * 0.5
        rl.draw_text_ex(font, text, rl.Vector2(dx + 1.0, dy + 2.0), size, spacing, rl.Color(0, 0, 0, 130))
        r, g, b = color[:3]
        glow = rl.Color(r, g, b, 34)  # 20:47 숫자에 은은한 빛
        for ox, oy in ((-1.5, -1.0), (1.5, 1.0)):
            rl.draw_text_ex(font, text, rl.Vector2(dx + ox, dy + oy), size, spacing, glow)
        rl.draw_text_ex(font, text, rl.Vector2(dx, dy), size, spacing, rl_color(color))

    def _k9_turzx_label_value(self, x: float, y: float, label: str, value: str, unit: str, sub: str) -> None:
        self._draw_text(label, x, y + 26.0, K9_TURZX_LABEL_SIZE, K9_TURZX_MUTED)
        self._k9_turzx_value_text(value, x, y + 92.0, K9_TURZX_VALUE_SIZE, K9_TURZX_TEXT if value != "-" else K9_TURZX_DIM)
        if unit and value != "-":
            w = self._k9_turzx_value_width(value, K9_TURZX_VALUE_SIZE)
            self._draw_text(unit, x + w + 8.0, y + 102.0, K9_TURZX_UNIT_SIZE, K9_TURZX_MUTED)
        if sub:
            self._draw_text(sub, x, y + 168.0, K9_TURZX_SUB_SIZE, K9_TURZX_DIM)

    def _k9_turzx_bar(self, x: float, y: float, w: float, fraction: float | None, color) -> None:
        rl.draw_rectangle_rounded(rl.Rectangle(x, y, w, 10.0), 1.0, 6, rl.Color(8, 14, 28, 255))
        rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x, y, w, 10.0), 1.0, 6, 1.0, rl_color(K9_TURZX_EDGE))
        if fraction is not None and fraction > 0.0:
            fw = max(10.0, w * clamp(fraction, 0.0, 1.0))
            rl.draw_rectangle_rounded(rl.Rectangle(x - 2.0, y - 2.0, fw + 4.0, 14.0), 1.0, 6, rl_color(color, 50))
            rl.draw_rectangle_rounded(rl.Rectangle(x, y, fw, 10.0), 1.0, 6, rl_color(color))

    # ---- K9 D side blocks: one three-tier type system for both sides and both styles (11/13 00:47) -----------------
    @staticmethod
    def k9t_split_unit(value: str) -> tuple[str, str]:
        """'0.20초' -> ('0.20', '초'), '← 150cm' -> ('← 150', 'cm'); values without a unit unchanged"""
        for u in K9T_UNITS:
            if value.endswith(u) and len(value) > len(u) and (value[-len(u) - 1].isdigit()):
                return value[:-len(u)], u
        return value, ""

    def _k9c_text(self, text: str, x: float, base: float, size: float, color, anchor: str = "left",
                  value: bool = False) -> float:
        """card (style 0) text on a baseline: KaiGen like _draw_text / _k9_turzx_value_text; returns the width"""
        if not text:
            return 0.0
        font = self._font_for_text(text)
        spacing = size * K9_TURZX_VALUE_TRACK if value else max(1.0, size * 0.02)
        tw, th = self._measure_text(text, size, spacing, font)
        b, _ = self._k9l_metrics(font)
        cy = base - b * size + th * 0.5
        if value:
            self._k9_turzx_value_text(text, x, cy, size, color, anchor)
        else:
            self._draw_text(text, x, cy, size, color, anchor)
        return tw

    def _k9t_size(self, kind: str) -> float:
        return {"title": K9T_TITLE, "label": K9T_LABEL, "unit": K9T_UNIT, "value": K9T_VALUE}[kind]

    def _k9t(self, lux: bool, kind: str, text: str, x: float, base: float, color, anchor: str = "left") -> float:
        size = self._k9t_size(kind)
        if lux:
            if kind == "title":
                return self._k9l_text(text, x, 0.0, size, color, anchor=anchor, track=K9L_TRACK, base=base)
            if kind == "value":
                return self._k9l_text(text, x, 0.0, size, color, anchor=anchor, numeric=True, track=0.01,
                                      glow=color != K9L_DIM, base=base)
            return self._k9l_text(text, x, 0.0, size, color, anchor=anchor, numeric=kind == "unit", base=base)
        return self._k9c_text(text, x, base, size, color, anchor, value=kind == "value")

    def _k9t_w(self, lux: bool, kind: str, text: str) -> float:
        size = self._k9t_size(kind)
        if lux:
            track = K9L_TRACK if kind == "title" else (0.01 if kind == "value" else 0.0)
            return self._k9l_width(text, size, kind in ("value", "unit"), track)
        font = self._font_for_text(text)
        spacing = size * K9_TURZX_VALUE_TRACK if kind == "value" else max(1.0, size * 0.02)
        return self._measure_text(text, size, spacing, font)[0]

    def _k9t_cap(self, lux: bool, kind: str) -> float:
        """cap height (px) of a tier: 'H' of the font its texts use"""
        size = self._k9t_size(kind)
        sample = "0" if kind in ("value", "unit") else "가"
        if lux:
            font, ink = self._k9l_font(sample, kind in ("value", "unit"))
        else:
            font, ink = self._font_for_text(sample), 1.0
        return self._k9l_metrics(font)[1] * size * ink

    def _k9t_slot(self, lux: bool, units) -> float:
        return max(self._k9t_w(lux, "unit", u) for u in units) + K9T_UNIT_GAP

    def _k9t_value(self, lux: bool, x1: float, base: float, value: str, color, slot: float) -> float:
        """value + unit: number right edge on x1 - slot, unit left in the slot (degree sign hangs from the cap line);
        returns the left x of the number"""
        num, unit = self.k9t_split_unit(value)
        nx = x1 - slot
        w = self._k9t(lux, "value", num, nx, base, color, anchor="right")
        if unit:
            ub = base
            if unit == "°":
                ub = base - (self._k9t_cap(lux, "value") - self._k9t_cap(lux, "unit"))
            self._k9t(lux, "unit", unit, nx + K9T_UNIT_GAP, ub, K9L_MUTED if lux else K9_TURZX_MUTED)
        return nx - w

    def _k9t_list(self, state: ClusterUiState, lux: bool, x0: float, x1: float, top: float, bottom: float) -> None:
        """차선 위치 + 조향 학습 block (left on screen) in the tier system; fixed slots (2 lane lines, 5 learn lines),
        so nothing moves or changes size with the values."""
        muted = K9L_MUTED if lux else K9_TURZX_MUTED
        dim = K9L_DIM if lux else K9_TURZX_DIM
        head = K9L_LABEL if lux else K9_TURZX_MUTED
        val = K9L_VALUE if lux else K9_TURZX_TEXT
        ca, cb, cv = self._k9t_cap(lux, "title"), self._k9t_cap(lux, "label"), self._k9t_cap(lux, "value")
        sgap = K9T_LIST_STACK_GAP if lux else K9T_LIST_STACK_GAP_CARD
        hgaps = K9T_LIST_HAIR_GAPS if lux else K9T_LIST_HAIR_GAPS_CARD
        stack = cb + sgap + cv
        g = (bottom - top - 2 * ca - 2 * cv - 5 * stack) / (7.0 + hgaps)
        slot = self._k9t_slot(lux, K9T_LIST_UNITS)
        mid = (x0 + x1) * 0.5
        halves = ((x0, mid - K9T_HALF_GAP * 0.5), (mid + K9T_HALF_GAP * 0.5, x1))
        tx = x0 + (10.0 if not lux else 0.0)

        def title(text, b):
            if not lux:
                rl.draw_rectangle_rounded(rl.Rectangle(x0, b - ca * 0.5 - 11.0, 3.0, 22.0), 1.0, 4,
                                          rl.Color(*K9_TURZX_CHAMPAGNE, 200))
            self._k9t(lux, "title", text, tx, b, head)

        b = top + ca
        title("차선 위치", b)
        lane = self.k9_lane_block(state)
        colors = (K9L_VALUE, K9L_VALUE) if lux else (K9_TURZX_POINT, K9_TURZX_GOOD)
        for i in range(2):
            b += g + cv
            if i >= len(lane):
                continue
            pairs = lane[i]
            if len(pairs) == 1 and not pairs[0][0]:
                self._k9t(lux, "value", pairs[0][1], x0, b, muted if pairs[0][1] in ("대기", "-", "--") else dim)
                continue
            spans = [(x0, x1)] if len(pairs) == 1 else halves
            for (name, value), (a0, a1) in zip(pairs, spans, strict=False):
                vc = muted if value in ("대기", "-", "--") else colors[i]  # 01:29 readable no-value (label grey)
                self._k9t(lux, "label", name, a0, b, muted)
                self._k9t_value(lux, a1, b, value, vc, slot)
        hair = b + g * hgaps * 0.5
        self._k9l_hair(x0, hair, x1 - x0, 110) if lux else self._k9_turzx_metal_h(x0, hair, x1 - x0, 130)
        b = hair + g * hgaps * 0.5 + ca
        title("조향 학습", b)
        rows: list[list[tuple[str, list[str]]]] = []
        for name, values, second in self.k9_lat_lines(state):
            if second and rows and len(rows[-1]) < 2:
                rows[-1].append((name, values))
            else:
                rows.append([(name, values)])
        for row in rows:
            lb = b + g + cb
            vb = lb + sgap + cv
            b = vb
            spans = [(x0, x1)] if len(row) == 1 else halves
            for (name, values), (a0, a1) in zip(row, spans, strict=False):
                self._k9t(lux, "label", name, a0, lb, muted)
                vx = a1
                for k, value in enumerate(reversed(values)):
                    vc = muted if value.strip("-") == "" or value == "대기" else val
                    if k == 0:
                        vx = self._k9t_value(lux, vx, vb, value, vc, slot)
                    else:
                        num, unit = self.k9t_split_unit(value)
                        uw = self._k9t_w(lux, "unit", unit) + K9T_UNIT_GAP if unit else 0.0
                        vx = self._k9t_value(lux, vx - K9T_VALUE_GAP - (uw - slot), vb, value, vc, slot)

    def _k9t_car_rows(self, state: ClusterUiState, lux: bool, x0: float, x1: float, top: float, bottom: float,
                      meter) -> None:
        """car block rows (range / trip / accel / steering angle): name + sub on one line, meter left and the value
        right-aligned under it (same tiers / spacing as the lane block)"""
        muted = K9L_MUTED if lux else K9_TURZX_MUTED
        dim = K9L_DIM if lux else K9_TURZX_DIM
        val = K9L_VALUE if lux else K9_TURZX_TEXT
        cb, cv = self._k9t_cap(lux, "label"), self._k9t_cap(lux, "value")
        stack = cb + K9T_STACK_GAP + cv
        g = (bottom - top - 4 * stack) / 4.0
        slot = self._k9t_slot(lux, K9T_CAR_UNITS)
        mx1 = x1 - slot - self._k9t_w(lux, "value", K9T_WIDE_VALUE) - 16.0
        km = self.k9_turzx_range_km(getattr(state, "fuel_gauge", None))
        trip = getattr(state, "trip_report", None)
        dist = getattr(trip, "distance_m", None) if trip is not None else None
        avg = getattr(trip, "average_speed_kph", None) if trip is not None else None
        trip_text = self.k9_trip_km_text(dist)
        accel = getattr(state, "accel_mps2", None)
        accel_text = "-" if accel is None or not math.isfinite(accel) else f"{accel:+.2f}"
        throttle = getattr(state, "throttle", None)
        pedal = "-" if throttle is None or not math.isfinite(throttle) else f"{int(round(clamp(throttle, 0.0, 1.0) * 100))}%"
        angle = getattr(state, "steering_angle_deg", None)
        angle_ok = angle is not None and math.isfinite(angle)
        angle_text = "-" if not angle_ok else (f"{angle:+.0f}" if abs(angle) >= 99.95 else f"{angle:+.1f}")
        side = "" if not angle_ok else ("가운데" if abs(angle) < 0.5 else ("왼쪽" if angle > 0.0 else "오른쪽"))
        km_text = "-" if km is None else str(km)
        rows = (
            ("주행가능거리", "", km_text + ("km" if km is not None else ""),
             ("plain", None if km is None else km / K9_DTE_FULL_KM)),
            # 11/13 00:47: km also from 1000 km on (fits at K9T_VALUE: "1234 km" < the 999.9 slot)
            ("이번 주행", "평균 -" if avg is None else f"평균 {avg:.0f} km/h",
             trip_text + ("km" if trip_text != "-" else ""), None),
            ("가속도 m/s²", f"페달 {pedal}", accel_text, ("accel", None if accel_text == "-" else accel / 3.0)),
            ("조향각", side, angle_text + ("°" if angle_ok else ""),
             ("angle", None if not angle_ok else -angle / K9_TURZX_STEER_BAR_DEG)),
        )
        b = top
        for i, (name, sub, value, bar) in enumerate(rows):
            lb = b + (g * 0.5 if i == 0 else g) + cb
            if i > 0:
                hy = b + g * 0.5
                self._k9l_hair(x0, hy, x1 - x0, 110) if lux else self._k9_turzx_metal_h(x0, hy, x1 - x0, 150)
            vb = lb + K9T_STACK_GAP + cv
            b = vb
            self._k9t(lux, "label", name, x0, lb, muted)
            # 01:29 no meter on this row: the sub item fills the empty left of the value line (balance with the
            # meter rows); only a trip of ~1000 km with a 3-digit average leaves no room, then it stays on the name line
            num = self.k9t_split_unit(value)[0]
            if sub and bar is None and (x0 + self._k9t_w(lux, "label", sub) + 12.0 <=
                                        x1 - slot - self._k9t_w(lux, "value", num)):
                self._k9t(lux, "label", sub, x0, vb, dim)
            elif sub:
                self._k9t(lux, "label", sub, x1, lb, dim, anchor="right")
            self._k9t_value(lux, x1, vb, value, val if value != "-" else muted, slot)
            if bar is not None:
                meter(x0, vb - cv * 0.5, mx1 - x0, bar[0], bar[1])

    def _k9_turzx_draw_left(self, state: ClusterUiState) -> None:
        # 19:55: fuel % (CF_Clu_FuelDispLvl always 0) and fuel economy (none on the K9) removed.
        # 11/13 00:47 (352 px card): range / trip / accel + pedal / steering angle in the K9T tiers, TPMS row
        x0, y0, h, w = K9_TURZX_LEFT_X, K9_TURZX_MARGIN, K9_TURZX_TOP_H, K9_TURZX_LEFT_W
        self._k9_turzx_glass(x0, y0, w, h)
        xa, xb = x0 + 20.0, x0 + w - 20.0

        def meter(x, cy, mw, kind, fraction):
            y = cy - 5.0
            if kind == "plain":
                self._k9_turzx_bar(x, y, mw, fraction, K9_TURZX_ACCENT)
            elif kind == "accel":
                self._k9_turzx_center_bar(x, y, mw, fraction, K9_TURZX_ACCENT, (255, 120, 90))
            else:
                self._k9_turzx_center_bar(x, y, mw, fraction, K9_TURZX_CHAMPAGNE, K9_TURZX_CHAMPAGNE)

        self._k9t_car_rows(state, False, xa, xb, y0 + 12.0, y0 + K9C_TPMS_Y - 4.0, meter)
        self._k9_turzx_metal_h(xa, y0 + K9C_TPMS_Y + 2.0, xb - xa, 150)
        ty = y0 + K9C_TPMS_Y
        self._k9_turzx_draw_tpms(state, x0, ty, w, y0 + h - ty, K9C_TPMS_SCALE)

    def _k9_turzx_center_bar(self, x: float, y: float, bw: float, fraction: float | None, pos_color, neg_color) -> None:
        # zero-centred bar: + right of the centre tick, - left
        rl.draw_rectangle_rounded(rl.Rectangle(x, y, bw, 10.0), 1.0, 6, rl.Color(8, 14, 28, 255))
        rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x, y, bw, 10.0), 1.0, 6, 1.0, rl_color(K9_TURZX_EDGE))
        cx = x + bw * 0.5
        if fraction is not None and math.isfinite(fraction):
            span = bw * 0.5 * clamp(abs(fraction), 0.0, 1.0)
            color = pos_color if fraction >= 0.0 else neg_color
            bx = cx if fraction >= 0.0 else cx - span
            rl.draw_rectangle_rec(rl.Rectangle(bx, y - 2.0, span, 14.0), rl_color(color, 50))
            rl.draw_rectangle_rec(rl.Rectangle(bx, y, span, 10.0), rl_color(color))
        rl.draw_line_ex(rl.Vector2(cx, y - 6.0), rl.Vector2(cx, y + 16.0), 2.0, rl_color(K9_TURZX_MUTED))

    def _k9_turzx_draw_tpms(self, state: ClusterUiState, x: float, y: float, w: float, h: float, k: float = 1.0) -> None:
        # 23:44 one row across the card: car in the middle, name + number beside each wheel, TPMS / psi at the row ends
        # 00:20 k scales the top view (sizes of the text unchanged)
        cx, cy = x + w * 0.5, y + h * 0.5 + 4.0
        self._draw_text("TPMS", x + 20, cy, K9_TURZX_LABEL_SIZE, K9_TURZX_MUTED)
        self._draw_text("psi", x + w - 20, cy, K9_TURZX_LABEL_SIZE, K9_TURZX_DIM, anchor="right")
        car_w, car_h = 56.0 * k, 150.0 * k
        top, left = cy - car_h * 0.5, cx - car_w * 0.5
        rl.draw_ellipse(int(cx), int(cy + 4), car_w * 0.9, car_h * 0.56, rl.Color(0, 0, 0, 60))
        for wx in (left - 5.0, left + car_w - 1.0):  # tyres
            for wy in (top + 22.0 * k, top + car_h - 50.0 * k):
                self._rounded_rect(wx, wy, 6.0, 28.0 * k, 3.0, (30, 34, 44), (*K9_TURZX_CHAMPAGNE, 110), 1.0)
        self._rounded_rect(left - 3, top - 3, car_w + 6, car_h + 6, 25.0 * k, (*K9_TURZX_LANE, 22))
        self._rounded_rect(left, top, car_w, car_h, 22.0 * k, (14, 22, 40), None)
        rl.draw_rectangle_gradient_h(int(left + 6 * k), int(top + 8 * k), int(car_w * 0.5 - 6 * k), int(car_h - 16 * k),
                                     rl.Color(60, 74, 100, 90), rl.Color(60, 74, 100, 0))
        self._rounded_rect(left, top, car_w, car_h, 22.0 * k, (0, 0, 0, 0), (*K9_TURZX_CHAMPAGNE, 190), 1.5)
        self._rounded_rect(left + 8 * k, top + 30 * k, car_w - 16 * k, 26 * k, 8.0 * k, (40, 58, 90), (*K9_TURZX_CHROME, 90), 1.0)
        self._rounded_rect(left + 9 * k, top + car_h - 40 * k, car_w - 18 * k, 18 * k, 6.0 * k, (34, 48, 74),
                           (*K9_TURZX_CHROME, 70), 1.0)
        rl.draw_line_ex(rl.Vector2(cx, top + 62 * k), rl.Vector2(cx, top + car_h - 46 * k), 1.0, rl.Color(*K9_TURZX_CHAMPAGNE, 60))
        tpms = state.tpms
        for value, sx, wy, name in ((tpms.fl, -1, top + 36.0 * k, "FL"), (tpms.fr, 1, top + 36.0 * k, "FR"),
                                    (tpms.rl, -1, top + car_h - 36.0 * k, "RL"), (tpms.rr, 1, top + car_h - 36.0 * k, "RR")):
            text = "-" if value is None or not math.isfinite(value) else str(int(round(value)))
            near = cx + sx * (car_w * 0.5 + 22.0)   # number next to the wheel, name outside it
            far = cx + sx * (car_w * 0.5 + 72.0)
            self._k9_turzx_value_text(text, near, wy, K9T_VALUE, K9_TURZX_TEXT if text != "-" else K9_TURZX_DIM,
                                      anchor="right" if sx < 0 else "left")
            self._draw_text(name, far, wy, K9_TURZX_LABEL_SIZE, K9_TURZX_MUTED, anchor="right" if sx < 0 else "left")

    # middle panel: 2D perspective road (TURZX-style, drawn from scratch; no code / art from the photo repo)
    def k9_turzx_road_project(self, forward_m: float, lateral_m: float) -> tuple[float, float, float]:
        """(screen x, screen y, px per m) of a road point, design px. forward >= -Z0 * 0.5."""
        z = max(K9_TURZX_ROAD_Z0 * 0.5, forward_m + K9_TURZX_ROAD_Z0)
        hy, ego_y, kx, _ = getattr(self, "_k9_geo", K9L_ROAD_GEO)  # card or scene road (ClusterHudK9Style)
        scale = kx / z
        return (getattr(self, "_k9_cx", K9C_CX) + lateral_m * scale,
                hy + (ego_y - hy) * K9_TURZX_ROAD_Z0 / z, scale)

    @staticmethod
    def _k9_turzx_points(points, max_m: float = K9_TURZX_ROAD_MAX_M) -> list[tuple[float, float]]:
        out = []
        for p in points or ():
            f, lat = getattr(p, "forward_m", None), getattr(p, "lateral_m", None)
            if f is None or lat is None or not (math.isfinite(f) and math.isfinite(lat)):
                continue
            if f > max_m:
                break
            if f >= min(-K9_TURZX_ROAD_BACK_M, 0.0):
                out.append((float(f), float(lat)))
        if out and out[0][0] > -K9_TURZX_ROAD_BACK_M:
            out.insert(0, (-K9_TURZX_ROAD_BACK_M, out[0][1]))
        return out

    @staticmethod
    def k9_path_normal(d_forward: float, d_lateral: float) -> tuple[float, float]:
        """unit normal (forward, lateral) of a path step, pointing to +lateral (right); (0, 1) on a straight path"""
        n = math.hypot(d_forward, d_lateral)
        return (0.0, 1.0) if n < 1e-9 else (-d_lateral / n, d_forward / n)

    @classmethod
    def k9_path_side(cls, path: list[tuple[float, float]], offset_m: float) -> list[tuple[float, float]]:
        """the path moved sideways by offset_m (+ = right) square to its own direction (대감님 11/13 20:28 \"경로하고
        예상추종커브나 똑바로 나오게\"): a band built by moving every point straight sideways gets narrower by
        cos(heading) in a bend (0.4 of its width in a 65 deg turn) and its edges stop running parallel to the lane
        lines; drawing only, straight paths are unchanged. Points that would fold back (inner edge of a very tight
        bend) are dropped so forward stays increasing."""
        out: list[tuple[float, float]] = []
        n = len(path)
        for i, (f, lat) in enumerate(path):
            a, b = path[max(0, i - 1)], path[min(n - 1, i + 1)]
            nf, nl = cls.k9_path_normal(b[0] - a[0], b[1] - a[1])
            q = (f + offset_m * nf, lat + offset_m * nl)
            if not out or q[0] > out[-1][0] + 1e-3:
                out.append(q)
        return out

    @staticmethod
    def _k9_turzx_lat_at(points: list[tuple[float, float]], forward_m: float) -> float | None:
        if not points:
            return None
        if forward_m <= points[0][0]:
            return points[0][1]
        for (f0, l0), (f1, l1) in zip(points, points[1:], strict=False):
            if f0 <= forward_m <= f1:
                return l0 if f1 - f0 < 1e-6 else l0 + (l1 - l0) * (forward_m - f0) / (f1 - f0)
        return None

    @staticmethod
    def _k9_turzx_tri(a, b, c, color) -> None:
        # raylib keeps one winding; order the corners so the triangle is always drawn
        if (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x) > 0.0:
            b, c = c, b
        rl.draw_triangle(a, b, c, color)

    def _k9_turzx_quad(self, p0, p1, p2, p3, color) -> None:
        self._k9_turzx_tri(p0, p1, p2, color)
        self._k9_turzx_tri(p0, p2, p3, color)

    def _k9_turzx_band(self, left: list[tuple[float, float]], right: list[tuple[float, float]], color, fade: bool = False,
                       end_m: float | None = None) -> None:
        if len(left) < 2 or len(right) < 2:
            return
        top = min(left[-1][0], right[-1][0], end_m if end_m is not None else 1e9)
        f = max(left[0][0], right[0][0], -K9_TURZX_ROAD_BACK_M)
        prev = None
        r, g, b = color[:3]
        a0 = color[3] if len(color) > 3 else 255
        while f <= top:
            ll, rr = self._k9_turzx_lat_at(left, f), self._k9_turzx_lat_at(right, f)
            if ll is None or rr is None:
                break
            lx, y, _ = self.k9_turzx_road_project(f, ll)
            rx, _, _ = self.k9_turzx_road_project(f, rr)
            cur = (rl.Vector2(lx, y), rl.Vector2(rx, y))
            if prev is not None:
                alpha = a0 if not fade else int(a0 * clamp(1.0 - f / max(1.0, top) * 0.75, 0.2, 1.0))
                self._k9_turzx_quad(prev[0], prev[1], cur[1], cur[0], rl.Color(r, g, b, alpha))
            prev = cur
            f += 3.0 if f < 0.0 else (1.5 if f < 20.0 else 3.0)
        return

    def _k9_turzx_line(self, pts: list[tuple[float, float]], color, width_m: float, glow: bool, dashed: bool,
                       alpha: float = 1.0) -> None:
        if len(pts) < 2:
            return
        r, g, b = color[:3]
        f = max(pts[0][0], -K9_TURZX_ROAD_BACK_M)
        prev = None
        while f <= pts[-1][0]:
            lat = self._k9_turzx_lat_at(pts, f)
            if lat is None:
                break
            x, y, scale = self.k9_turzx_road_project(f, lat)
            cur = (rl.Vector2(x, y), scale)
            if prev is not None and (not dashed or int((f + 60.0) // 4.0) % 2 == 0):
                w = max(1.4, width_m * (prev[1] + scale) * 0.5)
                fade = clamp(1.0 - f / K9_TURZX_ROAD_MAX_M * 0.7, 0.25, 1.0) * alpha
                if glow:
                    rl.draw_line_ex(prev[0], cur[0], w * 7.0, rl.Color(r, g, b, int(22 * fade)))
                    rl.draw_line_ex(prev[0], cur[0], w * 4.0, rl.Color(r, g, b, int(55 * fade)))
                    rl.draw_line_ex(prev[0], cur[0], w * 2.2, rl.Color(r, g, b, int(95 * fade)))
                rl.draw_line_ex(prev[0], cur[0], w, rl.Color(min(255, r + 60), min(255, g + 40), min(255, b), int(255 * fade)))
            prev = cur
            f += 3.0 if f < 0.0 else (1.5 if f < 20.0 else 2.5)

    def _k9_lanesm(self, key: str, pts: list[tuple[float, float]], conf: float | None = None) -> list[tuple[float, float]]:
        """K9 D road lines smoothed for drawing only (대감님 11/13 04:59 "D단 차선 흐물흐물"); see cluster_k9_lanesm"""
        if len(pts) < 2:
            return pts
        sm = getattr(self, "_k9_lanesm_state", None)
        if sm is None:
            sm = self._k9_lanesm_state = K9LaneSmoother()
        clock = getattr(self, "k9_lanesm_clock", None)
        return sm.smooth(key, pts, float(clock() if clock is not None else time.monotonic()), conf)

    def _k9_lanesm_lanes(self, state: ClusterUiState, lefts: list, rights: list) -> tuple[list, list]:
        """(near, lane, pts) lists, outermost-left first; slots = ego line, then 1st, 2nd .. line further out"""
        if not lefts and not rights:
            return lefts, rights
        lc = getattr(state, "left_lane_line_confidence", None)
        rc = getattr(state, "right_lane_line_confidence", None)
        n = len(lefts)
        lefts = [(nr, ln, self._k9_lanesm("egoL" if i == n - 1 else f"adjL{n - 2 - i}", p, lc if i == n - 1 else None))
                 for i, (nr, ln, p) in enumerate(lefts)]
        rights = [(nr, ln, self._k9_lanesm("egoR" if i == 0 else f"adjR{i - 1}", p, rc if i == 0 else None))
                  for i, (nr, ln, p) in enumerate(rights)]
        return lefts, rights

    def _k9_navdy_sprites(self):
        """{index: (texture, w, h, anchor x, anchor y, px per m)} read once per GL context; {} = failed (old box)."""
        cache = getattr(self, "_k9_navdy_cache", None)
        if cache is not None:
            return cache
        self._k9_navdy_cache = {}
        cache = {}
        try:
            rows = {}
            for line in (K9_NAVDY_DIR / "meta.txt").read_text(encoding="utf-8").splitlines():
                f = line.split()
                if len(f) >= 10 and f[0] == "car":
                    rows[int(f[1])] = (float(f[3]), float(f[4]), float(f[5]), float(f[6]), float(f[9]))
            for i, (w, h, ax, ay, ppm) in sorted(rows.items()):
                tex = rl.load_texture(str(K9_NAVDY_DIR / f"car_{i:02d}.png"))
                if tex is None or getattr(tex, "id", 0) <= 0:
                    raise RuntimeError(f"car_{i:02d}.png")
                rl.gen_texture_mipmaps(tex)
                rl.set_texture_filter(tex, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
                cache[i] = (tex, w, h, ax, ay, ppm)
            if sorted(cache) != list(range(2 * K9_NAVDY_MID + 1)):
                raise RuntimeError(f"{len(cache)} sprites")
            self._k9_navdy_cache = cache
        except Exception as exc:
            for item in cache.values():
                rl.unload_texture(item[0])
            print(f"K9 D: navdy car sprites not loaded ({exc}), boxes instead", flush=True)
        return self._k9_navdy_cache

    def _k9_navdy_unload(self) -> None:
        for item in (getattr(self, "_k9_navdy_cache", None) or {}).values():
            rl.unload_texture(item[0])
        self._k9_navdy_cache = None
        tex = getattr(self, "_k9_navdy_ego_tex", None)
        if tex is not None:
            rl.unload_texture(tex)
        self._k9_navdy_ego_tex = None
        self._k9_navdy_ego_tried = False

    def _k9_navdy_ego_texture(self):
        """K9 ego, menu-0 photo colours (K9_NAVDY_EGO_PATH), read once per GL context; None = failed (navdy car_12 instead)"""
        if not getattr(self, "_k9_navdy_ego_tried", False):
            self._k9_navdy_ego_tried = True
            self._k9_navdy_ego_tex = None
            try:
                tex = rl.load_texture(str(K9_NAVDY_EGO_PATH))
                if tex is None or getattr(tex, "id", 0) <= 0:
                    raise RuntimeError(K9_NAVDY_EGO_PATH.name)
                rl.gen_texture_mipmaps(tex)
                rl.set_texture_filter(tex, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
                self._k9_navdy_ego_tex = tex
            except Exception as exc:
                print(f"K9 D: K9 navdy ego not loaded ({exc}), navdy car instead", flush=True)
        return getattr(self, "_k9_navdy_ego_tex", None)

    @staticmethod
    def k9_navdy_index(forward_m: float, lateral_m: float, heading_deg: float = 0.0) -> int:
        """sprite number of a car on the road: its bearing from the road camera (forward + Z0) minus the road
        direction there (a car on a bend turns with the road), 2 deg steps"""
        yaw = math.degrees(math.atan2(lateral_m, max(1.0, forward_m + K9_TURZX_ROAD_Z0))) - heading_deg
        return int(clamp(round(yaw / K9_NAVDY_YAW_STEP), -K9_NAVDY_MID, K9_NAVDY_MID)) + K9_NAVDY_MID

    def _k9_navdy_vehicle(self, forward_m: float, lateral_m: float, tint,
                          heading_deg: float = 0.0) -> tuple[float, float, float] | None:
        """grey Navdy car times the screen colour, rear bottom centre on the road point. (centre x, top y, width)"""
        sprites = self._k9_navdy_sprites()
        if not sprites:
            return None
        x, y, scale = self.k9_turzx_road_project(forward_m, lateral_m)
        tex, w, h, ax, ay, ppm = sprites[self.k9_navdy_index(forward_m, lateral_m, heading_deg)]
        k = max(18.0 / K9_NAVDY_MIN_W_M, scale) / ppm  # sprite px -> screen px (meta px per m vs road px per m)
        dw, dh = w * k, h * k
        va = getattr(self, "_k9_va", 1.0)  # held / new car fade (cluster_k9_hold)
        if self.k9_navdy_on():
            rl.draw_ellipse(int(x), int(y), dw * 0.56, max(3.0, dh * 0.13), rl.Color(0, 0, 0, int(45 * va)))
            rl.draw_ellipse(int(x), int(y), dw * 0.44, max(2.0, dh * 0.07), rl.Color(0, 0, 0, int(85 * va)))
        else:  # K9HudNavdy 0: the shadow before b7e81bbd4
            rl.draw_ellipse(int(x), int(y), dw * 0.40, max(3.0, dh * 0.10), rl.Color(0, 0, 0, int(90 * va)))
        left, top = x - ax * k, y - ay * k
        rl.draw_texture_pro(tex, rl.Rectangle(0, 0, tex.width, tex.height), rl.Rectangle(left, top, dw, dh),
                            rl.Vector2(0, 0), 0.0, rl.Color(*tint[:3], int(255 * va)))
        return left + dw * 0.5, top, dw

    def _k9_turzx_draw_vehicle(self, forward_m: float, lateral_m: float, fill, edge,
                               heading_deg: float = 0.0) -> tuple[float, float, float]:
        lk = self.k9_look()
        drawn = self._k9_navdy_vehicle(forward_m, lateral_m, lk.lead_tint if fill == K9_TURZX_LEAD else (lk.other_tint or edge), heading_deg)
        if drawn is not None:
            return drawn
        x, y, scale = self.k9_turzx_road_project(forward_m, lateral_m)
        w = max(18.0, 1.9 * scale)
        h = w * 0.62
        rl.draw_ellipse(int(x), int(y), w * 0.72, max(4.0, h * 0.2), rl.Color(0, 0, 0, 60))
        rl.draw_ellipse(int(x), int(y), w * 0.58, max(3.0, h * 0.12), rl.Color(0, 0, 0, 110))
        self._rounded_rect(x - w * 0.5, y - h, w, h, w * 0.18, fill, edge, 1.5)
        self._rounded_rect(x - w * 0.36, y - h * 0.86, w * 0.72, h * 0.32, w * 0.08, (18, 26, 46), None)
        for side in (-1.0, 1.0):
            rl.draw_rectangle_rec(rl.Rectangle(x + side * w * 0.40 - w * 0.07, y - h * 0.42, w * 0.14, h * 0.13),
                                  rl.Color(255, 60, 80, 255))
        return x, y - h, w

    def _k9_turzx_draw_ego(self) -> None:
        # 대감님 19:58 "내 차량은 K9 뒷꽁무니 넣어놓은 거": the owner's K9 rear render (assets/images/k9_ego_car.png,
        # 2de680aea, same sprite as the old mode-0 HUD ego car), lane-width sized, soft floor shadow
        geo = getattr(self, "_k9_geo", K9L_ROAD_GEO)
        cx, by = getattr(self, "_k9_cx", K9C_CX), geo[1]  # rear bumper at forward 0
        sprites = self._k9_navdy_sprites()
        if sprites and self.k9_navdy_on():  # 11/13 01:57 "차크기 왜케크냐": Navdy straight rear, light grey, ~0.6 lane (was the 140~150 px photo)
            tex, sw, sh, ax, ay, _ = sprites[K9_NAVDY_MID]
            hy, ego_y, kx, _ = geo
            # 11/13 05:02 대감님 "d모드에 내차는어딧니?": the whole car well inside the card / screen (bottom edge
            # K9_NAVDY_EGO_BOTTOM_PAD up), still sized by the lane width at the row where it now sits
            limit = (8.0 + K9_TURZX_TOP_H if tuple(geo) == tuple(K9C_ROAD_GEO) else float(self.height)) - K9_NAVDY_EGO_BOTTOM_PAD
            dw = 3.6 * kx / K9_TURZX_ROAD_Z0 * K9_NAVDY_EGO_LANE_FRAC
            for _ in range(4):  # lane width at the car's own middle row (where the eye compares it), not at the bumper
                mid_y = by - ay * dw / sw * 0.5
                dw = 3.6 * kx * (mid_y - hy) / ((ego_y - hy) * K9_TURZX_ROAD_Z0) * K9_NAVDY_EGO_LANE_FRAC
                by -= max(0.0, by + (sh - ay) * dw / sw - limit)
            k = dw / sw
            dh = sh * k
            by -= max(0.0, by + dh - ay * k - limit)
            rl.draw_ellipse(int(cx), int(by - 1), dw * 0.60, max(4.0, dh * 0.12), rl.Color(0, 0, 0, 55))
            rl.draw_ellipse(int(cx), int(by - 1), dw * 0.48, max(3.0, dh * 0.07), rl.Color(0, 0, 0, 105))
            dst = rl.Rectangle(cx - ax * k, by - ay * k, dw, dh)
            k9 = self._k9_navdy_ego_texture()
            tex = k9 or tex  # 05:46: K9, same box as car_12 (geometry above unchanged)
            src = rl.Rectangle(0, 0, tex.width, tex.height)
            rl.draw_texture_pro(tex, src, dst, rl.Vector2(0, 0), 0.0, rl.WHITE)
            if k9 is None:  # 06:17 "왜 내차를 나브디로만듬?": the K9 photo is drawn as is (no lift); lift only the car_12 fallback
                rl.begin_blend_mode(rl.BlendMode.BLEND_ADDITIVE)
                lift = K9_NAVDY_EGO_TINT_LIFT  # 05:02: clearly lighter than the grey cars ahead (was K9_NAVDY_EGO_LIFT 26)
                rl.draw_texture_pro(tex, src, dst, rl.Vector2(0, 0), 0.0, rl.Color(lift, lift, lift + 4, 255))
                rl.end_blend_mode()
            self._k9_ego_rect = (dst.x, dst.y, dst.x + dw, dst.y + dh)
            return
        if getattr(self, "_ego_car_texture", None) is None and not getattr(self, "_k9_turzx_ego_load_tried", False):
            self._k9_turzx_ego_load_tried = True
            self._ego_car_texture = self._load_icon_texture(EGO_CAR_ICON_PATH, "K9 ego car")
        tex = getattr(self, "_ego_car_texture", None)
        w = geo[3]
        rl.draw_ellipse(int(cx), int(by - 2), w * 0.66, 9.0, rl.Color(0, 0, 0, 80))
        rl.draw_ellipse(int(cx), int(by - 2), w * 0.52, 5.0, rl.Color(0, 0, 0, 140))
        if tex is None:
            h = 38.0
            self._rounded_rect(cx - 31.0, by - h, 62.0, h, 14.0, (214, 224, 238), (120, 140, 170), 2.0)
            return
        h = w * tex.height / max(1, tex.width)
        rl.draw_texture_pro(tex, rl.Rectangle(0, 0, tex.width, tex.height), rl.Rectangle(cx - w * 0.5, by - h, w, h),
                            rl.Vector2(0, 0), 0.0, rl.WHITE)

    def _k9_turzx_pill(self, x: float, cy: float, text: str, anchor: str, dot=None) -> None:
        size = 26.0
        tw, _ = self._measure_text(text, size, max(1.0, size * 0.02), self._font_for_text(text))
        pw = tw + 28.0 + (22.0 if dot is not None else 0.0)
        px = x if anchor == "left" else x - pw
        self._k9_turzx_glass(px, cy - 20.0, pw, 40.0, K9_TURZX_RADIUS, K9_TURZX_MID_CARD, shadow=False)
        tx = px + 14.0
        if dot is not None:
            rl.draw_circle_v(rl.Vector2(tx + 6.0, cy), 6.0, rl_color(dot))
            tx += 22.0
        self._draw_text(text, tx, cy, size, K9_TURZX_TEXT)

    def _k9_turzx_draw_road(self, state: ClusterUiState) -> None:
        x0, y0, w, h = K9_TURZX_MID_X, K9_TURZX_MARGIN, K9_TURZX_MID_W, K9_TURZX_TOP_H
        rl.draw_rectangle_gradient_v(int(x0), int(y0), int(w), int(h), rl_color(K9_TURZX_MID_TOP), rl_color(K9_TURZX_MID_BOTTOM))
        lanes = list(getattr(state, "lanes", ()) or ())
        lane_pts = [(lane, self._k9_turzx_points(lane.model_points)) for lane in lanes]
        lane_pts = [(lane, pts) for lane, pts in lane_pts if len(pts) >= 2]
        def near(pts):
            return self._k9_turzx_lat_at(pts, 5.0) or pts[0][1]
        lefts = sorted([(near(p), lane, p) for lane, p in lane_pts if near(p) < 0.0], key=lambda t: t[0])
        rights = sorted([(near(p), lane, p) for lane, p in lane_pts if near(p) >= 0.0], key=lambda t: t[0])
        lefts, rights = self._k9_lanesm_lanes(state, lefts, rights)  # display-only smoothing (11/13 04:59)
        ego_l = lefts[-1] if lefts else None
        ego_r = rights[0] if rights else None
        # road surface between the road edges (else the outermost lane lines)
        le = self._k9_lanesm("edgeL", self._k9_turzx_points(getattr(state, "left_road_edge_points", ())))
        re_ = self._k9_lanesm("edgeR", self._k9_turzx_points(getattr(state, "right_road_edge_points", ())))
        if len(le) < 2 and lefts:
            le = lefts[0][2]
        if len(re_) < 2 and rights:
            re_ = rights[-1][2]
        if len(le) >= 2 and len(re_) >= 2:
            lk = self.k9_look()
            self._k9_turzx_band(le, re_, (*lk.road, 255))
            self._k9_turzx_line(le, lk.kerb, lk.kerb_w, False, False, lk.kerb_a)
            self._k9_turzx_line(re_, lk.kerb, lk.kerb_w, False, False, lk.kerb_a)
        # horizon haze + faint sky-blue glow on the horizon
        hy = getattr(self, "_k9_geo", K9C_ROAD_GEO)[0]
        rl.draw_rectangle_gradient_v(int(x0), int(hy - 40), int(w), 40,
                                     rl.Color(*self.k9_look().haze, 0), rl.Color(*self.k9_look().haze, self.k9_look().haze_a))
        rl.draw_rectangle_gradient_v(int(x0), int(hy - 6), int(w), 46,
                                     rl.Color(*K9_TURZX_MID_TOP, 255), rl.Color(*K9_TURZX_MID_TOP, 0))
        # adjacent lane lines: dashed, dim
        for group in (lefts[:-1], rights[1:]):
            for _, lane, pts in group:
                if getattr(lane, "visible", True):
                    self._k9_turzx_line(pts, self.k9_look().adj, 0.12, False, True, 0.7 * self._k9_fade(lane))
        # planned path band + arrows, ends at the lead car
        lead = self.k9_turzx_lead(state)
        path = self._k9_lanesm("path", self._k9_turzx_points(getattr(state, "model_path", ()), 90.0))
        end_m = None if lead is None else max(7.0, lead[0])  # band runs under the lead car (drawn on top)
        if len(path) >= 2:
            path = [(f, lat) for f, lat in path if f >= 0.0] or path  # ahead of my car only, nothing behind it
            if path[0][0] > 0.0:
                path.insert(0, (0.0, path[0][1]))
            if self.k9_navdy_on():
                bl_ = self.k9_path_side(path, -1.62)  # my lane, deep blue, along the plan (lane changes swing it)
                br_ = self.k9_path_side(path, 1.62)
                self._k9_turzx_band(bl_, br_, (*K9_NAVDY_EGO_LANE, 215), fade=True)
            else:  # K9HudNavdy 0: teal path band before b7e81bbd4
                self._k9_old_path_band(path, end_m, 1.05, 0.5, (*K9_TURZX_PATH, 128), (170, 250, 232, 62),
                                       (120, 255, 220), 0.10, 1.0)
            top = min(path[-1][0], end_m if end_m is not None else 1e9, 60.0)
            f = 2.0
            while f < top - 2.0:
                lat = self._k9_turzx_lat_at(path, f)
                lat2 = self._k9_turzx_lat_at(path, f + 1.2)
                if lat is None or lat2 is None:
                    break
                ax, ay, sc = self.k9_turzx_road_project(f + 1.2, lat2)
                nf, nl = self.k9_path_normal(1.2, lat2 - lat)  # chevron wings square to the path, not sideways
                bl = self.k9_turzx_road_project(f - 0.42 * nf, lat - 0.42 * nl)
                br = self.k9_turzx_road_project(f + 0.42 * nf, lat + 0.42 * nl)
                aw = max(1.2, 0.09 * sc)
                col = rl.Color(*self.k9_look().arrow, int(self.k9_look().arrow_a * clamp(1.0 - max(0.0, f) / 70.0, 0.3, 1.0)))
                rl.draw_line_ex(rl.Vector2(bl[0], bl[1]), rl.Vector2(ax, ay), aw, col)
                rl.draw_line_ex(rl.Vector2(br[0], br[1]), rl.Vector2(ax, ay), aw, col)
                f += 4.0 if f < 20.0 else 8.0
        # ego lane lines: cyan light beams, fainter when the model is unsure
        for item, conf in ((ego_l, getattr(state, "left_lane_line_confidence", None)),
                           (ego_r, getattr(state, "right_lane_line_confidence", None))):
            if item is None:
                continue
            a = 1.0 if conf is None or not math.isfinite(conf) else clamp(0.35 + conf * 0.65, 0.35, 1.0)
            if self.k9_navdy_on():
                self._k9_turzx_line(item[2], K9_NAVDY_LINE, 0.09, False, False, a * 0.9 * self._k9_fade(item[1]))
            else:
                self._k9_turzx_line(item[2], K9_TURZX_LANE, 0.13, True, False, a * self._k9_fade(item[1]))
        # depth: far road fades into the sky
        rl.draw_rectangle_gradient_v(int(x0), int(hy - 2), int(w), 110,
                                     rl.Color(*K9_TURZX_MID_TOP, 200), rl.Color(*K9_TURZX_MID_TOP, 0))
        # other cars (dim), then the lead (pink + yellow distance tag)
        # 11/13 01:29: one car per real car, turned with the road, never under the ego car (screen only)
        for v in sorted(self.k9_road_others(state), key=lambda v: -v.longitudinal_m):
            f = self.k9_road_clear_of_ego(v.longitudinal_m, v.lateral_m)
            self._k9_va = self._k9_fade(v)
            self._k9_turzx_draw_vehicle(f, v.lateral_m, (46, 66, 110), (96, 130, 186), self.k9_road_heading_deg(state, f))
        self._k9_va = la = self._k9_lead_fade(state)
        if lead is not None and lead[0] <= K9_TURZX_ROAD_MAX_M:
            lat = lead[0] * math.tan(math.radians(lead[1]))
            f = self.k9_road_clear_of_ego(lead[0], lat)
            lx, ly, lw = self._k9_turzx_draw_vehicle(f, lat, K9_TURZX_LEAD, (255, 236, 196), self.k9_road_heading_deg(state, f))
            tag = f"{lead[0]:.0f} m" if self.k9_navdy_on() else f"{lead[0]:.0f}m"
            tw, _ = self._measure_text(tag, 22.0, max(1.0, 22.0 * 0.02), self._font_for_text(tag))
            tbt = getattr(self, "_k9c_tbt_rect", None)  # 22:41 taller TBT card: a far lead tag would hide under it
            if tbt is not None and lx + tw * 0.5 + 8.0 > tbt[0] and ly - 32.0 < tbt[3]:
                ly = self.k9_turzx_road_project(f, lat)[1] + 36.0  # under the car instead
            if self.k9_navdy_on():
                self._draw_text(tag, lx + 1.0, ly - 18.0, 22.0, (0, 0, 0, int(150 * la)), anchor="center")  # floating above the car
                self._draw_text(tag, lx, ly - 19.0, 22.0, K9_NAVDY_LINE if la >= 1.0 else (*K9_NAVDY_LINE, int(255 * la)),
                                anchor="center")
            else:  # K9HudNavdy 0: gold tag box before b7e81bbd4
                self._rounded_rect(lx - tw * 0.5 - 7.0, ly - 31.0, tw + 16.0, 26.0, 8.0, (0, 0, 0, int(90 * la)), None)
                self._rounded_rect(lx - tw * 0.5 - 8.0, ly - 32.0, tw + 16.0, 26.0, 8.0,
                                   K9_TURZX_TAG if la >= 1.0 else (*K9_TURZX_TAG[:3], int(255 * la)), None)
                self._draw_text(tag, lx, ly - 19.0, 22.0, (34, 26, 12) if la >= 1.0 else (34, 26, 12, int(255 * la)), anchor="center")
        self._k9_va = 1.0
        self._k9_turzx_draw_ego()

    def _k9_turzx_draw_middle(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> None:
        x0, y0, w, h = K9_TURZX_MID_X, K9_TURZX_MARGIN, K9_TURZX_MID_W, K9_TURZX_TOP_H
        guidance, nxt, _, _ = self.k9_navi_items(state)
        self._k9c_tbt_rect = None if guidance is None else (x0 + w - 260.0, y0 + 12.0, x0 + w - 12.0,
                                                            y0 + 12.0 + (124.0 if nxt is not None else 100.0))
        sx, sy = self.width / DESIGN_WIDTH, self.height / DESIGN_HEIGHT
        self._k9_turzx_shadow(x0, y0, w, h, K9_TURZX_RADIUS)
        rl.begin_scissor_mode(int(x0 * sx), int(y0 * sy), int(w * sx), int(h * sy))
        try:
            self._k9_turzx_draw_road(state)
        finally:
            rl.end_scissor_mode()
        # mask the square scissor corners to the card radius, then the glass edge
        rr = K9_TURZX_RADIUS
        rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x0 - 6.0, y0 - 6.0, w + 12.0, h + 12.0), (rr + 6.0) / (h + 12.0), 12,
                                           6.0, rl_color(K9_TURZX_BG))
        rl.draw_rectangle_rounded_lines_ex(rl.Rectangle(x0, y0, w, h), rr / h, 12, 1.0, rl.Color(*K9_TURZX_CHAMPAGNE, 80))
        rl.draw_rectangle_gradient_h(int(x0 + rr), int(y0), int(w * 0.5 - rr), 1, rl.Color(*K9_TURZX_CHROME, 0),
                                     rl.Color(*K9_TURZX_CHROME, 170))
        rl.draw_rectangle_gradient_h(int(x0 + w * 0.5), int(y0), int(w * 0.5 - rr), 1, rl.Color(*K9_TURZX_CHROME, 170),
                                     rl.Color(*K9_TURZX_CHROME, 0))
        theme = self._current_theme()
        # speed box: gear / speed / MAX (cruise set)
        bx, by, bw, bh = x0 + 12, y0 + 12, 264.0, 88.0
        self._k9_turzx_glass(bx, by, bw, bh, K9_TURZX_RADIUS, K9_TURZX_MID_CARD, shadow=False)
        gear = str(getattr(state, "gear_text", "") or "").strip().upper() or "-"
        gear = "D" if gear.isdigit() else gear
        gx, gy = bx + 12, by + bh * 0.5 - 22.0
        self._rounded_rect(gx - 2, gy - 2, 44.0, 48.0, 12.0, (0, 0, 0, 0), (*K9_TURZX_CHAMPAGNE, 50), 1.0)
        self._rounded_rect(gx, gy, 40.0, 44.0, 10.0, (14, 30, 58, 240), None)
        rl.draw_rectangle_gradient_v(int(gx + 4), int(gy + 2), 32, 18, rl.Color(170, 200, 255, 40), rl.Color(170, 200, 255, 0))
        self._rounded_rect(gx, gy, 40.0, 44.0, 10.0, (0, 0, 0, 0), (*K9_TURZX_CHAMPAGNE, 170), 1.2)
        self._draw_text(gear, bx + 32, by + bh * 0.5, 36.0, K9_TURZX_ACCENT, anchor="center")
        display_speed_kph = state.display_speed_kph if state.display_speed_kph is not None else state.speed_kph
        speed_value = int(round(display_speed(clamp(display_speed_kph, 0.0, MAX_SPEED_KPH), self.is_metric)))
        self._k9_turzx_value_text(str(speed_value), bx + 116, by + bh * 0.5, 66.0, K9_TURZX_TEXT, anchor="center")
        self._draw_text("MAX", bx + 216, by + 26.0, 22.0, K9_TURZX_DIM, anchor="center")
        cruise = self._cruise_set_speed_text(state) if self._cruise_set_visible(state) else "-"
        self._draw_text(cruise, bx + 216, by + 60.0, 36.0, self._cruise_set_color(state, theme) if cruise != "-"
                        else K9_TURZX_DIM, anchor="center")
        left_lit, right_lit = signal_lights
        for lit, side in ((left_lit, -1.0), (right_lit, 1.0)):
            if not lit:
                continue
            ax = x0 + 348.0 + side * 30.0  # beside the speed box (was 960 + 60)
            rl.draw_triangle(rl.Vector2(ax + side * 22, by + 44), rl.Vector2(ax, by + 28) if side > 0 else rl.Vector2(ax, by + 60),
                             rl.Vector2(ax, by + 60) if side > 0 else rl.Vector2(ax, by + 28), rl_color(K9_TURZX_SIGNAL))
        # TBT card (navi guidance only); 22:41 bigger arrow / distance, next guidance small at the bottom
        navi = getattr(state, "navi_live", None)
        guidance, nxt, lane, cam = self.k9_navi_items(state)
        tbt_bottom = None
        if guidance is not None:
            tx, tw = x0 + w - 12 - 248.0, 248.0
            th = 124.0 if nxt is not None else 100.0
            self._k9_turzx_glass(tx, by, tw, th, K9_TURZX_RADIUS, K9_TURZX_MID_CARD, shadow=False)
            self._draw_navi_turn_icon(guidance.turn_type, tx + 42, by + 40, 60.0)
            self._draw_text(self._format_navi_distance(guidance.distance_m), tx + 84, by + 40.0, 48.0, K9_TURZX_TEXT)
            road = self._ellipsize_text(guidance.road_name or guidance.main_text or "", 24.0, tw - 28)
            self._draw_text(road, tx + 14, by + 84.0, 24.0, K9_TURZX_MUTED)
            if nxt is not None:
                self._k9_turzx_metal_h(tx + 14, by + 99.0, tw - 28, 90)
                self._draw_text("다음", tx + 14, by + 112.0, 20.0, K9_TURZX_DIM)
                self._draw_navi_turn_icon(nxt.turn_type, tx + 80, by + 112.0, 22.0)
                self._draw_text(self._format_navi_distance(nxt.distance_m), tx + tw - 14, by + 112.0, 22.0,
                                K9_TURZX_MUTED, anchor="right")
            tbt_bottom = by + th
        if cam is not None:
            self._k9c_draw_camera(cam)
        if lane is not None:
            lx1 = x0 + w - 12.0
            box = self._k9_lane_strip(lane, self.k9_turn_dir(guidance), lx1, K9C_LANE_Y, 216.0, "right", False)
            if lane.distance_m > 0:
                self._draw_text(self._format_navi_distance(lane.distance_m), lx1, K9C_LANE_Y - 14.0, 22.0, K9_TURZX_MUTED,
                                anchor="right")
            self._draw_text("차로", box[0], K9C_LANE_Y - 14.0, 22.0, K9_TURZX_MUTED)
        # speed limit / section enforcement
        speed = getattr(navi, "speed", None) if navi is not None else None
        sign_cx, sign_cy, r = x0 + 60.0, y0 + 178.0, 36.0
        section = speed is not None and speed.section_active and speed.section_speed_limit_kph
        limit = speed.section_speed_limit_kph if section else state.speed_limit_kph
        if limit is not None:
            center = rl.Vector2(sign_cx, sign_cy)
            rl.draw_circle_v(rl.Vector2(sign_cx + 1.0, sign_cy + 3.0), r + 3.0, rl.Color(0, 0, 0, 110))
            rl.draw_ring(center, r + 1.0, r + 3.0, 0.0, 360.0, 48, rl.Color(*K9_TURZX_CHAMPAGNE, 150))
            rl.draw_circle_v(center, r, rl_color(RED))
            rl.draw_circle_v(center, r - 7.0, rl_color(WHITE))
            rl.draw_ring(center, r - 8.0, r - 7.0, 0.0, 360.0, 48, rl.Color(120, 0, 0, 90))
            text = str(int(round(display_speed(limit, self.is_metric))))
            self._draw_text(text, sign_cx, sign_cy, 36.0 if len(text) <= 2 else 30.0, TEXT, anchor="center")
            if section:
                self._rounded_rect(sign_cx - 28.0, sign_cy - r - 30.0, 56.0, 26.0, 6.0, (236, 240, 246), None)
                self._draw_text("구간", sign_cx, sign_cy - r - 17.0, 20.0, (20, 26, 40), anchor="center")
                if speed.section_remaining_distance_m is not None:
                    dist = f"{speed.section_remaining_distance_m / 1000.0:.1f} km"
                    self._rounded_rect(sign_cx - 46.0, sign_cy + r + 6.0, 92.0, 28.0, 6.0, K9_TURZX_MID_CARD, K9_TURZX_MID_EDGE, 1.5)
                    self._draw_text(dist, sign_cx, sign_cy + r + 20.0, 22.0, K9_TURZX_TEXT, anchor="center")
                if speed.section_average_kph is not None:
                    ax0 = sign_cx + r + 12.0
                    self._rounded_rect(ax0, sign_cy - 36.0, 104.0, 72.0, 10.0, K9_TURZX_MID_CARD, K9_TURZX_MID_EDGE, 1.5)
                    self._draw_text("평균속도", ax0 + 52.0, sign_cy - 18.0, 20.0, K9_TURZX_MUTED, anchor="center")
                    self._draw_text(f"{speed.section_average_kph:.0f}", ax0 + 52.0, sign_cy + 14.0, 34.0, K9_TURZX_GOOD,
                                    anchor="center")
        # bottom pills: lane % (left), lead (right)
        pill_y = y0 + 132.0  # 20:48: off the bottom so my car sits at the panel floor; under the TBT card, right side
        if tbt_bottom is not None:
            pill_y = max(pill_y, tbt_bottom + 32.0)  # taller TBT card: pills stay under it
        if self._lane_confidence_label_visible(state):
            lc = getattr(state, "left_lane_line_confidence", None)
            rc = getattr(state, "right_lane_line_confidence", None)
            known = [c for c in (lc, rc) if c is not None and math.isfinite(c)]
            dot = (120, 130, 150) if not known else (K9_TURZX_GOOD if min(known) >= 0.5 else (255, 190, 70))
            text = f"차선 {self._lane_confidence_text(lc)} · {self._lane_confidence_text(rc)}"
            self._k9_turzx_pill(x0 + w - 12.0, pill_y, text, "right", dot)
        lead = self.k9_turzx_lead(state)
        if lead is not None:
            self._k9_turzx_pill(x0 + w - 12.0, pill_y + 48.0, f"앞차 {lead[0]:.0f}m · {lead[1]:+.1f}°", "right")

    def _k9c_draw_camera(self, cam) -> None:
        name, dist, limit, progress, warn = cam
        x, y, w, h = K9C_CAM_X, K9C_CAM_Y, K9C_CAM_W, K9C_CAM_H
        self._k9_turzx_glass(x, y, w, h, 12.0, K9_TURZX_MID_CARD, shadow=False)
        name = self._ellipsize_text(name, 20.0, w - 84.0)
        self._draw_text(name, x + 14, y + 17.0, 20.0, K9_TURZX_MUTED)
        self._draw_text(self._format_navi_distance(dist), x + 14, y + 38.0, 30.0, warn or K9_TURZX_TEXT)
        cx, cy, r = x + w - 32.0, y + h * 0.5 - 2.0, 22.0
        rl.draw_circle_v(rl.Vector2(cx, cy), r, rl_color(RED))
        rl.draw_circle_v(rl.Vector2(cx, cy), r - 5.0, rl_color(WHITE))
        text = str(int(round(display_speed(limit, self.is_metric))))
        self._draw_text(text, cx, cy, 22.0 if len(text) <= 2 else 18.0, TEXT, anchor="center")
        self._draw_clean_progress(x + 14.0, y + h - 7.0, w - 70.0, progress, warn or K9_TURZX_PATH, K9_TURZX_DIM)

    def k9_lat_lines(self, state: ClusterUiState) -> list[tuple[str, list[str], bool]]:
        """steering-learn texts as one item per line (00:20): [(name, values, second item of its text)], text unchanged;
        a nameless value ('지연학습 100%  0.20초') stays on its item's line"""
        texts = (
            lat_values_text(getattr(state, "applied_steer_ratio", None), getattr(state, "applied_steer_delay_s", None)),
            delay_learn_text(getattr(state, "delay_learn_perc", None), getattr(state, "delay_learn_s", None)),
            torque_learned_text(getattr(state, "torque_filtered_lat_accel_factor", None),
                                getattr(state, "torque_filtered_friction", None)),
            torque_applied_text(getattr(state, "torque_learn_lat_accel_factor", None),
                                getattr(state, "torque_learn_friction", None)),
            learned_steer_ratio_text(getattr(state, "learned_steer_ratio", None), getattr(state, "delay_learn_s", None)),
        )
        lines: list[tuple[str, list[str], bool]] = []
        for text in texts:
            if text is None:
                continue
            for j, (name, value) in enumerate(self._k9l_pairs(text)):
                if not name and lines:
                    lines[-1][1].append(value)
                else:
                    lines.append((name, [value], j > 0))
        return lines

    def _k9_turzx_draw_right(self, state: ClusterUiState) -> None:
        # 대감님 18:30: music card removed; lane position + steering-learn lines moved here from the middle (same text)
        # 23:12: drawn at card 3's x and moved to card 1 (K9C_SWAP_DX), only K9C_LANE_W wide now
        # 11/13 00:47: K9T tiers (same as the car card), steering learn as name-over-value items, two per line
        x0, y0, h, w = K9_TURZX_RIGHT_X, K9_TURZX_MARGIN, K9_TURZX_TOP_H, K9C_LANE_W
        self._k9_turzx_glass(x0, y0, w, h)
        self._k9t_list(state, False, x0 + 20.0, x0 + w - 20.0, y0 + 12.0, y0 + h - 8.0)

    def _k9_turzx_draw_alert(self, alert: ClusterAlert | None) -> None:
        # alert as a band at the top of the middle panel (was centred on the 1920 screen over the left panel)
        if alert is None or alert.size <= 0 or not (alert.text1 or alert.text2):
            return
        sx, sy = self.width / DESIGN_WIDTH, self.height / DESIGN_HEIGHT
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        try:
            w = K9_TURZX_MID_W - 16.0 if self.k9_hud_style != K9_HUD_STYLE_SCENE else 560.0
            x0 = getattr(self, "_k9_cx", K9C_CX) - w * 0.5
            title, detail = self._cluster_alert_text(alert)
            if not title and detail:
                title, detail = detail, ""
            title, title_size = self._fit_alert_text(title, 40.0, w - 32.0, 26.0)
            detail, detail_size = self._fit_alert_text(detail, 26.0, w - 32.0, 20.0)
            bh = 104.0 if detail else 72.0
            color = CLUSTER_ALERT_TEXT_COLORS.get(alert.status, CLUSTER_ALERT_TEXT_COLORS[0])
            self._rounded_rect(x0, K9_TURZX_MARGIN + 8.0, w, bh, 12.0, (16, 10, 14, 240), color, 3.0)
            cx = x0 + w * 0.5
            if detail:
                self._draw_text(title, cx, K9_TURZX_MARGIN + 40.0, title_size, color, anchor="center")
                self._draw_text(detail, cx, K9_TURZX_MARGIN + 82.0, detail_size, WHITE, anchor="center")
            else:
                self._draw_text(title, cx, K9_TURZX_MARGIN + 44.0, title_size, color, anchor="center")
        finally:
            rl.rl_pop_matrix()

    def _k9_turzx_draw_hud(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> None:
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        try:
            self._k9_ind_active = self._k9_indicator_active()
            if self.k9_hud_style == K9_HUD_STYLE_SCENE:
                self._k9_geo, self._k9_cx = K9L_ROAD_GEO, K9L_CX
                self._k9l_draw_hud(state, signal_lights)  # 21:44 one-scene redesign
            else:
                self._k9_geo, self._k9_cx = K9C_ROAD_GEO, K9C_CX
                self._k9c_draw_hud(state, signal_lights)  # b03a700cc cards
        finally:
            rl.rl_pop_matrix()

    k9_hud_navdy = 0   # K9HudNavdy (실험중): 0 = look before b7e81bbd4 / 1 = Navdy grey, K9 D road only

    def set_k9_hud_navdy(self, value) -> None:
        try:
            v = int(value)
        except (TypeError, ValueError):
            v = 0
        self.k9_hud_navdy = v if v in (0, 1) else 0

    def k9_navdy_on(self) -> bool:
        """the single K9HudNavdy switch point (later Navdy-only additions hang off this)"""
        return self.k9_hud_navdy == 1

    def k9_look(self):
        return K9_LOOK_NAVDY if self.k9_navdy_on() else K9_LOOK_OLD

    def _k9_old_path_band(self, path, end_m, outer, inner, outer_col, inner_col, edge_col, edge_w, edge_a) -> None:
        """K9HudNavdy 0: the path band + edges before b7e81bbd4 (same calls, same order)"""
        pl = self.k9_path_side(path, -outer)
        pr = self.k9_path_side(path, outer)
        self._k9_turzx_band(pl, pr, outer_col, fade=True, end_m=end_m)
        cl = self.k9_path_side(path, -inner)
        cr_ = self.k9_path_side(path, inner)
        self._k9_turzx_band(cl, cr_, inner_col, fade=True, end_m=end_m)
        pl_e = [(f, lat) for f, lat in pl if end_m is None or f <= end_m]
        pr_e = [(f, lat) for f, lat in pr if end_m is None or f <= end_m]
        self._k9_turzx_line(pl_e, edge_col, edge_w, False, False, edge_a)
        self._k9_turzx_line(pr_e, edge_col, edge_w, False, False, edge_a)

    def set_k9_hud_style(self, style) -> None:
        try:
            value = int(style)
        except (TypeError, ValueError):
            value = K9_HUD_STYLE_CARD
        self.k9_hud_style = value if value in (K9_HUD_STYLE_CARD, K9_HUD_STYLE_SCENE) else K9_HUD_STYLE_CARD

    @staticmethod
    def _k9_indicator_active() -> bool:
        try:
            from openpilot.common.indicator_display import current
            return current() is not None
        except Exception:
            return False

    def k9_indicator_y(self) -> float:
        return K9L_IND_Y if self.k9_hud_style == K9_HUD_STYLE_SCENE else K9C_IND_Y

    @contextmanager
    def _k9_shift(self, dx: float):
        """draw a side block moved by dx (1칸 <-> 3칸); _k9_dx lets checks know where the text really is"""
        rl.rl_push_matrix()
        rl.rl_translatef(dx, 0.0, 0.0)
        self._k9_dx = dx
        try:
            yield
        finally:
            rl.rl_pop_matrix()
            self._k9_dx = 0.0

    def _k9c_draw_hud(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> None:
        rl.draw_rectangle_gradient_v(0, 0, int(DESIGN_WIDTH), int(DESIGN_HEIGHT), rl_color(K9_TURZX_BG_TOP),
                                     rl_color(K9_TURZX_BG))
        rl.draw_rectangle_gradient_v(0, int(DESIGN_HEIGHT) - 24, int(DESIGN_WIDTH), 24, rl.Color(*K9_TURZX_LANE, 0),
                                     rl.Color(*K9_TURZX_LANE, 10))
        with self._k9_shift(K9C_SWAP_DX):
            self._k9_turzx_draw_left(state)
        self._k9_turzx_draw_middle(state, signal_lights)
        with self._k9_shift(-K9C_SWAP_DX):
            self._k9_turzx_draw_right(state)

    # ---- navi items for both K9 D layouts (11/12 22:41) ------------------------------------------------------------
    def k9_navi_items(self, state: ClusterUiState):
        """(turn guidance, next guidance, lane info, camera) shown on the K9 D screens, None when absent.
        camera = (name, distance m, limit kph, progress 0..1 filling while approaching, warn colour or None);
        like the EV6 chip it shows from CLEAN_CAMERA_SHOW_M (1000 m) on and only with a speed limit."""
        navi = getattr(state, "navi_live", None)
        if navi is None:
            return None, None, None, None
        cur = navi.current if navi.current is not None and navi.current.distance_m > 0 else None
        nxt = navi.next if navi.next is not None and navi.next.distance_m > 0 else None
        lane = navi.lane_current
        if (lane is None or not lane.visible) and navi.lane_ahead:
            lane = next((item for item in navi.lane_ahead if item.visible), None)
        if lane is not None and (not lane.visible or min(8, max(lane.count, len(lane.available), len(lane.turn_info))) <= 0):
            lane = None
        cam = None
        sp = navi.speed
        if sp is not None and sp.sdi_type is not None and sp.sdi_distance_m is not None:
            dist, limit = sp.sdi_distance_m, sp.sdi_speed_limit_kph or 0
            if 0 < dist <= CLEAN_CAMERA_SHOW_M and limit > 0:
                over = (state.speed_kph or 0.0) - limit
                warn = RED if over >= CLEAN_SPEED_OVER_RED_KPH else AMBER if over > 0 else None
                cam = (K9_SDI_NAMES.get(sp.sdi_type, "단속 카메라"), dist, limit,
                       clamp(1.0 - dist / CLEAN_CAMERA_SHOW_M, 0.0, 1.0), warn)
        return cur, nxt, lane, cam

    @staticmethod
    def k9_turn_dir(guidance) -> float:
        if guidance is None:
            return 0.0
        return -1.0 if guidance.turn_type in NAVI_TURN_LEFT_TYPES else 1.0 if guidance.turn_type in NAVI_TURN_RIGHT_TYPES else 0.0

    def _k9_lane_strip(self, lane, turn_dir: float, x: float, y: float, w: float, anchor: str, scene: bool):
        """one cell per lane, arrow in each; recommended lanes (available > 0) lit and bent toward the turn,
        my lane (currentLane) underlined. Returns the box (x0, y0, x1, y1)."""
        count = min(8, max(lane.count, len(lane.available), len(lane.turn_info)))
        gap, h = 4.0, K9_LANE_CELL_H
        cw = min(34.0, (w - gap * (count - 1)) / count)
        total = cw * count + gap * (count - 1)
        x0 = x - total if anchor == "right" else x
        cur = lane.current_lane - 1 if 1 <= lane.current_lane <= count else -1
        lit = K9L_ICE if scene else K9_TURZX_PATH
        for i in range(count):
            rec = i < len(lane.available) and lane.available[i] > 0
            lx = x0 + i * (cw + gap)
            cx = lx + cw * 0.5
            if scene:
                fill = (*lit, 46) if rec else (8, 13, 26, 150)
                edge = (*lit, 230) if rec else (*K9L_CHAMPAGNE, 70)
            else:
                fill = (18, 70, 70, 230) if rec else (12, 19, 36, 220)
                edge = (*lit, 255) if rec else (*K9_TURZX_EDGE, 255)
            self._rounded_rect(lx, y, cw, h, 6.0, fill, edge, 2.0 if rec else 1.0)
            col = rl_color((250, 252, 255) if rec else (K9L_DIM if scene else K9_TURZX_DIM))
            bot, mid, top = rl.Vector2(cx, y + h - 8.0), rl.Vector2(cx, y + h * 0.52), rl.Vector2(cx, y + 9.0)
            bend = turn_dir if rec else 0.0
            if bend:
                tip = rl.Vector2(cx + bend * cw * 0.32, y + 12.0)
                rl.draw_line_ex(bot, mid, 3.0, col)
                rl.draw_line_ex(mid, rl.Vector2(cx + bend * cw * 0.18, y + 18.0), 3.0, col)
                self._k9_turzx_tri(tip, rl.Vector2(cx + bend * cw * 0.02, y + 15.0), rl.Vector2(cx + bend * cw * 0.26, y + 25.0), col)
            else:
                rl.draw_line_ex(bot, rl.Vector2(cx, y + 16.0), 3.0, col)
                self._k9_turzx_tri(top, rl.Vector2(cx - 6.0, y + 18.0), rl.Vector2(cx + 6.0, y + 18.0), col)
            if i == cur:
                rl.draw_rectangle_rec(rl.Rectangle(lx + 4.0, y + h + 3.0, cw - 8.0, 3.0),
                                      rl_color(K9L_CHAMPAGNE if scene else K9_TURZX_POINT))
        return x0, y, x0 + total, y + h + 6.0

    def _k9_lane_rows(self, state: ClusterUiState) -> tuple[str, str]:
        """차선 위치 rows; -- (no line) reads as 대기 instead of an empty-looking dash (11/12 22:41 남은 약점)"""
        t1 = lane_offset_text(getattr(state, "k9_lane_offset_m", None))
        if t1 == lane_offset_text(None):
            t1 = "치우침 대기"
        t2 = lane_gap_text(getattr(state, "k9_lane_gap_left_m", None), getattr(state, "k9_lane_gap_right_m", None))
        return t1, t2.replace("--", "대기")

    def k9_lane_block(self, state: ClusterUiState) -> list[list[tuple[str, str]]]:
        """차선 위치 as one block (23:12): [[('치우침', '→ 12cm')], [('좌', '1.87m'), ('우', '1.63m')]], a missing value
        reads 대기; with no value at all a single [[('', '대기')]]"""
        t1, t2 = self._k9_lane_rows(state)
        if t1 == "치우침 대기" and t2 == lane_gap_text(None, None).replace("--", "대기"):
            return [[("", "대기")]]
        return [self._k9l_pairs(t1, first_space=True), self._k9l_pairs(t2, first_space=True)]

    @staticmethod
    def k9_trip_km_text(dist_m) -> str:
        if dist_m is None:
            return "-"
        km = dist_m / 1000.0
        return f"{km:.0f}" if km >= 999.95 else f"{km:.1f}"  # 1000 km and more: no decimal (same width as 999.9)

    # ---- K9 TURZX luxury scene (대감님 11/12 21:44 "그게 고급짐의 한계인가?") -----------------------------------------
    # One continuous night scene instead of three cards: no card borders, information floats as type on a deep navy
    # field, the road in the middle is the hero (horizon light, reflection, perspective fog), speed is the largest
    # glyph. Palette: black / deep navy / champagne / ice sky blue (+ red warnings, green turn signals unchanged).
    # Fonts: Inter Light (numbers) and Pretendard Medium (Korean labels), both SIL OFL, already in assets/fonts.
    # Every size is scaled so the drawn ink height is >= the KaiGen glyph height it replaces (K9L_*_INK).
    def _k9l_fonts(self):
        fonts = getattr(self, "_k9l_font_pair", None)
        if fonts is not None or getattr(self, "_k9l_font_tried", False):
            return fonts
        self._k9l_font_tried = True
        try:
            rl.set_trace_log_level(rl.TraceLogLevel.LOG_ERROR)
            num_cps = list(range(32, 127)) + [ord(c) for c in K9L_NUM_EXTRA]
            kr_cps = sorted(set(range(32, 127)) | {ord(c) for c in K9L_KR_GLYPHS if ord(c) > 126})
            nb = rl.ffi.new("int[]", num_cps)
            kb = rl.ffi.new("int[]", kr_cps)
            num = rl.load_font_ex(str(K9L_NUM_FONT_PATH), 160, rl.ffi.cast("int *", nb), len(num_cps))
            kr = rl.load_font_ex(str(K9L_KR_FONT_PATH), 72, rl.ffi.cast("int *", kb), len(kr_cps))
            rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
            if num.texture.id <= 0 or kr.texture.id <= 0:
                return None
            for f in (num, kr):
                rl.gen_texture_mipmaps(f.texture)
                rl.set_texture_filter(f.texture, rl.TextureFilter.TEXTURE_FILTER_TRILINEAR)
            self._k9l_font_pair = (num, kr, set(num_cps), set(kr_cps))
        except Exception as exc:  # fall back to the cluster fonts
            rl.set_trace_log_level(rl.TraceLogLevel.LOG_WARNING)
            print(f"K9 luxury font load failed: {exc}")
            self._k9l_font_pair = None
        return self._k9l_font_pair

    def _k9l_unload(self) -> None:
        fonts = getattr(self, "_k9l_font_pair", None)
        if fonts is not None:
            rl.unload_font(fonts[0])
            rl.unload_font(fonts[1])
        self._k9l_font_pair = None
        self._k9l_font_tried = False
        self._k9l_metric_cache = {}
        bg = getattr(self, "_k9l_bg_texture", None)
        if bg is not None:
            rl.unload_texture(bg)
        self._k9l_bg_texture = None

    def _k9l_font(self, text: str, numeric: bool):
        """(font, ink scale): Inter Light for numbers, Pretendard for Korean; else the cluster font, scale 1."""
        fonts = self._k9l_fonts()
        if fonts is not None:
            num, kr, num_set, kr_set = fonts
            cps = {ord(c) for c in text}
            if numeric and cps <= num_set:
                return num, K9L_NUM_INK
            if cps <= kr_set:
                return kr, K9L_KR_INK
        return self._font_for_text(text), 1.0

    def _k9l_metrics(self, font) -> tuple[float, float]:
        """(baseline, cap height) of a font as a fraction of the draw size, from the 'H' glyph (cached per font)"""
        cache = getattr(self, "_k9l_metric_cache", None)
        if cache is None:
            cache = {}
            self._k9l_metric_cache = cache
        key = int(font.texture.id)
        m = cache.get(key)
        if m is None:
            m = (0.8, 0.7)
            try:
                i = rl.get_glyph_index(font, ord("H"))
                base = max(1, int(font.baseSize))
                g, rec = font.glyphs[i], font.recs[i]
                m = ((float(g.offsetY) + float(rec.height)) / base, float(rec.height) / base)
            except Exception:
                pass
            cache[key] = m
        return m

    def _k9l_text(self, text: str, x: float, y: float, size: float, color, anchor: str = "left", numeric: bool = False,
                  track: float = 0.0, glow: bool = False, shadow: bool = True, base: float | None = None,
                  cap_cy: float | None = None) -> float:
        """floating type; y = box centre, or base = baseline, or cap_cy = centre of the cap height; returns the width"""
        if not text:
            return 0.0
        font, ink = self._k9l_font(text, numeric)
        fs = size * ink
        spacing = fs * track
        tw, th = self._measure_text(text, fs, spacing, font)
        if track > 0.0 and len(text) > 1:
            tw -= spacing  # no trailing letter space: right / centre anchors sit on the ink
        dx = x - tw * 0.5 if anchor == "center" else (x - tw if anchor == "right" else x)
        if base is not None or cap_cy is not None:
            b, cap = self._k9l_metrics(font)
            bl = base if base is not None else cap_cy + cap * fs * 0.5
            dy = float(round(bl - b * fs))
        else:
            dy = y - th * 0.5
        dx = float(round(dx))
        if shadow:
            rl.draw_text_ex(font, text, rl.Vector2(dx, dy + 2.0), fs, spacing, rl.Color(0, 0, 0, 150))
        r, g, b_ = color[:3]
        if glow:
            for ox, oy in ((-1.2, 0.0), (1.2, 0.0), (0.0, -1.2), (0.0, 1.2)):
                rl.draw_text_ex(font, text, rl.Vector2(dx + ox, dy + oy), fs, spacing, rl.Color(r, g, b_, 26))
        rl.draw_text_ex(font, text, rl.Vector2(dx, dy), fs, spacing, rl_color(color))
        return tw

    def _k9l_width(self, text: str, size: float, numeric: bool = False, track: float = 0.0) -> float:
        font, ink = self._k9l_font(text, numeric)
        w = self._measure_text(text, size * ink, size * ink * track, font)[0]
        return w - size * ink * track if track > 0.0 and len(text) > 1 else w

    def _k9l_background(self):
        """the static night field, drawn once with numpy and kept as a texture"""
        tex = getattr(self, "_k9l_bg_texture", None)
        if tex is not None:
            return tex
        w, h = int(DESIGN_WIDTH), int(DESIGN_HEIGHT)
        y = np.arange(h, dtype=np.float32)[:, None]
        x = np.arange(w, dtype=np.float32)[None, :]
        t = y / (h - 1)
        top, bot = np.array(K9L_BG_TOP, np.float32), np.array(K9L_BG_BOTTOM, np.float32)
        img = top[None, None, :] * (1.0 - t[..., None]) + bot[None, None, :] * t[..., None]
        img = np.broadcast_to(img, (h, w, 3)).copy()
        hy = K9_TURZX_ROAD_HORIZON_Y
        dx = (x - K9L_CX)
        ice = np.array(K9L_ICE, np.float32)
        champ = np.array(K9L_CHAMPAGNE, np.float32)
        above = y < hy
        dy = y - hy
        # wide soft horizon light (sky side taller, road side short), then a tight bright core
        glow = np.exp(-(dx / 560.0) ** 2) * np.where(above, np.exp(-(dy / 70.0) ** 2), np.exp(-(dy / 26.0) ** 2))
        core = np.exp(-(dx / 300.0) ** 2) * np.exp(-(dy / 9.0) ** 2)
        img += ice[None, None, :] * (glow * 0.30 + core * 0.42)[..., None]
        # the light reflected on the road: a long faint column under the vanishing point
        refl = np.where(above, 0.0, np.exp(-(dx / 150.0) ** 2) * np.exp(-(dy / 200.0)) * 0.13)
        img += ice[None, None, :] * refl[..., None]
        # one champagne hairline on the horizon, fading out to both sides
        line = np.exp(-(dx / 360.0) ** 2) * np.exp(-((y - hy) / 0.7) ** 2) * 0.55
        img += champ[None, None, :] * line[..., None]
        # vignette: corners fall into black
        vx = np.abs(dx) / 960.0
        vig = 1.0 - 0.45 * vx ** 3
        img *= vig[..., None]
        rng = np.random.default_rng(9)
        img += rng.uniform(-0.6, 0.6, img.shape).astype(np.float32)  # dither: no banding in the dark gradients
        rgba = np.empty((h, w, 4), np.uint8)
        rgba[..., :3] = np.clip(img, 0, 255).astype(np.uint8)
        # background colour beside the scene, per 12 px strip: the scene edge fades into exactly this colour
        y0s = int(hy) - 4
        xl, xr = int(K9L_SCENE_X0) + 1, int(K9L_SCENE_X1) - 2
        self._k9l_side_rows = [(yy, min(12, h - yy), tuple(int(v) for v in rgba[min(h - 1, yy + 6), xl, :3]),
                                tuple(int(v) for v in rgba[min(h - 1, yy + 6), xr, :3])) for yy in range(y0s, h, 12)]
        rgba[..., 3] = 255
        data = np.ascontiguousarray(rgba)
        image = rl.Image(rl.ffi.from_buffer(data), w, h, 1, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
        tex = rl.load_texture_from_image(image)
        rl.set_texture_filter(tex, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
        self._k9l_bg_texture = tex
        return tex

    def _k9l_hair(self, x: float, y: float, w: float, a: int = 120) -> None:
        self._k9_turzx_metal_h(x, y, w, a)

    def _k9l_meter(self, x: float, y: float, w: float, fraction: float | None, color, centred: bool = False,
                   neg_color=None) -> None:
        """every meter the same: 1 px champagne track, 2 px lit line, one glowing end point (centre tick if centred)"""
        x, y, w = int(x), int(y), int(w)
        h = w // 2
        rl.draw_rectangle_gradient_h(x, y, h, 1, rl.Color(*K9L_CHAMPAGNE, 30), rl.Color(*K9L_CHAMPAGNE, 84))
        rl.draw_rectangle_gradient_h(x + h, y, w - h, 1, rl.Color(*K9L_CHAMPAGNE, 84), rl.Color(*K9L_CHAMPAGNE, 30))
        if centred:
            rl.draw_rectangle(x + h, y - 4, 1, 9, rl.Color(*K9L_CHAMPAGNE, 150))
        if fraction is None or not math.isfinite(fraction):
            return
        if centred:
            f = clamp(fraction, -1.0, 1.0)
            x0, x1 = x + h + 0.5, x + h + 0.5 + h * f
            c = color if f >= 0.0 else (neg_color or color)
        else:
            f = clamp(fraction, 0.0, 1.0)
            x0, x1, c = float(x), x + w * f, color
        lo, hi = min(x0, x1), max(x0, x1)
        if hi - lo >= 1.0:
            rl.draw_rectangle_rec(rl.Rectangle(lo, y, hi - lo, 2.0), rl_color(c, 230))
        p = rl.Vector2(x1, y + 1.0)
        rl.draw_circle_v(p, 7.0, rl_color(c, 36))
        rl.draw_circle_v(p, 4.2, rl_color(c, 96))
        rl.draw_circle_v(p, 2.2, rl.Color(250, 252, 255, 255))

    def _k9l_draw_left(self, state: ClusterUiState) -> None:
        # 11/13 00:47 320 px block: range / trip / accel / steering angle in the K9T tiers, TPMS under them
        x0, x1 = K9L_EDGE, K9L_EDGE + K9L_CAR_W

        def meter(x, cy, mw, kind, fraction):
            if kind == "plain":
                self._k9l_meter(x, cy, mw, fraction, K9L_ICE)
            elif kind == "accel":
                self._k9l_meter(x, cy, mw, fraction, K9L_ICE, True, (255, 120, 90))
            else:
                self._k9l_meter(x, cy, mw, fraction, K9L_CHAMPAGNE, True, K9L_CHAMPAGNE)

        self._k9t_car_rows(state, True, x0, x1, 8.0, K9L_TPMS_HAIR - 4.0, meter)
        self._k9l_hair(x0, K9L_TPMS_HAIR, K9L_CAR_W, 110)
        self._k9l_draw_tpms(state)

    def _k9l_draw_tpms(self, state: ClusterUiState) -> None:
        # top view of the car, each tyre number right outside its wheel (label above the number, same side)
        cx, cy, k = K9L_TPMS_X, K9L_TPMS_Y, K9L_TPMS_SCALE
        car_w, car_h = 64.0 * k, 190.0 * k
        top, left = cy - car_h * 0.5, cx - car_w * 0.5
        wheel_w, wheel_h, wheel_in = 6.0, 34.0 * k, 29.0 * k
        num_x = (left - wheel_w - 12.0, left + car_w + wheel_w + 12.0)
        self._k9l_text("TPMS", K9L_EDGE, 0.0, K9_TURZX_LABEL_SIZE, K9L_LABEL, track=K9L_TRACK, base=K9L_TPMS_HEAD)
        self._k9l_text("psi", K9L_EDGE + K9L_CAR_W, 0.0, K9_TURZX_LABEL_SIZE, K9L_DIM, anchor="right", numeric=True,
                       base=K9L_TPMS_HEAD)
        rl.draw_ellipse(int(cx), int(cy + 4), car_w * 1.05, car_h * 0.6, rl.Color(*K9L_ICE, 6))
        wheel_cy = (top + wheel_in + wheel_h * 0.5, top + car_h - wheel_in - wheel_h * 0.5)
        for wx in (left - wheel_w, left + car_w):
            for wcy in wheel_cy:
                self._rounded_rect(wx, wcy - wheel_h * 0.5, wheel_w, wheel_h, 3.0, (10, 14, 24), (*K9L_CHAMPAGNE, 120), 1.0)
        self._rounded_rect(left, top, car_w, car_h, 26.0 * k, (8, 13, 26), (*K9L_CHAMPAGNE, 200), 1.4)
        self._rounded_rect(left + 9 * k, top + 40 * k, car_w - 18 * k, 32 * k, 9.0 * k, (20, 34, 60), (*K9L_ICE, 110), 1.0)
        self._rounded_rect(left + 10 * k, top + car_h - 50 * k, car_w - 20 * k, 22 * k, 7.0 * k, (16, 26, 46),
                           (*K9L_ICE, 80), 1.0)
        rl.draw_line_ex(rl.Vector2(cx, top + 80 * k), rl.Vector2(cx, top + car_h - 58 * k), 1.0, rl.Color(*K9L_CHAMPAGNE, 70))
        tpms = state.tpms
        gap = 12.0
        for value, sx, row, name in ((tpms.fl, 0, 0, "FL"), (tpms.fr, 1, 0, "FR"), (tpms.rl, 0, 1, "RL"), (tpms.rr, 1, 1, "RR")):
            vx, wcy = num_x[sx], wheel_cy[row]
            anchor = "right" if sx == 0 else "left"
            text = "-" if value is None or not math.isfinite(value) else str(int(round(value)))
            vw = self._k9l_text(text, vx, 0.0, K9T_VALUE, K9L_VALUE if text != "-" else K9L_DIM, anchor=anchor, numeric=True,
                                base=wcy + 13.0 * K9T_VALUE / 36.0)
            nx = vx - vw - gap if sx == 0 else vx + vw + gap  # 23:44 name beside the number (outside), not above it
            self._k9l_text(name, nx, 0.0, K9_TURZX_LABEL_SIZE, K9L_DIM, anchor=anchor, numeric=True, track=0.06,
                           base=wcy + 13.0 * K9T_VALUE / 36.0)

    def _k9l_vehicle(self, forward_m: float, lateral_m: float, lead: bool,
                     heading_deg: float = 0.0) -> tuple[float, float, float]:
        """rear view of a car ahead: dark body, metal rim, a thin glowing light bar, soft floor shadow"""
        lk = self.k9_look()
        drawn = self._k9_navdy_vehicle(forward_m, lateral_m, lk.l_lead_tint if lead else lk.l_other_tint, heading_deg)
        if drawn is not None:
            return drawn
        x, y, scale = self.k9_turzx_road_project(forward_m, lateral_m)
        w = max(18.0, 1.9 * scale)
        h = w * 0.58
        rim = K9L_CHAMPAGNE if lead else (130, 150, 186)
        rl.draw_ellipse(int(x), int(y), w * 0.74, max(4.0, h * 0.2), rl.Color(0, 0, 0, 90))
        self._rounded_rect(x - w * 0.5, y - h, w, h, w * 0.2, (22, 28, 44) if lead else (18, 26, 44), (*rim, 230), 1.4)
        self._rounded_rect(x - w * 0.34, y - h * 0.92, w * 0.68, h * 0.34, w * 0.1, (40, 56, 84), None)
        bar_y = y - h * 0.46
        rl.draw_rectangle_rec(rl.Rectangle(x - w * 0.44, bar_y - h * 0.08, w * 0.88, h * 0.16), rl.Color(255, 40, 60, 60))
        rl.draw_rectangle_rec(rl.Rectangle(x - w * 0.42, bar_y - 1.0, w * 0.84, max(2.0, h * 0.07)), rl.Color(255, 70, 90, 255))
        rl.draw_rectangle_gradient_v(int(x - w * 0.4), int(y + 1), int(w * 0.8), int(max(6.0, w * 0.55)),
                                     rl.Color(255, 60, 80, 40), rl.Color(255, 60, 80, 0))  # light bar on the wet road
        return x, y - h, w

    def _k9l_draw_road(self, state: ClusterUiState) -> None:
        sx0, sx1 = K9L_SCENE_X0, K9L_SCENE_X1
        hy = K9_TURZX_ROAD_HORIZON_Y
        lanes = list(getattr(state, "lanes", ()) or ())
        lane_pts = [(lane, self._k9_turzx_points(lane.model_points)) for lane in lanes]
        lane_pts = [(lane, pts) for lane, pts in lane_pts if len(pts) >= 2]
        def near(pts):
            return self._k9_turzx_lat_at(pts, 5.0) or pts[0][1]
        lefts = sorted([(near(p), lane, p) for lane, p in lane_pts if near(p) < 0.0], key=lambda t: t[0])
        rights = sorted([(near(p), lane, p) for lane, p in lane_pts if near(p) >= 0.0], key=lambda t: t[0])
        lefts, rights = self._k9_lanesm_lanes(state, lefts, rights)  # display-only smoothing (11/13 04:59)
        ego_l = lefts[-1] if lefts else None
        ego_r = rights[0] if rights else None
        le = self._k9_lanesm("edgeL", self._k9_turzx_points(getattr(state, "left_road_edge_points", ())))
        re_ = self._k9_lanesm("edgeR", self._k9_turzx_points(getattr(state, "right_road_edge_points", ())))
        if len(le) < 2 and lefts:
            le = lefts[0][2]
        if len(re_) < 2 and rights:
            re_ = rights[-1][2]
        if len(le) >= 2 and len(re_) >= 2:
            # translucent asphalt: the horizon light reflection of the background shows through it (wet road)
            lk = self.k9_look()
            self._k9_turzx_band(le, re_, lk.l_road)
            self._k9_turzx_line(le, lk.l_kerb, 0.06, False, False, lk.l_kerb_a)  # kerbs
            self._k9_turzx_line(re_, lk.l_kerb, 0.06, False, False, lk.l_kerb_a)
        for group in (lefts[:-1], rights[1:]):
            for _, lane, pts in group:
                if getattr(lane, "visible", True):
                    self._k9_turzx_line(pts, self.k9_look().l_adj, 0.11, False, True, self.k9_look().l_adj_a * self._k9_fade(lane))
        lead = self.k9_turzx_lead(state)
        path = self._k9_lanesm("path", self._k9_turzx_points(getattr(state, "model_path", ()), 90.0))
        end_m = None if lead is None else max(7.0, lead[0])
        if len(path) >= 2:
            path = [(f, lat) for f, lat in path if f >= 0.0] or path  # ahead of my car only
            if path[0][0] > 0.0:
                path.insert(0, (0.0, path[0][1]))
            if self.k9_navdy_on():
                bl_ = self.k9_path_side(path, -1.62)  # my lane, deep blue (same as the card style)
                br_ = self.k9_path_side(path, 1.62)
                self._k9_turzx_band(bl_, br_, (*K9_NAVDY_EGO_LANE, 215), fade=True)
            else:  # K9HudNavdy 0: ice path band before b7e81bbd4
                self._k9_old_path_band(path, end_m, 1.05, 0.42, (*K9L_ICE, 120), (220, 240, 255, 54), K9L_ICE, 0.07, 0.95)
            top = min(path[-1][0], end_m if end_m is not None else 1e9, 60.0)
            f = 3.0
            while f < top - 2.0:
                lat = self._k9_turzx_lat_at(path, f)
                lat2 = self._k9_turzx_lat_at(path, f + 1.0)
                if lat is None or lat2 is None:
                    break
                ax, ay, sc = self.k9_turzx_road_project(f + 1.0, lat2)
                nf, nl = self.k9_path_normal(1.0, lat2 - lat)  # chevron wings square to the path, not sideways
                bl = self.k9_turzx_road_project(f - 0.36 * nf, lat - 0.36 * nl)
                br = self.k9_turzx_road_project(f + 0.36 * nf, lat + 0.36 * nl)
                aw = max(1.0, 0.06 * sc)
                col = rl.Color(*self.k9_look().l_arrow, int(self.k9_look().l_arrow_a * clamp(1.0 - max(0.0, f) / 60.0, 0.25, 1.0)))
                rl.draw_line_ex(rl.Vector2(bl[0], bl[1]), rl.Vector2(ax, ay), aw, col)
                rl.draw_line_ex(rl.Vector2(br[0], br[1]), rl.Vector2(ax, ay), aw, col)
                f += 5.0 if f < 20.0 else 9.0
        for item, conf in ((ego_l, getattr(state, "left_lane_line_confidence", None)),
                           (ego_r, getattr(state, "right_lane_line_confidence", None))):
            if item is None:
                continue
            a = 1.0 if conf is None or not math.isfinite(conf) else clamp(0.35 + conf * 0.65, 0.35, 1.0)
            if self.k9_navdy_on():
                self._k9_turzx_line(item[2], K9_NAVDY_LINE, 0.09, False, False, a * 0.9 * self._k9_fade(item[1]))
            else:
                self._k9_turzx_line(item[2], K9L_LANE, 0.10, True, False, a * self._k9_fade(item[1]))
        # perspective fog: the far road dissolves into the horizon light
        rl.draw_rectangle_gradient_v(int(sx0), int(hy + 1), int(sx1 - sx0), 90, rl.Color(*K9L_FOG, self.k9_look().l_fog_a),
                                     rl.Color(*K9L_FOG, 0))
        for v in sorted(self.k9_road_others(state), key=lambda v: -v.longitudinal_m):
            f = self.k9_road_clear_of_ego(v.longitudinal_m, v.lateral_m)
            self._k9_va = self._k9_fade(v)
            self._k9l_vehicle(f, v.lateral_m, False, self.k9_road_heading_deg(state, f))
        self._k9_va = la = self._k9_lead_fade(state)
        if lead is not None and lead[0] <= K9_TURZX_ROAD_MAX_M:
            lat = lead[0] * math.tan(math.radians(lead[1]))
            f = self.k9_road_clear_of_ego(lead[0], lat)
            lx, ly, lw = self._k9l_vehicle(f, lat, True, self.k9_road_heading_deg(state, f))
            tag = f"{lead[0]:.0f} m" if self.k9_navdy_on() else f"{lead[0]:.0f}m"
            tw = self._k9l_width(tag, 22.0, True)
            keep_out = self._k9l_perc_rects(state)
            out = 1.0 if lx >= K9L_CX else -1.0
            keep_out = keep_out + self._k9l_navi_rects(state)
            if getattr(self, "_k9_ind_active", False):  # the automatic indicator box sits on the far road
                ix = K9L_CX - 230.0
                keep_out.append((ix, K9L_IND_Y, ix + 460.0, K9L_IND_Y + 24.0 * 2.7))
            spots = [(lx - tw * 0.5, ly - 18.0)]  # above the car, else beside it (outer, inner side)
            for side in (out, -out):
                spots.append((lx + lw * 0.5 + 8.0 if side > 0 else lx - lw * 0.5 - 8.0 - tw, ly + lw * 0.29))

            def free(px: float, cy: float) -> bool:
                if not (K9L_SCENE_X0 + 12.0 <= px and px + tw <= K9L_SCENE_X1 - 12.0):
                    return False
                return all(px + tw < x0 or px > x1 or cy + 10.0 < y0 or cy - 10.0 > y1 for x0, y0, x1, y1 in keep_out)
            spot = next((p for p in spots if free(*p)), None if getattr(self, "_k9_ind_active", False) else spots[0])
            if spot is not None and la >= 0.4:  # under the indicator box: no tag (the lead line keeps the distance)
                tc = self.k9_look().l_tag
                self._k9l_text(tag, spot[0], 0.0, 22.0, tc if la >= 1.0 else (*tc, int(255 * la)),
                               numeric=True, cap_cy=spot[1])
        self._k9_va = 1.0
        # the scene has no frame: the sides melt into the night field
        fw = int(K9L_SCENE_FADE)
        for yy, hh, cl, cr in getattr(self, "_k9l_side_rows", ()):
            rl.draw_rectangle_gradient_h(int(sx0), yy, fw, hh, rl.Color(*cl, 255), rl.Color(*cl, 0))
            rl.draw_rectangle_gradient_h(int(sx1) - fw, yy, fw, hh, rl.Color(*cr, 0), rl.Color(*cr, 255))
        self._k9_turzx_draw_ego()

    def _k9l_perc_texts(self, state: ClusterUiState) -> tuple[str | None, str | None]:
        lane = None
        if self._lane_confidence_label_visible(state):
            lc = self._lane_confidence_text(getattr(state, "left_lane_line_confidence", None))
            rc = self._lane_confidence_text(getattr(state, "right_lane_line_confidence", None))
            lane = f"차선 {lc} · {rc}"
        lead = self.k9_turzx_lead(state)
        return lane, (None if lead is None else f"앞차 {lead[0]:.0f}m · {lead[1]:+.1f}°")

    def _k9l_perc_rects(self, state: ClusterUiState) -> list[tuple[float, float, float, float]]:
        """screen boxes of the lane % / lead line (kept free by the lead distance tag)"""
        lane, lead = self._k9l_perc_texts(state)
        py, out = self._k9l_perc_y(), []
        if lane:
            out.append((K9L_CX - K9L_PERC_GAP - self._k9l_width(lane, 26.0) - 24.0, py - 15.0, K9L_CX - K9L_PERC_GAP, py + 15.0))
        if lead:
            out.append((K9L_CX + K9L_PERC_GAP, py - 15.0, K9L_CX + K9L_PERC_GAP + self._k9l_width(lead, 26.0), py + 15.0))
        return out

    def _k9l_draw_top(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> None:
        theme = self._current_theme()
        cy = K9L_TOP_CY
        display_speed_kph = state.display_speed_kph if state.display_speed_kph is not None else state.speed_kph
        speed_value = int(round(display_speed(clamp(display_speed_kph, 0.0, MAX_SPEED_KPH), self.is_metric)))
        self._k9l_text(str(speed_value), K9L_CX, 0.0, K9L_SPEED_SIZE, K9L_VALUE, anchor="center", numeric=True, glow=True,
                       base=K9L_SPEED_BASE)
        self._k9l_text("km/h", K9L_CX, 0.0, K9_TURZX_SUB_SIZE, K9L_MUTED, anchor="center", numeric=True, track=0.06,
                       base=K9L_KMH_BASE)
        gear = str(getattr(state, "gear_text", "") or "").strip().upper() or "-"
        gear = "D" if gear.isdigit() else gear
        gx = K9L_CX - K9L_SIDE_DX
        self._k9l_text(gear, gx, 0.0, K9L_GEAR_SIZE, K9L_ICE, anchor="center", numeric=True, glow=True, cap_cy=cy)
        rl.draw_ring(rl.Vector2(gx, cy), 33.0, 34.2, 0.0, 360.0, 64, rl.Color(*K9L_CHAMPAGNE, 150))
        mx = K9L_CX + K9L_SIDE_DX
        self._k9l_text("MAX", mx, 0.0, 22.0, K9L_LABEL, anchor="center", numeric=True, track=K9L_TRACK, base=K9L_HEAD)
        cruise = self._cruise_set_speed_text(state) if self._cruise_set_visible(state) else "-"
        self._k9l_text(cruise, mx, 0.0, 36.0, self._cruise_set_color(state, theme) if cruise != "-" else K9L_DIM,
                       anchor="center", numeric=True, base=K9L_SPEED_BASE)
        left_lit, right_lit = signal_lights
        for lit, side in ((left_lit, -1.0), (right_lit, 1.0)):
            if not lit:
                continue
            ax = K9L_CX + side * 48.0  # ◀ km/h ▶
            ay = K9L_KMH_BASE - 8.0
            tip = rl.Vector2(ax + side * 24.0, ay)
            a, b = rl.Vector2(ax, ay - 14.0), rl.Vector2(ax, ay + 14.0)
            self._k9_turzx_tri(tip, a, b, rl_color(K9_TURZX_SIGNAL))
        navi = getattr(state, "navi_live", None)
        self._k9l_draw_navi(state)
        speed = getattr(navi, "speed", None) if navi is not None else None
        sign_cx, sign_cy, r = K9L_SIGN_X, cy, 36.0
        section = speed is not None and speed.section_active and speed.section_speed_limit_kph
        limit = speed.section_speed_limit_kph if section else state.speed_limit_kph
        if limit is not None:
            center = rl.Vector2(sign_cx, sign_cy)
            rl.draw_circle_v(rl.Vector2(sign_cx, sign_cy + 3.0), r + 4.0, rl.Color(0, 0, 0, 120))
            rl.draw_ring(center, r + 2.0, r + 3.2, 0.0, 360.0, 64, rl.Color(*K9L_CHAMPAGNE, 170))
            rl.draw_circle_v(center, r, rl_color(RED))
            rl.draw_circle_v(center, r - 7.0, rl.Color(246, 246, 244, 255))
            text = str(int(round(display_speed(limit, self.is_metric))))
            self._draw_text(text, sign_cx, sign_cy, 36.0 if len(text) <= 2 else 30.0, TEXT, anchor="center")
            if section:
                # one line under the sign, above the horizon light: 평균속도 | 구간 chip | remaining km
                chip_cy = sign_cy + r + 21.0
                self._rounded_rect(sign_cx - 28.0, chip_cy - 13.0, 56.0, 26.0, 6.0, (236, 240, 246), None)
                self._draw_text("구간", sign_cx, chip_cy, 20.0, (20, 26, 40), anchor="center")
                if speed.section_remaining_distance_m is not None:
                    d = f"{speed.section_remaining_distance_m / 1000.0:.1f} km"
                    self._k9l_text(d, sign_cx + 38.0, 0.0, 22.0, K9L_VALUE, numeric=True, cap_cy=chip_cy)
                if speed.section_average_kph is not None:
                    # 22:41: under the chip (left of the chip it ran into the swapped list on the left side)
                    avg_cy = chip_cy + 30.0
                    avg = f"{speed.section_average_kph:.0f}"
                    lw = self._k9l_width("평균속도", 20.0) + 8.0
                    ax0 = sign_cx - (lw + self._k9l_width(avg, 34.0, True)) * 0.5
                    self._k9l_text("평균속도", ax0, 0.0, 20.0, K9L_LABEL, cap_cy=avg_cy)
                    self._k9l_text(avg, ax0 + lw, 0.0, 34.0, K9L_ICE, numeric=True, cap_cy=avg_cy)
        # lane % (left) and lead (right) beside the far road, mirrored about the centre line
        py = self._k9l_perc_y()
        lane_text, lead_text = self._k9l_perc_texts(state)
        if lane_text:
            lc = getattr(state, "left_lane_line_confidence", None)
            rc = getattr(state, "right_lane_line_confidence", None)
            known = [c for c in (lc, rc) if c is not None and math.isfinite(c)]
            dot = (120, 130, 150) if not known else (K9_TURZX_GOOD if min(known) >= 0.5 else (255, 190, 70))
            tx = K9L_CX - K9L_PERC_GAP
            tw = self._k9l_text(lane_text, tx, 0.0, 26.0, K9L_VALUE, anchor="right", cap_cy=py)
            rl.draw_circle_v(rl.Vector2(tx - tw - 16.0, py), 6.0, rl_color(dot))
        if lead_text:
            self._k9l_text(lead_text, K9L_CX + K9L_PERC_GAP, 0.0, 26.0, K9L_VALUE, cap_cy=py)

    def _k9l_perc_y(self) -> float:
        return K9L_PERC_Y_IND if getattr(self, "_k9_ind_active", False) else K9L_PERC_Y

    def _k9l_navi_rects(self, state: ClusterUiState) -> list[tuple[float, float, float, float]]:
        """screen boxes of the scene navi items (kept free by the lead distance tag)"""
        guidance, nxt, lane, cam = self.k9_navi_items(state)
        out = []
        if guidance is not None:
            out.append((K9L_SCENE_X1 - 200.0, K9L_NAVI_BASE2 - 62.0, K9L_SCENE_X1, K9L_NAVI_BASE2 + 72.0))
        if cam is not None:
            out.append((K9L_CAM_X, K9L_CAM_Y, K9L_CAM_X + K9L_CAM_W, K9L_CAM_Y + 92.0))
        if lane is not None:
            out.append((K9L_CAM_X, K9L_LANE_Y - 30.0, K9L_CAM_X + K9L_CAM_W, K9L_LANE_Y + K9_LANE_CELL_H + 6.0))
        return out

    def _k9l_draw_navi(self, state: ClusterUiState) -> None:
        guidance, nxt, lane, cam = self.k9_navi_items(state)
        rx = K9L_SCENE_X1 - 16.0
        if guidance is not None:
            # 22:41 bigger: 60 px arrow, 52 distance (was 40 / 40), road name under it, next guidance small below
            base = K9L_NAVI_BASE2
            dist = self._format_navi_distance(guidance.distance_m)
            dw = self._k9l_text(dist, rx, 0.0, 52.0, K9L_VALUE, anchor="right", numeric=True, glow=True, base=base)
            self._draw_navi_turn_icon(guidance.turn_type, rx - dw - 44.0, base - 24.0, 60.0)
            road = self._ellipsize_text(guidance.road_name or guidance.main_text or "", 24.0, 220.0)
            self._k9l_text(road, rx, 0.0, 24.0, K9L_MUTED, anchor="right", base=base + 34.0)
            if nxt is not None:
                nb = base + 68.0
                nw = self._k9l_text(self._format_navi_distance(nxt.distance_m), rx, 0.0, 24.0, K9L_MUTED, anchor="right",
                                    numeric=True, base=nb)
                self._draw_navi_turn_icon(nxt.turn_type, rx - nw - 22.0, nb - 9.0, 26.0)
                self._k9l_text("다음", rx - nw - 42.0, 0.0, 22.0, K9L_LABEL, anchor="right", track=K9L_TRACK, base=nb)
        if cam is not None:
            name, d, limit, progress, warn = cam
            x, y, w = K9L_CAM_X, K9L_CAM_Y, K9L_CAM_W
            self._k9l_text(name, x, 0.0, 22.0, warn or K9L_LABEL, track=0.04, base=y + 22.0)
            self._k9l_text(self._format_navi_distance(d), x - 2.0, 0.0, 40.0, warn or K9L_VALUE, numeric=True,
                           glow=True, base=y + 70.0)
            cx, cy, r = x + w - 30.0, y + 50.0, 26.0
            rl.draw_ring(rl.Vector2(cx, cy), r + 1.0, r + 2.2, 0.0, 360.0, 48, rl.Color(*K9L_CHAMPAGNE, 150))
            rl.draw_circle_v(rl.Vector2(cx, cy), r, rl_color(RED))
            rl.draw_circle_v(rl.Vector2(cx, cy), r - 5.0, rl.Color(246, 246, 244, 255))
            text = str(int(round(display_speed(limit, self.is_metric))))
            self._draw_text(text, cx, cy, 26.0 if len(text) <= 2 else 21.0, TEXT, anchor="center")
            self._k9l_meter(x, y + 88.0, w - 66.0, progress, warn or K9L_ICE)
        if lane is not None:
            box = self._k9_lane_strip(lane, self.k9_turn_dir(guidance), K9L_CAM_X, K9L_LANE_Y, K9L_CAM_W, "left", True)
            self._k9l_text("차로", box[0], 0.0, 22.0, K9L_LABEL, track=K9L_TRACK, base=K9L_LANE_Y - 10.0)
            if lane.distance_m > 0:
                self._k9l_text(self._format_navi_distance(lane.distance_m), box[2], 0.0, 22.0, K9L_MUTED, anchor="right",
                               numeric=True, base=K9L_LANE_Y - 10.0)

    @staticmethod
    def _k9l_pairs(text: str, first_space: bool = False) -> list[tuple[str, str]]:
        """'조향비 12.90  지연설정 0.20초' -> [('조향비', '12.90'), ('지연설정', '0.20초')] (text unchanged, only laid out)"""
        out = []
        for part in (p.strip() for p in text.split("  ")):
            if part:
                name, _, value = part.partition(" ") if first_space else part.rpartition(" ")
                out.append((name, value) if name or value else (part, ""))
        return out

    def _k9l_draw_right(self, state: ClusterUiState) -> None:
        # 11/13 00:47: 차선 위치 + 조향 학습 in the K9T tiers (same as the car block), 344 px
        self._k9t_list(state, True, K9L_RIGHT_X, K9L_RIGHT_X1, 8.0, 462.0)  # 01:29 last line >= 14 px over the edge

    def _k9l_draw_hud(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> None:
        tex = self._k9l_background()
        rl.draw_texture_pro(tex, rl.Rectangle(0, 0, tex.width, tex.height), rl.Rectangle(0, 0, DESIGN_WIDTH, DESIGN_HEIGHT),
                            rl.Vector2(0, 0), 0.0, rl.WHITE)
        sx = self.width / DESIGN_WIDTH
        rl.begin_scissor_mode(int(K9L_SCENE_X0 * sx), 0, int((K9L_SCENE_X1 - K9L_SCENE_X0) * sx), int(self.height))
        try:
            self._k9l_draw_road(state)
        finally:
            rl.end_scissor_mode()
        self._k9l_draw_top(state, signal_lights)
        with self._k9_shift(K9L_SWAP_LEFT_DX):   # 22:41 1칸 <-> 3칸
            self._k9l_draw_left(state)
        with self._k9_shift(K9L_SWAP_RIGHT_DX):
            self._k9l_draw_right(state)

    def _draw_alert_overlay(self, alert: ClusterAlert | None, center: tuple[float, float] | None = None,
                            max_w: float | None = None) -> None:
        if alert is None or alert.size <= 0 or not (alert.text1 or alert.text2):
            return

        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        try:
            panel_x = self._driving_panel_offset_design_x()
            panel_w = CAMERA_BACKGROUND_W
            panel_center_x = panel_x + panel_w * 0.5

            if alert.size >= CLUSTER_ALERT_SIZE_FULL:
                max_text_w = panel_w - 100.0
                title_size = 56.0
                detail_size = 32.0
            elif alert.size == CLUSTER_ALERT_SIZE_MID:
                max_text_w = panel_w - 128.0
                title_size = 48.0
                detail_size = 28.0
            else:
                max_text_w = panel_w - 200.0
                title_size = 42.0
                detail_size = 24.0

            title, detail = self._cluster_alert_text(alert)
            if not title and detail:
                title, detail = detail, ""
            if max_w is not None:
                max_text_w = max_w
            title, title_size = self._fit_alert_text(title, title_size, max_text_w, 30.0)
            detail, detail_size = self._fit_alert_text(detail, detail_size, max_text_w, 20.0)
            center_y = DESIGN_HEIGHT * 0.5
            if center is not None:
                panel_center_x, center_y = center
            title_color = CLUSTER_ALERT_TEXT_COLORS.get(alert.status, CLUSTER_ALERT_TEXT_COLORS[0])
            if detail:
                title_y = center_y - (22.0 if alert.size == CLUSTER_ALERT_SIZE_SMALL else 30.0)
                detail_y = center_y + (27.0 if alert.size == CLUSTER_ALERT_SIZE_SMALL else 36.0)
                self._draw_text_with_stroke(
                    title, panel_center_x, title_y, title_size, title_color,
                    CLUSTER_ALERT_TEXT_STROKE, 4, anchor="center", cache=True,
                )
                self._draw_text_with_stroke(
                    detail, panel_center_x, detail_y, detail_size, WHITE,
                    CLUSTER_ALERT_TEXT_STROKE, 3, anchor="center", cache=True,
                )
            else:
                self._draw_text_with_stroke(
                    title, panel_center_x, center_y, title_size, title_color,
                    CLUSTER_ALERT_TEXT_STROKE, 4, anchor="center", cache=True,
                )
        finally:
            rl.rl_pop_matrix()

    def _cluster_alert_text(self, alert: ClusterAlert) -> tuple[str, str]:
        keys = CLUSTER_SYNTHETIC_ALERT_TEXT_KEYS.get(alert.alert_type)
        if keys is not None:
            return self._text(keys[0]), self._text(keys[1])
        return " ".join(alert.text1.split()), " ".join(alert.text2.split())

    def _fit_alert_text(
        self,
        text: str,
        preferred_size: float,
        max_width: float,
        minimum_size: float,
    ) -> tuple[str, float]:
        if not text:
            return "", preferred_size
        size = preferred_size
        while size > minimum_size and self._measure_text(text, size)[0] > max_width:
            size -= 2.0
        return self._ellipsize_text(text, size, max_width), size

    def _draw_driving_hud_content(
        self,
        state: ClusterUiState,
        screen_mode: int,
        left_signal_lit: bool,
        right_signal_lit: bool,
    ) -> None:
        offset_x = self._driving_hud_offset_design_x(screen_mode)
        tpms_offset_x = self._tpms_offset_design_x(screen_mode)
        side_gauge_offset_x = self._side_gauge_offset_design_x(screen_mode)
        rl.rl_push_matrix()
        if abs(offset_x) > 0.001:
            rl.rl_translatef(offset_x, 0.0, 0.0)
        try:
            profile_stage = self._profile_start()
            self._draw_speed_block(state, tpms_offset_x=tpms_offset_x)
            self._profile_add("hud.speed_block", profile_stage)
            side_gauges_translated = abs(side_gauge_offset_x) > 0.001
            if side_gauges_translated:
                rl.rl_push_matrix()
                rl.rl_translatef(side_gauge_offset_x, 0.0, 0.0)
            try:
                profile_stage = self._profile_start()
                self._draw_accel_block(state)
                self._profile_add("hud.accel_block", profile_stage)
                self._draw_steering_output_block(state)
            finally:
                if side_gauges_translated:
                    rl.rl_pop_matrix()
            profile_stage = self._profile_start()
            left_center_x_offset = self._turn_signal_center_x_offset(state, "left")
            self._draw_turn_signal(
                "left",
                left_signal_lit,
                show_inactive=state.debug_ui_visible,
                center_x_offset=left_center_x_offset,
            )
            self._profile_add("hud.turn_signal_left", profile_stage)
            profile_stage = self._profile_start()
            self._draw_drive_status(state)
            self._profile_add("hud.drive_status", profile_stage)
            profile_stage = self._profile_start()
            right_center_x_offset = self._turn_signal_center_x_offset(state, "right")
            self._draw_turn_signal(
                "right",
                right_signal_lit,
                show_inactive=state.debug_ui_visible,
                center_x_offset=right_center_x_offset,
            )
            self._profile_add("hud.turn_signal_right", profile_stage)
            if self._lane_confidence_label_visible(state):
                profile_stage = self._profile_start()
                ego_car_center_x = self._ego_car_center_design_x(state) - offset_x
                self._draw_lane_confidence(
                    "left", getattr(state, "left_lane_line_confidence", None), ego_car_center_x,
                )
                self._draw_lane_confidence(
                    "right", getattr(state, "right_lane_line_confidence", None), ego_car_center_x,
                )
                self._profile_add("hud.lane_confidence", profile_stage)
            traffic_drawn_in_map = screen_mode == CLUSTER_SCREEN_MODE_DEFAULT and self._navi_map_frame_present(
                state.navi_dashboard
            )
            dashboard = state.navi_dashboard
            traffic_frame = next(
                (frame for frame in dashboard.media if frame.key == "image:traffic_signal"),
                None,
            ) if dashboard is not None and dashboard.connected else None
            if (
                traffic_frame is not None
                and not traffic_drawn_in_map
                and screen_mode != CLUSTER_SCREEN_MODE_TRIP_REPORT
            ):
                profile_stage = self._profile_start()
                traffic_panel_right = self._traffic_panel_right(screen_mode)
                self._draw_navi_media(
                    traffic_frame,
                    rl.Rectangle(traffic_panel_right - 230.0, NAVI_TRAFFIC_PANEL_Y, 230.0, 98.0),
                    align_x=1.0,
                    align_y=0.0,
                )
                self._profile_add("hud.navi_traffic", profile_stage)
            profile_stage = self._profile_start()
            self._draw_center_clock(state, center_x=self._center_clock_x(screen_mode))
            self._profile_add("hud.center_clock", profile_stage)
        finally:
            rl.rl_pop_matrix()

    def _effective_screen_mode(self, state: ClusterUiState) -> int:
        requested_screen_mode = getattr(self, "screen_mode", CLUSTER_SCREEN_MODE_DEFAULT)
        if (
            requested_screen_mode == CLUSTER_SCREEN_MODE_FULLSCREEN_3D
            and cluster_camera_view_is_road_camera(getattr(state, "camera_view_mode", 0))
        ):
            requested_screen_mode = CLUSTER_SCREEN_MODE_DEFAULT
        if requested_screen_mode != CLUSTER_SCREEN_MODE_DEFAULT:
            return requested_screen_mode
        gear_text = str(getattr(state, "gear_text", "") or "").strip().upper()
        if getattr(state, "onroad", False) and gear_text == "P":
            # Surface the completed trip as soon as the driver parks, even
            # when an active navigation session would otherwise own the panel.
            return CLUSTER_SCREEN_MODE_TRIP_REPORT
        dashboard = getattr(state, "navi_dashboard", None)
        dashboard_connected = bool(
            dashboard is not None and dashboard.connected
        )
        navigation_received = bool(
            getattr(state, "external_nav_active", False)
            or dashboard_connected
            or self._navi_live_panel_visible(getattr(state, "navi_live", None))
        )
        return (
            CLUSTER_SCREEN_MODE_DEFAULT
            if navigation_received
            else CLUSTER_SCREEN_MODE_TRIP_REPORT
        )

    def _draw_status_footer(
        self,
        state: ClusterUiState,
        *,
        include_core_usage: bool = True,
    ) -> None:
        if clean_ui_enabled():
            return  # EV6 HUD patch v6
        profile_stage = self._profile_start()
        screen_mode = self._effective_screen_mode(state)
        offset_x = self._driving_hud_offset_design_x(screen_mode)
        if abs(offset_x) > 0.001:
            rl.rl_push_matrix()
            try:
                rl.rl_translatef(offset_x, 0.0, 0.0)
                self._draw_git_status(state.git_status, state.network_address, state.actual_fps)
            finally:
                rl.rl_pop_matrix()
        else:
            self._draw_git_status(state.git_status, state.network_address, state.actual_fps)
        self._profile_add("hud.git_status", profile_stage)
        if include_core_usage:
            profile_stage = self._profile_start()
            self._draw_cluster_core_usage(
                state.cluster_core_usage_text,
                right_x=self._core_usage_right_x(screen_mode),
            )
            self._profile_add("hud.cluster_core_usage", profile_stage)

    def _draw_route_replay_controls(
        self,
        playback_s: float,
        duration_s: float,
        corner_lateral_offset_m: float,
        paused: bool,
        camera_overlay_tuning_visible: bool = False,
    ) -> None:
        sx = self.width / DESIGN_WIDTH
        sy = self.height / DESIGN_HEIGHT
        rl.rl_push_matrix()
        rl.rl_scalef(sx, sy, 1.0)
        try:
            theme = self._current_theme()
            panel = rl.Rectangle(
                ROUTE_CONTROL_PANEL_X,
                ROUTE_CONTROL_PANEL_Y,
                ROUTE_CONTROL_PANEL_W,
                ROUTE_CONTROL_PANEL_H,
            )
            rl.draw_rectangle_rounded(panel, 0.20, 12, rl_color((2, 5, 10, 188)))
            rl.draw_rectangle_rounded_lines_ex(panel, 0.20, 12, 1.4, rl_color((255, 255, 255, 54)))

            duration_s = max(0.001, duration_s)
            playback_s = clamp(playback_s, 0.0, duration_s)
            seek_ratio = playback_s / duration_s
            self._draw_route_slider(
                "seek",
                f"{self._format_time(playback_s)} / {self._format_time(duration_s)}{' PAUSED' if paused else ''}",
                seek_ratio,
                ROUTE_CONTROL_SEEK_Y,
                BLUE_SOFT,
                theme.text,
            )
            if camera_overlay_tuning_visible:
                pitch_ratio = (
                    (self.camera_overlay_pitch_offset_deg - CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG)
                    / max(0.001, CAMERA_OVERLAY_PITCH_OFFSET_MAX_DEG - CAMERA_OVERLAY_PITCH_OFFSET_MIN_DEG)
                )
                self._draw_route_slider(
                    "pitch",
                    f"{self.camera_overlay_pitch_offset_deg:+.1f} deg   ; / '",
                    pitch_ratio,
                    CAMERA_OVERLAY_PITCH_TUNE_PANEL_Y,
                    RED,
                    theme.text,
                )
                z_ratio = (
                    (self.camera_overlay_z_offset_m - CAMERA_OVERLAY_Z_OFFSET_MIN_M)
                    / max(0.001, CAMERA_OVERLAY_Z_OFFSET_MAX_M - CAMERA_OVERLAY_Z_OFFSET_MIN_M)
                )
                self._draw_route_slider(
                    "cam z",
                    f"{self.camera_overlay_z_offset_m:+.2f} m   [ / ]",
                    z_ratio,
                    CAMERA_OVERLAY_TUNE_PANEL_Y,
                    AMBER,
                    theme.text,
                )
        finally:
            rl.rl_pop_matrix()

    def _draw_route_slider(
        self,
        label: str,
        value: str,
        ratio: float,
        center_y: float,
        fill_color: tuple[int, int, int],
        text_color: tuple[int, int, int],
    ) -> None:
        ratio = clamp(ratio, 0.0, 1.0)
        self._draw_text(label, ROUTE_CONTROL_PANEL_X + 26.0, center_y - 9.0, 16, text_color)
        self._draw_text(value, ROUTE_CONTROL_PANEL_X + ROUTE_CONTROL_PANEL_W - 26.0, center_y - 9.0, 16, text_color, anchor="right")
        bar_bg = rl.Rectangle(ROUTE_CONTROL_BAR_X, center_y - 3.0, ROUTE_CONTROL_BAR_W, 6.0)
        bar_fill = rl.Rectangle(ROUTE_CONTROL_BAR_X, center_y - 3.0, ROUTE_CONTROL_BAR_W * ratio, 6.0)
        knob_x = ROUTE_CONTROL_BAR_X + ROUTE_CONTROL_BAR_W * ratio
        rl.draw_rectangle_rounded(bar_bg, 1.0, 8, rl_color((255, 255, 255, 50)))
        rl.draw_rectangle_rounded(bar_fill, 1.0, 8, rl_color(fill_color, 205))
        rl.draw_circle_v(rl.Vector2(knob_x, center_y), 8.5, rl_color(fill_color, 235))
        rl.draw_circle_lines(int(round(knob_x)), int(round(center_y)), 9.5, rl_color((255, 255, 255, 150)))

    @staticmethod
    def _format_time(seconds: float) -> str:
        total = max(0, int(round(seconds)))
        minutes = total // 60
        secs = total % 60
        return f"{minutes:d}:{secs:02d}"

    def _draw_center_clock(self, state: ClusterUiState, *, center_x: float = TOP_CLOCK_CENTER_X) -> None:
        if state.center_clock_text:
            self._draw_text_with_stroke(
                state.center_clock_text,
                center_x,
                TOP_STATUS_CENTER_Y,
                48,
                WHITE,
                (10, 13, 16),
                2,
                anchor="center",
            )
        navi_connected = bool(state.navi_dashboard is not None and state.navi_dashboard.connected)
        navi_status = navigation_status_presentation(
            getattr(state, "vehicle_navi_available", False),
            state.external_nav_active or navi_connected,
        )
        if navi_status is not None:
            navi_label, navi_color_mode = navi_status
            self._draw_text_with_stroke(
                navi_label,
                NAV_STATUS_CENTER_X,
                NAV_STATUS_CENTER_Y,
                NAV_STATUS_FONT_SIZE,
                VEHICLE_NAVI if navi_color_mode == 3 else AMBER,
                (10, 13, 16),
                2,
                anchor="center",
                cache=True,
            )

    def _draw_debug_plot(
        self,
        plot: DebugPlotSnapshot | None,
        panel_x: float,
        panel_y: float,
        panel_w: float,
        panel_h: float,
    ) -> None:
        if plot is None or plot.mode <= 0:
            if self._debug_plot_mode_prev != 0:
                self._clear_debug_plot(0)
            self._draw_debug_plot_panel("SHOW PLOT MODE 0", None, panel_x, panel_y, panel_w, panel_h)
            return

        if plot.mode != self._debug_plot_mode_prev:
            self._clear_debug_plot(plot.mode)

        now = time.perf_counter()
        if self._debug_plot_last_sample_time is None or now - self._debug_plot_last_sample_time >= DEBUG_PLOT_SAMPLE_SECONDS:
            self._append_debug_plot_values(plot.values)
            self._debug_plot_last_sample_time = now

        self._draw_debug_plot_panel(plot.title, plot, panel_x, panel_y, panel_w, panel_h)

    def _clear_debug_plot(self, mode: int) -> None:
        self._debug_plot_mode_prev = mode
        self._debug_plot_size = 0
        self._debug_plot_index = -1
        self._debug_plot_values = [[0.0] * DEBUG_PLOT_MAX_SAMPLES for _ in range(3)]
        self._debug_plot_min = -2.0
        self._debug_plot_max = 2.0
        self._debug_plot_last_sample_time = None

    def _append_debug_plot_values(self, values: tuple[float, float, float]) -> None:
        self._debug_plot_index = (self._debug_plot_index + 1) % DEBUG_PLOT_MAX_SAMPLES
        if self._debug_plot_size < DEBUG_PLOT_MAX_SAMPLES:
            self._debug_plot_size += 1

        for index, value in enumerate(values):
            self._debug_plot_values[index][self._debug_plot_index] = value if math.isfinite(value) else 0.0

        self._update_debug_plot_bounds()

    def _update_debug_plot_bounds(self) -> None:
        if self._debug_plot_size <= 0:
            self._debug_plot_min = -2.0
            self._debug_plot_max = 2.0
            return

        minimum = float("inf")
        maximum = float("-inf")
        for series_index in range(3):
            for offset in range(self._debug_plot_size):
                value = self._debug_plot_value(series_index, offset)
                minimum = min(minimum, value)
                maximum = max(maximum, value)

        if minimum == float("inf") or maximum == float("-inf"):
            minimum = -2.0
            maximum = 2.0
        if minimum > -2.0:
            minimum = -2.0
        if maximum < 2.0:
            maximum = 2.0
        if maximum - minimum < 0.001:
            minimum -= 1.0
            maximum += 1.0
        self._debug_plot_min = minimum
        self._debug_plot_max = maximum

    def _debug_plot_value(self, series_index: int, oldest_offset: int) -> float:
        oldest_index = (self._debug_plot_index - self._debug_plot_size + 1) % DEBUG_PLOT_MAX_SAMPLES
        return self._debug_plot_values[series_index][(oldest_index + oldest_offset) % DEBUG_PLOT_MAX_SAMPLES]

    def _draw_debug_plot_panel(
        self,
        title: str,
        plot: DebugPlotSnapshot | None,
        panel_x: float,
        panel_y: float,
        panel_w: float,
        panel_h: float,
    ) -> None:
        theme = self._current_theme()
        compact = panel_w < 700.0
        pad = 18.0 if compact else 24.0
        title_y = panel_y + 30.0
        plot_x = panel_x + pad
        plot_y = panel_y + (74.0 if compact else 70.0)
        plot_w = panel_w - pad * 2.0
        plot_h = panel_h - (100.0 if compact else 96.0)
        plot_bottom = plot_y + plot_h

        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 18, theme.route_panel_bg, theme.faint, 2)
        title_size = 18 if compact else 22
        title_max_w = panel_w - pad * 2.0 - (120.0 if compact else 190.0)
        title = self._ellipsize_text(title, title_size, title_max_w)
        self._draw_text(title, panel_x + pad, title_y, title_size, theme.text)
        self._draw_text(
            f"min {self._debug_plot_min:.2f}  max {self._debug_plot_max:.2f}",
            panel_x + panel_w - pad,
            title_y,
            13 if compact else 17,
            theme.muted,
            anchor="right",
        )

        grid_color = rl_color(theme.faint, 110)
        axis_color = rl_color(theme.muted, 160)
        plot_rect = rl.Rectangle(plot_x, plot_y, plot_w, plot_h)
        rl.draw_rectangle_rec(plot_rect, rl_color((0, 0, 0), 52 if theme.is_dark else 30))
        rl.draw_rectangle_lines_ex(plot_rect, 2.0, rl_color(theme.faint))
        for index in range(1, 6):
            x = plot_x + plot_w * index / 6.0
            rl.draw_line_ex(rl.Vector2(x, plot_y), rl.Vector2(x, plot_bottom), 1.0, grid_color)
        for index in range(1, 4):
            y = plot_y + plot_h * index / 4.0
            rl.draw_line_ex(rl.Vector2(plot_x, y), rl.Vector2(plot_x + plot_w, y), 1.0, grid_color)

        value_range = self._debug_plot_max - self._debug_plot_min
        if self._debug_plot_min < 0.0 < self._debug_plot_max and value_range > 0.001:
            zero_y = plot_bottom - (0.0 - self._debug_plot_min) / value_range * plot_h
            rl.draw_line_ex(rl.Vector2(plot_x, zero_y), rl.Vector2(plot_x + plot_w, zero_y), 2.0, axis_color)

        if plot is None or self._debug_plot_size < 2:
            self._draw_text("no plot data", plot_x + plot_w * 0.5, plot_y + plot_h * 0.5, 22, theme.muted, anchor="center")
            return

        colors = (
            (255, 220, 0),
            GREEN,
            (255, 165, 0),
        )
        for series_index, color in enumerate(colors):
            self._draw_debug_plot_series(series_index, plot_x, plot_y, plot_w, plot_h, color)

    def _draw_debug_plot_series(
        self,
        series_index: int,
        plot_x: float,
        plot_y: float,
        plot_w: float,
        plot_h: float,
        color: tuple[int, int, int],
    ) -> None:
        value_range = max(0.001, self._debug_plot_max - self._debug_plot_min)
        previous: rl.Vector2 | None = None
        latest: rl.Vector2 | None = None
        latest_value = 0.0
        count = self._debug_plot_size
        dx = plot_w / max(1, count - 1)
        for offset in range(count):
            value = self._debug_plot_value(series_index, offset)
            x = plot_x + dx * offset
            y = plot_y + plot_h - (value - self._debug_plot_min) / value_range * plot_h
            point = rl.Vector2(x, y)
            if previous is not None:
                rl.draw_line_ex(previous, point, 3.0, rl_color(color))
            previous = point
            latest = point
            latest_value = value

        if latest is None:
            return
        label = f"{latest_value:.2f}"
        label_size = 18.0
        label_x = min(plot_x + plot_w - 4.0, latest.x + 42.0)
        label_y = clamp(latest.y + (24.0 if series_index > 0 else 0.0), plot_y + 12.0, plot_y + plot_h - 12.0)
        self._draw_text(label, label_x, label_y, label_size, color, anchor="right")

    def _draw_navi_dashboard(self, state: ClusterUiState) -> None:
        theme = self._current_theme()
        dashboard = state.navi_dashboard
        navi = state.navi_live
        rl.draw_rectangle(0, 0, int(NAVI_MODE_LEFT_W), DESIGN_HEIGHT, rl_color(theme.panel_bg))
        rl.draw_rectangle(
            int(NAVI_MODE_RIGHT_X),
            0,
            int(NAVI_MODE_RIGHT_W),
            DESIGN_HEIGHT,
            rl_color(theme.panel_bg),
        )
        rl.draw_line_ex(
            rl.Vector2(NAVI_MODE_LEFT_W, 0.0),
            rl.Vector2(NAVI_MODE_LEFT_W, DESIGN_HEIGHT),
            2.0,
            rl_color(theme.faint),
        )
        rl.draw_line_ex(
            rl.Vector2(NAVI_MODE_RIGHT_X, 0.0),
            rl.Vector2(NAVI_MODE_RIGHT_X, DESIGN_HEIGHT),
            2.0,
            rl_color(theme.faint),
        )

        media = {frame.key: frame for frame in dashboard.media} if dashboard is not None else {}
        map_rect = rl.Rectangle(NAVI_MODE_MAP_X, 0.0, NAVI_MODE_MAP_W, DESIGN_HEIGHT)
        map_frame = media.get("render:map_main")
        rl.draw_rectangle_rec(map_rect, rl_color(NAVI_MAP_BACKGROUND))
        if not self._draw_navi_media(map_frame, map_rect, cover=False):
            self._draw_navi_route_fallback(navi, map_rect)
        if dashboard is not None and dashboard.map_stream_stalled:
            self._draw_navi_map_stalled(map_rect, dashboard.map_frame_age_ms)

        self._draw_navi_map_media(media)
        self._draw_navi_left_band(state, navi, media)
        self._draw_navi_right_band(navi, dashboard, media)

    def _draw_navi_left_band(
        self,
        state: ClusterUiState,
        navi: NaviLiveState | None,
        media: dict[str, NaviMediaFrame],
    ) -> None:
        theme = self._current_theme()
        full_rect = rl.Rectangle(10.0, 8.0, 500.0, 88.0)
        compact_rect = rl.Rectangle(10.0, 104.0, 330.0, 145.0)
        next_rect = rl.Rectangle(350.0, 104.0, 160.0, 72.0)
        drew_full = self._draw_navi_media(media.get("image:tbt_current_full"), full_rect)
        drew_compact = self._draw_navi_media(media.get("image:tbt_current_compact"), compact_rect)
        drew_next = self._draw_navi_media(media.get("image:tbt_next"), next_rect)

        current = navi.current if navi is not None else None
        if current is not None and not (drew_full or drew_compact):
            self._draw_navi_turn_icon(current.turn_type, 72.0, 78.0, 92.0)
            self._draw_text(self._format_navi_distance(current.distance_m), 136.0, 30.0, 42.0, theme.text)
            current_text = current.main_text or current.road_name or current.near_direction
            self._draw_text(
                self._ellipsize_text(current_text, 26.0, 350.0),
                136.0,
                82.0,
                26.0,
                theme.text,
            )
        next_guidance = navi.next if navi is not None else None
        if next_guidance is not None and not drew_next:
            self._draw_navi_turn_icon(next_guidance.turn_type, 386.0, 143.0, 54.0)
            self._draw_text(
                self._format_navi_distance(next_guidance.distance_m),
                422.0,
                119.0,
                20.0,
                theme.text,
            )

        displayed_speed = display_speed(state.speed_kph, self.is_metric)
        road_limit = state.speed_limit_kph
        road_name = ""
        if navi is not None:
            if navi.vehicle is not None:
                road_name = navi.vehicle.road_name
            if road_limit is None and navi.speed is not None:
                road_limit = navi.speed.road_limit_kph
        self._draw_text(f"{displayed_speed:.0f}", 32.0, 284.0, 82.0, theme.text)
        self._draw_text(speed_unit(self.is_metric), 143.0, 332.0, 18.0, theme.muted)
        if road_limit is not None:
            rl.draw_circle_v(rl.Vector2(218.0, 325.0), 36.0, rl_color(WHITE))
            rl.draw_ring(rl.Vector2(218.0, 325.0), 30.0, 36.0, 0.0, 360.0, 48, rl_color(RED))
            self._draw_text(
                str(int(round(display_speed(road_limit, self.is_metric)))),
                218.0,
                308.0,
                27.0,
                (20, 24, 28),
                anchor="center",
            )
        if road_name:
            self._draw_text(
                self._ellipsize_text(road_name, 22.0, 480.0),
                20.0,
                389.0,
                22.0,
                theme.text,
            )
        if navi is not None and navi.route is not None:
            route = navi.route
            route_text = self._format_navi_distance(route.remaining_distance_m)
            if route.remaining_time_s > 0:
                route_text += f"  {max(1, round(route.remaining_time_s / 60.0))} min"
            self._draw_text(route_text, 20.0, 431.0, 24.0, BLUE_SOFT)

    def _draw_navi_map_media(self, media: dict[str, NaviMediaFrame]) -> None:
        expanded = media.get("image:crossroad_expanded")
        minimized = media.get("image:crossroad_minimized")
        if expanded is not None and expanded.present:
            self._draw_navi_media(expanded, rl.Rectangle(NAVI_MODE_MAP_X + 55.0, 20.0, 770.0, 430.0))
        elif minimized is not None and minimized.present:
            self._draw_navi_media(
                minimized,
                rl.Rectangle(NAVI_MODE_MAP_X + NAVI_MODE_MAP_W - 260.0, 48.0, 250.0, 410.0),
            )

        self._draw_navi_media(
            media.get("image:lane_bottom"),
            rl.Rectangle(NAVI_MODE_MAP_X + 80.0, 298.0, NAVI_MODE_MAP_W - 160.0, 174.0),
        )
        self._draw_navi_media(
            media.get("image:traffic_signal"),
            rl.Rectangle(NAVI_MODE_MAP_X + 16.0, 18.0, 230.0, 98.0),
        )

        center_x = NAVI_MODE_MAP_X + NAVI_MODE_MAP_W * 0.5
        self._draw_navi_media(
            media.get("image:center_tbt_icon"),
            rl.Rectangle(center_x - 112.0, 104.0, 92.0, 92.0),
        )
        self._draw_navi_media(
            media.get("image:center_tbt_text"),
            rl.Rectangle(center_x - 12.0, 108.0, 220.0, 78.0),
        )
        self._draw_navi_media(
            media.get("image:center_tbt_fee"),
            rl.Rectangle(center_x - 90.0, 188.0, 180.0, 58.0),
        )

    def _draw_navi_right_band(
        self,
        navi: NaviLiveState | None,
        dashboard: NaviDashboardState | None,
        media: dict[str, NaviMediaFrame],
    ) -> None:
        theme = self._current_theme()
        x = NAVI_MODE_RIGHT_X + 18.0
        width = NAVI_MODE_RIGHT_W - 36.0
        current = navi.current if navi is not None else None
        next_guidance = navi.next if navi is not None else None
        self._draw_text(self._text("navigation"), x, 14.0, 16.0, theme.muted)
        if current is not None:
            current_text = current.main_text or current.road_name or current.near_direction
            self._draw_text(
                self._ellipsize_text(current_text, 27.0, width - 120.0),
                x,
                42.0,
                27.0,
                theme.text,
            )
            self._draw_text(
                self._format_navi_distance(current.distance_m),
                NAVI_MODE_RIGHT_X + NAVI_MODE_RIGHT_W - 18.0,
                42.0,
                27.0,
                BLUE_SOFT,
                anchor="right",
            )
        if next_guidance is not None:
            next_text = next_guidance.main_text or next_guidance.road_name or next_guidance.near_direction
            next_line = f"{self._text('next')} {self._format_navi_distance(next_guidance.distance_m)}  {next_text}"
            self._draw_text(self._ellipsize_text(next_line, 18.0, width), x, 82.0, 18.0, theme.muted)

        y = 116.0
        safety_frames = [
            media.get("image:safety_primary"),
            media.get("image:safety_secondary"),
            media.get("image:safety_section"),
        ]
        active_safety = [frame for frame in safety_frames if frame is not None and frame.present]
        if active_safety:
            slot_h = min(82.0, 176.0 / len(active_safety))
            for frame in active_safety:
                self._draw_navi_media(frame, rl.Rectangle(x, y, width, slot_h - 4.0))
                y += slot_h
        elif navi is not None and navi.speed is not None:
            speed = navi.speed
            sdi_values = (
                ("SDI", speed.sdi_type, speed.sdi_speed_limit_kph, speed.sdi_distance_m),
                ("SDI 2", speed.secondary_sdi_type, speed.secondary_sdi_speed_limit_kph,
                 speed.secondary_sdi_distance_m),
            )
            for label, sdi_type, speed_limit_kph, distance_m in sdi_values:
                if sdi_type is None:
                    continue
                sdi = label
                if speed_limit_kph is not None:
                    sdi += f" {display_speed(speed_limit_kph, self.is_metric):.0f} {speed_unit(self.is_metric)}"
                if distance_m is not None:
                    sdi += f"  {self._format_navi_distance(distance_m)}"
                self._draw_text(sdi, x, y + 6.0, 24.0, AMBER)
                y += 40.0
            if speed.section_active:
                section = self._text("section")
                if speed.section_average_kph is not None:
                    section += f" {self._text('average')} {display_speed(speed.section_average_kph, self.is_metric):.0f}"
                if speed.section_remaining_distance_m is not None:
                    section += f"  {self._format_navi_distance(speed.section_remaining_distance_m)}"
                self._draw_text(self._ellipsize_text(section, 20.0, width), x, y + 4.0, 20.0, theme.text)
                y += 34.0

        route_y = max(292.0, y + 8.0)
        if navi is not None and navi.route is not None:
            route = navi.route
            total = max(1, route.total_distance_m)
            progress = clamp(route.moved_distance_m / total, 0.0, 1.0)
            self._draw_text(self._text("route"), x, route_y, 15.0, theme.muted)
            route_value = self._format_navi_distance(route.remaining_distance_m)
            if route.remaining_time_s > 0:
                route_value += f" / {max(1, round(route.remaining_time_s / 60.0))} min"
            self._draw_text(route_value, x + width, route_y - 2.0, 20.0, theme.text, anchor="right")
            bar_y = route_y + 28.0
            rl.draw_rectangle_rounded(rl.Rectangle(x, bar_y, width, 8.0), 1.0, 8, rl_color(theme.faint))
            if progress > 0.0:
                rl.draw_rectangle_rounded(
                    rl.Rectangle(x, bar_y, max(8.0, width * progress), 8.0),
                    1.0,
                    8,
                    rl_color(BLUE_SOFT),
                )

        status_y = 358.0
        if dashboard is None:
            self._draw_text(f"TCP 7714 {self._text('waiting')}", x, status_y, 18.0, AMBER)
            return
        status_color = GREEN if dashboard.connected and dashboard.error is None else RED if dashboard.error else AMBER
        status_text = self._text("connected") if dashboard.connected else self._text("waiting")
        self._draw_text(status_text, x, status_y, 18.0, status_color)
        self._draw_text(
            f"{dashboard.app_version or '-'}  rev {dashboard.manifest_revision}  rx {dashboard.received_count}",
            x + width,
            status_y,
            15.0,
            theme.muted,
            anchor="right",
        )
        self._draw_text(self._ellipsize_text(dashboard.app_status, 14.0, width), x, status_y + 27.0, 14.0, theme.text)
        self._draw_text(self._ellipsize_text(dashboard.camera_status, 14.0, width), x, status_y + 49.0, 14.0, theme.text)
        self._draw_text(
            self._ellipsize_text(dashboard.composition_status, 14.0, width),
            x,
            status_y + 71.0,
            14.0,
            theme.text,
        )
        present = sum(1 for item in dashboard.items if item.present)
        age = "-" if dashboard.last_received_age_ms is None else f"{dashboard.last_received_age_ms} ms"
        footer = f"STREAMS {present}/28 VALUE  |  AGE {age}  |  {dashboard.peer}"
        self._draw_text(self._ellipsize_text(footer, 13.0, width), x, 458.0, 13.0, theme.muted)
        if dashboard.error:
            self._draw_text(self._ellipsize_text(dashboard.error, 13.0, width), x, 436.0, 13.0, RED)

    def _draw_navi_route_fallback(self, navi: NaviLiveState | None, rect: rl.Rectangle) -> None:
        theme = self._current_theme()
        rl.draw_rectangle_rec(rect, rl_color((9, 13, 18)))
        route = navi.route if navi is not None else None
        points = route.polyline if route is not None else ()
        if len(points) >= 2:
            latitudes = [point[0] for point in points]
            longitudes = [point[1] for point in points]
            min_lat, max_lat = min(latitudes), max(latitudes)
            min_lon, max_lon = min(longitudes), max(longitudes)
            lat_span = max(0.00001, max_lat - min_lat)
            lon_span = max(0.00001, max_lon - min_lon)

            def project(latitude: float, longitude: float) -> rl.Vector2:
                px = rect.x + 42.0 + (longitude - min_lon) / lon_span * (rect.width - 84.0)
                py = rect.y + rect.height - 42.0 - (latitude - min_lat) / lat_span * (rect.height - 84.0)
                return rl.Vector2(px, py)

            previous = project(*points[0])
            for point in points[1:]:
                current = project(*point)
                rl.draw_line_ex(previous, current, 7.0, rl_color((21, 58, 96)))
                rl.draw_line_ex(previous, current, 3.0, rl_color(BLUE_SOFT))
                previous = current
            if navi is not None and navi.vehicle is not None:
                vehicle = project(navi.vehicle.latitude, navi.vehicle.longitude)
                rl.draw_circle_v(vehicle, 11.0, rl_color(WHITE))
                rl.draw_circle_v(vehicle, 7.0, rl_color(BLUE))
        self._draw_text("MAP STREAM WAITING", rect.x + rect.width * 0.5, 224.0, 18.0, theme.muted, anchor="center")

    def _draw_navi_media(
        self,
        frame: NaviMediaFrame | None,
        rect: rl.Rectangle,
        *,
        cover: bool = False,
        align_x: float = 0.5,
        align_y: float = 0.5,
    ) -> bool:
        texture = self._navi_media_texture_for(frame)
        cached = self._navi_media_textures.get(frame.key) if frame is not None else None
        if texture is None or cached is None or cached.size[0] <= 0 or cached.size[1] <= 0:
            return False
        source_w = float(cached.size[0])
        source_h = float(cached.size[1])
        scale = max(rect.width / source_w, rect.height / source_h) if cover else min(
            rect.width / source_w,
            rect.height / source_h,
        )
        draw_w = source_w * scale
        draw_h = source_h * scale
        source = rl.Rectangle(0.0, 0.0, source_w, source_h)
        dest = rl.Rectangle(
            rect.x + (rect.width - draw_w) * clamp(align_x, 0.0, 1.0),
            rect.y + (rect.height - draw_h) * clamp(align_y, 0.0, 1.0),
            draw_w,
            draw_h,
        )
        self._draw_cached_navi_media(cached, source, dest)
        return True

    def _navi_media_fitted_size(
        self,
        frame: NaviMediaFrame | None,
        rect: rl.Rectangle,
        *,
        cover: bool = False,
    ) -> tuple[float, float] | None:
        texture = self._navi_media_texture_for(frame)
        cached = self._navi_media_textures.get(frame.key) if frame is not None else None
        if texture is None or cached is None or cached.size[0] <= 0 or cached.size[1] <= 0:
            return None
        source_w = float(cached.size[0])
        source_h = float(cached.size[1])
        scale = max(rect.width / source_w, rect.height / source_h) if cover else min(
            rect.width / source_w,
            rect.height / source_h,
        )
        return source_w * scale, source_h * scale

    def _draw_cached_navi_media(
        self,
        cached: CachedNaviMediaTexture,
        source: rl.Rectangle,
        dest: rl.Rectangle,
    ) -> None:
        if cached.mime == "video/nv12-dmabuf":
            token = cached.hardware_token
            egl_image = self._navi_egl_images.get(token) if token is not None else None
            if egl_image is None:
                return
            from openpilot.system.ui.lib.egl import bind_egl_image_to_texture

            shader = self._get_navi_external_shader()
            rl.begin_shader_mode(shader)
            try:
                # GL_TEXTURE_EXTERNAL_OES is texture-unit state and raylib only
                # restores GL_TEXTURE_2D during a batch draw. Rebind on every
                # draw so the road camera cannot remain selected on texture0.
                bind_egl_image_to_texture(cached.texture.id, egl_image)
                rl.draw_texture_pro(cached.texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))
            finally:
                rl.end_shader_mode()
            return
        if cached.mime != "image/yuv420p":
            rl.draw_texture_pro(cached.texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))
            return
        if cached.u_texture is None or cached.v_texture is None:
            return
        shader = self._get_navi_yuv_shader()
        locations = self._navi_yuv_shader_locations
        rl.begin_shader_mode(shader)
        try:
            rl.set_shader_value_texture(shader, locations["texture1"], cached.u_texture)
            rl.set_shader_value_texture(shader, locations["texture2"], cached.v_texture)
            rl.set_shader_value(
                shader,
                locations["uvScaleU"],
                cached.uv_scale_u,
                rl.ShaderUniformDataType.SHADER_UNIFORM_VEC2,
            )
            rl.set_shader_value(
                shader,
                locations["uvScaleV"],
                cached.uv_scale_v,
                rl.ShaderUniformDataType.SHADER_UNIFORM_VEC2,
            )
            rl.draw_texture_pro(cached.texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))
        finally:
            rl.end_shader_mode()

    def _get_navi_external_shader(self):
        if self._navi_external_shader is None:
            self._navi_external_shader = rl.load_shader_from_memory(
                NAVI_EXTERNAL_VERTEX_SHADER,
                NAVI_EXTERNAL_FRAGMENT_SHADER,
            )
            if not rl.is_shader_valid(self._navi_external_shader):
                rl.unload_shader(self._navi_external_shader)
                self._navi_external_shader = None
                raise RuntimeError("failed to load Navi external NV12 shader")
        return self._navi_external_shader

    def _get_navi_yuv_shader(self):
        if self._navi_yuv_shader is None:
            self._navi_yuv_shader = rl.load_shader_from_memory(
                NV12_PACK_VERTEX_SHADER,
                NAVI_YUV420_FRAGMENT_SHADER,
            )
            if not rl.is_shader_valid(self._navi_yuv_shader):
                rl.unload_shader(self._navi_yuv_shader)
                self._navi_yuv_shader = None
                raise RuntimeError("failed to load Navi YUV420 shader")
            self._navi_yuv_shader_locations = {
                name: rl.get_shader_location(self._navi_yuv_shader, name)
                for name in ("texture1", "texture2", "uvScaleU", "uvScaleV")
            }
        return self._navi_yuv_shader

    @staticmethod
    def _load_navi_plane_texture(width: int, height: int, texture_filter):
        image = rl.Image(None, int(width), int(height), 1, rl.PixelFormat.PIXELFORMAT_UNCOMPRESSED_GRAYSCALE)
        texture = rl.load_texture_from_image(image)
        if not rl.is_texture_valid(texture):
            raise RuntimeError(f"failed to allocate Navi YUV plane texture {width}x{height}")
        rl.set_texture_filter(texture, texture_filter)
        return texture

    @staticmethod
    def _unload_navi_media_texture(cached: CachedNaviMediaTexture) -> None:
        for texture in (cached.texture, cached.u_texture, cached.v_texture):
            if texture is not None:
                rl.unload_texture(texture)

    def _evict_navi_egl_images(self) -> None:
        if len(self._navi_egl_images) <= NAVI_EGL_IMAGE_CACHE_LIMIT:
            return
        from openpilot.system.ui.lib.egl import destroy_egl_image

        active_tokens = {
            cached.hardware_token
            for cached in self._navi_media_textures.values()
            if cached.hardware_token is not None
        }
        for token in tuple(self._navi_egl_images):
            if len(self._navi_egl_images) <= NAVI_EGL_IMAGE_CACHE_LIMIT:
                break
            if token in active_tokens:
                continue
            destroy_egl_image(self._navi_egl_images.pop(token))

    def _discard_stale_navi_egl_generation(self, generation: int) -> None:
        stale_tokens = tuple(token for token in self._navi_egl_images if token[0] != generation)
        if not stale_tokens:
            return
        from openpilot.system.ui.lib.egl import destroy_egl_image

        for token in stale_tokens:
            destroy_egl_image(self._navi_egl_images.pop(token))

    def _upload_navi_hardware_buffer(
        self,
        frame: NaviMediaFrame,
        cached: CachedNaviMediaTexture | None,
    ):
        hardware_buffer = frame.hardware_buffer
        if hardware_buffer is None:
            return cached.texture if cached is not None else None
        width = int(frame.width)
        height = int(frame.height)
        stride = int(getattr(hardware_buffer, "stride", 0))
        uv_offset = int(getattr(hardware_buffer, "uv_offset", 0))
        fd = int(getattr(hardware_buffer, "fd", -1))
        token = tuple(getattr(hardware_buffer, "token", ()))
        if (
            width <= 0
            or height <= 0
            or stride < width
            or uv_offset < stride * height
            or fd < 0
            or len(token) != 2
        ):
            return cached.texture if cached is not None else None

        profile_stage = self._profile_start()
        try:
            from openpilot.system.ui.lib.egl import bind_egl_image_to_texture, create_egl_image, init_egl

            if not init_egl():
                raise RuntimeError("EGL DMA-BUF import is unavailable")
            self._discard_stale_navi_egl_generation(int(token[0]))
            egl_image = self._navi_egl_images.get(token)
            if egl_image is None:
                egl_image = create_egl_image(width, height, stride, fd, uv_offset)
                if egl_image is None:
                    raise RuntimeError("EGL rejected the decoded NV12 DMA-BUF")
                self._navi_egl_images[token] = egl_image
            else:
                self._navi_egl_images.move_to_end(token)

            reuse = bool(
                cached is not None
                and cached.mime == frame.mime
                and cached.size == (width, height)
                and cached.u_texture is None
                and cached.v_texture is None
            )
            texture = cached.texture if reuse else None
            if texture is None:
                image = rl.gen_image_color(1, 1, rl.BLACK)
                try:
                    texture = rl.load_texture_from_image(image)
                finally:
                    rl.unload_image(image)
                if not rl.is_texture_valid(texture):
                    raise RuntimeError("failed to allocate Navi external texture")
                rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            texture.width = width
            texture.height = height
            bind_egl_image_to_texture(texture.id, egl_image)
        except Exception as exc:
            if "texture" in locals() and texture is not None and (cached is None or texture is not cached.texture):
                rl.unload_texture(texture)
            mark_failed = getattr(hardware_buffer, "mark_egl_import_failed", None)
            if mark_failed is not None:
                mark_failed(str(exc))
            print(
                f"Navi hardware H264 EGL import failed token={token}; requesting PyAV fallback: {exc}",
                flush=True,
            )
            return cached.texture if cached is not None else None

        replacement = CachedNaviMediaTexture(
            sequence=frame.sequence,
            size=(width, height),
            mime=frame.mime,
            texture=texture,
            hardware_token=(int(token[0]), int(token[1])),
        )
        if cached is not None and cached.texture is not texture:
            self._unload_navi_media_texture(cached)
        self._navi_media_textures[frame.key] = replacement
        self._evict_navi_egl_images()
        self._profile_add("navi_media.bind_nv12_dmabuf", profile_stage)
        return texture

    def _upload_navi_yuv420p(
        self,
        frame: NaviMediaFrame,
        cached: CachedNaviMediaTexture | None,
    ):
        if frame.plane_data is None or frame.plane_strides is None:
            return cached.texture if cached is not None else None
        width = int(frame.width)
        height = int(frame.height)
        if width <= 0 or height <= 0 or (width & 1) != 0 or (height & 1) != 0:
            return cached.texture if cached is not None else None
        y_stride, u_stride, v_stride = (int(value) for value in frame.plane_strides)
        chroma_width = width // 2
        chroma_height = height // 2
        if y_stride < width or u_stride < chroma_width or v_stride < chroma_width:
            return cached.texture if cached is not None else None
        plane_shapes = (
            (y_stride, height),
            (u_stride, chroma_height),
            (v_stride, chroma_height),
        )
        if any(
            len(data) < stride * plane_height
            for data, (stride, plane_height) in zip(frame.plane_data, plane_shapes, strict=True)
        ):
            return cached.texture if cached is not None else None

        reuse = bool(
            cached is not None
            and cached.mime == frame.mime
            and cached.size == (width, height)
            and cached.texture.width == y_stride
            and cached.texture.height == height
            and cached.u_texture is not None
            and cached.u_texture.width == u_stride
            and cached.v_texture is not None
            and cached.v_texture.width == v_stride
        )
        replacement = cached
        if not reuse:
            created: list[object] = []
            try:
                y_texture = self._load_navi_plane_texture(
                    y_stride,
                    height,
                    rl.TextureFilter.TEXTURE_FILTER_BILINEAR,
                )
                created.append(y_texture)
                u_texture = self._load_navi_plane_texture(
                    u_stride,
                    chroma_height,
                    rl.TextureFilter.TEXTURE_FILTER_POINT,
                )
                created.append(u_texture)
                v_texture = self._load_navi_plane_texture(
                    v_stride,
                    chroma_height,
                    rl.TextureFilter.TEXTURE_FILTER_POINT,
                )
                created.append(v_texture)
                replacement = CachedNaviMediaTexture(
                    sequence=frame.sequence,
                    size=(width, height),
                    mime=frame.mime,
                    texture=y_texture,
                    u_texture=u_texture,
                    v_texture=v_texture,
                    uv_scale_u=rl.ffi.new("float[]", [y_stride / (2.0 * u_stride), 1.0]),
                    uv_scale_v=rl.ffi.new("float[]", [y_stride / (2.0 * v_stride), 1.0]),
                )
            except Exception:
                for texture in created:
                    rl.unload_texture(texture)
                return cached.texture if cached is not None else None

        if replacement is None or replacement.u_texture is None or replacement.v_texture is None:
            return cached.texture if cached is not None else None
        profile_stage = self._profile_start()
        try:
            for texture, plane in zip(
                (replacement.texture, replacement.u_texture, replacement.v_texture),
                frame.plane_data,
                strict=True,
            ):
                pixels = rl.ffi.cast("void *", rl.ffi.from_buffer("const unsigned char[]", plane))
                rl.update_texture(texture, pixels)
        except Exception:
            if replacement is not cached:
                self._unload_navi_media_texture(replacement)
            return cached.texture if cached is not None else None
        self._profile_add("navi_media.upload_yuv420p", profile_stage)

        replacement.sequence = frame.sequence
        if replacement is not cached:
            if cached is not None:
                self._unload_navi_media_texture(cached)
            self._navi_media_textures[frame.key] = replacement
        return replacement.texture

    def _navi_media_texture_for(self, frame: NaviMediaFrame | None):
        if frame is None:
            return None
        cached = self._navi_media_textures.get(frame.key)
        has_payload = frame.hardware_buffer is not None or frame.data is not None or (
            frame.mime == "image/yuv420p" and frame.plane_data is not None and frame.plane_strides is not None
        )
        if not frame.present or not has_payload:
            if cached is not None:
                self._unload_navi_media_texture(cached)
                self._navi_media_textures.pop(frame.key, None)
            return None
        if cached is not None and cached.sequence == frame.sequence and cached.mime == frame.mime:
            return cached.texture
        if frame.mime == "video/nv12-dmabuf":
            return self._upload_navi_hardware_buffer(frame, cached)
        if frame.mime == "image/yuv420p":
            return self._upload_navi_yuv420p(frame, cached)
        size = (frame.width, frame.height)
        if frame.mime == "image/rgba":
            if len(frame.data) != frame.width * frame.height * 4:
                return cached.texture if cached is not None else None
            if cached is None or cached.mime != frame.mime or cached.size != size:
                if cached is not None:
                    self._unload_navi_media_texture(cached)
                image = rl.gen_image_color(frame.width, frame.height, rl_color((0, 0, 0)))
                texture = rl.load_texture_from_image(image)
                rl.unload_image(image)
                if not rl.is_texture_valid(texture):
                    return None
                rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            else:
                texture = cached.texture
            pixels = rl.ffi.cast("void *", rl.ffi.from_buffer("const unsigned char[]", frame.data))
            rl.update_texture(texture, pixels)
            self._navi_media_textures[frame.key] = CachedNaviMediaTexture(
                frame.sequence,
                size,
                frame.mime,
                texture,
            )
            return texture

        extension = ".jpg" if "jpeg" in frame.mime else ".png"
        loaded_image = None
        try:
            loaded_image = rl.load_image_from_memory(extension, frame.data, len(frame.data))
            if not rl.is_image_valid(loaded_image):
                return cached.texture if cached is not None else None
            texture = rl.load_texture_from_image(loaded_image)
            if not rl.is_texture_valid(texture):
                rl.unload_texture(texture)
                return cached.texture if cached is not None else None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            if cached is not None:
                self._unload_navi_media_texture(cached)
            self._navi_media_textures[frame.key] = CachedNaviMediaTexture(
                frame.sequence,
                (int(texture.width), int(texture.height)),
                frame.mime,
                texture,
            )
            return texture
        except Exception:
            return cached.texture if cached is not None else None
        finally:
            if loaded_image is not None and rl.is_image_valid(loaded_image):
                rl.unload_image(loaded_image)

    @staticmethod
    def _navi_live_panel_visible(navi: NaviLiveState | None) -> bool:
        if navi is None:
            return False
        return bool(
            navi.current is not None
            or navi.next is not None
            or navi.lane_current is not None
            or navi.route is not None
            or (navi.crossroad is not None and navi.crossroad.visible)
            or (
                navi.speed is not None
                and (navi.speed.sdi_type is not None or navi.speed.section_active)
            )
            or (navi.status is not None and navi.status.guidance_active)
        )

    @staticmethod
    def _navi_map_frame_present(dashboard: NaviDashboardState | None) -> bool:
        if dashboard is None or not dashboard.connected or dashboard.map_stream_stalled:
            return False
        return any(frame.key == "render:map_main" and frame.present for frame in dashboard.media)

    def _draw_navi_map_stalled(self, rect: rl.Rectangle, age_ms: int | None) -> None:
        rl.draw_rectangle_rec(rect, rl_color(NAVI_MAP_BACKGROUND))
        center_x = rect.x + rect.width * 0.5
        center_y = rect.y + rect.height * 0.5
        self._draw_text_with_stroke(
            "MAP STREAM STALLED",
            center_x,
            center_y - 18.0,
            24.0,
            AMBER,
            (5, 9, 12),
            2,
            anchor="center",
        )
        age_text = "WAITING FOR NEXT FRAME"
        if age_ms is not None:
            age_text = f"NO MAP FRAME FOR {age_ms / 1000.0:.1f} s"
        self._draw_text_with_stroke(
            age_text,
            center_x,
            center_y + 18.0,
            16.0,
            WHITE,
            (5, 9, 12),
            1,
            anchor="center",
        )

    def _draw_navi_live_panel(self, state: ClusterUiState) -> None:
        navi = state.navi_live
        theme = self._current_theme()
        x = self._information_panel_x(NAVI_LIVE_PANEL_X)
        y = NAVI_LIVE_PANEL_Y
        w = NAVI_LIVE_PANEL_W
        h = NAVI_LIVE_PANEL_H

        dashboard = state.navi_dashboard
        if dashboard is not None and not dashboard.connected:
            self._draw_system_stats_panel(
                state,
                panel_x=x,
                panel_y=y,
                panel_w=w,
                panel_h=h,
                status_text="NAVI DISCONNECTED",
            )
            return
        if dashboard is not None and dashboard.map_stream_stalled:
            self._rounded_rect(x, y, w, h, 8.0, NAVI_MAP_BACKGROUND, theme.faint, 2.0)
            self._draw_navi_map_stalled(
                rl.Rectangle(x + 3.0, y + 3.0, w - 6.0, h - 6.0),
                dashboard.map_frame_age_ms,
            )
            self._rounded_rect(x, y, w, h, 8.0, (0, 0, 0, 0), theme.faint, 2.0)
            return

        media = {
            frame.key: frame
            for frame in dashboard.media
        } if dashboard is not None else {}
        map_frame = media.get("render:map_main")
        panel_bg = NAVI_MAP_BACKGROUND if map_frame is not None and map_frame.present else theme.route_panel_bg
        self._rounded_rect(x, y, w, h, 8.0, panel_bg, theme.faint, 2.0)
        map_rect = rl.Rectangle(x + 3.0, y + 3.0, w - 6.0, h - 6.0)
        if map_frame is not None and map_frame.present:
            rl.draw_rectangle_rec(map_rect, rl_color(NAVI_MAP_BACKGROUND))
            rl.begin_scissor_mode(
                int(round(map_rect.x)),
                int(round(map_rect.y)),
                int(round(map_rect.width)),
                int(round(map_rect.height)),
            )
            try:
                self._draw_navi_media(map_frame, map_rect, cover=True)
            finally:
                rl.end_scissor_mode()
            self._rounded_rect(x, y, w, h, 8.0, (0, 0, 0, 0), theme.faint, 2.0)
            self._draw_navi_crossroad_box(media.get("image:crossroad_expanded"), x, y, h)

            current_frame = media.get("image:tbt_current_compact")
            if current_frame is None or not current_frame.present:
                current_frame = media.get("image:tbt_current_full")
            current_rect = rl.Rectangle(
                x + 12.0,
                y + 12.0,
                310.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE,
                116.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE,
            )
            current_size = self._navi_media_fitted_size(current_frame, current_rect)
            self._draw_navi_media(
                current_frame,
                current_rect,
                align_x=0.0,
                align_y=0.0,
            )
            # The compact TBT bitmap includes transparent padding at its bottom.
            next_y = current_rect.y + max(
                0.0,
                (current_size[1] if current_size is not None else 0.0)
                - 24.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE,
            )
            self._draw_navi_media(
                media.get("image:tbt_next"),
                rl.Rectangle(
                    x + 12.0,
                    next_y,
                    190.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE,
                    68.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE,
                ),
                align_x=0.0,
                align_y=0.0,
            )

            map_center_x = x + w * 0.5
            center_tbt_icon_rect = rl.Rectangle(map_center_x - 55.0, y + 76.0, 110.0, 110.0)
            self._draw_navi_media(
                media.get("image:center_tbt_icon"),
                center_tbt_icon_rect,
            )
            self._draw_navi_media(
                media.get("image:center_tbt_text"),
                rl.Rectangle(
                    map_center_x - 110.0,
                    center_tbt_icon_rect.y + center_tbt_icon_rect.height + 2.0,
                    220.0,
                    78.0,
                ),
            )
            traffic_rect = rl.Rectangle(x + w - 242.0, y + 12.0, 230.0, 98.0)
            self._draw_navi_media(
                media.get("image:traffic_signal"),
                traffic_rect,
                align_x=1.0,
                align_y=0.0,
            )

            safety_frame = next(
                (
                    frame
                    for key in ("image:safety_primary", "image:safety_secondary", "image:safety_section")
                    for frame in (media.get(key),)
                    if frame is not None and frame.present
                ),
                None,
            )
            self._draw_navi_media(
                safety_frame,
                rl.Rectangle(x + 10.0, y + h * 0.62 - 50.0, 110.0, 100.0),
                align_x=0.0,
            )
            lane_width = 226.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE
            lane_height = 67.0 * NAVI_LIVE_GUIDANCE_MEDIA_SCALE
            lane_rect = rl.Rectangle(
                x + (w - lane_width) * 0.5,
                y + h - lane_height - 6.0,
                lane_width,
                lane_height,
            )
            lane_frame = media.get("image:lane_bottom")
            lane_size = self._navi_media_fitted_size(lane_frame, lane_rect)
            self._draw_navi_media(
                lane_frame,
                lane_rect,
            )

            lane_left = lane_rect.x
            lane_right = lane_rect.x + lane_rect.width
            if lane_size is not None:
                lane_left += (lane_rect.width - lane_size[0]) * 0.5
                lane_right = lane_left + lane_size[0]

            if navi is not None and navi.route is not None:
                route = navi.route
                left_x = x + 14.0
                left_width = lane_left - left_x - 14.0
                distance = self._format_navi_distance(route.remaining_distance_m)
                minutes = max(1, round(route.remaining_time_s / 60.0))
                arrival = time.strftime("%H:%M", time.localtime(time.time() + max(0, route.remaining_time_s)))
                self._draw_text_with_stroke(
                    self._ellipsize_text(distance, 25.0, left_width),
                    left_x,
                    y + h - 48.0,
                    25.0,
                    WHITE,
                    (10, 13, 16),
                    2,
                )
                self._draw_text_with_stroke(
                    self._ellipsize_text(f"{arrival}  {minutes} min", 22.0, left_width),
                    left_x,
                    y + h - 19.0,
                    22.0,
                    WHITE,
                    (10, 13, 16),
                    2,
                )

            road_name = navi.vehicle.road_name if navi is not None and navi.vehicle is not None else ""
            right_x = x + w - 14.0
            right_width = right_x - lane_right - 14.0
            if road_name and right_width >= 70.0:
                self._draw_text_with_stroke(
                    self._ellipsize_text(road_name, 20.0, right_width),
                    right_x,
                    y + h - 25.0,
                    20.0,
                    WHITE,
                    (10, 13, 16),
                    2,
                    anchor="right",
                    cache=True,
                )
            return

        if navi is None:
            return

        current = navi.current
        if current is not None:
            self._draw_navi_turn_icon(current.turn_type, x + 72.0, NAVI_LIVE_ICON_Y, NAVI_LIVE_ICON_SIZE)
            distance_text = self._format_navi_distance(current.distance_m)
            self._draw_text(distance_text, x + 136.0, y + 26.0, 38.0, theme.text)
            main_text = current.main_text or current.road_name or current.near_direction
            self._draw_text(
                self._ellipsize_text(main_text, 25.0, NAVI_LIVE_CONTENT_W),
                x + 136.0,
                y + 75.0,
                25.0,
                theme.text,
            )
            detail = current.road_name if current.road_name and current.road_name != main_text else current.near_direction
            if detail:
                self._draw_text(
                    self._ellipsize_text(detail, 18.0, NAVI_LIVE_CONTENT_W),
                    x + 136.0,
                    y + 112.0,
                    18.0,
                    theme.muted,
                )
        elif navi.vehicle is not None and navi.vehicle.road_name:
            road_name = self._ellipsize_text(navi.vehicle.road_name, 28.0, w - 48.0)
            self._draw_text(road_name, x + 24.0, y + 34.0, 28.0, theme.text)

        next_guidance = navi.next
        if next_guidance is not None:
            rl.draw_line_ex(
                rl.Vector2(x + 20.0, NAVI_LIVE_NEXT_Y - 12.0),
                rl.Vector2(x + w - 20.0, NAVI_LIVE_NEXT_Y - 12.0),
                1.5,
                rl_color(theme.faint),
            )
            self._draw_navi_turn_icon(next_guidance.turn_type, x + 46.0, NAVI_LIVE_NEXT_Y + 22.0, 44.0)
            self._draw_text(
                self._format_navi_distance(next_guidance.distance_m),
                x + 82.0,
                NAVI_LIVE_NEXT_Y - 1.0,
                24.0,
                theme.text,
            )
            next_text = next_guidance.main_text or next_guidance.road_name or next_guidance.near_direction
            self._draw_text(
                self._ellipsize_text(next_text, 18.0, w - 180.0),
                x + 180.0,
                NAVI_LIVE_NEXT_Y + 5.0,
                18.0,
                theme.muted,
            )

        lane = navi.lane_current
        if lane is None and navi.lane_ahead:
            lane = navi.lane_ahead[0]
        if lane is not None and lane.visible:
            self._draw_navi_lane_strip(lane)

        footer_parts: list[str] = []
        if navi.route is not None and navi.route.remaining_distance_m > 0:
            route_text = self._format_navi_distance(navi.route.remaining_distance_m)
            if navi.route.remaining_time_s > 0:
                route_text += f" / {max(1, round(navi.route.remaining_time_s / 60.0))} min"
            footer_parts.append(route_text)
        if navi.speed is not None and navi.speed.sdi_type is not None:
            sdi_text = "SDI"
            if navi.speed.sdi_speed_limit_kph:
                sdi_text += f" {display_speed(navi.speed.sdi_speed_limit_kph, self.is_metric):.0f}"
            if navi.speed.sdi_distance_m is not None:
                sdi_text += f" / {self._format_navi_distance(navi.speed.sdi_distance_m)}"
            footer_parts.append(sdi_text)
        if navi.speed is not None and navi.speed.secondary_sdi_type is not None:
            secondary_sdi_text = "SDI2"
            if navi.speed.secondary_sdi_speed_limit_kph:
                secondary_sdi_text += (
                    f" {display_speed(navi.speed.secondary_sdi_speed_limit_kph, self.is_metric):.0f}"
                )
            if navi.speed.secondary_sdi_distance_m is not None:
                secondary_sdi_text += f" / {self._format_navi_distance(navi.speed.secondary_sdi_distance_m)}"
            footer_parts.append(secondary_sdi_text)
        if navi.crossroad is not None and navi.crossroad.visible:
            footer_parts.append(f"JCT {self._format_navi_distance(navi.crossroad.distance_m)}")
        if navi.status is not None and navi.status.off_route:
            footer_parts.append(self._text("off_route"))
        if footer_parts:
            footer = self._ellipsize_text("   ".join(footer_parts), 18.0, w - 40.0)
            self._draw_text(footer, x + 20.0, NAVI_LIVE_FOOTER_Y, 18.0, theme.muted)

    def _draw_navi_crossroad_box(
        self,
        frame: NaviMediaFrame | None,
        map_left: float,
        map_top: float,
        map_height: float,
    ) -> None:
        if frame is None or not frame.present or frame.width <= 0 or frame.height <= 0:
            return
        theme = self._current_theme()
        box_h = map_height * 0.70
        aspect = frame.width / max(1.0, float(frame.height))
        if self._panel_swap_active():
            box_x = map_left + NAVI_LIVE_PANEL_W
            available_w = DESIGN_WIDTH - box_x - 4.0
        else:
            available_w = map_left - 830.0
            box_x = map_left
        box_w = clamp(box_h * aspect, 320.0, max(320.0, available_w))
        if not self._panel_swap_active():
            box_x -= box_w
        box = rl.Rectangle(box_x, map_top, box_w, box_h)
        self._rounded_rect(box.x, box.y, box.width, box.height, 8.0, theme.route_panel_bg, theme.faint, 2.0)
        image_rect = rl.Rectangle(box.x + 4.0, box.y + 4.0, box.width - 8.0, box.height - 8.0)
        rl.begin_scissor_mode(
            int(round(image_rect.x)),
            int(round(image_rect.y)),
            int(round(image_rect.width)),
            int(round(image_rect.height)),
        )
        try:
            self._draw_navi_media(frame, image_rect, cover=True)
        finally:
            rl.end_scissor_mode()
        self._rounded_rect(box.x, box.y, box.width, box.height, 8.0, (0, 0, 0, 0), theme.faint, 2.0)

    def _draw_navi_lane_strip(self, lane: NaviLaneInfo) -> None:
        theme = self._current_theme()
        count = min(8, max(lane.count, len(lane.available), len(lane.turn_info)))
        if count <= 0:
            return
        x = self._information_panel_x(NAVI_LIVE_PANEL_X) + 22.0
        available_w = NAVI_LIVE_PANEL_W - 44.0
        gap = 6.0
        cell_w = min(46.0, (available_w - gap * (count - 1)) / count)
        total_w = cell_w * count + gap * (count - 1)
        x += (available_w - total_w) * 0.5
        y = NAVI_LIVE_LANE_Y
        current_index = lane.current_lane - 1 if 1 <= lane.current_lane <= count else lane.current_lane
        for index in range(count):
            available = index < len(lane.available) and lane.available[index] > 0
            active = index == current_index
            fill = (35, 92, 58, 230) if available else theme.panel_bg
            outline = GREEN if active else (102, 194, 132) if available else theme.faint
            self._rounded_rect(x, y, cell_w, 46.0, 4.0, fill, outline, 3.0 if active else 1.5)
            center_x = x + cell_w * 0.5
            arrow_color = GREEN if available else theme.muted
            self._draw_navi_round_line(
                rl.Vector2(center_x, y + 33.0),
                rl.Vector2(center_x, y + 14.0),
                3.0,
                arrow_color,
            )
            rl.draw_triangle(
                rl.Vector2(center_x, y + 8.0),
                rl.Vector2(center_x - 5.0, y + 16.0),
                rl.Vector2(center_x + 5.0, y + 16.0),
                rl_color(arrow_color),
            )
            x += cell_w + gap

    def _draw_navi_turn_icon(self, turn_type: int, cx: float, cy: float, size: float) -> None:
        theme = self._current_theme()
        radius = size * 0.5
        rl.draw_circle_v(rl.Vector2(cx, cy), radius, rl_color((24, 88, 148, 235)))
        rl.draw_ring(
            rl.Vector2(cx, cy),
            max(0.0, radius - 2.0),
            radius,
            0.0,
            360.0,
            48,
            rl_color(BLUE_SOFT),
        )
        color = WHITE if theme.is_dark else (246, 249, 252)
        width = max(3.0, size * 0.075)

        def point(dx: float, dy: float) -> rl.Vector2:
            return rl.Vector2(cx + dx * size, cy + dy * size)

        if turn_type in (153, 154, 249):
            self._draw_text("TG", cx, cy - size * 0.16, size * 0.34, color, anchor="center")
            return
        if turn_type == 14:
            rl.draw_ring(
                rl.Vector2(cx, cy - size * 0.04),
                size * 0.16,
                size * 0.16 + width,
                190.0,
                360.0,
                30,
                rl_color(color),
            )
            self._draw_navi_round_line(point(0.20, -0.04), point(0.20, 0.28), width, color)
            rl.draw_triangle(point(-0.24, 0.23), point(-0.34, 0.08), point(-0.12, 0.13), rl_color(color))
            return
        if turn_type in NAVI_TURN_ROUNDABOUT_TYPES:
            rl.draw_ring(
                rl.Vector2(cx, cy),
                size * 0.16,
                size * 0.16 + width,
                25.0,
                330.0,
                36,
                rl_color(color),
            )
            rl.draw_triangle(point(0.29, -0.20), point(0.11, -0.22), point(0.23, -0.05), rl_color(color))
            return

        direction = -1.0 if turn_type in NAVI_TURN_LEFT_TYPES else 1.0 if turn_type in NAVI_TURN_RIGHT_TYPES else 0.0
        if direction == 0.0:
            self._draw_navi_round_line(point(0.0, 0.28), point(0.0, -0.24), width, color)
            rl.draw_triangle(point(0.0, -0.35), point(-0.11, -0.19), point(0.11, -0.19), rl_color(color))
            return
        self._draw_navi_round_line(point(0.0, 0.28), point(0.0, -0.03), width, color)
        self._draw_navi_round_line(point(0.0, -0.03), point(direction * 0.27, -0.03), width, color)
        rl.draw_triangle(
            point(direction * 0.36, -0.03),
            point(direction * 0.22, -0.15),
            point(direction * 0.22, 0.09),
            rl_color(color),
        )

    def _format_navi_distance(self, distance_m: int | float) -> str:
        return format_navi_distance(distance_m, self.is_metric)

    def _draw_navi_debug_panel(self, info: NaviDebugInfo | None) -> None:
        theme = self._current_theme()
        panel_x = self._information_panel_x(SYSTEM_PANEL_X)
        panel_y = SYSTEM_PANEL_Y
        panel_w = SYSTEM_PANEL_W
        panel_h = min(DESIGN_HEIGHT - SYSTEM_PANEL_Y - 18.0, 520.0)
        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 18, theme.route_panel_bg, theme.faint, 2)

        if info is None:
            self._draw_text("NAVI receiver", panel_x + 24, panel_y + 34, 24, theme.text)
            self._draw_text("waiting for data", panel_x + 24, panel_y + 76, 22, theme.muted)
            self._draw_navi_guidance_image_box(None)
            return

        severity = info.severity.lower()
        title_color = {
            "stop": RED,
            "go": GREEN,
            "warning": RED,
            "caution": AMBER,
        }.get(severity, theme.text)
        title = self._ellipsize_text(info.title, 24, panel_w - 48)
        self._draw_text(title, panel_x + 24, panel_y + 34, 24, title_color)

        if severity not in ("normal", ""):
            badge_w = 92.0
            badge_h = 28.0
            badge_x = panel_x + panel_w - badge_w - 24.0
            badge_y = panel_y + 23.0
            self._rounded_rect(badge_x, badge_y, badge_w, badge_h, 10, title_color, None, 0.0)
            self._draw_text(severity.upper(), badge_x + badge_w * 0.5, badge_y + 6.0, 15, WHITE, anchor="center")

        y = panel_y + 82.0
        line_size = 19
        max_w = panel_w - 48.0
        lines = info.lines or ("no navi event",)
        for index, line in enumerate(lines[:4]):
            text = self._ellipsize_text(str(line), line_size, max_w)
            color = theme.text if index < 4 else theme.muted
            self._draw_text(text, panel_x + 24, y, line_size, color)
            y += 31.0
        self._draw_navi_guidance_image_box(info.guidance_image)

    def _draw_navi_traffic_light_panel(
        self,
        traffic: NaviTrafficLightInfo,
        *,
        panel_right: float = NAVI_TRAFFIC_PANEL_RIGHT,
        panel_y: float = NAVI_TRAFFIC_PANEL_Y,
    ) -> None:
        theme = self._current_theme()
        y = panel_y
        h = NAVI_TRAFFIC_PANEL_H
        bg = NAVI_TRAFFIC_BG_DARK if theme.is_dark else NAVI_TRAFFIC_BG_LIGHT
        off = NAVI_TRAFFIC_OFF_DARK if theme.is_dark else NAVI_TRAFFIC_OFF_LIGHT

        elapsed_s = 0
        if traffic.meta is not None:
            elapsed_s = max(0, int(time.monotonic() - traffic.meta.received_mono_s))

        def countdown(seconds: int | None) -> int | None:
            return None if seconds is None else max(0, seconds - elapsed_s)

        red_s = countdown(traffic.red_s)
        straight_s = countdown(traffic.straight_s)
        left_s = countdown(traffic.left_s)
        right_s = countdown(traffic.right_s)
        uturn_s = countdown(traffic.uturn_s)
        red_on = self._navi_signal_active(traffic, "red", red_s)
        straight_on = self._navi_signal_active(traffic, "straight", straight_s)
        left_on = self._navi_signal_active(traffic, "left", left_s)
        right_on = self._navi_signal_active(traffic, "right", right_s)
        uturn_on = self._navi_signal_active(traffic, "uturn", uturn_s)
        use_uturn_slot = (uturn_on or uturn_s is not None) and not (left_on or left_s is not None)

        primary_seconds, primary_red = self._navi_primary_signal_seconds(
            traffic,
            red_s=red_s,
            straight_s=straight_s,
            left_s=left_s,
            right_s=right_s,
            uturn_s=uturn_s,
        )
        remain_text = "--" if primary_seconds is None else str(primary_seconds)
        remain_color = NAVI_TRAFFIC_RED if primary_red else NAVI_TRAFFIC_GREEN
        remain_size = 54.0
        remain_width, _ = self._measure_text(remain_text, remain_size, max(1.0, remain_size * 0.02))
        show_right = right_on or right_s is not None
        slot_count = 4 if show_right else 3
        slot_span = slot_count * NAVI_TRAFFIC_SIGNAL_SIZE + (slot_count - 1) * NAVI_TRAFFIC_SIGNAL_GAP
        content_w = slot_span + NAVI_TRAFFIC_TEXT_GAP + remain_width
        w = max(270.0, content_w + NAVI_TRAFFIC_PANEL_PAD_X * 2.0)
        x = panel_right - w
        shadow = (0, 0, 0, 92)
        outline = theme.faint if theme.is_dark else NAVI_TRAFFIC_BG_OUTLINE
        self._rounded_rect(x + 5.0, y + 7.0, w, h, 20.0, shadow, None, 0.0)
        self._rounded_rect(x, y, w, h, 20.0, bg, outline, 3.0)

        slot_y = y + h * 0.5
        slot_x = x + NAVI_TRAFFIC_PANEL_PAD_X + NAVI_TRAFFIC_SIGNAL_SIZE * 0.5
        step = NAVI_TRAFFIC_SIGNAL_SIZE + NAVI_TRAFFIC_SIGNAL_GAP
        self._draw_navi_red_signal(slot_x, slot_y, red_on, off)
        self._draw_navi_turn_signal_slot(
            slot_x + step,
            slot_y,
            active=uturn_on if use_uturn_slot else left_on,
            uturn=use_uturn_slot,
            off=off,
        )
        self._draw_navi_green_signal(slot_x + step * 2.0, slot_y, straight_on, off)
        if show_right:
            self._draw_navi_turn_signal_slot(slot_x + step * 3.0, slot_y, active=right_on, right=True, off=off)

        remain_x = slot_x + NAVI_TRAFFIC_SIGNAL_SIZE * 0.5 + step * (slot_count - 1) + NAVI_TRAFFIC_TEXT_GAP
        self._draw_text_with_stroke(
            remain_text,
            remain_x,
            slot_y,
            remain_size,
            remain_color,
            (0, 0, 0),
            4,
            anchor="left",
        )

    @staticmethod
    def _navi_signal_active(traffic: NaviTrafficLightInfo | None, name: str, seconds: int | None) -> bool:
        if traffic is None:
            return False
        flag = getattr(traffic, f"{name}_on", None)
        if flag is not None:
            return bool(flag)
        return seconds is not None

    def _navi_primary_signal_seconds(
        self,
        traffic: NaviTrafficLightInfo | None,
        *,
        red_s: int | None = None,
        straight_s: int | None = None,
        left_s: int | None = None,
        right_s: int | None = None,
        uturn_s: int | None = None,
    ) -> tuple[int | None, bool]:
        if traffic is None:
            return None, False
        ordered = (
            ("red", traffic.red_s if red_s is None else red_s, True),
            ("left", traffic.left_s if left_s is None else left_s, False),
            ("uturn", traffic.uturn_s if uturn_s is None else uturn_s, False),
            ("straight", traffic.straight_s if straight_s is None else straight_s, False),
            ("right", traffic.right_s if right_s is None else right_s, False),
        )
        for name, seconds, is_red in ordered:
            if self._navi_signal_active(traffic, name, seconds):
                return seconds, is_red
        for _, seconds, is_red in ordered:
            if seconds is not None:
                return seconds, is_red
        return None, False

    def _draw_navi_red_signal(self, cx: float, cy: float, active: bool, off: tuple[int, int, int]) -> None:
        radius = NAVI_TRAFFIC_SIGNAL_SIZE * (12.5 / 26.0 if active else 0.5)
        color = NAVI_TRAFFIC_RED if active else off
        rl.draw_circle_v(rl.Vector2(cx, cy), radius, rl_color(color))
        if active:
            self._draw_navi_circle_stroke(cx, cy, radius, max(1.6, NAVI_TRAFFIC_SIGNAL_SIZE / 26.0), (0, 0, 0))

    def _draw_navi_green_signal(self, cx: float, cy: float, active: bool, off: tuple[int, int, int]) -> None:
        radius = NAVI_TRAFFIC_SIGNAL_SIZE * (12.5 / 26.0 if active else 0.5)
        color = NAVI_TRAFFIC_GREEN if active else off
        rl.draw_circle_v(rl.Vector2(cx, cy), radius, rl_color(color))
        if active:
            self._draw_navi_circle_stroke(cx, cy, radius, max(1.6, NAVI_TRAFFIC_SIGNAL_SIZE / 26.0), (0, 0, 0))

    def _draw_navi_turn_signal_slot(
        self,
        cx: float,
        cy: float,
        *,
        active: bool,
        uturn: bool = False,
        right: bool = False,
        off: tuple[int, int, int],
    ) -> None:
        radius = NAVI_TRAFFIC_SIGNAL_SIZE * 0.5
        active_bg = (0, 0, 0) if self._current_theme().is_dark else (34, 34, 34)
        rl.draw_circle_v(rl.Vector2(cx, cy), radius, rl_color(active_bg if active else off))
        color = NAVI_TRAFFIC_GREEN if active else NAVI_TRAFFIC_OFF_ARROW
        if uturn:
            self._draw_navi_uturn_arrow(cx, cy, color)
        else:
            self._draw_navi_horizontal_arrow(cx, cy, color, right=right)

    def _draw_navi_circle_stroke(
        self,
        cx: float,
        cy: float,
        radius: float,
        stroke_width: float,
        color: tuple[int, int, int],
    ) -> None:
        rl.draw_ring(
            rl.Vector2(cx, cy),
            max(0.0, radius - stroke_width),
            radius,
            0.0,
            360.0,
            48,
            rl_color(color),
        )

    @staticmethod
    def _navi_slot_point(cx: float, cy: float, x: float, y: float) -> "rl.Vector2":
        scale = NAVI_TRAFFIC_SIGNAL_SIZE / 26.0
        return rl.Vector2(cx + (x - 13.0) * scale, cy + (y - 13.0) * scale)

    @staticmethod
    def _draw_navi_round_line(start: "rl.Vector2", end: "rl.Vector2", width: float, color: tuple[int, int, int]) -> None:
        draw_color = rl_color(color)
        rl.draw_line_ex(start, end, width, draw_color)
        cap_radius = width * 0.5
        rl.draw_circle_v(start, cap_radius, draw_color)
        rl.draw_circle_v(end, cap_radius, draw_color)

    def _draw_navi_horizontal_arrow(self, cx: float, cy: float, color: tuple[int, int, int], *, right: bool) -> None:
        def point(x: float, y: float) -> "rl.Vector2":
            return self._navi_slot_point(cx, cy, 26.0 - x if right else x, y)

        width = max(3.0, 3.0 * NAVI_TRAFFIC_SIGNAL_SIZE / 26.0)
        self._draw_navi_round_line(point(8.5, 13.0), point(20.5, 13.0), width, color)
        tip = point(6.418, 13.0)
        top = point(12.532, 7.0)
        bottom = point(12.532, 19.0)
        self._draw_navi_round_line(top, tip, width, color)
        self._draw_navi_round_line(tip, bottom, width, color)

    def _draw_navi_uturn_arrow(self, cx: float, cy: float, color: tuple[int, int, int]) -> None:
        scale = NAVI_TRAFFIC_SIGNAL_SIZE / 26.0
        width = max(3.0, 3.0 * scale)
        rl.draw_ring(
            rl.Vector2(cx, cy - 3.2 * scale),
            4.7 * scale,
            4.7 * scale + width,
            190.0,
            360.0,
            28,
            rl_color(color),
        )
        self._draw_navi_round_line(
            self._navi_slot_point(cx, cy, 17.8, 10.0),
            self._navi_slot_point(cx, cy, 17.8, 18.6),
            width,
            color,
        )
        tip = self._navi_slot_point(cx, cy, 8.0, 18.8)
        top = self._navi_slot_point(cx, cy, 4.9, 12.7)
        bottom = self._navi_slot_point(cx, cy, 12.6, 15.0)
        rl.draw_triangle(top, tip, bottom, rl_color(color))

    def _draw_navi_guidance_image_box(self, image: NaviGuidanceImage | None) -> None:
        theme = self._current_theme()
        box_x = self._information_panel_x(NAVI_GUIDANCE_IMAGE_X)
        box_y = NAVI_GUIDANCE_IMAGE_Y
        box_w = NAVI_GUIDANCE_IMAGE_W
        box_h = NAVI_GUIDANCE_IMAGE_H
        self._rounded_rect(box_x, box_y, box_w, box_h, 14, theme.panel_bg, theme.faint, 2)
        self._draw_text("3D GUIDE", box_x + 16, box_y + 18, 15, theme.muted)
        texture = self._navi_guidance_texture_for(image)
        if texture is None:
            return
        texture_w = float(texture.width)
        texture_h = float(texture.height)
        if texture_w <= 0.0 or texture_h <= 0.0:
            return
        inner_x = box_x + 14.0
        inner_y = box_y + 40.0
        inner_w = box_w - 28.0
        inner_h = box_h - 54.0
        scale = min(inner_w / texture_w, inner_h / texture_h)
        draw_w = texture_w * scale
        draw_h = texture_h * scale
        dest = rl.Rectangle(inner_x + (inner_w - draw_w) * 0.5, inner_y + (inner_h - draw_h) * 0.5, draw_w, draw_h)
        source = rl.Rectangle(0.0, 0.0, texture_w, texture_h)
        rl.draw_texture_pro(texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))

    def _navi_guidance_texture_for(self, image: NaviGuidanceImage | None):
        image_hash = image.image_hash if image is not None else ""
        image_base64 = image.image_base64 if image is not None else ""
        if not image_hash and image_base64:
            image_hash = str(hash(image_base64))
        if not image_base64:
            if self._navi_guidance_texture is not None:
                rl.unload_texture(self._navi_guidance_texture)
                self._navi_guidance_texture = None
                self._navi_guidance_hash = ""
                self._navi_guidance_size = None
            return None
        if self._navi_guidance_texture is not None and image_hash == self._navi_guidance_hash:
            return self._navi_guidance_texture
        if self._navi_guidance_texture is not None:
            rl.unload_texture(self._navi_guidance_texture)
            self._navi_guidance_texture = None
            self._navi_guidance_hash = ""
            self._navi_guidance_size = None
        try:
            payload = image_base64.split(",", 1)[1] if "," in image_base64[:64] else image_base64
            image_bytes = base64.b64decode(payload, validate=False)
        except Exception:
            return None
        extension = ".jpg" if image is not None and "jpeg" in image.image_mime.lower() else ".png"
        loaded_image = None
        try:
            loaded_image = rl.load_image_from_memory(extension, image_bytes, len(image_bytes))
            if not rl.is_image_valid(loaded_image):
                return None
            texture = rl.load_texture_from_image(loaded_image)
            if not rl.is_texture_valid(texture):
                rl.unload_texture(texture)
                return None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            self._navi_guidance_texture = texture
            self._navi_guidance_hash = image_hash
            self._navi_guidance_size = (int(texture.width), int(texture.height))
            return self._navi_guidance_texture
        except Exception:
            return None
        finally:
            if loaded_image is not None and rl.is_image_valid(loaded_image):
                rl.unload_image(loaded_image)

    def _draw_system_dashboard_panel(self, state: ClusterUiState) -> None:
        theme = self._current_theme()
        stats = self._system_stats.sample()
        panel_x = self._information_panel_x(NAVI_LIVE_PANEL_X)
        panel_y = NAVI_LIVE_PANEL_Y
        panel_w = NAVI_LIVE_PANEL_W
        panel_h = NAVI_LIVE_PANEL_H
        card_y = panel_y + 8.0
        card_h = panel_h - 16.0
        detail_x = panel_x + 16.0
        detail_w = 474.0
        health_x = detail_x + detail_w + 10.0
        health_w = panel_x + panel_w - 16.0 - health_x

        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 12.0, theme.panel_bg, theme.faint, 1.5)
        self._draw_system_stats_panel(
            state,
            panel_x=detail_x,
            panel_y=card_y,
            panel_w=detail_w,
            panel_h=card_h,
            show_runtime_info=True,
            title_text="DETAIL",
            stats=stats,
        )
        self._draw_system_health_card(
            state,
            stats,
            health_x,
            card_y,
            health_w,
            card_h,
        )

    def _draw_system_stats_panel(
        self,
        state: ClusterUiState,
        *,
        panel_x: float | None = None,
        panel_y: float = SYSTEM_PANEL_Y,
        panel_w: float = SYSTEM_PANEL_W,
        panel_h: float | None = None,
        status_text: str | None = None,
        show_runtime_info: bool = False,
        title_text: str = "SYSTEM",
        stats: SystemStats | None = None,
    ) -> None:
        if panel_x is None:
            panel_x = self._information_panel_x(SYSTEM_PANEL_X)
        theme = self._current_theme()
        if stats is None:
            stats = self._system_stats.sample()
        disconnected = status_text is not None
        detailed = disconnected or show_runtime_info
        cpu_count = len(stats.cpu_core_percents)
        columns = 2 if cpu_count <= 8 else 4
        rows = max(1, math.ceil(max(1, cpu_count) / columns))
        core_row_h = 30.0 if columns == 2 else 24.0
        header_h = 216.0 if detailed else 122.0
        if panel_h is None:
            panel_h = min(DESIGN_HEIGHT - panel_y - 18.0, header_h + rows * core_row_h + 18.0)
        core_area_h = max(24.0, panel_h - header_h - 14.0)
        core_row_h = min(core_row_h, core_area_h / rows)

        pad_x = 24.0
        panel_bg = NAVI_MAP_BACKGROUND if disconnected else theme.route_panel_bg
        panel_outline = (82, 92, 100, 255) if disconnected else theme.faint
        text_color = WHITE if disconnected else theme.text
        muted_color = (154, 164, 172, 255) if disconnected else theme.muted
        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 18, panel_bg, panel_outline, 2)
        self._draw_text(title_text, panel_x + pad_x, panel_y + 28, 18, muted_color)
        if status_text:
            self._draw_text(
                status_text,
                panel_x + panel_w - pad_x,
                panel_y + 28,
                18,
                AMBER,
                anchor="right",
            )

        if detailed:
            fps_text = "-- Hz"
            if state.actual_fps is not None and math.isfinite(state.actual_fps):
                fps_text = f"{state.actual_fps:.1f} Hz"
            camera_text = "STANDBY"
            if state.onroad:
                camera_text = (
                    "ROAD CAMERA"
                    if cluster_camera_view_is_road_camera(state.camera_view_mode)
                    else "ONROAD"
                )
            info_rows = (
                ("NETWORK", state.network_address or "unavailable"),
                ("DISPLAY", f"{self.width} x {self.height}  /  {fps_text}"),
                ("CAMERA", camera_text),
            )
            for index, (label, value) in enumerate(info_rows):
                line_y = panel_y + 66.0 + index * 30.0
                self._draw_text(label, panel_x + pad_x, line_y, 16, muted_color)
                self._draw_text(value, panel_x + panel_w - pad_x, line_y, 17, text_color, anchor="right")

        mem_percent = stats.memory_used_percent
        mem_color = self._system_metric_color(mem_percent)
        mem_text_y = panel_y + (164.0 if detailed else 62.0)
        mem_bar_y = panel_y + (182.0 if detailed else 80.0)
        self._draw_text("MEM", panel_x + pad_x, mem_text_y, 17, muted_color)
        self._draw_text(
            self._memory_text(stats),
            panel_x + 86,
            mem_text_y,
            17,
            text_color if stats.memory_used_bytes is not None else muted_color,
        )
        self._draw_text(
            self._percent_text(mem_percent),
            panel_x + panel_w - pad_x,
            mem_text_y,
            17,
            mem_color,
            anchor="right",
        )
        self._draw_percent_bar(panel_x + pad_x, mem_bar_y, panel_w - pad_x * 2, 12, mem_percent, mem_color)

        cpu_header_y = panel_y + (208.0 if detailed else 104.0)
        self._draw_text("CPU CORE %", panel_x + pad_x, cpu_header_y, 15, muted_color)
        if cpu_count == 0:
            self._draw_text("unavailable", panel_x + panel_w - pad_x, cpu_header_y, 15, muted_color, anchor="right")
            return

        core_start_y = panel_y + header_h
        gap_x = 18.0 if columns == 2 else 10.0
        cell_w = (panel_w - pad_x * 2 - gap_x * (columns - 1)) / columns
        for index, percent in enumerate(stats.cpu_core_percents):
            row = index // columns
            column = index % columns
            cell_x = panel_x + pad_x + column * (cell_w + gap_x)
            line_y = core_start_y + row * core_row_h
            color = self._system_metric_color(percent)
            text_size = 15 if columns == 2 else 12
            self._draw_text(f"C{index}", cell_x, line_y + 8, text_size, muted_color)
            self._draw_text(self._percent_text(percent), cell_x + cell_w, line_y + 8, text_size, color, anchor="right")
            self._draw_percent_bar(cell_x, line_y + 19, cell_w, 6, percent, color)

    def _draw_trip_report_panel(self, state: ClusterUiState) -> None:
        target = getattr(self, "_trip_report_target", None)
        if not getattr(self, "_trip_report_cache_valid", False) or target is None:
            self._draw_trip_report_panel_contents(state)
            return

        panel_x = self._information_panel_x(TRIP_REPORT_PANEL_X)
        source = rl.Rectangle(
            0.0,
            0.0,
            float(target.texture.width),
            -float(target.texture.height),
        )
        destination = rl.Rectangle(
            panel_x,
            TRIP_REPORT_PANEL_Y,
            TRIP_REPORT_PANEL_W,
            TRIP_REPORT_PANEL_H,
        )
        rl.draw_texture_pro(
            target.texture,
            source,
            destination,
            rl.Vector2(0.0, 0.0),
            0.0,
            rl_color(WHITE),
        )

    def _draw_trip_report_panel_contents(self, state: ClusterUiState) -> None:
        report = state.trip_report or TripReportState()
        stats = self._system_stats.sample()
        theme = self._current_theme()
        panel_x = self._information_panel_x(TRIP_REPORT_PANEL_X)
        panel_y = TRIP_REPORT_PANEL_Y
        panel_w = TRIP_REPORT_PANEL_W
        panel_h = TRIP_REPORT_PANEL_H
        panel_bg = theme.panel_bg
        card_bg = theme.route_panel_bg
        card_outline = theme.faint
        text_color = theme.text
        muted = theme.muted

        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 12.0, panel_bg, card_outline, 1.5)

        summary_x = panel_x + 16.0
        summary_y = panel_y + 8.0
        summary_w = 474.0
        summary_h = panel_h - 16.0
        system_x = summary_x + summary_w + 10.0
        system_y = summary_y
        system_w = panel_x + panel_w - 16.0 - system_x
        system_h = summary_h
        self._rounded_rect(summary_x, summary_y, summary_w, summary_h, 10.0, card_bg, card_outline, 1.2)

        self._draw_text(self._text("trip_summary"), summary_x + 18.0, summary_y + 31.0, 22.0, muted)
        self._draw_text(self._text("time"), summary_x + 18.0, summary_y + 82.0, 19.0, muted)
        self._draw_text(
            self._trip_format_time(report.duration_s),
            summary_x + summary_w - 18.0,
            summary_y + 82.0,
            35.0,
            (255, 177, 105),
            anchor="right",
        )
        rl.draw_line_ex(
            rl.Vector2(summary_x + 18.0, summary_y + 114.0),
            rl.Vector2(summary_x + summary_w - 18.0, summary_y + 114.0),
            1.0,
            rl_color(card_outline),
        )
        metric_w = (summary_w - 54.0) * 0.5
        metric_left = summary_x + 18.0
        metric_right = metric_left + metric_w + 18.0
        report_speed_unit = speed_unit(self.is_metric)
        self._draw_trip_metric(
            metric_left,
            summary_y + 138.0,
            self._text("distance"),
            self._trip_distance_text(report.distance_m),
            metric_w,
            text_color=text_color,
            muted_color=muted,
        )
        self._draw_trip_metric(
            metric_right,
            summary_y + 138.0,
            self._text("average_speed"),
            f"{display_speed(report.average_speed_kph, self.is_metric):.1f}",
            metric_w,
            report_speed_unit,
            text_color=text_color,
            muted_color=muted,
        )
        self._draw_trip_metric(
            metric_left,
            summary_y + 218.0,
            self._text("max_speed"),
            f"{display_speed(report.max_speed_kph, self.is_metric):.1f}",
            metric_w,
            report_speed_unit,
            text_color=text_color,
            muted_color=muted,
        )
        self._draw_trip_metric(
            metric_right,
            summary_y + 218.0,
            self._text("auto_drive"),
            f"{report.auto_ratio_percent:.0f}",
            metric_w,
            "%",
            text_color=text_color,
            muted_color=muted,
        )
        self._draw_trip_metric(
            metric_left,
            summary_y + 298.0,
            self._text("max_accel"),
            f"{report.max_accel_mps2:+.2f}",
            metric_w,
            "m/s²",
            text_color=text_color,
            muted_color=muted,
        )
        self._draw_trip_metric(
            metric_right,
            summary_y + 298.0,
            self._text("max_decel"),
            f"{report.max_decel_mps2:+.2f}",
            metric_w,
            "m/s²",
            text_color=text_color,
            muted_color=muted,
        )

        event_y = summary_y + 390.0
        event_w = (summary_w - 56.0) / 3.0
        event_label_size = 16.0 if self.language == CLUSTER_LANGUAGE_KO else 13.0
        for index, (label, count, color) in enumerate((
            (self._text("hard_accel"), report.hard_accel_count, AMBER),
            (self._text("hard_brake"), report.hard_brake_count, RED),
            (self._text("hard_corner"), report.hard_corner_count, BLUE_SOFT),
        )):
            event_x = summary_x + 18.0 + index * (event_w + 10.0)
            self._rounded_rect(event_x, event_y, event_w, 47.0, 7.0, theme.panel_bg, color, 1.2)
            self._draw_text(label, event_x + 9.0, event_y + 23.5, event_label_size, muted)
            self._draw_text(str(count), event_x + event_w - 9.0, event_y + 23.5, 23.0, color, anchor="right")

        self._draw_system_health_card(
            state,
            stats,
            system_x,
            system_y,
            system_w,
            system_h,
            panel_bg=card_bg,
            panel_outline=card_outline,
            text_color=text_color,
            muted_color=muted,
            target_fill=theme.panel_bg,
        )

    def _draw_system_health_card(
        self,
        state: ClusterUiState,
        stats: SystemStats,
        panel_x: float,
        panel_y: float,
        panel_w: float,
        panel_h: float,
        *,
        panel_bg: tuple[int, ...] | None = None,
        panel_outline: tuple[int, ...] | None = None,
        text_color: tuple[int, ...] | None = None,
        muted_color: tuple[int, ...] | None = None,
        target_fill: tuple[int, ...] | None = None,
    ) -> None:
        theme = self._current_theme() if any(
            value is None
            for value in (panel_bg, panel_outline, text_color, muted_color, target_fill)
        ) else None
        if panel_bg is None:
            assert theme is not None
            panel_bg = theme.route_panel_bg
        if panel_outline is None:
            assert theme is not None
            panel_outline = theme.faint
        if text_color is None:
            assert theme is not None
            text_color = theme.text
        if muted_color is None:
            assert theme is not None
            muted_color = theme.muted
        if target_fill is None:
            assert theme is not None
            target_fill = theme.panel_bg

        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 10.0, panel_bg, panel_outline, 1.2)
        self._draw_text(self._text("system"), panel_x + 18.0, panel_y + 31.0, 22.0, muted_color)
        cpu_percent = state.cpu_usage_percent if state.cpu_usage_percent is not None else stats.cpu_used_percent
        memory_percent = (
            state.memory_used_percent
            if state.memory_used_percent is not None
            else stats.memory_used_percent
        )
        disk_percent = (
            state.disk_used_percent
            if state.disk_used_percent is not None
            else stats.disk_used_percent
        )
        system_metrics = (
            ("CPU", self._percent_text(cpu_percent).strip(), cpu_percent, self._system_metric_color(cpu_percent)),
            (
                "TEMP",
                "--°C" if state.cpu_temp_c is None else f"{state.cpu_temp_c:.0f}°C",
                state.cpu_temp_c,
                self._trip_temp_color(state.cpu_temp_c, muted_color),
            ),
            ("MEM", self._percent_text(memory_percent).strip(), memory_percent, self._system_metric_color(memory_percent)),
            ("DISK", self._percent_text(disk_percent).strip(), disk_percent, self._system_metric_color(disk_percent)),
        )
        gauge_pad_x = 16.0
        gauge_gap_x = 8.0
        gauge_w = (panel_w - gauge_pad_x * 2.0 - gauge_gap_x) * 0.5
        gauge_centers_y = (panel_y + 107.0, panel_y + 224.0)
        for index, (label, value, percent, color) in enumerate(system_metrics):
            column = index % 2
            row = index // 2
            center_x = panel_x + gauge_pad_x + gauge_w * 0.5 + column * (gauge_w + gauge_gap_x)
            self._draw_system_gauge(
                center_x,
                gauge_centers_y[row],
                label,
                value,
                percent,
                color,
                muted_color,
                panel_outline,
            )

        rl.draw_line_ex(
            rl.Vector2(panel_x + 18.0, panel_y + 282.0),
            rl.Vector2(panel_x + panel_w - 18.0, panel_y + 282.0),
            1.0,
            rl_color(panel_outline),
        )
        self._draw_text(self._text("device_angle"), panel_x + 18.0, panel_y + 308.0, 18.0, muted_color)
        pitch_deg: float | None = None
        yaw_deg: float | None = None
        calibration = state.camera_calibration_euler
        if calibration is not None and len(calibration) >= 3:
            candidate_pitch = math.degrees(calibration[1])
            candidate_yaw = math.degrees(calibration[2])
            if math.isfinite(candidate_pitch) and math.isfinite(candidate_yaw):
                pitch_deg = candidate_pitch
                yaw_deg = candidate_yaw
        self._draw_device_angle_indicator(
            panel_x + 14.0,
            panel_y + 325.0,
            panel_w - 28.0,
            117.0,
            pitch_deg,
            yaw_deg,
            muted_color,
            panel_outline,
            text_color=text_color,
            target_fill=target_fill,
        )

    def _draw_system_gauge(
        self,
        center_x: float,
        center_y: float,
        label: str,
        value_text: str,
        percent: float | None,
        value_color: tuple[int, int, int],
        muted: tuple[int, int, int],
        track_color: tuple[int, int, int],
    ) -> None:
        radius = 41.0
        stroke_width = 5.0
        start_angle = 135.0
        sweep_angle = 270.0
        segments = 24
        rl.draw_ring(
            rl.Vector2(center_x, center_y),
            radius - stroke_width,
            radius,
            start_angle,
            start_angle + sweep_angle,
            segments,
            rl_color(track_color),
        )
        if percent is not None and math.isfinite(percent):
            ratio = clamp(percent, 0.0, 100.0) / 100.0
            if ratio > 0.0:
                end_angle = start_angle + sweep_angle * ratio
                progress_color = BLUE_SOFT
                rl.draw_ring(
                    rl.Vector2(center_x, center_y),
                    radius - stroke_width,
                    radius,
                    start_angle,
                    end_angle,
                    max(4, int(round(segments * ratio))),
                    rl_color(progress_color),
                )
                cap_radius = stroke_width * 0.5
                for angle in (start_angle, end_angle):
                    angle_rad = math.radians(angle)
                    cap_center = rl.Vector2(
                        center_x + (radius - cap_radius) * math.cos(angle_rad),
                        center_y + (radius - cap_radius) * math.sin(angle_rad),
                    )
                    rl.draw_circle_v(cap_center, cap_radius, rl_color(progress_color))

        self._draw_text(label, center_x, center_y - 13.0, 13.0, muted, anchor="center")
        self._draw_text(value_text, center_x, center_y + 9.0, 23.0, value_color, anchor="center")

    @staticmethod
    def _device_angle_target_offset(
        pitch_deg: float,
        yaw_deg: float,
        radius: float,
        max_angle_deg: float = 6.0,
    ) -> tuple[float, float]:
        usable_radius = radius * 0.68
        scale = usable_radius / max_angle_deg
        # Match the device settings convention: positive pitch points down and
        # positive yaw points left.
        return (
            -clamp(yaw_deg, -max_angle_deg, max_angle_deg) * scale,
            clamp(pitch_deg, -max_angle_deg, max_angle_deg) * scale,
        )

    def _draw_device_angle_indicator(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        pitch_deg: float | None,
        yaw_deg: float | None,
        muted: tuple[int, int, int],
        outline: tuple[int, int, int],
        *,
        text_color: tuple[int, ...] = WHITE,
        target_fill: tuple[int, ...] = (11, 18, 26, 235),
    ) -> None:
        center_x = x + 52.0
        center_y = y + height * 0.5
        radius = 31.0
        rl.draw_circle_v(rl.Vector2(center_x, center_y), radius, rl_color(target_fill))
        rl.draw_ring(
            rl.Vector2(center_x, center_y),
            radius - 1.2,
            radius,
            0.0,
            360.0,
            24,
            rl_color(outline),
        )
        rl.draw_line_ex(
            rl.Vector2(center_x - radius + 6.0, center_y),
            rl.Vector2(center_x + radius - 6.0, center_y),
            1.0,
            rl_color(outline),
        )
        rl.draw_line_ex(
            rl.Vector2(center_x, center_y - radius + 6.0),
            rl.Vector2(center_x, center_y + radius - 6.0),
            1.0,
            rl_color(outline),
        )
        self._draw_text("P-", center_x, center_y - radius - 7.0, 9.0, muted, anchor="center")
        self._draw_text("P+", center_x, center_y + radius + 7.0, 9.0, muted, anchor="center")
        self._draw_text("Y+", center_x - radius - 8.0, center_y, 9.0, muted, anchor="center")
        self._draw_text("Y-", center_x + radius + 8.0, center_y, 9.0, muted, anchor="center")
        rl.draw_circle_v(rl.Vector2(center_x, center_y), 2.5, rl_color(muted))

        valid_angles = (
            pitch_deg is not None
            and yaw_deg is not None
            and math.isfinite(pitch_deg)
            and math.isfinite(yaw_deg)
        )
        if valid_angles:
            offset_x, offset_y = self._device_angle_target_offset(pitch_deg, yaw_deg, radius)
            marker_x = center_x + offset_x
            marker_y = center_y + offset_y
            rl.draw_line_ex(
                rl.Vector2(center_x, center_y),
                rl.Vector2(marker_x, marker_y),
                2.5,
                rl_color(BLUE_SOFT),
            )
            rl.draw_circle_v(rl.Vector2(marker_x, marker_y), 6.0, rl_color(BLUE_SOFT))
            rl.draw_circle_v(rl.Vector2(marker_x, marker_y), 2.2, rl_color(target_fill))

        value_x = x + width * 0.45
        pitch_text = "P  --°" if pitch_deg is None else f"P {pitch_deg:+.1f}°"
        yaw_text = "Y  --°" if yaw_deg is None else f"Y {yaw_deg:+.1f}°"
        self._draw_text(pitch_text, value_x, y + 36.0, 22.0, text_color)
        self._draw_text(yaw_text, value_x, y + 69.0, 22.0, text_color)

    def _draw_trip_metric(
        self,
        x: float,
        y: float,
        label: str,
        value: str,
        width: float,
        unit: str = "",
        *,
        text_color: tuple[int, ...] | None = None,
        muted_color: tuple[int, ...] | None = None,
    ) -> None:
        theme = self._current_theme() if text_color is None or muted_color is None else None
        if text_color is None:
            assert theme is not None
            text_color = theme.text
        if muted_color is None:
            assert theme is not None
            muted_color = theme.muted
        self._draw_text(label, x, y, 18.0, muted_color)
        self._draw_text(value, x, y + 32.0, 29.0, text_color)
        if unit:
            self._draw_text(unit, x + width, y + 32.0, 16.0, muted_color, anchor="right")

    @staticmethod
    def _trip_temp_color(
        temp_c: float | None,
        unavailable_color: tuple[int, ...],
    ) -> tuple[int, ...]:
        if temp_c is None or not math.isfinite(temp_c):
            return unavailable_color
        if temp_c >= 90.0:
            return RED
        if temp_c >= 75.0:
            return AMBER
        return GREEN

    @staticmethod
    def _trip_format_time(duration_s: float) -> str:
        total_seconds = max(0, int(round(duration_s)))
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def _trip_distance_text(self, distance_m: float) -> str:
        return format_trip_distance(distance_m, self.is_metric)

    def _draw_live_debug_panel(self, state: ClusterUiState) -> None:
        sections = self._live_debug_sections(state)
        theme = self._current_theme()
        panel_x = self._information_panel_x(NAVI_LIVE_PANEL_X)
        panel_y = NAVI_LIVE_PANEL_Y
        panel_w = NAVI_LIVE_PANEL_W
        panel_h = NAVI_LIVE_PANEL_H
        card_pad_x = 16.0
        card_pad_y = 8.0
        card_gap = 10.0
        card_w = (panel_w - card_pad_x * 2.0 - card_gap) * 0.5
        card_h = (panel_h - card_pad_y * 2.0 - card_gap) * 0.5

        self._rounded_rect(panel_x, panel_y, panel_w, panel_h, 12.0, theme.panel_bg, theme.faint, 1.5)
        for index, (section_title, rows) in enumerate(sections):
            column = index % 2
            row = index // 2
            card_x = panel_x + card_pad_x + column * (card_w + card_gap)
            card_y = panel_y + card_pad_y + row * (card_h + card_gap)
            content_x = card_x + 18.0
            value_x = card_x + card_w - 18.0
            value_max_w = card_w - 210.0

            self._rounded_rect(card_x, card_y, card_w, card_h, 12.0, theme.route_panel_bg, theme.faint, 1.2)
            self._draw_text(section_title, content_x, card_y + 30.0, 18.0, theme.muted)
            for row_index, (label, value) in enumerate(rows):
                text_y = card_y + 78.0 + row_index * 38.0
                self._draw_text(label, content_x, text_y, 17.0, theme.muted)
                value = self._ellipsize_text(value, 17.0, value_max_w)
                self._draw_text(value, value_x, text_y, 17.0, theme.text, anchor="right")

    def _live_debug_sections(self, state: ClusterUiState) -> tuple[tuple[str, tuple[tuple[str, str], ...]], ...]:
        live_debug = state.live_debug
        live_valid = "--"
        if live_debug is not None and live_debug.live_torque_valid is not None:
            live_valid = "ON" if live_debug.live_torque_valid else "OFF"
        lateral_plan_text = str(state.lateral_plan_debug_text) if state.lateral_plan_debug_text else "--"
        return (
            (
                "LIVE DELAY",
                (
                    (
                        "CAL / LAT",
                        f"{self._optional_percent_text(live_debug.live_delay_calibration_percent if live_debug else None)} / "
                        f"{self._optional_seconds_text(live_debug.live_delay_lateral_s if live_debug else None, 2)}",
                    ),
                ),
            ),
            (
                "LIVE TORQUE",
                (
                    (
                        "STATE",
                        f"{live_valid} / "
                        f"{self._optional_percent_text(live_debug.live_torque_calibration_percent if live_debug else None)}",
                    ),
                    (
                        "FACT / FRIC",
                        f"{self._optional_float_text(live_debug.live_torque_lat_accel_factor if live_debug else None, 2)} / "
                        f"{self._optional_float_text(live_debug.live_torque_friction if live_debug else None, 2)}",
                    ),
                ),
            ),
            (
                "STEERING",
                (
                    (
                        "SR LIVE / CUSTOM",
                        f"{self._optional_float_text(live_debug.live_steer_ratio if live_debug else None, 1)} / "
                        f"{self._optional_float_text(live_debug.custom_steer_ratio if live_debug else None, 1)}",
                    ),
                    (
                        "SAD",
                        self._optional_seconds_text(live_debug.steer_actuator_delay_s if live_debug else None, 2),
                    ),
                ),
            ),
            (
                "LATERAL PLAN",
                (("DEBUG", lateral_plan_text),),
            ),
        )

    @staticmethod
    def _optional_percent_text(value: float | None) -> str:
        if value is None or not math.isfinite(value):
            return "--%"
        return f"{value:.0f}%"

    @staticmethod
    def _optional_float_text(value: float | None, digits: int) -> str:
        if value is None or not math.isfinite(value):
            return "--"
        return f"{value:.{digits}f}"

    def _optional_seconds_text(self, value: float | None, digits: int) -> str:
        text = self._optional_float_text(value, digits)
        return text if text == "--" else f"{text} s"

    def _draw_percent_bar(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        percent: float | None,
        fill: tuple[int, int, int],
    ) -> None:
        theme = self._current_theme()
        self._rounded_rect(x, y, width, height, height * 0.5, theme.gauge_bg)
        if percent is None:
            return
        fill_ratio = clamp(percent, 0.0, 100.0) / 100.0
        if fill_ratio <= 0.0:
            return
        fill_width = max(2.0, width * fill_ratio)
        self._rounded_rect(x, y, fill_width, height, height * 0.5, fill)

    @staticmethod
    def _memory_text(stats: SystemStats) -> str:
        if stats.memory_used_bytes is None or stats.memory_total_bytes is None:
            return "--/-- GB"
        used_gib = stats.memory_used_bytes / (1024.0 ** 3)
        total_gib = stats.memory_total_bytes / (1024.0 ** 3)
        return f"{used_gib:.1f}/{total_gib:.1f} GB"

    @staticmethod
    def _percent_text(percent: float | None) -> str:
        if percent is None:
            return "--%"
        return f"{clamp(percent, 0.0, 100.0):3.0f}%"

    def _system_metric_color(self, percent: float | None) -> tuple[int, int, int]:
        theme = self._current_theme()
        if percent is None:
            return theme.muted
        if percent >= 85.0:
            return RED
        if percent >= 60.0:
            return AMBER
        return BLUE

    def _draw_route_overlay(self, overlay: RouteOverlay | None) -> None:
        if overlay is None or not overlay.panel_visible:
            return
        theme = self._current_theme()
        panel_x = self._information_panel_x(SYSTEM_PANEL_X)
        panel_y = 34
        panel_w = 476
        video_h = 244
        data_y = 300
        profile_stage = self._profile_start()
        self._rounded_rect(panel_x, panel_y, panel_w, 410, 18, theme.route_panel_bg, theme.faint, 2)
        self._profile_add("route_overlay.panel", profile_stage)
        profile_stage = self._profile_start()
        self._draw_route_video(overlay, panel_x + 10, panel_y + 10, panel_w - 20, video_h)
        self._profile_add("route_overlay.video", profile_stage)
        profile_stage = self._profile_start()
        self._draw_route_data(overlay, panel_x + 18, data_y, panel_w - 36)
        self._profile_add("route_overlay.data", profile_stage)

    def _draw_route_video(self, overlay: RouteOverlay, x: float, y: float, width: float, height: float) -> None:
        theme = self._current_theme()
        video_rect = rl.Rectangle(x, y, width, height)
        profile_stage = self._profile_start()
        rl.draw_rectangle_rounded(video_rect, 0.04, 10, rl_color(theme.route_video_bg))
        self._profile_add("route_video.background", profile_stage)
        if overlay.video_rgba is None or overlay.video_width <= 0 or overlay.video_height <= 0:
            status = overlay.video_status or "qcamera unavailable"
            profile_stage = self._profile_start()
            self._draw_text(status, x + width * 0.5, y + height * 0.5, 20, theme.route_video_status, anchor="center")
            self._profile_add("route_video.status_text", profile_stage)
            return

        profile_stage = self._profile_start()
        texture = self._route_video_texture_for_overlay(overlay)
        self._profile_add("route_video.texture_for_overlay", profile_stage)
        if texture is None:
            return
        source = rl.Rectangle(0.0, 0.0, float(overlay.video_width), float(overlay.video_height))
        scale = min(width / overlay.video_width, height / overlay.video_height)
        draw_w = overlay.video_width * scale
        draw_h = overlay.video_height * scale
        dest = rl.Rectangle(x + (width - draw_w) * 0.5, y + (height - draw_h) * 0.5, draw_w, draw_h)
        profile_stage = self._profile_start()
        rl.draw_texture_pro(texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))
        self._profile_add("route_video.draw_texture", profile_stage)

    def _route_video_texture_for_overlay(self, overlay: RouteOverlay):
        size = (overlay.video_width, overlay.video_height)
        if self._route_video_texture is None or self._route_video_size != size:
            if self._route_video_texture is not None:
                rl.unload_texture(self._route_video_texture)
            profile_stage = self._profile_start()
            image = rl.gen_image_color(overlay.video_width, overlay.video_height, rl_color((0, 0, 0)))
            self._route_video_texture = rl.load_texture_from_image(image)
            rl.unload_image(image)
            self._profile_add("route_video.alloc_texture", profile_stage)
            profile_stage = self._profile_start()
            rl.set_texture_filter(self._route_video_texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
            self._profile_add("route_video.filter_texture", profile_stage)
            self._route_video_size = size
            self._route_video_frame_id = None

        if overlay.video_frame_id != self._route_video_frame_id:
            expected = overlay.video_width * overlay.video_height * 4
            if len(overlay.video_rgba or b"") != expected:
                return self._route_video_texture
            profile_stage = self._profile_start()
            pixels = rl.ffi.new("unsigned char[]", overlay.video_rgba)
            self._profile_add("route_video.copy_pixels", profile_stage)
            profile_stage = self._profile_start()
            rl.update_texture(self._route_video_texture, pixels)
            self._profile_add("route_video.update_texture", profile_stage)
            self._route_video_frame_id = overlay.video_frame_id
        return self._route_video_texture

    def _draw_route_data(self, overlay: RouteOverlay, x: float, y: float, width: float) -> None:
        theme = self._current_theme()
        self._draw_text("CURRENT CODE CUT-IN", x, y, 16, theme.muted)
        status_parts = (overlay.cutin_status or "NEW CUTIN: waiting").split(" | ", 1)
        status_color = RED if ": YES" in status_parts[0] else GREEN
        self._draw_text(status_parts[0], x, y + 22, 15, status_color)
        if len(status_parts) > 1:
            self._draw_text(status_parts[1], x, y + 41, 12, theme.text)
        for index, line in enumerate(overlay.data_lines[:6]):
            self._draw_text(line, x, y + 61 + index * 13, 11, theme.text)

    def _draw_git_status(
        self,
        status: GitBranchStatus | None,
        network_address: str | None = None,
        actual_fps: float | None = None,
    ) -> None:
        if status is None and network_address is None:
            return

        theme = self._current_theme()
        text_size = 20
        spacing = max(1.0, text_size * 0.02)
        _, text_height = self._measure_text("0", text_size, spacing)
        row_h = max(text_height, GIT_STATUS_DOT_RADIUS * 2)
        center_y = DESIGN_HEIGHT - GIT_STATUS_BOTTOM_MARGIN - row_h * 0.5
        text_x = GIT_STATUS_MARGIN + GIT_STATUS_DOT_RADIUS * 2 + GIT_STATUS_DOT_TEXT_GAP
        if status is not None:
            color = self._git_status_color(status, theme)
            text = status.branch if not status.detail else f"{status.branch} ({status.detail})"
            text = self._ellipsize_text(text, text_size, GIT_STATUS_MAX_TEXT_W)
            dot_center_x = GIT_STATUS_MARGIN + GIT_STATUS_DOT_RADIUS
            rl.draw_circle_v(rl.Vector2(dot_center_x, center_y), GIT_STATUS_DOT_RADIUS, rl_color(color))
            self._draw_text_with_stroke(text, text_x, center_y, text_size, WHITE, (5, 9, 12), 2, cache=True)
        if network_address:
            network_text = self._ellipsize_text(network_address, text_size, GIT_STATUS_MAX_TEXT_W)
            network_y = center_y - row_h - 4.0
            self._draw_text_with_stroke(
                network_text,
                text_x,
                network_y,
                text_size,
                WHITE,
                (5, 9, 12),
                2,
                cache=True,
            )
            network_width, _ = self._measure_text(network_text, text_size, spacing)
            self._draw_actual_fps(actual_fps, text_x + network_width + 18.0, network_y)

    def _draw_actual_fps(self, actual_fps: float | None, x: float, center_y: float) -> None:
        if actual_fps is None or not math.isfinite(actual_fps):
            return

        text = f"FPS {actual_fps:.1f} Hz"
        text_size = 20
        text = self._ellipsize_text(text, text_size, FPS_STATUS_MAX_TEXT_W)
        dot_center_x = x + FPS_STATUS_DOT_RADIUS
        text_x = x + FPS_STATUS_DOT_RADIUS * 2 + FPS_STATUS_DOT_TEXT_GAP
        rl.draw_circle_v(rl.Vector2(dot_center_x, center_y), FPS_STATUS_DOT_RADIUS, rl_color(GREEN))
        self._draw_text_with_stroke(text, text_x, center_y, text_size, WHITE, (5, 9, 12), 2)

    def _draw_cluster_core_usage(self, text: str | None, *, right_x: float = DESIGN_WIDTH) -> None:
        if not text:
            return

        theme = self._current_theme()
        text_size = 18
        text = self._ellipsize_text(text, text_size, CLUSTER_CORE_USAGE_MAX_TEXT_W)
        spacing = max(1.0, text_size * 0.02)
        _, text_height = self._measure_text(text, text_size, spacing)
        x = right_x - CLUSTER_CORE_USAGE_MARGIN
        y = DESIGN_HEIGHT - CLUSTER_CORE_USAGE_MARGIN - text_height * 0.5
        self._draw_text(text, x, y, text_size, theme.muted, anchor="right")

    @staticmethod
    def _git_status_color(status: GitBranchStatus, theme: ClusterTheme) -> tuple[int, int, int]:
        if status.state == "ok":
            return GREEN
        if status.state == "pull":
            return AMBER
        if status.state == "missing":
            return RED
        return theme.muted

    def _draw_drive_status(self, state: ClusterUiState) -> None:
        if clean_ui_enabled():
            return  # EV6 HUD patch v6
        gear_text = (state.gear_text or "").strip().upper()
        if (
            not state.debug_ui_visible
            and not gear_text
            and state.cruise_gap is None
            and not self._cruise_set_visible(state)
            and state.lfa_active is None
            and not state.egpu_active
            and not state.external_compute_label
        ):
            return

        self._draw_network_status(state, TOP_STATUS_CENTER_Y + WIFI_STATUS_ICON_SIZE * 0.5)
        self._draw_egpu_status(state)
        self._draw_lfa_status_icon(state, TOP_STATUS_CENTER_Y + LFA_STATUS_ICON_SIZE * 0.5)

    def _draw_egpu_status(self, state: ClusterUiState) -> None:
        label = 'eGPU' if state.egpu_active else state.external_compute_label
        if not label:
            return
        width = max(EGPU_STATUS_W, len(label) * EGPU_STATUS_FONT_SIZE * 0.7 + 16)
        rect = rl.Rectangle(
            EGPU_STATUS_CENTER_X - width * 0.5,
            TOP_STATUS_CENTER_Y - EGPU_STATUS_H * 0.5,
            width,
            EGPU_STATUS_H,
        )
        rl.draw_rectangle_rounded(rect, 0.35, 8, rl_color((0, 0, 0), 150))
        rl.draw_rectangle_rounded_lines_ex(rect, 0.35, 8, 2.0, rl_color(GREEN))
        self._draw_text(label, EGPU_STATUS_CENTER_X, TOP_STATUS_CENTER_Y + 1.0,
                        EGPU_STATUS_FONT_SIZE, GREEN, anchor="center")

    def _draw_drive_status_box(
        self,
        text: str,
        center_x: float,
        center_y: float,
        box_size: float,
        font_size: float,
        text_color: tuple[int, int, int],
    ) -> None:
        box_x = center_x - box_size * 0.5
        box_y = center_y - box_size * 0.5
        rect = rl.Rectangle(box_x, box_y, box_size, box_size)
        roundness = max(0.0, min(1.0, DRIVE_STATUS_BOX_RADIUS / max(1.0, box_size)))
        rl.draw_rectangle_rounded_lines_ex(rect, roundness, 12, GEAR_STATUS_OUTLINE_WIDTH, rl_color(text_color))
        self._draw_text(
            text,
            center_x,
            center_y + 1,
            font_size,
            text_color,
            anchor="center",
        )

    def _draw_follow_gap_status(self, state: ClusterUiState, bottom_y: float) -> None:
        x = FOLLOW_STATUS_CENTER_X - FOLLOW_STATUS_W * 0.5

        gap_count = 0 if state.cruise_gap is None else int(clamp(float(state.cruise_gap), 1.0, float(FOLLOW_STATUS_GAP_BARS)))
        bar_w = FOLLOW_GAP_BAR_W * FOLLOW_GAP_BAR_SCALE
        bar_h = FOLLOW_GAP_BAR_H * FOLLOW_GAP_BAR_SCALE * 2.0
        bar_r = FOLLOW_GAP_BAR_R * FOLLOW_GAP_BAR_SCALE
        bar_step = FOLLOW_GAP_BAR_STEP_X * FOLLOW_GAP_BAR_SCALE
        bars_total_w = bar_w + bar_step * (FOLLOW_STATUS_GAP_BARS - 1)
        icon_x = x + FOLLOW_STATUS_W - FOLLOW_GAP_ICON_W
        icon_y = bottom_y - FOLLOW_GAP_ICON_H
        bar_x = icon_x - bars_total_w - 3.0
        bar_y = bottom_y - bar_h
        for index in range(FOLLOW_STATUS_GAP_BARS):
            active = index >= FOLLOW_STATUS_GAP_BARS - gap_count
            self._rounded_rect(
                bar_x + index * bar_step,
                bar_y,
                bar_w,
                bar_h,
                bar_r,
                FOLLOW_GAP_ACTIVE if active else FOLLOW_GAP_INACTIVE,
                None,
                0.0,
            )

        self._draw_follow_vehicle_icon(icon_x, icon_y)

    def _draw_network_status(self, state: ClusterUiState, bottom_y: float) -> None:
        theme = self._current_theme()
        tint = WHITE if state.network_connected else theme.muted
        alpha = 255 if state.network_connected else 130
        self._draw_outlined_bottom_aligned_texture_icon(
            self._wifi_texture,
            WIFI_STATUS_CENTER_X,
            bottom_y,
            WIFI_STATUS_ICON_SIZE,
            WIFI_STATUS_ICON_SIZE,
            tint,
            alpha,
        )

    def _draw_follow_vehicle_icon(self, x: float, y: float) -> None:
        texture = self._follow_vehicle_texture
        if texture is None:
            theme = self._current_theme()
            car_x = x + FOLLOW_GAP_ICON_W * 0.5
            car_y = y + FOLLOW_GAP_ICON_H * 0.5
            self._rounded_rect(car_x - 16, car_y - 8, 32, 16, 5.0, theme.muted, None, 0.0)
            self._rounded_rect(car_x - 7, car_y - 14, 15, 8, 4.0, theme.muted, None, 0.0)
            return

        source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
        dest = rl.Rectangle(x, y, FOLLOW_GAP_ICON_W, FOLLOW_GAP_ICON_H)
        rl.draw_texture_pro(texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))

    def _draw_bottom_aligned_texture_icon(
        self,
        texture,
        center_x: float,
        bottom_y: float,
        width: float,
        height: float,
        tint: tuple[int, int, int] | tuple[int, int, int, int],
        alpha: int | None = None,
        rotation_deg: float = 0.0,
    ) -> bool:
        if texture is None:
            return False
        source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
        dest = rl.Rectangle(center_x, bottom_y - height * 0.5, width, height)
        origin = rl.Vector2(width * 0.5, height * 0.5)
        rl.draw_texture_pro(texture, source, dest, origin, rotation_deg, rl_color(tint, alpha))
        return True

    def _draw_outlined_bottom_aligned_texture_icon(
        self,
        texture,
        center_x: float,
        bottom_y: float,
        width: float,
        height: float,
        tint: tuple[int, int, int] | tuple[int, int, int, int],
        alpha: int,
        rotation_deg: float = 0.0,
    ) -> bool:
        if texture is None:
            return False
        outline_offset = 2.0
        outline_alpha = max(150, min(245, alpha))
        for dx, dy in (
            (-outline_offset, 0.0),
            (outline_offset, 0.0),
            (0.0, -outline_offset),
            (0.0, outline_offset),
            (-outline_offset, -outline_offset),
            (outline_offset, -outline_offset),
            (-outline_offset, outline_offset),
            (outline_offset, outline_offset),
        ):
            self._draw_bottom_aligned_texture_icon(
                texture,
                center_x + dx,
                bottom_y + dy,
                width,
                height,
                (5, 9, 12),
                outline_alpha,
                rotation_deg,
            )
        return self._draw_bottom_aligned_texture_icon(
            texture,
            center_x,
            bottom_y,
            width,
            height,
            tint,
            alpha,
            rotation_deg,
        )

    def _draw_lfa_status_icon(self, state: ClusterUiState, bottom_y: float) -> None:
        if self._carrot_wheel_hidden(state):
            return  # 보노보노 11:48 "당근스티어링은 빼자": on the C1 meter screen only the clam shows steering
        theme = self._current_theme()
        active = bool(state.lfa_active)
        texture = self._lfa_active_texture if active and self._lfa_active_texture is not None else self._lfa_texture
        tint = WHITE if active else theme.muted
        alpha = 255 if active else 190
        rotation_deg = -float(state.steering_angle_deg or 0.0)
        drew_wheel = self._draw_bottom_aligned_texture_icon(
            texture,
            LFA_STATUS_CENTER_X,
            bottom_y,
            LFA_STATUS_ICON_SIZE,
            LFA_STATUS_ICON_SIZE,
            tint,
            alpha,
            rotation_deg,
        )
        if state.active_lane_line:
            self._draw_bottom_aligned_texture_icon(
                self._lfa_lane_texture,
                LFA_STATUS_CENTER_X,
                bottom_y - LFA_LANE_ICON_TOP_OFFSET,
                LFA_STATUS_ICON_SIZE * LFA_LANE_ICON_WIDTH_SCALE,
                LFA_STATUS_ICON_SIZE,
                GREEN if active else theme.muted,
                alpha,
            )
        if drew_wheel:
            return

        outline = GREEN if active else theme.muted
        fill_alpha = 46 if active else 26
        center = rl.Vector2(LFA_STATUS_CENTER_X, bottom_y - LFA_STATUS_ICON_SIZE * 0.5)
        scale = TOP_ICON_SIZE / 34.0
        rl.draw_circle_v(center, TOP_ICON_SIZE * 0.5, rl_color(outline, fill_alpha))
        rl.draw_circle_lines(int(center.x), int(center.y), TOP_ICON_SIZE * 0.5, rl_color(outline, 210))
        rl.draw_circle_lines(int(center.x), int(center.y + 1), TOP_ICON_SIZE * 0.26, rl_color(outline, 210))
        rl.draw_line_ex(
            rl.Vector2(center.x - 7 * scale, center.y + 5 * scale),
            rl.Vector2(center.x + 7 * scale, center.y + 5 * scale),
            2.2 * scale,
            rl_color(outline, 210),
        )
        rl.draw_line_ex(
            rl.Vector2(center.x, center.y + 5 * scale),
            rl.Vector2(center.x, center.y + 12 * scale),
            2.2 * scale,
            rl_color(outline, 210),
        )

    def _draw_speed_block(self, state: ClusterUiState, *, tpms_offset_x: float = 0.0) -> None:
        theme = self._current_theme()
        display_speed_kph = state.display_speed_kph if state.display_speed_kph is not None else state.speed_kph
        speed_value = int(round(display_speed(clamp(display_speed_kph, 0.0, MAX_SPEED_KPH), self.is_metric)))
        speed_text = str(speed_value)
        speed_font_size = SPEED_VALUE_FONT_SIZE if len(speed_text) <= 2 else SPEED_VALUE_FONT_SIZE * 0.86
        if clean_ui_enabled():
            self._draw_clean_speed(state, speed_value, theme)  # EV6 HUD patch v6
            if tpms_offset_x:
                rl.rl_push_matrix()
                rl.rl_translatef(tpms_offset_x, 0.0, 0.0)
            try:
                self._draw_tpms_status(state)
            finally:
                if tpms_offset_x:
                    rl.rl_pop_matrix()
            return
        self._draw_speed_panel_bg()
        self._draw_text_with_stroke(
            speed_text,
            SPEED_VALUE_CENTER_X,
            SPEED_VALUE_CENTER_Y,
            speed_font_size,
            WHITE,
            (0, 0, 0),
            3,
            anchor="center",
        )

        cruise_color = self._cruise_set_color(state, theme)
        cruise_text = self._cruise_set_speed_text(state)
        self._draw_text_with_stroke(
            cruise_text,
            CRUISE_SET_SPEED_CENTER_X,
            CRUISE_SPEED_CENTER_Y,
            CRUISE_SET_SPEED_FONT_SIZE,
            cruise_color,
            (0, 0, 0),
            2,
            anchor="center",
        )
        self._draw_driving_mode_indicator(state)
        self._draw_model_traffic_state(state.traffic_state)
        self._draw_cruise_gap_badge(state.cruise_gap)
        self._draw_speed_gear_badge(state)
        self._draw_ev_mode_indicator(state)
        tpms_translated = abs(tpms_offset_x) > 0.001
        if tpms_translated:
            rl.rl_push_matrix()
            rl.rl_translatef(tpms_offset_x, 0.0, 0.0)
        try:
            self._draw_tpms_status(state)
            self._draw_lat_values(state)
            self._draw_lane_values(state)
        finally:
            if tpms_translated:
                rl.rl_pop_matrix()

        if self._cruise_set_visible(state) and state.cruise_override_kph is not None:
            override_color = (
                GREEN
                if state.cruise_override_color_mode == 1
                else AMBER
                if state.cruise_override_color_mode == 4
                else VEHICLE_NAVI
                if state.cruise_override_color_mode == 3
                else CRUISE_OVERRIDE_APPLY_COLOR
                if state.cruise_override_color_mode == 2
                else theme.text
            )
            override_text = str(int(round(display_speed(state.cruise_override_kph, self.is_metric))))
            override_label = state.cruise_override_label or ""
            override_label_font_size = CRUISE_OVERRIDE_LABEL_FONT_SIZE * min(
                1.0,
                8.0 / max(8, len(override_label)),
            )
            self._draw_text_with_stroke(
                override_label,
                CRUISE_OVERRIDE_SPEED_CENTER_X,
                CRUISE_OVERRIDE_LABEL_CENTER_Y,
                override_label_font_size,
                override_color,
                (0, 0, 0),
                2,
                anchor="center",
            )
            self._draw_text_with_stroke(
                override_text,
                CRUISE_OVERRIDE_SPEED_CENTER_X,
                CRUISE_OVERRIDE_SPEED_CENTER_Y,
                CRUISE_OVERRIDE_SPEED_FONT_SIZE,
                override_color,
                (0, 0, 0),
                2,
                anchor="center",
            )

        if state.speed_limit_kph is not None or state.navi_debug is not None:
            center = rl.Vector2(SPEED_LIMIT_SIGN_CENTER_X, SPEED_LIMIT_SIGN_CENTER_Y)
            rl.draw_circle_v(center, SPEED_LIMIT_SIGN_RADIUS, rl_color(RED))
            rl.draw_circle_v(center, SPEED_LIMIT_SIGN_RADIUS - SPEED_LIMIT_SIGN_RING_WIDTH, rl_color(WHITE))
            limit_text = (
                "--"
                if state.speed_limit_kph is None
                else str(int(round(display_speed(state.speed_limit_kph, self.is_metric))))
            )
            limit_font_size = 42 if len(limit_text) <= 2 else 36
            self._draw_text(
                limit_text,
                SPEED_LIMIT_SIGN_CENTER_X,
                SPEED_LIMIT_SIGN_CENTER_Y,
                limit_font_size,
                TEXT,
                anchor="center",
            )

    # ---- EV6 HUD patch v6: clean layout -------------------------------------------------
    def _clean_text_colors(self, theme):
        if theme.is_dark:
            return WHITE, (0, 0, 0), (150, 160, 172)
        return (26, 30, 36), (246, 247, 249), (92, 100, 110)

    def _draw_clean_speed(self, state: ClusterUiState, speed_value: int, theme) -> None:
        text_color, stroke, muted = self._clean_text_colors(theme)
        limit_value = None
        if state.speed_limit_kph is not None:
            limit_value = int(round(display_speed(state.speed_limit_kph, self.is_metric)))
            center = rl.Vector2(82.0, 128.0)
            rl.draw_circle_v(center, 38.0, rl_color(RED))
            rl.draw_circle_v(center, 32.0, rl_color(WHITE))
            limit_text = str(limit_value)
            self._draw_text(limit_text, 82.0, 129.0, 38.0 if len(limit_text) <= 2 else 31.0, (20, 22, 26), anchor="center")
        if self._cruise_set_visible(state):
            color = self._cruise_set_color(state, theme)
            x, y, w, h = 140.0, 102.0, 156.0, 52.0
            fill = (0, 0, 0, 110) if theme.is_dark else (255, 255, 255, 200)
            self._rounded_rect(x, y, w, h, h * 0.5, fill, (*color[:3], 160), 2.0)
            self._draw_text("SET", x + 22.0, y + h * 0.5, 18, muted, anchor="left")
            self._draw_text_with_stroke(self._cruise_set_speed_text(state), x + w - 22.0, y + h * 0.5, 34, color,
                                        stroke, 2, anchor="right")
        chip_x = self._draw_clean_slowdown_badge(state, theme) or 140.0
        self._draw_clean_safety_chip(state, theme, chip_x)  # EV6 HUD patch v7
        if state.traffic_state in (1, 2):
            texture = self._traffic_red_texture if state.traffic_state == 1 else self._traffic_green_texture
            if texture is not None:
                size = 44.0
                source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
                dest = rl.Rectangle(338.0 - size * 0.5, 128.0 - size * 0.5, size, size)
                rl.draw_texture_pro(texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))
        self._ev6_draw_signal_assist_chip(theme)  # EV6 HUD patch v22
        speed_color = text_color
        if limit_value is not None and limit_value > 0 and speed_value > limit_value:
            speed_color = RED if speed_value >= limit_value + display_speed(CLEAN_SPEED_OVER_RED_KPH, self.is_metric) else AMBER
        self._draw_text_with_stroke(str(speed_value), 175.0, 300.0, 160, speed_color, stroke, 3, anchor="center")
        self._draw_text("km/h" if self.is_metric else "mph", 175.0, 384.0, 24, muted, anchor="center")

    def _ev6_draw_signal_assist_chip(self, theme) -> None:
        # EV6 HUD patch v22: what the signal assist (SignalAssistMode 1/2) currently sees, as a two-lamp signal head:
        # red lamp lit = red seen, green lamp lit = green seen, both = both; dimmed while it holds a previous reading.
        # Nothing is drawn while the mode is 0 or nothing is recognised.
        try:
            from openpilot.selfdrive.carrot.signal_display import display_requested, signal_display_status

            if not display_requested():
                return
            color, held, _ = signal_display_status()
        except Exception:
            return
        if color not in (1, 2, 3):
            return
        x, y, w, h = 372.0, 106.0, 86.0, 44.0
        fill = (0, 0, 0, 150) if theme.is_dark else (255, 255, 255, 215)
        edge = (90, 98, 108, 200) if theme.is_dark else (170, 176, 184, 220)
        self._rounded_rect(x, y, w, h, h * 0.5, fill, edge, 2.0)
        lamp_off = (58, 62, 68) if theme.is_dark else (210, 213, 218)
        for i, (bit, lit) in enumerate(((1, (255, 70, 70)), (2, (60, 230, 120)))):
            cx, cy = x + 25.0 + i * 36.0, y + h * 0.5
            on = bool(color & bit)
            lamp = tuple(int(c * 0.45) for c in lit) if on and held else lit if on else lamp_off
            rl.draw_circle_v(rl.Vector2(cx, cy), 13.0, rl_color(lamp))
            if on and not held:
                rl.draw_circle_lines(int(cx), int(cy), 16.0, rl_color((*lit, 120)))

    def _draw_clean_slowdown_badge(self, state: ClusterUiState, theme) -> float | None:
        # why openpilot is slowing down (carrotMan desiredSource) or a planned stop
        _, stroke, muted = self._clean_text_colors(theme)
        label = None
        value = None
        color = AMBER
        if self._cruise_set_visible(state) and state.cruise_override_kph is not None:
            source = (state.cruise_override_label or "").strip().lower()
            label = CLEAN_SLOWDOWN_LABELS_KO.get(source, source[:6]) if self.language == CLUSTER_LANGUAGE_KO else source[:8]
            value = str(int(round(display_speed(state.cruise_override_kph, self.is_metric))))
            color = GREEN if state.cruise_override_color_mode == 1 else (196, 160, 255) if state.cruise_override_color_mode == 3 else AMBER
        elif state.longitudinal_plan_should_stop and state.speed_kph > 3.0:
            label = "정지 예정" if self.language == CLUSTER_LANGUAGE_KO else "STOP"
        if not label:
            return
        x, y, h = 140.0, 168.0, 40.0
        label_w, _ = self._measure_text(label, 18, 1.0)
        value_w = 0.0 if value is None else self._measure_text(value, 26, 1.0)[0] + 12.0
        w = max(96.0, label_w + value_w + 32.0)
        fill = (0, 0, 0, 110) if theme.is_dark else (255, 255, 255, 200)
        self._rounded_rect(x, y, w, h, h * 0.5, fill, (*color[:3], 170), 2.0)
        self._draw_text(label, x + 16.0, y + h * 0.5, 18, color, anchor="left")
        if value is not None:
            self._draw_text_with_stroke(value, x + w - 16.0, y + h * 0.5, 26, color, stroke, 2, anchor="right")
        return x + w + 10.0

    @staticmethod
    def _clean_distance_text(distance_m: float) -> str:
        if distance_m >= 10000:
            return f"{distance_m / 1000.0:.0f} km"
        if distance_m >= 1000:
            return f"{distance_m / 1000.0:.1f} km"
        return f"{int(round(distance_m / 10.0) * 10)} m"

    def _draw_clean_progress(self, x: float, y: float, w: float, progress: float, color, muted) -> None:
        self._rounded_rect(x, y, w, 3.0, 1.5, (*muted[:3], 70))
        if progress > 0.01:
            self._rounded_rect(x, y, w * min(1.0, progress), 3.0, 1.5, (*color[:3], 230))

    def _draw_clean_safety_chip(self, state: ClusterUiState, theme, x: float) -> None:
        # EV6 HUD patch v7: speed camera distance, otherwise section control remaining distance + average speed
        navi = state.navi_live
        speed = navi.speed if navi is not None else None
        if speed is None:
            return
        text_color, stroke, muted = self._clean_text_colors(theme)
        sub = None
        camera_m = speed.sdi_distance_m
        if camera_m is not None and 0 < camera_m <= CLEAN_CAMERA_SHOW_M and (speed.sdi_speed_limit_kph or 0) > 0:
            over = state.speed_kph - speed.sdi_speed_limit_kph
            label = "카메라" if self.language == CLUSTER_LANGUAGE_KO else "CAM"
            value = self._clean_distance_text(camera_m)
            color = RED if over >= CLEAN_SPEED_OVER_RED_KPH else AMBER if over > 0 else BLUE
            progress = 1.0 - camera_m / CLEAN_CAMERA_SHOW_M
        elif speed.section_active and (speed.section_remaining_distance_m or 0) > 0:
            limit = speed.section_speed_limit_kph or 0
            average = speed.section_average_kph or 0.0
            label = "구간" if self.language == CLUSTER_LANGUAGE_KO else "SECTION"
            value = self._clean_distance_text(speed.section_remaining_distance_m)
            if average > 0.0:
                sub = f"평균 {average:.0f}" if self.language == CLUSTER_LANGUAGE_KO else f"avg {average:.0f}"
            color = RED if limit and average >= limit + CLEAN_SPEED_OVER_RED_KPH else AMBER if limit and average > limit else None
            progress = speed.section_progress or 0.0
        else:
            return
        y, h = 168.0, 40.0
        label_w, _ = self._measure_text(label, 18, 1.0)
        value_w, _ = self._measure_text(value, 24, 1.0)
        sub_w = self._measure_text(sub, 20, 1.0)[0] + 22.0 if sub else 0.0
        w = 42.0 + label_w + value_w + sub_w + 16.0
        edge = muted if color is None else color
        fill = (0, 0, 0, 110) if theme.is_dark else (255, 255, 255, 200)
        self._rounded_rect(x, y, w, h, h * 0.5, fill, (*edge[:3], 170), 2.0)
        self._draw_text(label, x + 16.0, y + h * 0.5, 18, muted, anchor="left")
        self._draw_text_with_stroke(value, x + 26.0 + label_w, y + h * 0.5, 24, text_color, stroke, 2, anchor="left")
        if sub:
            sx = x + 36.0 + label_w + value_w
            rl.draw_line_ex(rl.Vector2(sx, y + 11.0), rl.Vector2(sx, y + h - 11.0), 1.5, rl_color(muted, 140))
            self._draw_text_with_stroke(sub, sx + 12.0, y + h * 0.5, 20, text_color if color is None else color,
                                        stroke, 2, anchor="left")
        self._draw_clean_progress(x + 18.0, y + h - 5.0, w - 36.0, progress, edge, muted)

    def _draw_clean_bar(self, center_x: float, value: float, color, value_text: str, label: str) -> None:
        theme = self._current_theme()
        _, stroke, muted = self._clean_text_colors(theme)
        top, bottom, width = SIDE_GAUGE_TOP + 4.0, SIDE_GAUGE_BOTTOM - 4.0, 14.0
        mid = (top + bottom) * 0.5
        track = (255, 255, 255, 34) if theme.is_dark else (0, 0, 0, 30)
        self._rounded_rect(center_x - width * 0.5, top, width, bottom - top, width * 0.5, track)
        rl.draw_line_ex(rl.Vector2(center_x - 13.0, mid), rl.Vector2(center_x + 13.0, mid), 2.0, rl_color(muted))
        span = abs(clamp(value, -1.0, 1.0)) * (mid - top)
        if span >= 1.0:
            y = mid - span if value > 0.0 else mid
            self._rounded_rect(center_x - width * 0.5, y, width, span, width * 0.5, color)
        active = span >= 1.0
        self._draw_text_with_stroke(value_text, center_x, SIDE_GAUGE_VALUE_Y + 4.0, 18, color if active else muted,
                                    stroke, 2, anchor="center")
        self._draw_text(label, center_x, bottom + 20.0, 16, muted, anchor="center")

    def _draw_clean_side_gauges(self, state: ClusterUiState) -> None:
        theme = self._current_theme()
        ko = self.language == CLUSTER_LANGUAGE_KO
        accel = 0.0 if abs(state.accel_mps2) < 0.005 else state.accel_mps2
        accel_color = GREEN if accel > 0 else RED if accel < 0 else theme.muted
        self._draw_clean_bar(SIDE_GAUGE_LEFT_CENTER_X, accel / MAX_ACCEL_MPS2, accel_color, f"{accel:+.2f}",
                             "가속" if ko else "ACCEL")
        if (
            state.steering_output is not None
            and state.steering_output_normalized is not None
            and state.steering_output_kind is not None
        ):
            value = float(state.steering_output)
            normalized = clamp(float(state.steering_output_normalized), -1.0, 1.0)
            if state.steering_output_kind == "angle":
                value_text = f"{value:+.0f}%"
            else:
                value_text = f"{normalized * 100.0:+.0f}%" if abs(value) > 999.0 else f"{value:+.0f}"
            color = BLUE if normalized > 0 else AMBER if normalized < 0 else theme.muted
            self._draw_clean_bar(SIDE_GAUGE_LEFT_CENTER_X + SIDE_GAUGE_COLUMN_GAP, normalized, color, value_text,
                                 "조향" if ko else "STEER")

    def _draw_clean_tpms(self, state: ClusterUiState) -> None:
        tpms = state.tpms
        pressures = (tpms.fl, tpms.fr, tpms.rl, tpms.rr)
        if not any(value is not None for value in pressures):
            return
        theme = self._current_theme()
        text_color, stroke, muted = self._clean_text_colors(theme)
        cx, cy = TPMS_STATUS_CENTER_X, TPMS_STATUS_CAR_CENTER_Y
        body_w, body_h = 26.0, 52.0
        outline = (*muted[:3], 230)
        self._rounded_rect(cx - body_w * 0.5, cy - body_h * 0.5, body_w, body_h, 9.0, (0, 0, 0, 0), outline, 2.0)
        rl.draw_line_ex(rl.Vector2(cx - body_w * 0.5 + 4.0, cy - 9.0), rl.Vector2(cx + body_w * 0.5 - 4.0, cy - 9.0),
                        2.0, rl_color(outline))
        for index, pressure in enumerate(pressures):
            sx = -1.0 if index in (0, 2) else 1.0
            sy = -1.0 if index in (0, 1) else 1.0
            wheel_x = cx + sx * (body_w * 0.5 + 3.0)
            wheel_y = cy + sy * 15.0
            low = pressure is not None and pressure < TPMS_LOW_PRESSURE_PSI
            wheel_color = RED if low else outline
            rl.draw_line_ex(rl.Vector2(wheel_x, wheel_y - 7.0), rl.Vector2(wheel_x, wheel_y + 7.0), 4.0, rl_color(wheel_color))
            value_text = "--" if pressure is None else f"{pressure:.0f}"
            value_color = RED if low else (text_color if pressure is not None else muted)
            self._draw_text_with_stroke(value_text, cx + sx * 44.0, wheel_y, 19, value_color, stroke, 2, anchor="center")

    def _draw_driving_mode_indicator(self, state: ClusterUiState) -> None:
        style = SPEED_DRIVING_MODE_STYLES.get(state.driving_mode)
        if style is None:
            return
        text_key, color = style
        text = self._text(text_key)
        font_size = SPEED_DRIVING_MODE_FONT_SIZE if self.language == CLUSTER_LANGUAGE_KO else 22.0
        self._draw_text_with_stroke(
            text,
            SPEED_DRIVING_MODE_CENTER_X,
            SPEED_DRIVING_MODE_CENTER_Y,
            font_size,
            color,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

    def _draw_model_traffic_state(self, traffic_state: int) -> None:
        from openpilot.selfdrive.carrot.signal_display import signal_display_status, display_requested
        if display_requested():
            color, held, _ = signal_display_status()
            rgb = ((160, 165, 170), (255, 75, 75), (60, 255, 120), (255, 185, 40))[color]
            if held:
                rgb = tuple(int(c*.55) for c in rgb)
            for offset in (2, 3, 4):
                rl.draw_circle_lines(int(SPEED_MODEL_TRAFFIC_CENTER_X), int(SPEED_MODEL_TRAFFIC_CENTER_Y),
                                     SPEED_MODEL_TRAFFIC_ICON_SIZE*.5+offset, rl_color(rgb))
        if traffic_state not in (1, 2):
            return
        red_light = traffic_state == 1
        texture = self._traffic_red_texture if red_light else self._traffic_green_texture
        if texture is None:
            return
        size = SPEED_MODEL_TRAFFIC_ICON_SIZE
        source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
        destination = rl.Rectangle(
            SPEED_MODEL_TRAFFIC_CENTER_X - size * 0.5,
            SPEED_MODEL_TRAFFIC_CENTER_Y - size * 0.5,
            size,
            size,
        )
        rl.draw_texture_pro(texture, source, destination, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE))

    def _draw_cruise_gap_badge(self, cruise_gap: int | None) -> None:
        if cruise_gap is None:
            return
        gap = int(clamp(float(cruise_gap), 1.0, 4.0))
        self._draw_text_with_stroke(
            str(gap),
            SPEED_GAP_CENTER_X,
            SPEED_GAP_CENTER_Y,
            SPEED_GAP_FONT_SIZE,
            WHITE,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

    def _draw_speed_gear_badge(self, state: ClusterUiState) -> None:
        gear = (state.gear_text or "").strip().upper()[:2]
        if not gear:
            return
        theme = self._current_theme()
        color = RED if state.brake_lights else WHITE if gear != "U" else theme.muted
        outline = color if cluster_camera_view_is_road_camera(state.camera_view_mode) else (5, 9, 12, 245)
        rect = rl.Rectangle(
            SPEED_GEAR_CENTER_X - SPEED_GEAR_W * 0.5,
            SPEED_GEAR_CENTER_Y - SPEED_GEAR_H * 0.5,
            SPEED_GEAR_W,
            SPEED_GEAR_H,
        )
        self._rounded_rect(rect.x, rect.y, rect.width, rect.height, 8.0, (0, 0, 0, 0), outline, 3.0)
        self._draw_text_with_stroke(
            gear,
            SPEED_GEAR_CENTER_X,
            SPEED_GEAR_CENTER_Y,
            SPEED_GEAR_FONT_SIZE,
            color,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

    def _draw_ev_mode_indicator(
        self,
        state: ClusterUiState,
        center_x: float = SPEED_EV_CENTER_X,
        center_y: float = SPEED_EV_CENTER_Y,
        font_size: float = SPEED_EV_FONT_SIZE,
    ) -> None:
        if not (state.ev_mode_valid and state.ev_mode_active):
            return
        self._draw_text_with_stroke(
            "EV",
            center_x,
            center_y,
            font_size,
            GREEN,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

    def _draw_speed_panel_bg(self) -> None:
        texture = self._speed_bg_texture
        if texture is None:
            return
        source = rl.Rectangle(0.0, 0.0, float(texture.width), float(texture.height))
        dest = rl.Rectangle(SPEED_PANEL_X, SPEED_PANEL_Y, SPEED_PANEL_W, SPEED_PANEL_H)
        rl.draw_texture_pro(texture, source, dest, rl.Vector2(0.0, 0.0), 0.0, rl_color(WHITE, 235))

    @staticmethod
    def _cruise_set_visible(state: ClusterUiState) -> bool:
        return state.cruise_kph is not None and state.cruise_display_state != "off"

    def _cruise_set_speed_text(self, state: ClusterUiState) -> str:
        if state.cruise_display_state == "off" or state.cruise_kph is None:
            return "--"
        return str(int(round(display_speed(state.cruise_kph, self.is_metric))))

    @staticmethod
    def _cruise_set_color(state: ClusterUiState, theme: ClusterTheme) -> tuple[int, int, int]:
        if state.cruise_display_state == "off" or state.cruise_kph is None:
            return theme.muted
        if state.cruise_display_state == "paused":
            return theme.muted
        return GREEN

    def _draw_accel_block(self, state: ClusterUiState) -> None:
        if clean_ui_enabled():
            self._draw_clean_side_gauges(state)  # EV6 HUD patch v6
            return
        theme = self._current_theme()
        top = SIDE_GAUGE_TOP
        bottom = SIDE_GAUGE_BOTTOM
        center = (top + bottom) // 2
        gauge_width = SIDE_GAUGE_WIDTH
        accel_value = 0.0 if abs(state.accel_mps2) < 0.005 else state.accel_mps2
        accel_text = f"{accel_value:+05.2f}"
        accel_text_size = 17
        gauge_center_x = SIDE_GAUGE_LEFT_CENTER_X
        gauge_x = gauge_center_x - gauge_width * 0.5
        fill_x = gauge_x + 8
        fill_width = gauge_width - 16
        outline = self._side_gauge_outline(state)
        self._rounded_rect(gauge_x, top, gauge_width, bottom - top, 18, (0, 0, 0, 0), outline, 2)
        rl.draw_line_ex(
            rl.Vector2(gauge_x, center),
            rl.Vector2(gauge_x + gauge_width, center),
            3,
            rl_color(theme.gauge_midline),
        )
        value = clamp(state.accel_mps2, -MAX_ACCEL_MPS2, MAX_ACCEL_MPS2)
        fill_color = GREEN if value > 0 else RED if value < 0 else theme.muted
        if value != 0.0:
            fill_height = int(abs(value) / MAX_ACCEL_MPS2 * ((bottom - top) / 2 - 8))
            if value > 0:
                self._rounded_rect(fill_x, center - fill_height, fill_width, fill_height, 13, fill_color)
            else:
                self._rounded_rect(fill_x, center, fill_width, fill_height, 13, fill_color)
        self._draw_text_with_stroke(
            accel_text,
            gauge_center_x,
            SIDE_GAUGE_VALUE_Y,
            accel_text_size,
            fill_color,
            (5, 9, 12),
            2,
            anchor="center",
            cache=False,
        )
        self._draw_text_with_stroke(
            "accel",
            gauge_center_x,
            bottom + SIDE_GAUGE_LABEL_OFFSET,
            17,
            WHITE,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

        energy_value = state.fuel_gauge
        # K9 (대감님 11/12 05:10): no green fuel bar on the driving screen; the K9 fuel level stays on the P screen only.
        if ego_model_name(getattr(state, "car_fingerprint", "")) == "k9":
            energy_value = None
        if energy_value is not None:
            self._draw_level_gauge(
                gauge_center_x,
                SIDE_GAUGE_LOWER_TOP,
                SIDE_GAUGE_LOWER_BOTTOM,
                gauge_width,
                clamp(energy_value, 0.0, 1.0),
                state.energy_gauge_label,
                GREEN if energy_value > 0.15 else RED,
                outline,
            )

    def _draw_steering_output_block(self, state: ClusterUiState) -> None:
        if clean_ui_enabled():
            return  # EV6 HUD patch v6: drawn by _draw_clean_side_gauges
        theme = self._current_theme()
        gauge_center_x = SIDE_GAUGE_LEFT_CENTER_X + SIDE_GAUGE_COLUMN_GAP
        top = SIDE_GAUGE_TOP
        bottom = SIDE_GAUGE_BOTTOM
        gauge_width = SIDE_GAUGE_WIDTH
        outline = self._side_gauge_outline(state)
        if (
            state.steering_output is not None
            and state.steering_output_normalized is not None
            and state.steering_output_kind is not None
        ):
            value = float(state.steering_output)
            output_kind = state.steering_output_kind
            normalized = clamp(float(state.steering_output_normalized), -1.0, 1.0)
            if output_kind == "angle":
                value_text = f"{value:+.0f}%"
            else:
                value_text = f"{normalized * 100.0:+.0f}%" if abs(value) > 999.0 else f"{value:+.0f}"
            color = BLUE if normalized > 0 else AMBER if normalized < 0 else theme.muted
            self._draw_bipolar_gauge(gauge_center_x, top, bottom, gauge_width, normalized, color, outline)
            self._draw_text_with_stroke(
                value_text,
                gauge_center_x,
                SIDE_GAUGE_VALUE_Y,
                17,
                color,
                (5, 9, 12),
                2,
                anchor="center",
                cache=False,
            )
            self._draw_text_with_stroke(
                "steer",
                gauge_center_x,
                bottom + SIDE_GAUGE_LABEL_OFFSET,
                17,
                WHITE,
                (5, 9, 12),
                2,
                anchor="center",
                cache=True,
            )

        urea_value = state.urea_gauge
        if urea_value is not None:
            self._draw_level_gauge(
                gauge_center_x,
                SIDE_GAUGE_LOWER_TOP,
                SIDE_GAUGE_LOWER_BOTTOM,
                gauge_width,
                clamp(urea_value, 0.0, 1.0),
                "DEF",
                AMBER if urea_value <= 0.15 else BLUE,
                outline,
            )

    def _side_gauge_outline(self, state: ClusterUiState) -> tuple[int, int, int, int]:
        if self._current_theme().is_dark or cluster_camera_view_is_road_camera(state.camera_view_mode):
            return SIDE_GAUGE_OUTLINE
        return (5, 9, 12, 235)

    def _draw_bipolar_gauge(
        self,
        center_x: float,
        top: float,
        bottom: float,
        width: float,
        value: float,
        color: tuple[int, int, int],
        outline: tuple[int, int, int, int],
    ) -> None:
        theme = self._current_theme()
        center_y = (top + bottom) * 0.5
        gauge_x = center_x - width * 0.5
        fill_x = gauge_x + 8
        fill_width = width - 16
        self._rounded_rect(gauge_x, top, width, bottom - top, 18, (0, 0, 0, 0), outline, 2)
        rl.draw_line_ex(rl.Vector2(gauge_x, center_y), rl.Vector2(gauge_x + width, center_y), 3, rl_color(theme.gauge_midline))
        fill_height = abs(value) * ((bottom - top) * 0.5 - 8)
        if fill_height <= 0.0:
            return
        fill_y = center_y - fill_height if value > 0.0 else center_y
        self._rounded_rect(fill_x, fill_y, fill_width, fill_height, 13, color)

    def _draw_level_gauge(
        self,
        center_x: float,
        top: float,
        bottom: float,
        width: float,
        value: float,
        label: str,
        color: tuple[int, int, int],
        outline: tuple[int, int, int, int],
    ) -> None:
        gauge_x = center_x - width * 0.5
        self._rounded_rect(gauge_x, top, width, bottom - top, 18, (0, 0, 0, 0), outline, 2)
        fill_height = value * (bottom - top - 16)
        if fill_height > 0.0:
            self._rounded_rect(gauge_x + 8, bottom - 8 - fill_height, width - 16, fill_height, 13, color)
        self._draw_text_with_stroke(
            f"{value * 100:.0f}%", center_x, top - 16, 17, color, (5, 9, 12), 2, anchor="center"
        )
        self._draw_text_with_stroke(
            label,
            center_x,
            bottom + SIDE_GAUGE_LABEL_OFFSET,
            17,
            WHITE,
            (5, 9, 12),
            2,
            anchor="center",
            cache=True,
        )

    def _turn_signal_lights(self, state: ClusterUiState) -> tuple[bool, bool]:
        now = time.perf_counter()
        if state.left_signal and state.right_signal:
            if self._hazard_signal_started_at is None:
                self._hazard_signal_started_at = now
                self._left_turn_signal_started_at = None
                self._right_turn_signal_started_at = None
            lit = blink_visible(now, self._hazard_signal_started_at, float("inf"))
            return lit, lit

        self._hazard_signal_started_at = None
        return (
            self._turn_signal_lit("left", state.left_signal, now),
            self._turn_signal_lit("right", state.right_signal, now),
        )

    def _highlight_lane_lit(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> bool:
        lit = self._highlight_lane_blink_lit(state, signal_lights)
        # Default HUD (same scope as the lane-confidence labels): the lane highlight
        # beside the car stays steady. Blinker arrows and other modes still blink;
        # the strip is still only built while highlight_lane_offset is present.
        if self._lane_confidence_visible(state):
            return True
        return lit

    def _highlight_lane_blink_lit(self, state: ClusterUiState, signal_lights: tuple[bool, bool]) -> bool:
        left_signal_lit, right_signal_lit = signal_lights
        side = state.highlight_lane if state.highlight_lane in ("left", "right") else None
        if side is not None and state.highlight_lane_offset is not None:
            now = time.perf_counter()
            if side != self._lane_highlight_side or self._lane_highlight_started_at is None:
                self._lane_highlight_side = side
                self._lane_highlight_started_at = now

            signal_active = state.left_signal if side == "left" else state.right_signal
            signal_lit = left_signal_lit if side == "left" else right_signal_lit
            signal_started_at = (
                self._hazard_signal_started_at
                if state.left_signal and state.right_signal
                else self._left_turn_signal_started_at
                if side == "left"
                else self._right_turn_signal_started_at
            )
            if signal_started_at is not None:
                self._lane_highlight_started_at = signal_started_at
            if signal_active:
                return signal_lit
            return blink_visible(now, self._lane_highlight_started_at, float("inf"))

        self._lane_highlight_side = None
        self._lane_highlight_started_at = None
        if state.left_signal != state.right_signal:
            return left_signal_lit if state.left_signal else right_signal_lit
        return True

    def _turn_signal_lit(self, side: str, active: bool, now: float | None = None) -> bool:
        if not active:
            if side == "left":
                self._left_turn_signal_started_at = None
            else:
                self._right_turn_signal_started_at = None
            return False

        if now is None:
            now = time.perf_counter()
        if side == "left":
            if self._left_turn_signal_started_at is None:
                self._left_turn_signal_started_at = now
            started_at = self._left_turn_signal_started_at
        else:
            if self._right_turn_signal_started_at is None:
                self._right_turn_signal_started_at = now
            started_at = self._right_turn_signal_started_at
        return blink_visible(now, started_at, float("inf"))

    def _lane_confidence_hold_indices(self, state: ClusterUiState, now: float | None = None) -> frozenset[int]:
        """state.lanes indices to keep drawing as thin lines through a confidence dip.

        Presentation-only and never mutates state. The hold window starts at the
        last render where the line was drawn by the existing rules with a known
        (non-None) live confidence; that confidence already allows modelV2 up to
        cluster_live's 0.5 s age, and a repeated visible frame re-arms the start.
        """
        last_visible_at = self._lane_confidence_last_visible_at
        if not self._lane_confidence_visible(state):
            last_visible_at["left"] = None
            last_visible_at["right"] = None
            return frozenset()
        if now is None:
            now = time.monotonic()
        lanes = state.lanes
        held: list[int] = []
        seen: set[str] = set()
        for index, marking in enumerate(lanes):
            side = marking.confidence_hold_side
            if side not in last_visible_at or side in seen:
                continue
            seen.add(side)
            confidence = state.left_lane_line_confidence if side == "left" else state.right_lane_line_confidence
            if confidence is None:
                # Stale/invalid/missing model confidence: never add or arm a hold.
                # An already-visible line keeps its existing (baseline) drawing.
                last_visible_at[side] = None
                continue
            if marking.visible:
                last_visible_at[side] = now
                continue
            started_at = last_visible_at[side]
            if (
                marking.confidence_dip
                and confidence < LANE_CONFIDENCE_HOLD_PROBABILITY_MIN
                and started_at is not None
                and 0.0 <= now - started_at <= LANE_CONFIDENCE_HOLD_MAX_S
            ):
                held.append(index)
            else:
                last_visible_at[side] = None
        for side in ("left", "right"):
            if side not in seen:
                # No current geometry for this side: drop any pending hold.
                last_visible_at[side] = None
        return frozenset(held)

    def _road_edge_hold_sides(self, state: ClusterUiState, now: float | None = None) -> frozenset[str]:
        """Road-edge sides to keep drawing through a short near-lane gate drop.

        Same rules as the inner-lane confidence hold: default HUD only, both
        live lane confidences known (fresh modelV2), the edge's current points
        present, and at most LANE_CONFIDENCE_HOLD_MAX_S since the last render
        where the existing rules drew it. Holding never re-arms the start.
        """
        last_visible_at = self._road_edge_last_visible_at
        fresh = state.left_lane_line_confidence is not None and state.right_lane_line_confidence is not None
        if not self._lane_confidence_visible(state) or not fresh:
            last_visible_at["left"] = None
            last_visible_at["right"] = None
            return frozenset()
        if now is None:
            now = time.monotonic()
        held: list[str] = []
        for side, offset, points, hold_points in (
            ("left", state.left_road_edge_offset, state.left_road_edge_points, state.left_road_edge_hold_points),
            ("right", state.right_road_edge_offset, state.right_road_edge_points, state.right_road_edge_hold_points),
        ):
            if offset is not None or points:
                last_visible_at[side] = now
                continue
            started_at = last_visible_at[side]
            if hold_points and started_at is not None and 0.0 <= now - started_at <= LANE_CONFIDENCE_HOLD_MAX_S:
                held.append(side)
            else:
                last_visible_at[side] = None
        return frozenset(held)

    def _lane_confidence_visible(self, state: ClusterUiState) -> bool:
        # Only the user's default HUD: default screen mode (automatic trip-report
        # panel included) and default 3D camera view. Other modes stay unchanged.
        if getattr(self, "screen_mode", CLUSTER_SCREEN_MODE_DEFAULT) != CLUSTER_SCREEN_MODE_DEFAULT:
            return False
        return normalize_cluster_camera_view_mode(
            getattr(state, "camera_view_mode", CLUSTER_CAMERA_VIEW_MODE_DEFAULT)
        ) == CLUSTER_CAMERA_VIEW_MODE_DEFAULT

    @staticmethod
    def _lane_confidence_label_visible(state: ClusterUiState) -> bool:
        # The lane % labels under the turn-signal arrows: every screen mode (보노보노 2026-10-26 17:42 "외부hud 차선 % 안보이는데?":
        # the car runs ClusterHudScreenMode 2 (1cc initData), where _lane_confidence_visible hid them), default 3D camera view
        # only as before. Lane-line hold / steady lane highlight keep _lane_confidence_visible (default screen mode only).
        return normalize_cluster_camera_view_mode(
            getattr(state, "camera_view_mode", CLUSTER_CAMERA_VIEW_MODE_DEFAULT)
        ) == CLUSTER_CAMERA_VIEW_MODE_DEFAULT

    @staticmethod
    def _lane_confidence_text(confidence: float | None) -> str:
        if confidence is None or not math.isfinite(confidence) or not 0.0 <= confidence <= 1.0:
            return "--%"
        return f"{int(round(confidence * 100.0))}%"

    @staticmethod
    def _lane_confidence_anchor(side: str, ego_car_center_x: float, text_width: float = 0.0) -> tuple[float, float]:
        """Center of a side's label: against that side of the centre ego car, at the car's height.

        Shifted out by the measured text width so the opaque box edge - not the text - is what keeps
        LANE_CONFIDENCE_EGO_CAR_GAP_X from the car, whatever the text width is.
        """
        half_slot = text_width * 0.5 + LANE_CONFIDENCE_BOX_PAD_X + LANE_CONFIDENCE_EGO_CAR_GAP_X
        direction = -1.0 if side == "left" else 1.0
        return (
            ego_car_center_x + direction * (LANE_CONFIDENCE_EGO_CAR_HALF_W + half_slot),
            LANE_CONFIDENCE_CENTER_Y,
        )

    @staticmethod
    def _lane_confidence_box(center_x: float, center_y: float, text_width: float) -> tuple[float, float, float, float]:
        box_w = text_width + LANE_CONFIDENCE_BOX_PAD_X * 2.0
        return center_x - box_w * 0.5, center_y - LANE_CONFIDENCE_BOX_H * 0.5, box_w, LANE_CONFIDENCE_BOX_H

    def _draw_lane_confidence(self, side: str, confidence: float | None, ego_car_center_x: float) -> None:
        text = self._lane_confidence_text(confidence)
        size = LANE_CONFIDENCE_FONT_SIZE
        text_width, _text_height = self._measure_text(text, size, max(1.0, size * 0.02), self._font_for_text(text))
        x, y = self._lane_confidence_anchor(side, ego_car_center_x, text_width)
        rl.draw_rectangle_rounded(
            rl.Rectangle(*self._lane_confidence_box(x, y, text_width)), 0.3, 6, rl_color(LANE_CONFIDENCE_BOX_COLOR),
        )
        self._draw_text_with_stroke(
            text,
            x,
            y,
            size,
            LANE_CONFIDENCE_UNKNOWN_COLOR if text == "--%" else WHITE,
            (0, 0, 0, 255),
            2,
            anchor="center",
            cache=True,
        )

    def _draw_turn_signal(
        self,
        side: str,
        lit: bool,
        show_inactive: bool = False,
        center_x_offset: float = 0.0,
    ) -> None:
        if not lit and not show_inactive:
            return

        theme = self._current_theme()
        cx = (
            LANE_TURN_SIGNAL_LEFT_CENTER_X if side == "left" else LANE_TURN_SIGNAL_RIGHT_CENTER_X
        ) + center_x_offset
        cy = LANE_TURN_SIGNAL_CENTER_Y
        direction = -1 if side == "left" else 1
        fill = GREEN if lit else (*theme.muted, 42)
        outline = (8, 118, 65) if lit else (*theme.muted, 150)
        tail_back = -36
        tail_front = 12
        tail_half_height = 16
        head_tip_x = 60
        head_half_height = TURN_SIGNAL_HEAD_HALF_HEIGHT

        def point(local_x: float, local_y: float) -> rl.Vector2:
            return rl.Vector2(cx + direction * local_x, cy + local_y)

        tail_rect = rl.Rectangle(
            cx + direction * tail_back,
            cy - tail_half_height,
            direction * (tail_front - tail_back),
            tail_half_height * 2,
        )
        if tail_rect.width < 0:
            tail_rect.x += tail_rect.width
            tail_rect.width = -tail_rect.width

        head_top = point(tail_front, -head_half_height)
        head_tip = point(head_tip_x, 0)
        head_bottom = point(tail_front, head_half_height)
        if direction < 0:
            head_vertices = (head_top, head_tip, head_bottom)
        else:
            head_vertices = (head_top, head_bottom, head_tip)

        rl.draw_rectangle_rec(tail_rect, rl_color(fill))
        rl.draw_triangle(*head_vertices, rl_color(fill))

        outline_points = [
            point(tail_back, -tail_half_height),
            point(tail_front, -tail_half_height),
            head_top,
            head_tip,
            head_bottom,
            point(tail_front, tail_half_height),
            point(tail_back, tail_half_height),
        ]
        line_color = rl_color(outline)
        for index, start in enumerate(outline_points):
            end = outline_points[(index + 1) % len(outline_points)]
            rl.draw_line_ex(start, end, 3, line_color)

    def _rounded_rect(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        radius: float,
        fill: tuple[int, int, int],
        outline: tuple[int, int, int] | None = None,
        outline_width: float = 1.0,
    ) -> None:
        rect = rl.Rectangle(x, y, width, height)
        roundness = max(0.0, min(1.0, radius / max(1.0, min(width, height))))
        rl.draw_rectangle_rounded(rect, roundness, 12, rl_color(fill))
        if outline is not None and outline_width > 0:
            rl.draw_rectangle_rounded_lines_ex(rect, roundness, 12, outline_width, rl_color(outline))

    def _draw_text(
        self,
        text: str,
        x: float,
        y: float,
        size: float,
        color: tuple[int, int, int],
        anchor: str = "left",
    ) -> None:
        if not text:
            return
        font = self._font_for_text(text)
        spacing = max(1.0, size * 0.02)
        text_width, text_height = self._measure_text(text, size, spacing, font)
        draw_x = x
        draw_y = y
        if anchor == "center":
            draw_x = x - text_width * 0.5
            draw_y = y - text_height * 0.5
        elif anchor == "left":
            draw_y = y - text_height * 0.5
        elif anchor == "right":
            draw_x = x - text_width
            draw_y = y - text_height * 0.5
        rl.draw_text_ex(font, text, rl.Vector2(draw_x, draw_y), size, spacing, rl_color(color))

    def _font_for_text(self, text: str):
        if self._font is None:
            self._font = rl.get_font_default()
        if self._korean_font is not None and any(ord(char) > 0x7F for char in text):
            return self._korean_font
        return self._font

    def _draw_text_with_stroke(
        self,
        text: str,
        x: float,
        y: float,
        size: float,
        color: tuple[int, int, int],
        stroke_color: tuple[int, int, int],
        stroke_width: int,
        anchor: str = "left",
        cache: bool = False,
    ) -> None:
        if not text:
            return
        if cache and stroke_width > 0 and self._stroked_text_texture_cache_enabled:
            cached_text = self._stroked_text_texture(
                text,
                size,
                color,
                stroke_color,
                stroke_width,
            )
            if cached_text is not None:
                self._draw_cached_text_texture(cached_text, x, y, anchor)
                return
        if stroke_width > 0 and self._draw_stroked_text_raw(
            text,
            x,
            y,
            size,
            color,
            stroke_color,
            stroke_width,
            anchor,
        ):
            return
        if stroke_width > 0:
            for dx, dy in (
                (-stroke_width, 0),
                (stroke_width, 0),
                (0, -stroke_width),
                (0, stroke_width),
                (-stroke_width, -stroke_width),
                (stroke_width, -stroke_width),
                (-stroke_width, stroke_width),
                (stroke_width, stroke_width),
            ):
                self._draw_text(text, x + dx, y + dy, size, stroke_color, anchor)
        self._draw_text(text, x, y, size, color, anchor)

    def _draw_stroked_text_raw(
        self,
        text: str,
        x: float,
        y: float,
        size: float,
        color: tuple[int, int, int],
        stroke_color: tuple[int, int, int],
        stroke_width: int,
        anchor: str,
    ) -> bool:
        draw_text_ex = getattr(self, "_raw_draw_text_ex", None)
        if not getattr(self, "_raw_stroked_text_enabled", False) or draw_text_ex is None:
            return False

        font = self._font_for_text(text)
        spacing = max(1.0, size * 0.02)
        text_width, text_height = self._measure_text(text, size, spacing, font)
        encoded_text = text.encode("utf-8")
        position = rl.Vector2(0.0, 0.0)
        fill = rl_color(color)
        stroke = rl_color(stroke_color)

        def draw_at(draw_x: float, draw_y: float, draw_color: rl.Color) -> None:
            if anchor == "center":
                draw_x -= text_width * 0.5
                draw_y -= text_height * 0.5
            elif anchor == "left":
                draw_y -= text_height * 0.5
            elif anchor == "right":
                draw_x -= text_width
                draw_y -= text_height * 0.5
            position.x = draw_x
            position.y = draw_y
            draw_text_ex(font, encoded_text, position, size, spacing, draw_color)

        for dx, dy in (
            (-stroke_width, 0),
            (stroke_width, 0),
            (0, -stroke_width),
            (0, stroke_width),
            (-stroke_width, -stroke_width),
            (stroke_width, -stroke_width),
            (-stroke_width, stroke_width),
            (stroke_width, stroke_width),
        ):
            draw_at(x + dx, y + dy, stroke)
        draw_at(x, y, fill)
        return True

    def _draw_cached_text_texture(
        self,
        cached_text: CachedTextTexture,
        x: float,
        y: float,
        anchor: str,
    ) -> None:
        draw_x = x
        draw_y = y
        if anchor == "center":
            draw_x -= cached_text.text_width * 0.5
            draw_y -= cached_text.text_height * 0.5
        elif anchor == "left":
            draw_y -= cached_text.text_height * 0.5
        elif anchor == "right":
            draw_x -= cached_text.text_width
            draw_y -= cached_text.text_height * 0.5
        draw_x -= cached_text.padding_px
        draw_y -= cached_text.padding_px
        rl.draw_texture_pro(
            cached_text.texture,
            rl.Rectangle(
                0.0,
                0.0,
                float(cached_text.texture_width),
                float(cached_text.texture_height),
            ),
            rl.Rectangle(
                draw_x,
                draw_y,
                float(cached_text.texture_width),
                float(cached_text.texture_height),
            ),
            rl.Vector2(0.0, 0.0),
            0.0,
            rl_color(WHITE),
        )

    def _stroked_text_texture(
        self,
        text: str,
        size: float,
        color: tuple[int, int, int] | tuple[int, int, int, int],
        stroke_color: tuple[int, int, int] | tuple[int, int, int, int],
        stroke_width: int,
    ) -> CachedTextTexture | None:
        font = self._font_for_text(text)
        render_size = float(size)
        spacing = max(1.0, render_size * 0.02)
        fill_key = rgba_key(color)
        stroke_key = rgba_key(stroke_color)
        cache_key = (
            id(font),
            text,
            render_size,
            spacing,
            fill_key,
            stroke_key,
            int(stroke_width),
        )
        cached_text = self._stroked_text_texture_cache.get(cache_key)
        if cached_text is not None:
            self._stroked_text_texture_cache.move_to_end(cache_key)
            return cached_text

        # Texture upload inside an active target corrupts the miss frame on GLES.
        self._pending_stroked_text_textures.setdefault(
            cache_key,
            PendingStrokedTextTexture(
                font=font,
                text=text,
                render_size=render_size,
                spacing=spacing,
                fill_color=fill_key,
                stroke_color=stroke_key,
                stroke_width=int(stroke_width),
            ),
        )
        return None

    def _flush_pending_stroked_text_textures(self) -> None:
        if not self._pending_stroked_text_textures:
            return
        if not self._stroked_text_texture_cache_enabled:
            self._pending_stroked_text_textures.clear()
            return

        profile_stage = self._profile_start()
        pending_textures = self._pending_stroked_text_textures
        self._pending_stroked_text_textures = OrderedDict()
        for cache_key, pending in pending_textures.items():
            if cache_key in self._stroked_text_texture_cache:
                continue
            cached_text = self._create_stroked_text_texture(pending)
            if cached_text is None:
                continue
            self._stroked_text_texture_cache[cache_key] = cached_text
            while len(self._stroked_text_texture_cache) > STROKED_TEXT_TEXTURE_CACHE_LIMIT:
                _, old_text = self._stroked_text_texture_cache.popitem(last=False)
                rl.unload_texture(old_text.texture)
        self._profile_add("stroked_text_texture_cache.flush", profile_stage)

    def _create_stroked_text_texture(
        self,
        pending: PendingStrokedTextTexture,
    ) -> CachedTextTexture | None:
        text_width, text_height = self._measure_text(
            pending.text,
            pending.render_size,
            pending.spacing,
            pending.font,
        )
        padding_px = float(max(0, pending.stroke_width) + STROKED_TEXT_TEXTURE_PADDING_PX)
        texture_width = max(1, int(math.ceil(text_width + padding_px * 2.0)))
        texture_height = max(1, int(math.ceil(text_height + padding_px * 2.0)))
        image = None
        texture = None
        try:
            image = rl.gen_image_color(texture_width, texture_height, rl_color((0, 0, 0, 0)))
            for dx, dy in (
                (-pending.stroke_width, 0),
                (pending.stroke_width, 0),
                (0, -pending.stroke_width),
                (0, pending.stroke_width),
                (-pending.stroke_width, -pending.stroke_width),
                (pending.stroke_width, -pending.stroke_width),
                (-pending.stroke_width, pending.stroke_width),
                (pending.stroke_width, pending.stroke_width),
            ):
                rl.image_draw_text_ex(
                    image,
                    pending.font,
                    pending.text,
                    rl.Vector2(padding_px + dx, padding_px + dy),
                    pending.render_size,
                    pending.spacing,
                    rl_color(pending.stroke_color),
                )
            rl.image_draw_text_ex(
                image,
                pending.font,
                pending.text,
                rl.Vector2(padding_px, padding_px),
                pending.render_size,
                pending.spacing,
                rl_color(pending.fill_color),
            )
            texture = rl.load_texture_from_image(image)
            if hasattr(rl, "is_texture_valid") and not rl.is_texture_valid(texture):
                rl.unload_texture(texture)
                return None
            rl.set_texture_filter(texture, rl.TextureFilter.TEXTURE_FILTER_BILINEAR)
        except Exception:
            if texture is not None:
                try:
                    rl.unload_texture(texture)
                except Exception:
                    pass
            return None
        finally:
            if image is not None:
                rl.unload_image(image)

        cached_text = CachedTextTexture(
            texture=texture,
            text_width=text_width,
            text_height=text_height,
            texture_width=texture_width,
            texture_height=texture_height,
            padding_px=padding_px,
        )
        return cached_text

    def _draw_world_label_text(
        self,
        text: str,
        x: float,
        y: float,
        size: float,
        color: tuple[int, int, int] | tuple[int, int, int, int],
        anchor: str = "left",
    ) -> None:
        if not self._world_label_texture_cache_enabled:
            self._draw_text(text, x, y, size, color, anchor)
            return

        cached_text = self._world_label_texture(text, size, color)
        if cached_text is None:
            self._draw_text(text, x, y, size, color, anchor)
            return

        draw_x = x
        draw_y = y
        if anchor == "center":
            draw_x = x - cached_text.text_width * 0.5
            draw_y = y - cached_text.text_height * 0.5
        elif anchor == "left":
            draw_y = y - cached_text.text_height * 0.5
        elif anchor == "right":
            draw_x = x - cached_text.text_width
            draw_y = y - cached_text.text_height * 0.5
        draw_x -= cached_text.padding_px
        draw_y -= cached_text.padding_px

        source = rl.Rectangle(
            0.0,
            0.0,
            float(cached_text.texture_width),
            float(cached_text.texture_height),
        )
        dest = rl.Rectangle(
            draw_x,
            draw_y,
            float(cached_text.texture_width),
            float(cached_text.texture_height),
        )
        rl.draw_texture_pro(
            cached_text.texture,
            source,
            dest,
            rl.Vector2(0.0, 0.0),
            0.0,
            rl_color(WHITE),
        )

    def _world_label_texture(
        self,
        text: str,
        size: float,
        color: tuple[int, int, int] | tuple[int, int, int, int],
    ) -> CachedTextTexture | None:
        font = self._font_for_text(text)
        render_size = max(
            1.0,
            round(float(size) / WORLD_LABEL_TEXTURE_SIZE_GRID) * WORLD_LABEL_TEXTURE_SIZE_GRID,
        )
        spacing = max(1.0, render_size * 0.02)
        color_key = rgba_key(color)
        cache_key = (id(font), text, render_size, spacing, color_key)
        cached_text = self._world_label_texture_cache.get(cache_key)
        if cached_text is not None:
            self._world_label_texture_cache.move_to_end(cache_key)
            return cached_text

        profile_stage = self._profile_start()
        text_width, text_height = self._measure_text(text, render_size, spacing, font)
        padding_px = float(WORLD_LABEL_TEXTURE_PADDING_PX)
        texture_width = max(1, int(math.ceil(text_width + padding_px * 2.0)))
        texture_height = max(1, int(math.ceil(text_height + padding_px * 2.0)))
        image = None
        texture = None
        try:
            image = rl.gen_image_color(texture_width, texture_height, rl_color((0, 0, 0, 0)))
            rl.image_draw_text_ex(
                image,
                font,
                text,
                rl.Vector2(padding_px, padding_px),
                render_size,
                spacing,
                rl_color(color_key),
            )
            texture = rl.load_texture_from_image(image)
            if hasattr(rl, "is_texture_valid") and not rl.is_texture_valid(texture):
                rl.unload_texture(texture)
                return None
        except Exception:
            if texture is not None:
                try:
                    rl.unload_texture(texture)
                except Exception:
                    pass
            return None
        finally:
            if image is not None:
                rl.unload_image(image)

        cached_text = CachedTextTexture(
            texture=texture,
            text_width=text_width,
            text_height=text_height,
            texture_width=texture_width,
            texture_height=texture_height,
            padding_px=padding_px,
        )
        self._world_label_texture_cache[cache_key] = cached_text
        while len(self._world_label_texture_cache) > WORLD_LABEL_TEXTURE_CACHE_LIMIT:
            _, old_text = self._world_label_texture_cache.popitem(last=False)
            rl.unload_texture(old_text.texture)
        self._profile_add("world_label_texture_cache.miss", profile_stage)
        return cached_text

    def _measure_text(
        self,
        text: str,
        size: float,
        spacing: float | None = None,
        font=None,
    ) -> tuple[float, float]:
        if font is None:
            font = self._font_for_text(text)
        measure_spacing = max(1.0, size * 0.02) if spacing is None else spacing
        key = (id(font), text, float(size), float(measure_spacing))
        measured = self._text_measure_cache.get(key)
        if measured is not None:
            return measured
        if len(self._text_measure_cache) >= TEXT_MEASURE_CACHE_LIMIT:
            self._text_measure_cache.clear()
        text_size = rl.measure_text_ex(font, text, size, measure_spacing)
        measured = (float(text_size.x), float(text_size.y))
        self._text_measure_cache[key] = measured
        return measured

    def _ellipsize_text(self, text: str, size: float, max_width: float) -> str:
        spacing = max(1.0, size * 0.02)
        if self._measure_text(text, size, spacing)[0] <= max_width:
            return text
        ellipsis = "..."
        low = 0
        high = len(text)
        while low < high:
            mid = (low + high + 1) // 2
            candidate = text[:mid] + ellipsis
            if self._measure_text(candidate, size, spacing)[0] <= max_width:
                low = mid
            else:
                high = mid - 1
        return text[:low] + ellipsis
