from __future__ import annotations

from dataclasses import replace
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

from cluster_config import BLUE, DEFAULT_LANE_WIDTH_M, SHOW_PLOT_MODE_PARAM
from cluster_models import (
    ClusterAlert,
    ClusterUiState,
    DebugPlotSnapshot,
    LaneMarking,
    LiveDebugInfo,
    ModelPathPoint,
    NaviDebugInfo,
    NaviGuidanceImage,
    NaviTrafficLightInfo,
)
from cluster_navi import fresh_carrot_navi, parse_carrot_navi, resolve_navi_speed_limit
from cluster_navi_source import NaviIpcMediaSource
from cluster_route_replay import RouteLogParser, finite_float, frame_to_state, safe_get, safe_optional_float
from cluster_utils import clamp
from cluster_lat_values import LaneTextHold, applied_steer_delay_s, applied_steer_ratio, live_parameters_usable
from cluster_lat_values import applied_torque, learned_delay, learned_torque_filtered


def find_openpilot_root(start: Path) -> Path | None:
    for path in (start, *start.parents):
        if (path / "cereal").exists() and (path / "selfdrive").exists():
            return path
        nested = path / "openpilot"
        if (nested / "cereal").exists() and (nested / "selfdrive").exists():
            return nested
    return None


OPENPILOT_ROOT = find_openpilot_root(Path(__file__).resolve().parent)
if OPENPILOT_ROOT is not None:
    sys.path.insert(0, str(OPENPILOT_ROOT))

from openpilot.selfdrive.carrot.deceleration_source import deceleration_source_presentation, external_navigation_connected

LIVE_NAV_ROUTE_MAX_POINTS = 4096
LIVE_NAVI_IMAGE_BASE64_MAX_CHARS = 2 * 1024 * 1024
LIVE_NAVI_IMAGE_MAX_DIMENSION = 2048
ACCELERATION_DUE_TO_GRAVITY = 9.80665
DEFAULT_MAX_LATERAL_ACCEL = 3.0
SELFDRIVE_STATE_TIMEOUT_SECONDS = 5.0
SELFDRIVE_UNRESPONSIVE_TIMEOUT_SECONDS = 10.0
# modelV2 publishes at 20 Hz; older lane-line confidence is shown as unknown.
LANE_LINE_CONFIDENCE_MAX_AGE_S = 0.5


def deceleration_source_display_label(source: str | None) -> str:
    return deceleration_source_presentation(source)[0]


def _limited_items(items: Any, max_items: int):
    if max_items <= 0:
        return ()
    try:
        count = len(items)
    except Exception:
        return items
    if count <= max_items:
        return items

    last_index = count - 1
    indices: list[int] = []
    previous_index = -1
    for i in range(max_items):
        source_index = round(i * last_index / max(1, max_items - 1))
        if source_index == previous_index:
            continue
        indices.append(source_index)
        previous_index = source_index
    return (items[index] for index in indices)


LIVE_SERVICES_BASE = (
    "carState",
    "carParams",
    "modelV2",
    "radarState",
    "liveTracks",
    "longitudinalPlan",
    "lateralPlan",
    "controlsState",
    "selfdriveState",
    "carControl",
    "carOutput",
    "deviceState",
    "roadCameraState",
    "cameraOdometry",
    "liveCalibration",
    "livePose",
    "drivingModelData",
    "liveDelay",
    "liveParameters",
    "liveTorqueParameters",
    "navInstruction",
    "navInstructionCarrot",
    "navRoute",
    "carrotMan",
    "carrotNavi",
    "wideRoadCameraState",
)
LIVE_CAN_SERVICES = ("can", "sendcan")
NAVI_TRAFFIC_LIGHT_HOLD_SECONDS = 10.0


def live_route_parser() -> RouteLogParser:
    # radarState is authoritative in production. Recomputing CUT-IN from
    # liveTracks here duplicates radard's per-track motion pipeline and makes
    # the external HUD cost grow sharply with dense radar scenes.
    return RouteLogParser(recompute_cutins=False)


class TaxiSpeedSampleReader:
    """Every carState (not the conflated latest) for the K9ExtHud=1 taxi meter: a separate
    non-conflated socket, opened on first use (K9ExtHud=1 only) and closed when the meter is off."""

    def __init__(self, messaging: Any) -> None:
        self._messaging = messaging
        self._sock: Any | None = None

    def drain(self) -> list[tuple[float, float]]:
        if self._sock is None:
            try:
                self._sock = self._messaging.sub_sock("carState", conflate=False)
            except Exception:
                self._sock = None
            return []
        out: list[tuple[float, float]] = []
        try:
            msgs = self._messaging.drain_sock(self._sock)
        except Exception:
            return out
        for msg in msgs:
            try:
                out.append((int(msg.logMonoTime) * 1e-9, float(msg.carState.vEgo)))
            except Exception:
                continue
        return out

    def stop(self) -> None:
        self._sock = None


class TaxiOccupantReader:
    """K9ExtHud=1 C1 meter: passenger-seat occupant flag from CAN 0x500 (ACU14 CF_TTL_Ind, bits 2-3) on bus 0.
    Own non-conflated 'can' socket, opened on first use (K9ExtHud=1 only), read-only. Cost cap: raw messages
    are received every frame but only the newest OCC_PARSE_TAIL (~150 ms of CAN at 100 Hz; 0x500 is ~10 Hz)
    are parsed, at most every OCC_PARSE_PERIOD_S."""

    OCC_PARSE_TAIL = 15
    OCC_PARSE_PERIOD_S = 0.25
    MAX_RAW_PER_CALL = 400

    def __init__(self, messaging: Any) -> None:
        self._messaging = messaging
        self._sock: Any | None = None
        self._tail: list = []
        self._next_parse = 0.0
        self.last: tuple[float, bool] | None = None   # (logMonoTime s, present)
        self._new_t: float | None = None               # logMonoTime of the frame poll_new() returned last

    def poll(self, now: float | None = None) -> tuple[float, bool] | None:
        if self._sock is None:
            try:
                self._sock = self._messaging.sub_sock("can", conflate=False)
            except Exception:
                self._sock = None
            return None
        try:
            for _ in range(self.MAX_RAW_PER_CALL):
                dat = self._sock.receive(non_blocking=True)
                if dat is None:
                    break
                self._tail.append(dat)
                if len(self._tail) > self.OCC_PARSE_TAIL:
                    del self._tail[0]
        except Exception:
            return self.last
        now = time.monotonic() if now is None else now
        if now < self._next_parse or not self._tail:
            return self.last
        self._next_parse = now + self.OCC_PARSE_PERIOD_S
        tail, self._tail = self._tail, []
        for dat in reversed(tail):
            try:
                msg = self._messaging.log_from_bytes(dat)
                for c in msg.can:
                    if c.address == 0x500 and c.src == 0 and len(c.dat) >= 1:
                        self.last = (int(msg.logMonoTime) * 1e-9, ((c.dat[0] >> 2) & 0x3) == 1)
                        return self.last
            except Exception:
                continue
        return self.last

    def poll_new(self, now: float | None = None) -> tuple[float, bool] | None:
        """poll(), but only a frame newer than the one poll_new() returned last time; None = no new 0x500 frame."""
        last = self.poll(now)
        if last is None or (self._new_t is not None and last[0] <= self._new_t):
            return None
        self._new_t = last[0]
        return last

    def stop(self) -> None:
        self._sock = None
        self._tail = []
        self._new_t = None


class OpenpilotLiveSource:
    def __init__(self, include_can: bool = False, timeout_ms: int = 0) -> None:
        try:
            import openpilot.cereal.messaging as messaging
        except Exception as exc:
            raise RuntimeError(
                "Openpilot live input requires cereal.messaging. Run from an openpilot environment "
                "or use --input route/random for local checks."
            ) from exc

        self.messaging: Any = messaging
        try:
            from openpilot.cereal import log

            self.log: Any | None = log
        except Exception:
            self.log = None
        self.services = list(LIVE_SERVICES_BASE + (LIVE_CAN_SERVICES if include_can else ()))
        self.sm = messaging.SubMaster(self.services)
        self._taxi_speed_reader: TaxiSpeedSampleReader | None = None
        self.parser = live_route_parser()
        self.parser.trip_report_tracker.set_onroad(False)
        self.timeout_ms = max(0, int(timeout_ms))
        self.last_state: ClusterUiState | None = None
        self.start_t = time.monotonic()
        self.frames = 0
        self.params: Any | None = None
        self.params_memory: Any | None = None
        self._energy_gauge_label = "fuel"
        self._max_lateral_accel = DEFAULT_MAX_LATERAL_ACCEL
        self._next_debug_param_read_t = 0.0
        self._custom_steer_ratio: float | None = None
        self._steer_actuator_delay_param_s: float | None = None
        self._cached_live_debug: LiveDebugInfo | None = None
        self._cached_navi_debug: NaviDebugInfo | None = None
        self._cached_navi_image: NaviGuidanceImage | None = None
        self._held_navi_traffic_light: NaviTrafficLightInfo | None = None
        self._held_navi_traffic_light_received_t: float | None = None
        self._show_plot_mode = 0
        self._egpu_active = False
        self._next_egpu_param_read_t = 0.0
        self._hud_debug_mode = 0
        self._live_debug_enabled = False
        self._debug_plot_enabled = False
        self._navi_debug_enabled = False
        self._alert_onroad = False
        self._alert_onroad_started_t: float | None = None
        self._selfdrive_seen_onroad = False
        self._nav_route_coords: tuple[tuple[float, float], ...] = ()
        self._nav_route_model_path: tuple[ModelPathPoint, ...] = ()
        self._nav_route_anchor: tuple[float, float, float] | None = None
        self._carrot_navi = None
        self._carrot_navi_generation = -1
        self._carrot_navi_next_expiry_s = math.inf
        try:
            self._carrot_navi_media = NaviIpcMediaSource(messaging)
        except Exception as exc:
            print(f"Carrot navigation media IPC unavailable: {exc}", flush=True)
            self._carrot_navi_media = None
        self._standby_state = standby_state()
        self.profile_enabled = False
        self._profile_samples: list[tuple[str, float]] = []
        try:
            from openpilot.common.params import Params

            self.params = Params()
            self.params_memory = Params("/dev/shm/params")
            self._energy_gauge_label = self._resolve_energy_gauge_label()
            self._max_lateral_accel = self._resolve_max_lateral_accel()
            self._load_cached_car_params()
            self._load_cached_calibration()
        except Exception:
            pass

    def _load_cached_car_params(self) -> None:
        if self.params is None:
            return
        try:
            from openpilot.cereal import car

            car_params_bytes = self.params.get("CarParams")
            if car_params_bytes:
                self.parser._update_car_params(self.messaging.log_from_bytes(car_params_bytes, car.CarParams))
        except Exception:
            pass

    def _load_cached_calibration(self) -> None:
        if self.params is None or self.log is None:
            return
        try:
            calibration_bytes = self.params.get("CalibrationParams")
            if calibration_bytes:
                event = self.messaging.log_from_bytes(calibration_bytes, self.log.Event)
                self.parser._update_live_calibration(
                    event.liveCalibration,
                    bool(safe_get(event, "valid", True)),
                )
        except Exception:
            pass

    def _resolve_energy_gauge_label(self) -> str:
        if self.params is None:
            return "fuel"
        try:
            from openpilot.cereal import car
            from opendbc.car.hyundai.values import HyundaiFlags

            car_params_bytes = self.params.get("CarParams")
            if not car_params_bytes:
                return "fuel"
            car_params = self.messaging.log_from_bytes(car_params_bytes, car.CarParams)
            if car_params.brand == "hyundai" and car_params.flags & HyundaiFlags.EV.value:
                return "battery"
        except Exception:
            pass
        return "fuel"

    def _resolve_max_lateral_accel(self) -> float:
        if self.params is None:
            return DEFAULT_MAX_LATERAL_ACCEL
        try:
            from openpilot.cereal import car

            car_params_bytes = self.params.get("CarParams")
            if not car_params_bytes:
                return DEFAULT_MAX_LATERAL_ACCEL
            car_params = self.messaging.log_from_bytes(car_params_bytes, car.CarParams)
            value = finite_float(car_params.maxLateralAccel)
            if value is not None and value > 0.0:
                return value
        except Exception:
            pass
        return DEFAULT_MAX_LATERAL_ACCEL

    def set_profile_enabled(self, enabled: bool) -> None:
        self.profile_enabled = enabled

    def set_debug_panels_enabled(self, *, live_debug: bool, debug_plot: bool, navi_debug: bool = False) -> None:
        if (
            live_debug != self._live_debug_enabled
            or debug_plot != self._debug_plot_enabled
            or navi_debug != self._navi_debug_enabled
        ):
            self._next_debug_param_read_t = 0.0
        self._live_debug_enabled = live_debug
        self._debug_plot_enabled = debug_plot
        self._navi_debug_enabled = navi_debug

    def set_hud_debug_mode(self, mode: int) -> None:
        try:
            next_mode = int(mode)
        except (TypeError, ValueError):
            next_mode = 0
        next_mode = max(0, min(3, next_mode))
        if next_mode != self._hud_debug_mode:
            self._next_debug_param_read_t = 0.0
        self._hud_debug_mode = next_mode

    def profile_samples(self) -> tuple[tuple[str, float], ...]:
        samples = tuple(self._profile_samples)
        self._profile_samples.clear()
        return samples

    def _profile_start(self) -> float:
        return time.perf_counter() if self.profile_enabled else 0.0

    def _profile_add(self, name: str, start_time: float) -> None:
        if self.profile_enabled:
            self._profile_samples.append((name, (time.perf_counter() - start_time) * 1000.0))

    def drain_taxi_speed_samples(self) -> list[tuple[float, float]]:
        """K9ExtHud=1: every carState (logMonoTime s, vEgo m/s) since the last call."""
        if self._taxi_speed_reader is None:
            self._taxi_speed_reader = TaxiSpeedSampleReader(self.messaging)
        return self._taxi_speed_reader.drain()

    def stop_taxi_speed_samples(self) -> None:
        if self._taxi_speed_reader is not None:
            self._taxi_speed_reader.stop()
            self._taxi_speed_reader = None
        if getattr(self, "_taxi_occ_reader", None) is not None:
            self._taxi_occ_reader.stop()
            self._taxi_occ_reader = None

    def poll_taxi_occupant(self) -> tuple[float, bool] | None:
        """K9ExtHud=1: (logMonoTime s, passenger present) of a NEW CAN 0x500 bus0 frame since the last call,
        None = no new frame. (The reader keeps its last value; handing that on again every frame would hide a
        lost signal from the 2 s stale check of the C1 meter.)"""
        if getattr(self, "_taxi_occ_reader", None) is None:
            self._taxi_occ_reader = TaxiOccupantReader(self.messaging)
        return self._taxi_occ_reader.poll_new()

    def update(self) -> ClusterUiState:
        profile_stage = self._profile_start()
        self.sm.update(self.timeout_ms)
        self._profile_add("source.live.submaster_update", profile_stage)

        profile_stage = self._profile_start()
        self._update_current_speed()
        self._profile_add("source.live.current_speed", profile_stage)

        profile_stage = self._profile_start()
        for service in self.services:
            if not self._service_updated(service):
                continue
            event_t = self._service_time(service)
            self._apply_service_update(service, event_t)
        self._profile_add("source.live.apply_updates", profile_stage)

        onroad_state = self.onroad_state()
        if onroad_state is not None:
            self.parser.trip_report_tracker.set_onroad(onroad_state)
        if self._service_alive("carState"):
            profile_stage = self._profile_start()
            event_t = self._service_time("carState")
            frame = self.parser._frame_from_car_state(self.sm["carState"], event_t)
            self._profile_add("source.live.car_frame", profile_stage)

            profile_stage = self._profile_start()
            state = frame_to_state(frame)
            self._profile_add("source.live.frame_to_state", profile_stage)

            self.last_state = self._with_live_hud_state(self._with_debug_state(state))
            self.frames += 1
            return self.last_state

        profile_stage = self._profile_start()
        state = self._standby_state
        self._profile_add("source.live.standby_state", profile_stage)

        self.last_state = self._with_live_hud_state(self._with_debug_state(state))
        return self.last_state

    def _with_live_hud_state(self, state: ClusterUiState) -> ClusterUiState:
        now = time.monotonic()
        if now >= getattr(self, "_next_egpu_param_read_t", 0.0):
            params = getattr(self, "params", None)
            try:
                self._egpu_active = bool(params is not None and params.get_bool("UsbGpuActive"))
            except Exception:
                self._egpu_active = False
            self._external_compute_label = ''
            try:
                if callable(getattr(params, 'external_compute_label', None)):
                    self._external_compute_label = params.external_compute_label()
                else:
                    from openpilot.common.jetlink_status import badge
                    device_badge = badge()
                    if device_badge and device_badge[1] == 'active':
                        self._external_compute_label = device_badge[0]
            except Exception:
                pass
            self._next_egpu_param_read_t = now + 1.0

        device_state = self._service_data("deviceState")
        onroad = self._service_alive("deviceState") and bool(safe_get(device_state, "started", False))
        car_state = self._service_data("carState")
        fuel_gauge = safe_optional_float(car_state, "fuelGauge")
        if fuel_gauge is None or not 0.0 < fuel_gauge <= 1.0:
            fuel_gauge = None
        energy_gauge_label = "battery" if bool(safe_get(car_state, "charging", False)) else self._energy_gauge_label
        urea_gauge = safe_optional_float(car_state, "ureaGauge")
        if urea_gauge is None or not 0.0 < urea_gauge <= 1.0:
            urea_gauge = None

        steering_output = None
        steering_output_normalized = None
        steering_output_kind = None
        car_output = self._service_data("carOutput")
        actuators_output = safe_get(car_output, "actuatorsOutput")
        controls_state = self._service_data("controlsState")
        lateral_state = safe_get(controls_state, "lateralControlState")
        try:
            lateral_kind = str(lateral_state.which()) if lateral_state is not None else ""
        except Exception:
            lateral_kind = ""
        if lateral_kind == "angleState":
            # Angle-control cars send a positive maximum-torque authority value,
            # which normally stays pinned at its maximum. Estimate signed steering
            # utilization like mici's TorqueBar instead so the gauge reflects demand.
            car_control = self._service_data("carControl")
            lat_active = bool(safe_get(car_control, "latActive", False))
            if lat_active:
                v_ego = max(0.0, safe_optional_float(car_state, "vEgo") or 0.0)
                curvature = safe_optional_float(controls_state, "curvature") or 0.0
                desired_curvature = safe_optional_float(controls_state, "desiredCurvature") or curvature
                live_parameters = self._service_data("liveParameters")
                roll = safe_optional_float(live_parameters, "roll") or 0.0
                roll_weight = clamp((v_ego - 5.0) / 10.0, 0.0, 1.0)
                desired_lateral_accel = desired_curvature * v_ego * v_ego
                roll_compensation = roll * ACCELERATION_DUE_TO_GRAVITY * roll_weight
                steering_output_normalized = clamp(
                    (desired_lateral_accel - roll_compensation) / self._max_lateral_accel,
                    -1.0,
                    1.0,
                )
            else:
                steering_output_normalized = 0.0
            steering_output = steering_output_normalized * 100.0
            steering_output_kind = "angle"
        elif lateral_kind in ("torqueState", "pidState"):
            actuator_torque = safe_optional_float(actuators_output, "torque")
            if actuator_torque is not None:
                steering_output_normalized = clamp(actuator_torque, -1.0, 1.0)
            torque_output_can = safe_optional_float(actuators_output, "torqueOutputCan")
            if torque_output_can is not None and abs(torque_output_can) <= 999.0:
                steering_output = torque_output_can
            elif steering_output_normalized is not None:
                # Simulator and some non-CAN paths don't have a meaningful raw CAN
                # torque value. Show normalized steering demand instead of sentinel
                # values such as -4096.
                steering_output = steering_output_normalized * 100.0
            steering_output_kind = "torque"

        carrot_man = self._service_data("carrotMan")
        desired_source = str(safe_get(carrot_man, "desiredSource", "") or "").strip()
        navi_live = self._current_carrot_navi(time.monotonic())
        navi_dashboard = (
            self._carrot_navi_media.update(navi_live)
            if self._carrot_navi_media is not None else None
        )
        carrot_navi = self._service_data("carrotNavi")
        carrot_navi_connected = bool(
            self._service_alive("carrotNavi")
            and self._service_valid("carrotNavi")
            and safe_get(carrot_navi, "connected", False)
        )
        external_nav_active = external_navigation_connected(
            safe_get(carrot_man, "remote", ""),
            carrot_navi_connected or bool(navi_dashboard is not None and navi_dashboard.connected),
        )

        speed_limit_kph, speed_limit_source = resolve_navi_speed_limit(
            state.speed_limit_kph,
            state.speed_limit_source,
            navi_live,
        )

        cruise_override_kph = None
        cruise_override_label = None
        cruise_override_color_mode = 0
        driving_mode = (
            state.driving_mode
            if state.driving_mode in (1, 2, 3, 4)
            and self._service_alive("longitudinalPlan")
            and self._service_valid("longitudinalPlan")
            else None
        )
        vehicle_navi_available = bool(safe_get(carrot_man, "vehicleNaviAvailable", False))
        if state.cruise_kph is not None and state.cruise_display_state != "off":
            # Keep this priority and the thresholds in sync with mici's SetSpeedOverride.
            longitudinal_plan = self._service_data("longitudinalPlan")
            cruise_target = safe_optional_float(longitudinal_plan, "cruiseTarget")
            if cruise_target is not None and cruise_target > state.cruise_kph + 0.5:
                cruise_override_kph = cruise_target
                cruise_override_label = "eco"
                cruise_override_color_mode = 1
            else:
                desired_speed = safe_optional_float(carrot_man, "desiredSpeed")
                if desired_speed is not None and 0.0 < desired_speed < 200.0 and desired_speed < state.cruise_kph:
                    cruise_override_kph = desired_speed
                    cruise_override_label, cruise_override_color_mode = deceleration_source_presentation(desired_source)

        left_lane_line_confidence, right_lane_line_confidence = self._live_lane_line_confidence(now)

        try:
            applied_sr, applied_sad = self._live_lat_values(now)
        except Exception:
            applied_sr, applied_sad = None, None
        try:
            (d_perc, d_s), (t_perc, t_af, t_fr) = self._live_learn_values(now)
        except Exception:
            (d_perc, d_s), (t_perc, t_af, t_fr) = (None, None), (None, None, None)
        try:
            t_af_learned, t_fr_learned = self._live_torque_learned()
        except Exception:
            t_af_learned, t_fr_learned = None, None
        try:
            learned_sr = self._live_learned_steer_ratio()
        except Exception:
            learned_sr = None
        try:
            k9_lane_offset, k9_lane_state, k9_lane_accel, k9_gap_l, k9_gap_r = self._live_lane_values(now)
        except Exception:
            k9_lane_offset, k9_lane_state, k9_lane_accel, k9_gap_l, k9_gap_r = None, None, None, None, None
        return replace(
            state,
            onroad=onroad,
            alert=self._live_cluster_alert(state.alert, onroad),
            egpu_active=getattr(self, "_egpu_active", False),
            external_compute_label=getattr(self, '_external_compute_label', ''),
            external_nav_active=external_nav_active,
            vehicle_navi_available=vehicle_navi_available,
            speed_limit_kph=speed_limit_kph,
            speed_limit_source=speed_limit_source,
            navi_live=navi_live,
            navi_dashboard=navi_dashboard,
            steering_output=steering_output,
            steering_output_normalized=steering_output_normalized,
            steering_output_kind=steering_output_kind,
            fuel_gauge=fuel_gauge,
            energy_gauge_label=energy_gauge_label,
            urea_gauge=urea_gauge,
            driving_mode=driving_mode,
            cruise_override_kph=cruise_override_kph,
            cruise_override_label=cruise_override_label,
            cruise_override_color_mode=cruise_override_color_mode,
            left_lane_line_confidence=left_lane_line_confidence,
            right_lane_line_confidence=right_lane_line_confidence,
            applied_steer_ratio=applied_sr,
            applied_steer_delay_s=applied_sad,
            delay_learn_perc=d_perc,
            delay_learn_s=d_s,
            torque_learn_perc=t_perc,
            torque_learn_lat_accel_factor=t_af,
            torque_learn_friction=t_fr,
            torque_filtered_lat_accel_factor=t_af_learned,
            torque_filtered_friction=t_fr_learned,
            learned_steer_ratio=learned_sr,
            k9_lane_offset_m=k9_lane_offset,
            k9_lane_state=k9_lane_state,
            k9_lane_accel=k9_lane_accel,
            k9_lane_gap_left_m=k9_gap_l,
            k9_lane_gap_right_m=k9_gap_r,
        )

    def _live_lane_values(self, now: float) -> tuple[float | None, int | None, float | None, float | None, float | None]:
        """치우침 / 보정 / 좌·우 차선 간격 for the lines above SR / SAD (display only, see cluster_lat_values)."""
        hold = getattr(self, "_lane_text_hold", None)
        if hold is None:  # 11/13 05:12 "치우침 좌우 유지시켜라": steady text (hysteresis + short hold), display only
            hold = self._lane_text_hold = LaneTextHold()
        model = None
        if self._service_alive("modelV2"):
            receive_t = self._service_receive_time("modelV2") if hasattr(self, "_service_receive_time") else now
            if receive_t is not None and 0.0 <= now - receive_t <= LANE_LINE_CONFIDENCE_MAX_AGE_S:
                model = self._service_data("modelV2")
        offset, gap_l, gap_r = hold.update(model, now)
        controls_state = self._service_data("controlsState") if self._service_alive("controlsState") else None
        state = safe_get(controls_state, "k9LaneState") if controls_state is not None else None
        accel = safe_get(controls_state, "k9LaneAccel") if controls_state is not None else None
        try:
            state = int(state) if state is not None else None
        except (TypeError, ValueError):
            state = None
        return offset, state, finite_float(accel) if accel is not None else None, gap_l, gap_r

    def _live_learn_values(self, now: float | None = None) -> tuple[tuple[int | None, float | None],
                                                                     tuple[int | None, float | None, float | None]]:
        """지연학습 / 토크학습 lines (display only, see cluster_lat_values.learned_delay / applied_torque).
        LateralTorqueCustom / LateralTorqueAccelFactor / LateralTorqueFriction re-read once per second."""
        now = time.monotonic() if now is None else now
        if now >= getattr(self, "_next_torque_param_read_t", 0.0):
            params = getattr(self, "params", None)
            values = []
            for key in ("LateralTorqueCustom", "LateralTorqueAccelFactor", "LateralTorqueFriction"):
                try:
                    values.append(float(params.get_float(key)) if params is not None else None)
                except Exception:
                    values.append(None)
            self._torque_params = tuple(values)
            self._next_torque_param_read_t = now + 1.0
        custom, custom_laf, custom_fr = getattr(self, "_torque_params", (None, None, None))
        live_delay = self._service_data("liveDelay") if self._service_alive("liveDelay") else None
        live_torque = self._service_data("liveTorqueParameters") if self._service_alive("liveTorqueParameters") else None
        return learned_delay(live_delay), applied_torque(live_torque, custom, custom_laf, custom_fr)

    def _live_torque_learned(self) -> tuple[float | None, float | None]:
        """학습 line: liveTorqueParameters Filtered as torqued publishes it, whatever LateralTorqueCustom is (display only)."""
        live_torque = self._service_data("liveTorqueParameters") if self._service_alive("liveTorqueParameters") else None
        return learned_torque_filtered(live_torque)

    def _live_learned_steer_ratio(self) -> float | None:
        """학습 조향비 line: liveParameters.steerRatio (display only)."""
        live_parameters = self._service_data("liveParameters") if self._service_alive("liveParameters") else None
        return safe_optional_float(live_parameters, "steerRatio") if live_parameters is not None else None

    def _live_lat_values(self, now: float) -> tuple[float | None, float | None]:
        """SR / SAD for the text above the TPMS car (display only, see cluster_lat_values)."""
        if now >= getattr(self, "_next_lat_param_read_t", 0.0):
            params = getattr(self, "params", None)
            values = []
            for key in ("CustomSR", "SteerRatioRate", "SteerActuatorDelay"):
                try:
                    values.append(float(params.get_float(key)) if params is not None else None)
                except Exception:
                    values.append(None)
            self._lat_params = tuple(values)
            self._next_lat_param_read_t = now + 1.0
        custom_sr, sr_rate, sad_param = getattr(self, "_lat_params", (None, None, None))
        live_parameters = self._service_data("liveParameters") if self._service_alive("liveParameters") else None
        live_ok = live_parameters_usable(live_parameters)
        parser = getattr(self, "parser", None)
        # parser.steer_ratio = CarParams.steerRatio once CarParams was read (car_brand set), else unknown
        nominal_sr = getattr(parser, "steer_ratio", None) if getattr(parser, "car_brand", "") else None
        sr = applied_steer_ratio(safe_get(live_parameters, "steerRatio") if live_ok else None, live_ok,
                                 nominal_sr, sr_rate, custom_sr)
        live_delay = self._service_data("liveDelay") if self._service_alive("liveDelay") else None
        sad = applied_steer_delay_s(sad_param, safe_get(live_delay, "lateralDelay") if live_delay is not None else None)
        return sr, sad

    def _live_lane_line_confidence(self, now: float) -> tuple[float | None, float | None]:
        # modelV2.laneLineProbs is [outer left, inner left, inner right, outer right].
        # Report unknown instead of the parser's sticky defaults/last values.
        if not self._service_valid("modelV2"):
            return None, None
        receive_t = self._service_receive_time("modelV2")
        if receive_t is None or not 0.0 <= now - receive_t <= LANE_LINE_CONFIDENCE_MAX_AGE_S:
            return None, None
        lane_probs = safe_get(self._service_data("modelV2"), "laneLineProbs")
        try:
            if lane_probs is None or len(lane_probs) < 3:
                return None, None
            values = (finite_float(lane_probs[1]), finite_float(lane_probs[2]))
        except Exception:
            return None, None
        return tuple(value if value is not None and 0.0 <= value <= 1.0 else None for value in values)

    def _live_cluster_alert(self, current_alert: ClusterAlert | None, onroad: bool) -> ClusterAlert | None:
        now = time.monotonic()
        was_onroad = bool(getattr(self, "_alert_onroad", False))
        if not onroad:
            self._alert_onroad = False
            self._alert_onroad_started_t = None
            self._selfdrive_seen_onroad = False
            return current_alert

        if not was_onroad:
            self._alert_onroad_started_t = now
            self._selfdrive_seen_onroad = False
        self._alert_onroad = True

        started_t = getattr(self, "_alert_onroad_started_t", None)
        if started_t is None:
            started_t = now
            self._alert_onroad_started_t = started_t

        receive_t = self._service_receive_time("selfdriveState")
        if self._service_updated("selfdriveState") or (receive_t is not None and receive_t >= started_t):
            self._selfdrive_seen_onroad = True

        if not getattr(self, "_selfdrive_seen_onroad", False):
            if now - started_t > SELFDRIVE_STATE_TIMEOUT_SECONDS:
                return ClusterAlert(
                    text1="openpilot Unavailable",
                    text2="Waiting to start",
                    size=2,
                    status=0,
                    alert_type="clusterSelfdriveStartup",
                )
            return None

        if receive_t is not None:
            missing_s = max(0.0, now - receive_t)
            if missing_s > SELFDRIVE_STATE_TIMEOUT_SECONDS:
                selfdrive_state = self._service_data("selfdriveState")
                enabled = bool(safe_get(selfdrive_state, "enabled", False))
                if enabled and missing_s - SELFDRIVE_STATE_TIMEOUT_SECONDS < SELFDRIVE_UNRESPONSIVE_TIMEOUT_SECONDS:
                    return ClusterAlert(
                        text1="TAKE CONTROL IMMEDIATELY",
                        text2="System Unresponsive",
                        size=3,
                        status=2,
                        alert_type="clusterSelfdriveTimeout",
                    )
                return ClusterAlert(
                    text1="System Unresponsive",
                    text2="Reboot Device",
                    size=2,
                    status=0,
                    alert_type="clusterSelfdriveReboot",
                )
        return current_alert

    def onroad_state(self) -> bool | None:
        if not self._service_alive("deviceState"):
            return None
        started = safe_get(self._service_data("deviceState"), "started", None)
        return bool(started) if started is not None else None

    def status_text(self) -> str:
        profile_stage = self._profile_start()
        alive = sum(1 for service in self.services if self._service_alive(service))
        updated = sum(1 for service in self.services if self._service_updated(service))
        can_status = "can/sendcan" if "sendcan" in self.services else "no-can"
        age = time.monotonic() - self.start_t
        fps = self.frames / age if age > 0.1 else 0.0
        radar_count = len(self.last_state.radar_points) if self.last_state is not None else 0
        detected_count = len(self.last_state.detected_vehicles) if self.last_state is not None else 0
        text = (
            f"live {can_status} alive={alive}/{len(self.services)} upd={updated} state={fps:.1f}Hz "
            f"radar={radar_count} detected={detected_count}"
        )
        self._profile_add("source.live.status_text", profile_stage)
        return text

    def screen_brightness_percent(self) -> int | None:
        camera_brightness = self._camera_brightness_percent()
        if camera_brightness is not None:
            return camera_brightness

        if not self._service_alive("deviceState"):
            return None
        try:
            if not bool(self.sm["deviceState"].started):
                return 0
        except Exception:
            return None
        try:
            value = float(self.sm["deviceState"].screenBrightnessPercent)
        except Exception:
            return None
        if not math.isfinite(value):
            return None
        return int(round(clamp(value, 0.0, 100.0)))

    def _camera_brightness_percent(self) -> int | None:
        if not self._service_alive("wideRoadCameraState") or not self._service_valid("wideRoadCameraState"):
            return None
        try:
            exposure = float(self.sm["wideRoadCameraState"].exposureValPercent)
        except Exception:
            return None
        if not math.isfinite(exposure):
            return None

        lightness = clamp(100.0 - exposure, 0.0, 100.0)
        if lightness <= 8.0:
            normalized = lightness / 903.3
        else:
            normalized = ((lightness + 16.0) / 116.0) ** 3.0
        brightness = 30.0 + clamp(normalized, 0.0, 1.0) * 70.0
        return int(round(clamp(brightness, 0.0, 100.0)))

    def close(self) -> None:
        if self._carrot_navi_media is not None:
            self._carrot_navi_media.close()
        return None

    def _apply_service_update(self, service: str, event_t: float) -> None:
        data = self.sm[service]
        if service == "drivingModelData":
            self.parser._update_driving_model(data)
        elif service == "modelV2":
            self.parser._update_model_v2(data, event_t)
        elif service == "lateralPlan":
            self.parser._update_lateral_plan(data)
        elif service in ("navInstruction", "navInstructionCarrot"):
            self.parser._update_nav_instruction(data, event_t)
        elif service == "navRoute":
            self._update_nav_route(data)
        elif service == "carrotNavi":
            self._update_carrot_navi(data)
        elif service == "longitudinalPlan":
            self.parser._update_longitudinal_plan(data, self._service_valid(service))
        elif service == "controlsState":
            self.parser._update_controls_state(data)
        elif service == "selfdriveState":
            self.parser._update_selfdrive_state(data, event_t)
        elif service == "carControl":
            self.parser._update_car_control(data)
        elif service == "deviceState":
            self.parser._update_device_state(data)
        elif service == "roadCameraState":
            self.parser._update_road_camera_state(data)
        elif service == "cameraOdometry":
            self.parser._update_camera_odometry(data, self._service_valid(service))
        elif service == "liveCalibration":
            self.parser._update_live_calibration(data, self._service_valid(service))
        elif service == "livePose":
            self.parser._update_live_pose(data, event_t)
        elif service == "carParams":
            self.parser._update_car_params(data)
        elif service == "radarState":
            self.parser._update_radar_state(data, event_t)
        elif service == "liveTracks":
            self.parser._update_live_tracks(data, event_t)
        elif service in ("can", "sendcan"):
            self.parser._update_can_detections(data, event_t, service)

    def _update_carrot_navi(self, data: Any) -> None:
        try:
            generation = int(data.generation)
        except Exception:
            generation = -1
        if generation == self._carrot_navi_generation:
            return
        now = time.monotonic()
        self._carrot_navi_generation = generation
        self._carrot_navi = parse_carrot_navi(data, now, self._carrot_navi)
        self._carrot_navi, self._carrot_navi_next_expiry_s = fresh_carrot_navi(self._carrot_navi, now)

    def _current_carrot_navi(self, now: float):
        if now >= self._carrot_navi_next_expiry_s:
            self._carrot_navi, self._carrot_navi_next_expiry_s = fresh_carrot_navi(self._carrot_navi, now)
        return self._carrot_navi

    def _with_debug_state(self, state: ClusterUiState) -> ClusterUiState:
        force_debug_ui = self._hud_debug_mode in (2, 3)
        navi_mode = self._navi_debug_enabled or self._hud_debug_mode == 3
        if force_debug_ui:
            state = replace(state, debug_ui_visible=True)
        if not self._live_debug_enabled and not self._debug_plot_enabled and not navi_mode:
            return state

        profile_stage = self._profile_start()
        live_debug = self._live_debug_info() if self._live_debug_enabled else None
        self._profile_add("source.live.debug_info", profile_stage)

        profile_stage = self._profile_start()
        debug_plot = self._debug_plot_snapshot() if self._debug_plot_enabled else None
        self._profile_add("source.live.debug_plot", profile_stage)

        profile_stage = self._profile_start()
        navi_debug = self._navi_debug_info() if navi_mode else None
        state = self._with_external_nav_route(state) if navi_mode else state
        state = self._with_navi_speed_limit(state, navi_debug) if navi_mode else state
        self._profile_add("source.live.navi_debug", profile_stage)

        profile_stage = self._profile_start()
        state = replace(state, live_debug=live_debug, debug_plot=debug_plot, navi_debug=navi_debug)
        self._profile_add("source.live.debug_replace", profile_stage)
        return state

    def _live_debug_info(self) -> LiveDebugInfo | None:
        self._refresh_debug_params()
        cached = self._cached_live_debug

        live_delay_calibration_percent = cached.live_delay_calibration_percent if cached is not None else None
        live_delay_lateral_s = cached.live_delay_lateral_s if cached is not None else None
        if self._service_alive("liveDelay"):
            live_delay = self.sm["liveDelay"]
            live_delay_calibration_percent = self._first_present(
                safe_optional_float(live_delay, "calPerc"),
                live_delay_calibration_percent,
            )
            live_delay_lateral_s = self._first_present(
                safe_optional_float(live_delay, "lateralDelay"),
                live_delay_lateral_s,
            )
        steer_actuator_delay_s = self._effective_steer_actuator_delay(live_delay_lateral_s)

        live_torque_calibration_percent = cached.live_torque_calibration_percent if cached is not None else None
        live_torque_valid = cached.live_torque_valid if cached is not None else None
        live_torque_lat_accel_factor = cached.live_torque_lat_accel_factor if cached is not None else None
        live_torque_friction = cached.live_torque_friction if cached is not None else None
        if self._service_alive("liveTorqueParameters"):
            live_torque = self.sm["liveTorqueParameters"]
            live_torque_calibration_percent = self._first_present(
                safe_optional_float(live_torque, "calPerc"),
                live_torque_calibration_percent,
            )
            live_valid = safe_get(live_torque, "liveValid")
            live_torque_valid = bool(live_valid) if live_valid is not None else live_torque_valid
            live_torque_lat_accel_factor = self._first_present(
                safe_optional_float(live_torque, "latAccelFactorFiltered"),
                live_torque_lat_accel_factor,
            )
            if live_torque_lat_accel_factor is None:
                live_torque_lat_accel_factor = safe_optional_float(live_torque, "latAccelFactor")
            live_torque_friction = self._first_present(
                safe_optional_float(live_torque, "frictionCoefficientFiltered"),
                live_torque_friction,
            )
            if live_torque_friction is None:
                live_torque_friction = safe_optional_float(live_torque, "frictionCoefficient")

        live_steer_ratio = cached.live_steer_ratio if cached is not None else None
        if self._service_alive("liveParameters"):
            live_steer_ratio = self._first_present(
                safe_optional_float(self.sm["liveParameters"], "steerRatio"),
                live_steer_ratio,
            )

        info = LiveDebugInfo(
            live_delay_calibration_percent=live_delay_calibration_percent,
            live_delay_lateral_s=live_delay_lateral_s,
            live_torque_calibration_percent=live_torque_calibration_percent,
            live_torque_valid=live_torque_valid,
            live_torque_lat_accel_factor=live_torque_lat_accel_factor,
            live_torque_friction=live_torque_friction,
            live_steer_ratio=live_steer_ratio,
            custom_steer_ratio=self._custom_steer_ratio,
            steer_actuator_delay_s=steer_actuator_delay_s,
        )
        values = (
            info.live_delay_calibration_percent,
            info.live_delay_lateral_s,
            info.live_torque_calibration_percent,
            info.live_torque_valid,
            info.live_torque_lat_accel_factor,
            info.live_torque_friction,
            info.live_steer_ratio,
            info.custom_steer_ratio,
            info.steer_actuator_delay_s,
        )
        return info if any(value is not None for value in values) else None

    def _refresh_debug_params(self) -> None:
        now = time.monotonic()
        if now < self._next_debug_param_read_t:
            return
        self._next_debug_param_read_t = now + 1.0
        if self.params is None:
            return
        self._custom_steer_ratio = self._finite_param_float("CustomSR", 0.1)
        self._steer_actuator_delay_param_s = self._finite_param_float("SteerActuatorDelay", 0.01)
        self._show_plot_mode = self._param_int(SHOW_PLOT_MODE_PARAM, 0)
        self._cached_live_debug = self._read_cached_live_debug()
        self._cached_navi_image = self._read_navi_image_info()
        self._cached_navi_debug = self._read_navi_debug_info()

    def _debug_plot_snapshot(self) -> DebugPlotSnapshot | None:
        self._refresh_debug_params()
        mode = self._show_plot_mode
        if mode <= 0:
            return None
        values, title = self._make_debug_plot_data(mode)
        return DebugPlotSnapshot(mode=mode, title=title, values=values)

    def _make_debug_plot_data(self, show_plot_mode: int) -> tuple[tuple[float, float, float], str]:
        car_state = self._service_data("carState")
        long_plan = self._service_data("longitudinalPlan")
        car_control = self._service_data("carControl")
        controls_state = self._service_data("controlsState")
        model = self._service_data("modelV2")
        radar = self._service_data("radarState")
        live_params = self._service_data("liveParameters")

        a_ego = self._finite_attr(car_state, "aEgo")
        v_ego = self._finite_attr(car_state, "vEgo")
        accel_target = self._finite_index(safe_get(long_plan, "accels"), 0)
        speed_target = self._finite_index(safe_get(long_plan, "speeds"), 0)
        accel_out = self._finite_path(car_control, "actuators.accel")

        if show_plot_mode == 1:
            return (a_ego, accel_target, accel_out), "1.Accel (Y:a_ego, G:a_target, O:a_out)"

        if show_plot_mode == 2:
            return (speed_target, v_ego, a_ego), "2.Speed/Accel(Y:speed_0, G:v_ego, O:a_ego)"

        if show_plot_mode == 3:
            position = safe_get(model, "position")
            velocity = safe_get(model, "velocity")
            pos_32 = self._finite_index(safe_get(position, "x"), 32) if position is not None else 0.0
            vel_32 = self._finite_index(safe_get(velocity, "x"), 32) if velocity is not None else 0.0
            vel_0 = self._finite_index(safe_get(velocity, "x"), 0) if velocity is not None else 0.0
            return (pos_32, vel_32, vel_0), "3.Model(Y:pos_32, G:vel_32, O:vel_0)"

        if show_plot_mode == 4:
            lead = safe_get(radar, "leadOne")
            return (
                accel_target,
                self._finite_attr(lead, "aLeadK"),
                self._finite_attr(lead, "vRel"),
            ), "4.Lead(Y:accel, G:a_leadK, O:v_rel)"

        if show_plot_mode == 5:
            lead = safe_get(radar, "leadOne")
            return (
                a_ego,
                self._finite_attr(lead, "aLead"),
                self._finite_attr(lead, "jLead"),
            ), "5.Lead(Y:a_ego, G:a_lead, O:j_lead)"

        if show_plot_mode == 6:
            torque_state = self._path_value(controls_state, "lateralControlState.torqueState")
            return (
                self._finite_attr(torque_state, "actualLateralAccel") * 10.0,
                self._finite_attr(torque_state, "desiredLateralAccel") * 10.0,
                self._finite_attr(torque_state, "output") * 10.0,
            ), "6.Steer(Y:actual, G:desire, O:output) *10"

        if show_plot_mode == 7:
            return (
                self._finite_attr(car_state, "steeringAngleDeg"),
                self._finite_path(car_control, "actuators.steeringAngleDeg"),
                self._finite_attr(live_params, "angleOffsetDeg") * 10.0,
            ), "7.SteerA(Y:Actual, G:Target, O:Offset*10)"

        if show_plot_mode == 8:
            curvature = self._finite_path(car_control, "actuators.curvature") * 10000.0
            return (curvature, curvature, curvature), "8.Curvature(*10000)"

        return (0.0, 0.0, 0.0), "no data"

    def _navi_debug_info(self) -> NaviDebugInfo | None:
        self._refresh_debug_params()
        traffic_light = self._held_navi_traffic_light_at(time.monotonic())
        if self._cached_navi_debug is not None:
            return replace(
                self._cached_navi_debug,
                traffic_light=traffic_light,
                guidance_image=self._cached_navi_image,
            )
        route_count = len(self._nav_route_coords)
        lines = (f"Route points: {route_count}", "Waiting for POST /api/navi/{appVersion}")
        return NaviDebugInfo(
            title="NAVI receiver",
            lines=lines,
            severity="normal",
            traffic_light=traffic_light,
            guidance_image=self._cached_navi_image,
        )

    def _read_navi_debug_info(self) -> NaviDebugInfo | None:
        params = self.params_memory or self.params
        if params is None:
            return None
        try:
            raw = params.get("CarrotNaviDebug")
        except Exception:
            return None
        if not raw:
            return None
        try:
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            data = json.loads(raw)
        except Exception:
            return None
        if not isinstance(data, dict):
            return None
        title = str(data.get("title") or "Navi")
        severity = str(data.get("severity") or "normal")
        raw_lines = data.get("lines", ())
        lines = tuple(str(line)[:80] for line in raw_lines if str(line).strip()) if isinstance(raw_lines, list) else ()
        speed_limit_kph = self._parse_positive_int(data.get("speedLimitKph"), maximum=300)
        now = time.monotonic()
        received_t = finite_float(data.get("receivedMono"))
        if received_t is None:
            received_t = now
        parsed_traffic_light = self._parse_navi_traffic_light(data.get("trafficLight"))
        if parsed_traffic_light is not None:
            self._update_held_navi_traffic_light(parsed_traffic_light, received_t, now)
        traffic_light = self._held_navi_traffic_light_at(now)
        return NaviDebugInfo(
            title=title[:80],
            lines=lines[:12],
            severity=severity[:16],
            speed_limit_kph=speed_limit_kph,
            traffic_light=traffic_light,
            guidance_image=self._cached_navi_image,
        )

    def _read_navi_image_info(self) -> NaviGuidanceImage | None:
        params = self.params_memory or self.params
        if params is None:
            return None
        try:
            raw = params.get("CarrotNaviImage")
        except Exception:
            return None
        if not raw:
            return None
        try:
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            data = json.loads(raw)
        except Exception:
            return None
        if not isinstance(data, dict):
            return None
        image_base64 = str(data.get("imageBase64") or "")
        image_hash = str(data.get("imageHash") or "")[:32]
        width = self._parse_positive_int(data.get("imageWidth"), maximum=10000) or 0
        height = self._parse_positive_int(data.get("imageHeight"), maximum=10000) or 0
        if (
            image_base64
            and (
                len(image_base64) > LIVE_NAVI_IMAGE_BASE64_MAX_CHARS
                or width > LIVE_NAVI_IMAGE_MAX_DIMENSION
                or height > LIVE_NAVI_IMAGE_MAX_DIMENSION
            )
        ):
            image_base64 = ""
        if not image_base64 and not image_hash:
            return None
        return NaviGuidanceImage(
            image_base64=image_base64,
            image_mime=str(data.get("imageMime") or "")[:64],
            image_hash=image_hash,
            width=width,
            height=height,
        )

    def _parse_navi_traffic_light(self, value: Any) -> NaviTrafficLightInfo | None:
        if not isinstance(value, dict):
            return None
        return NaviTrafficLightInfo(
            distance_m=self._parse_positive_int(value.get("distanceM"), maximum=10000),
            red_s=self._parse_positive_int(value.get("redS"), maximum=999),
            straight_s=self._parse_positive_int(value.get("straightS"), maximum=999),
            left_s=self._parse_positive_int(value.get("leftS"), maximum=999),
            right_s=self._parse_positive_int(value.get("rightS"), maximum=999),
            uturn_s=self._parse_positive_int(value.get("uturnS"), maximum=999),
            red_on=self._parse_optional_bool(value.get("redOn")),
            straight_on=self._parse_optional_bool(value.get("straightOn")),
            left_on=self._parse_optional_bool(value.get("leftOn")),
            right_on=self._parse_optional_bool(value.get("rightOn")),
            uturn_on=self._parse_optional_bool(value.get("uturnOn")),
        )

    def _update_held_navi_traffic_light(
        self,
        traffic_light: NaviTrafficLightInfo,
        received_t: float,
        now: float,
    ) -> None:
        if now - received_t > NAVI_TRAFFIC_LIGHT_HOLD_SECONDS:
            return
        self._held_navi_traffic_light = traffic_light
        self._held_navi_traffic_light_received_t = received_t

    def _held_navi_traffic_light_at(self, now: float) -> NaviTrafficLightInfo | None:
        traffic_light = self._held_navi_traffic_light
        received_t = self._held_navi_traffic_light_received_t
        if traffic_light is None or received_t is None:
            return None
        age_s = max(0.0, now - received_t)
        if age_s > NAVI_TRAFFIC_LIGHT_HOLD_SECONDS:
            self._held_navi_traffic_light = None
            self._held_navi_traffic_light_received_t = None
            return None
        elapsed_s = int(age_s)

        def countdown(seconds: int | None) -> int | None:
            if seconds is None:
                return None
            return max(0, int(seconds) - elapsed_s)

        return replace(
            traffic_light,
            red_s=countdown(traffic_light.red_s),
            straight_s=countdown(traffic_light.straight_s),
            left_s=countdown(traffic_light.left_s),
            right_s=countdown(traffic_light.right_s),
            uturn_s=countdown(traffic_light.uturn_s),
        )

    @staticmethod
    def _parse_positive_int(value: Any, maximum: int) -> int | None:
        try:
            parsed = int(float(value))
        except (TypeError, ValueError):
            return None
        if parsed <= 0 or parsed > maximum:
            return None
        return parsed

    @staticmethod
    def _parse_optional_bool(value: Any) -> bool | None:
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in ("1", "true", "yes", "on"):
                return True
            if normalized in ("0", "false", "no", "off"):
                return False
        try:
            return bool(int(value))
        except Exception:
            return None

    def _update_nav_route(self, data: Any) -> None:
        coords = safe_get(data, "coordinates")
        if not coords:
            self._nav_route_coords = ()
            self._nav_route_model_path = ()
            self._nav_route_anchor = None
            return

        parsed: list[tuple[float, float]] = []
        for coord in _limited_items(coords, LIVE_NAV_ROUTE_MAX_POINTS):
            lat = finite_float(safe_get(coord, "latitude"))
            lon = finite_float(safe_get(coord, "longitude"))
            if lat is None or lon is None:
                continue
            if not -90.0 <= lat <= 90.0 or not -180.0 <= lon <= 180.0:
                continue
            parsed.append((lat, lon))

        self._nav_route_coords = tuple(parsed)
        self._nav_route_model_path = ()
        self._nav_route_anchor = None

    def _with_external_nav_route(self, state: ClusterUiState) -> ClusterUiState:
        path = self._external_nav_route_model_path()
        if len(path) < 2:
            return state
        return replace(
            state,
            model_path=path,
            planned_speed_kph=None,
            planned_accel_mps2=None,
            planned_curvature_m_inv=None,
        )

    def _with_navi_speed_limit(self, state: ClusterUiState, navi_debug: NaviDebugInfo | None) -> ClusterUiState:
        if state.speed_limit_kph is not None:
            return state
        if navi_debug is None or navi_debug.speed_limit_kph is None:
            return state
        return replace(state, speed_limit_kph=navi_debug.speed_limit_kph, speed_limit_source="n")

    def _external_nav_route_model_path(self) -> tuple[ModelPathPoint, ...]:
        anchor = self._nav_route_anchor_from_carrot_man()
        if anchor is None or len(self._nav_route_coords) < 2:
            return ()
        if self._nav_route_anchor == anchor and self._nav_route_model_path:
            return self._nav_route_model_path

        lat0, lon0, heading_deg = anchor
        heading_rad = math.radians(heading_deg)
        cos_h = math.cos(heading_rad)
        sin_h = math.sin(heading_rad)
        meters_per_lat = 40008000.0 / 360.0
        meters_per_lon = meters_per_lat * math.cos(math.radians(lat0))
        points: list[ModelPathPoint] = [ModelPathPoint(forward_m=0.0, lateral_m=0.0)]
        previous_forward = 0.0

        for lat, lon in self._nav_route_coords:
            east_m = (lon - lon0) * meters_per_lon
            north_m = (lat - lat0) * meters_per_lat
            lateral_m = east_m * cos_h - north_m * sin_h
            forward_m = east_m * sin_h + north_m * cos_h
            if forward_m < 0.0 or forward_m > 180.0:
                continue
            if abs(lateral_m) > 40.0:
                continue
            if forward_m <= previous_forward + 0.25:
                continue
            points.append(ModelPathPoint(forward_m=forward_m, lateral_m=lateral_m))
            previous_forward = forward_m
            if len(points) >= 96:
                break

        self._nav_route_anchor = anchor
        self._nav_route_model_path = tuple(points)
        return self._nav_route_model_path

    def _nav_route_anchor_from_carrot_man(self) -> tuple[float, float, float] | None:
        carrot_man = self._service_data("carrotMan")
        lat = self._finite_attr(carrot_man, "xPosLat", 0.0)
        lon = self._finite_attr(carrot_man, "xPosLon", 0.0)
        heading = self._finite_attr(carrot_man, "xPosAngle", 0.0)
        if abs(lat) < 0.000001 or abs(lon) < 0.000001:
            return None
        if not -90.0 <= lat <= 90.0 or not -180.0 <= lon <= 180.0:
            return None
        return (lat, lon, heading % 360.0)

    def _read_cached_live_debug(self) -> LiveDebugInfo | None:
        if self.params is None:
            return None

        live_delay = self._event_service_from_param("LiveDelay", "liveDelay")
        live_torque = self._event_service_from_param("LiveTorqueParameters", "liveTorqueParameters")
        live_parameters = self._event_service_from_param("LiveParametersV2", "liveParameters")
        live_steer_ratio = None
        if live_parameters is not None:
            live_steer_ratio = safe_optional_float(live_parameters, "steerRatio")
        if live_steer_ratio is None:
            live_steer_ratio = self._legacy_live_parameters_steer_ratio()

        live_torque_valid = None
        if live_torque is not None:
            live_valid = safe_get(live_torque, "liveValid")
            live_torque_valid = bool(live_valid) if live_valid is not None else None

        info = LiveDebugInfo(
            live_delay_calibration_percent=safe_optional_float(live_delay, "calPerc") if live_delay is not None else None,
            live_delay_lateral_s=safe_optional_float(live_delay, "lateralDelay") if live_delay is not None else None,
            live_torque_calibration_percent=(
                safe_optional_float(live_torque, "calPerc") if live_torque is not None else None
            ),
            live_torque_valid=live_torque_valid,
            live_torque_lat_accel_factor=(
                safe_optional_float(live_torque, "latAccelFactorFiltered") if live_torque is not None else None
            ),
            live_torque_friction=(
                safe_optional_float(live_torque, "frictionCoefficientFiltered") if live_torque is not None else None
            ),
            live_steer_ratio=live_steer_ratio,
        )
        values = (
            info.live_delay_calibration_percent,
            info.live_delay_lateral_s,
            info.live_torque_calibration_percent,
            info.live_torque_valid,
            info.live_torque_lat_accel_factor,
            info.live_torque_friction,
            info.live_steer_ratio,
        )
        return info if any(value is not None for value in values) else None

    def _event_service_from_param(self, param_key: str, service_name: str) -> Any | None:
        if self.params is None or self.log is None:
            return None
        try:
            data = self.params.get(param_key)
        except Exception:
            return None
        if not data:
            return None
        try:
            event = self.messaging.log_from_bytes(data, self.log.Event)
            return safe_get(event, service_name)
        except Exception:
            return None

    def _legacy_live_parameters_steer_ratio(self) -> float | None:
        if self.params is None:
            return None
        try:
            data = self.params.get("LiveParameters")
        except Exception:
            return None
        if not data:
            return None
        if isinstance(data, dict):
            return finite_float(data.get("steerRatio"))
        try:
            if isinstance(data, (bytes, bytearray)):
                data = data.decode("utf-8")
            parsed = json.loads(data)
        except Exception:
            return None
        if not isinstance(parsed, dict):
            return None
        return finite_float(parsed.get("steerRatio"))

    def _effective_steer_actuator_delay(self, live_delay_lateral_s: float | None) -> float | None:
        if self._steer_actuator_delay_param_s is not None and self._steer_actuator_delay_param_s > 0.0:
            return self._steer_actuator_delay_param_s
        if live_delay_lateral_s is not None:
            return live_delay_lateral_s
        return self._steer_actuator_delay_param_s

    @staticmethod
    def _first_present(value: Any | None, fallback: Any | None) -> Any | None:
        return value if value is not None else fallback

    def _finite_param_float(self, key: str, scale: float) -> float | None:
        if self.params is None:
            return None
        try:
            value = float(self.params.get_float(key)) * scale
        except Exception:
            return None
        return value if math.isfinite(value) else None

    def _param_int(self, key: str, default: int) -> int:
        if self.params is None:
            return default
        try:
            value = int(self.params.get_int(key))
        except Exception:
            return default
        return value if value >= 0 else default

    def _service_data(self, service: str) -> Any | None:
        try:
            return self.sm[service]
        except Exception:
            return None

    @staticmethod
    def _path_value(obj: Any | None, path: str) -> Any | None:
        current = obj
        for name in path.split("."):
            if current is None:
                return None
            current = safe_get(current, name)
        return current

    def _finite_path(self, obj: Any | None, path: str, default: float = 0.0) -> float:
        return self._finite_value(self._path_value(obj, path), default)

    def _finite_attr(self, obj: Any | None, name: str, default: float = 0.0) -> float:
        return self._finite_value(safe_get(obj, name), default)

    def _finite_index(self, values: Any | None, index: int, default: float = 0.0) -> float:
        if values is None or index < 0:
            return default
        try:
            value = values[index]
        except Exception:
            return default
        return self._finite_value(value, default)

    @staticmethod
    def _finite_value(value: Any | None, default: float = 0.0) -> float:
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            return default
        return parsed if math.isfinite(parsed) else default

    def _update_current_speed(self) -> None:
        if not self._service_alive("carState"):
            return
        try:
            self.parser.current_speed_kph = clamp(float(self.sm["carState"].vEgo) * 3.6, 0.0, 260.0)
        except Exception:
            return

    def _service_time(self, service: str) -> float:
        try:
            mono_time = self.sm.logMonoTime.get(service, 0)
        except AttributeError:
            mono_time = 0
        return float(mono_time) / 1_000_000_000.0 if mono_time else time.monotonic()

    def _service_receive_time(self, service: str) -> float | None:
        try:
            receive_t = float(self.sm.recv_time.get(service, 0.0))
        except (AttributeError, TypeError, ValueError):
            return None
        return receive_t if math.isfinite(receive_t) and receive_t > 0.0 else None

    def _service_alive(self, service: str) -> bool:
        try:
            return bool(self.sm.alive.get(service, False))
        except AttributeError:
            return False

    def _service_updated(self, service: str) -> bool:
        try:
            return bool(self.sm.updated.get(service, False))
        except AttributeError:
            return False

    def _service_valid(self, service: str) -> bool:
        try:
            return bool(self.sm.valid.get(service, True))
        except AttributeError:
            return True


def standby_state() -> ClusterUiState:
    return ClusterUiState(
        speed_kph=0.0,
        accel_mps2=0.0,
        steering=0.0,
        speed_limit_kph=None,
        speed_limit_source=None,
        cruise_kph=None,
        cruise_display_state="off",
        gear_text=None,
        cruise_gap=None,
        lfa_active=None,
        left_signal=False,
        right_signal=False,
        left_blindspot=False,
        right_blindspot=False,
        lane_change=None,
        lane_change_phase="idle",
        lane_change_progress=0.0,
        highlight_lane=None,
        highlight_lane_offset=None,
        ego_lane_offset=0.0,
        road_view_lane_position=0.0,
        camera_lane_center_offset_m=None,
        lane_width_m=DEFAULT_LANE_WIDTH_M,
        steering_angle_deg=None,
        surround_yaw_deg=0.0,
        surround_pitch_deg=0.0,
        surround_view_active=False,
        lanes=(
            LaneMarking(-0.5, BLUE, "solid", width=7),
            LaneMarking(0.5, BLUE, "solid", width=7),
        ),
    )
