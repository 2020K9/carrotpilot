#!/usr/bin/env python3
import time
import numpy as np

from openpilot.cereal import log
import openpilot.cereal.messaging as messaging
from opendbc.car.interfaces import ACCEL_MIN, ACCEL_MAX
from openpilot.common.constants import CV
from openpilot.common.filter_simple import FirstOrderFilter
from openpilot.common.realtime import DT_MDL
from openpilot.selfdrive.modeld.constants import ModelConstants
from openpilot.selfdrive.controls.lib.longcontrol import LongCtrlState
from openpilot.selfdrive.controls.lib.longitudinal_mpc_lib.long_mpc import LongitudinalMpc, N
from openpilot.selfdrive.controls.lib.longitudinal_mpc_lib.long_mpc import T_IDXS as T_IDXS_MPC
from openpilot.selfdrive.controls.lib.drive_helpers import CONTROL_N, get_accel_from_plan, is_volkswagen_meb
from openpilot.selfdrive.controls.lib.cutin_predecel import (
  apply_cutin_predecel_accel_limit,
  get_cutin_predecel_accel_limit,
)
from openpilot.selfdrive.controls.lib.longitudinal_preview import (
  apply_preview_target,
  clip_preview_offset,
  get_lead_preview_request,
  rate_limit_preview,
)
from openpilot.selfdrive.controls.lib.turn_accel import get_future_curvature, limit_accel_in_turns
from openpilot.selfdrive.car.cruise import V_CRUISE_MAX, V_CRUISE_UNSET
from openpilot.common.swaglog import cloudlog
from openpilot.common.params import Params
from openpilot.common.stopping_params import get_stopping_speed
from openpilot.selfdrive.carrot.carrot_man_input import get_carrot_man
from openpilot.selfdrive.carrot.signal_stop_prepare import PrepareAccel
from openpilot.selfdrive.controls.lib.cruise_coasting import CruiseCoastingPlan, coasting_percent, no_coasting_lead
from openpilot.selfdrive.controls.lib.tesla_traffic_stop import STOP_BUFFER, create_tesla_traffic_stop


LON_MPC_STEP = 0.2  # first step is 0.2s
A_CRUISE_MIN = -2.0 #-1.2
A_CRUISE_MAX_VALS = [1.6, 1.2, 0.8, 0.6]
A_CRUISE_MAX_BP = [0., 10.0, 25., 40.]
CONTROL_N_T_IDX = ModelConstants.T_IDXS[:CONTROL_N]
ALLOW_THROTTLE_THRESHOLD = 0.5
MIN_ALLOW_THROTTLE_SPEED = 2.5
RESET_DECEL_RAMP_TIME = 2.0


def get_max_accel(v_ego):
  return np.interp(v_ego, A_CRUISE_MAX_BP, A_CRUISE_MAX_VALS)

def get_coast_accel(pitch):
  return np.sin(pitch) * -5.65 - 0.3  # fitted from data using xx/projects/allow_throttle/compute_coast_accel.py


class LongitudinalPlanner:
  def __init__(self, CP, init_v=0.0, init_a=0.0, dt=DT_MDL):
    self.CP = CP
    self.mpc = LongitudinalMpc(dt=dt)
    self.fcw = False
    # VW MEB(ID.4/ID.5)에서만 True. 가속 오버라이드 중 출발 FCW 오탐을 끄기 위한 게이트.
    self.is_vw_meb = is_volkswagen_meb(CP)
    self.dt = dt
    self.allow_throttle = True

    self.a_desired = init_a
    self.v_desired_filter = FirstOrderFilter(init_v, 2.0, self.dt)
    self.prev_accel_clip = [ACCEL_MIN, ACCEL_MAX]
    self.output_a_target = 0.0
    self.output_a_target_base = 0.0
    self.output_v_target_now = 0.0
    self.output_j_target_now = 0.0
    self.output_should_stop = False
    self._signal_prepare_accel = PrepareAccel()
    self._signal_prepare_time = None
    self._signal_prepare_previous = None
    self.lead_preview = 0.0
    self.lead_preview_action_time = 0.0
    self.lead_preview_accel = 0.0
    self.lead_track_ids = [-1, -1]
    self.lead_track_frames = [0, 0]

    self.v_desired_trajectory = np.zeros(CONTROL_N)
    self.a_desired_trajectory = np.zeros(CONTROL_N)
    self.j_desired_trajectory = np.zeros(CONTROL_N)
    self.solverExecutionTime = 0.0

    self.vCluRatio = 1.0
    self.reset_decel_timer = 0
    self.reset_decel_start_a = 0.0

    self.v_cruise_kph = 0.0

    self.params = Params()
    self.coasting = CruiseCoastingPlan()
    self.coasting_percent = 0
    self.coasting_param_time = 1.0
    self.coasting_target = 0.0
    self.tesla_traffic_stop = create_tesla_traffic_stop(CP)
    self.tesla_traffic_decision = None
    self.tesla_traffic_blended = False
    self._tesla_traffic_status = None
    self._tesla_traffic_log_ns = 0

  def update_tesla_traffic_stop(self, sm, carrot, reset_state, now=None):
    if self.tesla_traffic_stop is None:
      return
    now = time.clock_gettime_ns(getattr(time, "CLOCK_BOOTTIME", time.CLOCK_MONOTONIC)) if now is None else now
    decision = self.tesla_traffic_stop.update(
      sm['carState'], now, engaged=sm['selfdriveState'].enabled,
      control_active=(not reset_state and sm['carControl'].longActive and sm.all_checks(
        service_list=['carState', 'carControl', 'selfdriveState', 'controlsState', 'modelV2'])),
    )
    self.tesla_traffic_decision = decision
    if decision.fault:
      carrot.events.add(log.OnroadEvent.EventName.teslaTrafficStopTakeover)
    elif decision.warn:
      carrot.events.add(log.OnroadEvent.EventName.teslaTrafficStopWarning)
    if decision.reason != self._tesla_traffic_status or (decision.active and now - self._tesla_traffic_log_ns >= 1_000_000_000):
      cloudlog.event("tesla_can_traffic_stop", reason=decision.reason, active=decision.active,
                     distance=decision.distance, required_decel=decision.required_decel,
                     sample_ns=int(sm['carState'].teslaTrafficControl.sampleMonoTime))
      self._tesla_traffic_status, self._tesla_traffic_log_ns = decision.reason, now

  def apply_tesla_traffic_stop(self):
    decision = self.tesla_traffic_decision
    if decision is not None and decision.active:
      self.coasting_target = 0.0
      self.coasting.reset()
      if decision.hold:
        self.output_should_stop = True
        self.output_v_target_now = 0.0
        self.output_a_target = min(self.output_a_target, 0.0)
        self.a_desired = min(self.a_desired, 0.0)

  def update_lead_tracks(self, radar_state):
    for index, lead in enumerate((radar_state.leadOne, radar_state.leadTwo)):
      track_id = int(lead.radarTrackId) if lead.status and lead.radar and lead.radarTrackId >= 0 else -1
      if track_id >= 0 and track_id == self.lead_track_ids[index]:
        self.lead_track_frames[index] += 1
      elif track_id >= 0:
        self.lead_track_ids[index] = track_id
        self.lead_track_frames[index] = 1
      else:
        self.lead_track_ids[index] = -1
        self.lead_track_frames[index] = 0
    return tuple(self.lead_track_frames)

  @staticmethod
  def parse_model(model_msg):
    if (len(model_msg.position.x) == ModelConstants.IDX_N and
      len(model_msg.velocity.x) == ModelConstants.IDX_N and
      len(model_msg.acceleration.x) == ModelConstants.IDX_N):
      x = np.interp(T_IDXS_MPC, ModelConstants.T_IDXS, model_msg.position.x)
      v = np.interp(T_IDXS_MPC, ModelConstants.T_IDXS, model_msg.velocity.x)
      a = np.interp(T_IDXS_MPC, ModelConstants.T_IDXS, model_msg.acceleration.x)
      j = np.zeros(len(T_IDXS_MPC))
    else:
      x = np.zeros(len(T_IDXS_MPC))
      v = np.zeros(len(T_IDXS_MPC))
      a = np.zeros(len(T_IDXS_MPC))
      j = np.zeros(len(T_IDXS_MPC))
    if len(model_msg.meta.disengagePredictions.gasPressProbs) > 1:
      throttle_prob = model_msg.meta.disengagePredictions.gasPressProbs[1]
    else:
      throttle_prob = 1.0
    return x, v, a, j, throttle_prob

  def update(self, sm, carrot):
    self.coasting_param_time += self.dt
    if self.coasting_param_time >= 1.0:
      self.coasting_param_time = 0.0
      self.coasting_percent = coasting_percent(self.params.get_int('CruiseCoastingPercent'))
    self.mpc.mode = 'blended' if sm['selfdriveState'].experimentalMode else 'acc'

    if len(sm['carControl'].orientationNED) == 3:
      accel_coast = get_coast_accel(sm['carControl'].orientationNED[1])
    else:
      accel_coast = ACCEL_MAX

    v_ego = sm['carState'].vEgo
    v_cruise_kph = min(sm['carState'].vCruise, V_CRUISE_MAX)

    self.v_cruise_kph = carrot.update(sm, v_cruise_kph, self.mpc.mode)
    self.mpc.mode = carrot.mode
    v_cruise = self.v_cruise_kph * CV.KPH_TO_MS

    vCluRatio = sm['carState'].vCluRatio
    if vCluRatio > 0.5:
      self.vCluRatio = vCluRatio
      v_cruise *= vCluRatio

    v_cruise_initialized = sm['carState'].vCruise != V_CRUISE_UNSET

    long_control_off = sm['controlsState'].longControlState == LongCtrlState.off
    force_slow_decel = sm['controlsState'].forceDecel

    # Reset current state when not engaged, or user is controlling the speed
    reset_state = long_control_off if self.CP.openpilotLongitudinalControl else not sm['selfdriveState'].enabled
    # PCM cruise speed may be updated a few cycles later, check if initialized
    reset_state = reset_state or not v_cruise_initialized or carrot.soft_hold_active
    if getattr(self, 'tesla_traffic_stop', None) is not None:
      self.update_tesla_traffic_stop(sm, carrot, reset_state)
      self.tesla_traffic_blended = self.mpc.mode == 'blended' and self.tesla_traffic_decision.active
      if self.tesla_traffic_decision.active:
        self.mpc.mode = 'acc'

    # No change cost when user is controlling the speed, or when standstill
    prev_accel_constraint = not (reset_state or sm['carState'].standstill)

    if self.mpc.mode == 'acc':
      #accel_limits = [A_CRUISE_MIN, get_max_accel(v_ego)]
      accel_limits = [A_CRUISE_MIN, carrot.get_carrot_accel(v_ego)]
      curvature_future = get_future_curvature(sm['modelV2'], sm['controlsState'].desiredCurvature)
      a_lat_max = 3.0
      accel_limits_turns = limit_accel_in_turns(
        v_ego, curvature_future, accel_limits, a_lat_max,
        model_msg=sm['modelV2'], v_cruise=v_cruise,
        current_curvature=sm['controlsState'].curvature,
      )
    else:
      accel_limits = [ACCEL_MIN, ACCEL_MAX]
      accel_limits_turns = [ACCEL_MIN, ACCEL_MAX]

    coasting_turn_blocked = accel_limits_turns[1] < accel_limits[1] - 0.05

    if reset_state:
      self.v_desired_filter.x = v_ego
      # Clip aEgo to cruise limits to prevent large accelerations when becoming active
      self.a_desired = np.clip(sm['carState'].aEgo, accel_limits[0], accel_limits[1])

      self.mpc.prev_a = np.full(N+1, self.a_desired) ## carrot

      self.reset_decel_timer = int(RESET_DECEL_RAMP_TIME / self.dt)
      self.reset_decel_start_a = self.a_desired

    elif self.reset_decel_timer > 0:
      ramp_steps = max(1, int(RESET_DECEL_RAMP_TIME / self.dt))
      t = float(np.clip(self.reset_decel_timer / ramp_steps, 0.0, 1.0))
      self.reset_decel_timer -= 1

      # 2초 동안 감속 하한을 현재 가속도 근처에서 원래 limit으로 천천히 복귀
      soft_min_accel = min(0.0, self.reset_decel_start_a - 0.05)
      ramped_min_accel = soft_min_accel * t + accel_limits_turns[0] * (1.0 - t)

      accel_limits_turns[0] = max(
        accel_limits_turns[0],
        min(0.0, ramped_min_accel)
      )

    # Prevent divergence, smooth in current v_ego
    self.v_desired_filter.x = max(0.0, self.v_desired_filter.update(v_ego))
    x, v, a, j, throttle_prob = self.parse_model(sm['modelV2'])
    # Don't clip at low speeds since throttle_prob doesn't account for creep
    self.allow_throttle = True #throttle_prob > ALLOW_THROTTLE_THRESHOLD or v_ego <= MIN_ALLOW_THROTTLE_SPEED

    if not self.allow_throttle:
      clipped_accel_coast = max(accel_coast, accel_limits_turns[0])
      clipped_accel_coast_interp = np.interp(v_ego, [MIN_ALLOW_THROTTLE_SPEED, MIN_ALLOW_THROTTLE_SPEED*2], [accel_limits_turns[1], clipped_accel_coast])
      accel_limits_turns[1] = min(accel_limits_turns[1], clipped_accel_coast_interp)

    if force_slow_decel:
      v_cruise = 0.0
    cutin_predecel_limit = (
      get_cutin_predecel_accel_limit(sm['radarState'])
      if not reset_state and not sm['carState'].gasPressed
      else None
    )
    # clip limits, cannot init MPC outside of bounds
    accel_limits_turns[0] = min(accel_limits_turns[0], self.a_desired + 0.05)
    accel_limits_turns[1] = apply_cutin_predecel_accel_limit(
      accel_limits_turns[1],
      self.a_desired,
      cutin_predecel_limit,
    )

    lead_track_frames = self.update_lead_tracks(sm['radarState'])
    # Response strength is a driver preference at every following-distance level.
    lead_accel_response_enabled = (
      carrot.leadAccelResponse > 0
      and not carrot.lane_change_active
      and not reset_state
      and not sm['carState'].gasPressed
      and not force_slow_decel
      and accel_limits_turns[1] > 0.0
      and not self.output_should_stop
    )
    self.mpc.set_accel_limits(accel_limits_turns[0], accel_limits_turns[1])
    self.mpc.set_cur_state(self.v_desired_filter.x, self.a_desired)
    self.mpc.update(
      carrot, reset_state, sm['radarState'], v_cruise, x, v, a, j,
      personality=sm['selfdriveState'].personality,
      prev_accel_constraint=prev_accel_constraint,
      jerk_factor=carrot.jerk_factor,
      a_change_cost_starting=carrot.aChangeCostStarting,
      lead_accel_response_enabled=lead_accel_response_enabled,
      lead_gap_enabled=(
        not reset_state and not sm['carState'].gasPressed
        and not force_slow_decel and not carrot.lane_change_active
      ),
      cutout_relief_enabled=(
        not reset_state and not sm['carState'].gasPressed
        and not force_slow_decel and not self.output_should_stop
      ),
      lead_track_frames=lead_track_frames,
      measured_a_ego=sm['carState'].aEgo,
      tesla_stop_distance=(
        max(0.0, self.tesla_traffic_decision.distance - STOP_BUFFER)
        if self.tesla_traffic_decision is not None and self.tesla_traffic_decision.active else None
      ),
    )

    self.v_desired_trajectory = np.interp(CONTROL_N_T_IDX, T_IDXS_MPC, self.mpc.v_solution)
    self.a_desired_trajectory = np.interp(CONTROL_N_T_IDX, T_IDXS_MPC, self.mpc.a_solution)
    self.j_desired_trajectory = np.interp(CONTROL_N_T_IDX, T_IDXS_MPC[:-1], self.mpc.j_solution)

    # TODO counter is only needed because radar is glitchy, remove once radar is gone
    # VW MEB: 운전자가 가속페달을 밟는 중(오버라이드)이면 출발 FCW 오탐을 억제. 정지 후 급출발 시
    # 레이더 dRel 지연(stale)·vLead 음수 아티팩트로 한 프레임 충돌예측이 떴음. gasPressed 동안엔
    # 운전자가 직접 가속 제어 중이라 경고 의미가 약하고, FCW는 경고표시일 뿐 제동에는 영향 없음.
    # 또 MEB는 crash_cnt 문턱을 높여(>15 ≈ 0.8s 지속) 잠깐 스치는 marginal 예측의 nuisance "삐"를
    # 줄인다. 실제 제동(MPC)은 fcw와 무관하게 동작하므로 안전성 저하 없음. 타 차종은 기존 >2 유지.
    # MEB 추가 억제: 차가 '가속 중'(aEgo>1.0)이면 충돌 임박 상태가 아니므로(임박하면 감속부터 함)
    # 출발/따라잡기 중 nuisance "삐"를 끈다. gasPressed가 순간 누락돼도 이걸로 커버. 진짜 위험은
    # 차가 감속(aEgo<0)으로 들어가면서 그때 FCW가 뜨고, 제동은 fcw와 무관하게 이미 작동한다.
    fcw_crash_thresh = 15 if self.is_vw_meb else 2
    meb_suppress = self.is_vw_meb and (sm['carState'].gasPressed or sm['carState'].aEgo > 1.0)
    self.fcw = (self.mpc.crash_cnt > fcw_crash_thresh and not sm['carState'].standstill and not reset_state
                and not meb_suppress)
    if self.fcw:
      cloudlog.info("FCW triggered")

    # Interpolate 0.05 seconds and save as starting point for next iteration
    a_prev = self.a_desired
    self.a_desired = float(np.interp(self.dt, CONTROL_N_T_IDX, self.a_desired_trajectory))
    self.v_desired_filter.x = self.v_desired_filter.x + self.dt * (self.a_desired + a_prev) / 2.0

    longitudinalActuatorDelay = self.params.get_float("LongActuatorDelay")*0.01
    vEgoStopping = get_stopping_speed(self.params)
    action_t =  longitudinalActuatorDelay + DT_MDL

    output_a_target_base, output_should_stop_mpc, output_v_target_mpc, _ = get_accel_from_plan(
      self.v_desired_trajectory,
      self.a_desired_trajectory,
      CONTROL_N_T_IDX,
      action_t=action_t,
      vEgoStopping=vEgoStopping,
    )

    lead_index = 1 if self.mpc.source == 'lead1' else 0
    leads = (sm['radarState'].leadOne, sm['radarState'].leadTwo)
    lead = leads[lead_index]
    preview_enabled = (
      self.mpc.mode == 'acc'
      and not reset_state
      and not sm['carState'].gasPressed
      and not sm['carState'].brakePressed
      and not (getattr(self, 'tesla_traffic_decision', None) and self.tesla_traffic_decision.active)
    )
    preview_request = get_lead_preview_request(
      carrot.myDrivingMode,
      lead_status=(
        preview_enabled
        and lead.status
        and lead.radar
        and lead.radarTrackId >= 0
      ),
      a_lead=lead.aLeadK,
      a_ego=sm['carState'].aEgo,
    )
    if preview_enabled:
      # Losing radar support stops requesting preview; it must not erase an
      # existing braking correction in one frame. Release on the current MPC
      # trajectory, without retaining the old lead or delaying new braking.
      requested_preview = rate_limit_preview(
        preview_request.offset_s,
        self.lead_preview,
      )
      self.lead_preview = clip_preview_offset(action_t, requested_preview)
      self.lead_preview_accel = preview_request.lead_accel_signal
      self.lead_preview_action_time = action_t + self.lead_preview
    else:
      self.lead_preview = 0.0
      self.lead_preview_accel = 0.0
      self.lead_preview_action_time = action_t

    output_a_target_preview, _, _, _ = get_accel_from_plan(
      self.v_desired_trajectory,
      self.a_desired_trajectory,
      CONTROL_N_T_IDX,
      action_t=self.lead_preview_action_time,
      vEgoStopping=vEgoStopping,
    )
    output_a_target_mpc = apply_preview_target(
      output_a_target_base,
      output_a_target_preview,
      carrot.myDrivingMode,
    ) if preview_enabled else output_a_target_base
    output_a_target_e2e = sm['modelV2'].action.desiredAcceleration
    output_should_stop_e2e = sm['modelV2'].action.shouldStop
    output_v_target_now_e2e = sm['modelV2'].action.desiredVelocity

    if self.mpc.mode == 'acc' and not getattr(self, 'tesla_traffic_blended', False):
      output_a_target = output_a_target_mpc
      output_v_target_now = output_v_target_mpc
      self.output_should_stop = output_should_stop_mpc
    else:
      output_a_target = min(output_a_target_mpc, output_a_target_e2e)
      output_v_target_now = min(output_v_target_mpc, output_v_target_now_e2e)
      self.output_should_stop = output_should_stop_e2e or output_should_stop_mpc

    #for idx in range(2):
    #  accel_clip[idx] = np.clip(accel_clip[idx], self.prev_accel_clip[idx] - 0.05, self.prev_accel_clip[idx] + 0.05)
    #self.output_a_target = np.clip(output_a_target, accel_clip[0], accel_clip[1])
    #self.prev_accel_clip = accel_clip
    self.output_a_target_base = output_a_target_base
    self.output_a_target = output_a_target
    self.output_v_target_now = output_v_target_now
    self.output_j_target_now = self.j_desired_trajectory[0]

    self.update_coasting(sm, carrot, v_cruise_kph, v_cruise, reset_state,
                         force_slow_decel, coasting_turn_blocked, cutin_predecel_limit)
    self.apply_signal_stop_prepare(sm, carrot, reset_state)
    self.apply_signal_start_guard(carrot, v_ego)
    if getattr(self, 'tesla_traffic_decision', None) is not None:
      self.apply_tesla_traffic_stop()

  def apply_signal_stop_prepare(self, sm, carrot, reset_state, now=None):
    from openpilot.selfdrive.carrot.signal_stop_prepare import prepare_lead_blocked
    now = time.monotonic() if now is None else now
    elapsed = now-(now-self.dt) if self._signal_prepare_time is None else now-self._signal_prepare_time
    self._signal_prepare_time = now
    cs = sm['carState']
    active = (carrot.prepare_decision is not None and carrot.prepare_decision.active
              and carrot.prepare_control_active
              and not reset_state and not cs.gasPressed and not cs.brakePressed
              and 5/3.6 < cs.vEgo < 82/3.6 and cs.softHoldActive == 0
              and 0 < elapsed <= .2
              and not self.output_should_stop and self.mpc.mode == 'acc'
              and not prepare_lead_blocked(sm['radarState']))
    previous = cs.aEgo if self._signal_prepare_previous is None else self._signal_prepare_previous
    uncapped = self.output_a_target
    self.output_a_target = self._signal_prepare_accel.apply(self.output_a_target, previous, elapsed, active)
    self._signal_prepare_previous = self.output_a_target
    if active:
      # Coasting must not cancel the requested gentle deceleration downstream.
      self.coasting_target = 0.0
      self.output_v_target_now = min(self.output_v_target_now, max(0., cs.vEgo+self.output_a_target*self.dt))
      self.a_desired = min(self.a_desired, self.output_a_target)
      if self.output_a_target < uncapped:
        self.output_j_target_now = min(self.output_j_target_now, (self.output_a_target-previous)/elapsed)
      # No shouldStop or go request: the existing model owns stopping/handover.

  def apply_signal_start_guard(self, carrot, v_ego):
    from openpilot.selfdrive.carrot.signal_assist import departed_signal_stop
    if (not departed_signal_stop(v_ego)
        and carrot.start_decision is not None and carrot.start_decision.hold):
      # Explicit departure veto, including the first constrained MPC cycle.
      # Preserve any stronger braking and normal longitudinal/Panda gating.
      self.output_should_stop = True
      self.output_v_target_now = 0.0
      self.output_a_target = min(self.output_a_target, 0.0)

  def update_coasting(self, sm, carrot, v_cruise_kph, v_cruise, reset_state,
                      force_slow_decel, coasting_turn_blocked, cutin_predecel_limit):
    self.coasting_target = 0.0
    # Reject cheap controller/driver states before walking subscriber health or
    # reading navigation. Every veto still clears the coasting stability history.
    if not self.coasting_percent > 0 or not self.CP.openpilotLongitudinalControl or reset_state or self.reset_decel_timer != 0:
      self.coasting.reset()
      return
    if self.mpc.mode != 'acc' or self.mpc.source != 'cruise' or self.mpc.solution_status != 0:
      self.coasting.reset()
      return
    if force_slow_decel or self.output_should_stop or self.fcw:
      self.coasting.reset()
      return
    cs = sm['carState']
    if cs.gasPressed or cs.brakePressed or cs.carrotCruise or cs.standstill or carrot.soft_hold_active:
      self.coasting.reset()
      return
    if cutin_predecel_limit is not None or coasting_turn_blocked or carrot.atc_active or carrot.lane_change_active:
      self.coasting.reset()
      return
    if (carrot.xState.name not in ('cruise', 'e2eCruise') or carrot.eco_target_speed != 0
        or not abs(self.v_cruise_kph - v_cruise_kph) < 0.001 or not abs(carrot.v_cruise - v_cruise) < 0.001):
      self.coasting.reset()
      return
    if not no_coasting_lead(sm['radarState']) or not sm.all_checks(
        service_list=('carState', 'controlsState', 'selfdriveState', 'radarState', 'modelV2')):
      self.coasting.reset()
      return
    carrot_man = get_carrot_man(sm)
    # An unseen publisher is optional; a seen but stale one still cancels relief.
    if sm.seen['carrotMan'] and carrot_man is None:
      self.coasting.reset()
      return
    ratio = cs.vCluRatio if cs.vCluRatio > 0.5 else 1.0
    external_limit = carrot_man.desiredSpeed * CV.KPH_TO_MS * ratio if carrot_man is not None else 250 * CV.KPH_TO_MS
    self.coasting_target = self.coasting.update(
      enabled=True, percent=self.coasting_percent, set_speed=v_cruise_kph,
      target=v_cruise, external_limit=external_limit, dt=self.dt,
    )

  def publish(
    self,
    sm,
    pm,
    carrot,
    *,
    planner_execution_time=0.0,
    live_tracks_mono_time=0,
    fast_lead_mask=0,
    fast_lead_track_id=-1,
    planning_trigger="modelV2",
    fast_radar_execution_time=0.0,
    fast_lead_reason="inactive",
  ):
    plan_send = messaging.new_message('longitudinalPlan')

    plan_send.valid = sm.all_checks(service_list=['carState', 'controlsState', 'selfdriveState'])

    longitudinalPlan = plan_send.longitudinalPlan
    longitudinalPlan.modelMonoTime = sm.logMonoTime['modelV2']
    longitudinalPlan.deprecated.radarStateMonoTime = sm.logMonoTime['radarState']
    longitudinalPlan.processingDelay = (plan_send.logMonoTime - sm.logMonoTime['modelV2']) / 1e9
    longitudinalPlan.solverExecutionTime = self.mpc.solve_time
    longitudinalPlan.plannerExecutionTime = float(planner_execution_time)
    longitudinalPlan.liveTracksMonoTime = int(live_tracks_mono_time)
    longitudinalPlan.fastLeadTrackId = int(fast_lead_track_id)
    longitudinalPlan.fastLeadMask = int(fast_lead_mask)
    longitudinalPlan.planningTrigger = planning_trigger
    longitudinalPlan.fastRadarExecutionTime = float(fast_radar_execution_time)
    longitudinalPlan.fastLeadReason = fast_lead_reason

    longitudinalPlan.speeds = self.v_desired_trajectory.tolist()
    longitudinalPlan.accels = self.a_desired_trajectory.tolist()
    longitudinalPlan.jerks = self.j_desired_trajectory.tolist()

    longitudinalPlan.hasLead = sm['radarState'].leadOne.status
    longitudinalPlan.longitudinalPlanSource = self.mpc.source
    longitudinalPlan.fcw = self.fcw

    longitudinalPlan.aTarget = float(self.output_a_target)
    longitudinalPlan.aTargetBase = float(self.output_a_target_base)
    longitudinalPlan.leadPreviewSeconds = float(self.lead_preview)
    longitudinalPlan.leadPreviewActionTime = float(self.lead_preview_action_time)
    longitudinalPlan.leadPreviewAccel = float(self.lead_preview_accel)
    longitudinalPlan.aChangeCost = float(self.mpc.a_change_cost)
    longitudinalPlan.trafficStopModelLeadOffset = float(carrot.trafficStopModelLeadOffset)
    longitudinalPlan.vTargetNow = float(self.output_v_target_now)
    longitudinalPlan.jTargetNow = float(self.output_j_target_now)
    longitudinalPlan.shouldStop = bool(self.output_should_stop)
    longitudinalPlan.allowBrake = True
    longitudinalPlan.allowThrottle = bool(self.allow_throttle)

    longitudinalPlan.xState = carrot.xState.value
    longitudinalPlan.trafficState = carrot.trafficState.value
    longitudinalPlan.signalDetectionSuspended = carrot.signal_detection_suspended
    longitudinalPlan.signalObservationColor = carrot.signal_observation_color
    longitudinalPlan.signalAssistAction = (1 if carrot.start_decision and carrot.start_decision.hold else
                                          2 if carrot.prepare_control_active else
                                          3 if carrot.signal_green_active else 0)
    longitudinalPlan.cruiseTarget = self.v_cruise_kph
    longitudinalPlan.cruiseCoastingTarget = self.coasting_target
    longitudinalPlan.cruiseCoastingPercent = self.coasting_percent
    longitudinalPlan.tFollow = float(self.mpc.t_follow)
    longitudinalPlan.desiredDistance = float(self.mpc.desired_distance)
    longitudinalPlan.events = carrot.events.to_msg()
    longitudinalPlan.myDrivingMode = carrot.myDrivingMode.value

    pm.send('longitudinalPlan', plan_send)
