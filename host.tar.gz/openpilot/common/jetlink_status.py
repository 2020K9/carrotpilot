"""Read-only display identity; independent of model/runtime imports."""
import json
import ipaddress
import math
from pathlib import Path
import time

from openpilot.common.jetlink_peer import classify_auto_peer, is_mac_peer, may_provision

LINK_STATUS = Path('/dev/shm/carrot-jetlink.json')
MODEL_STATUS = Path('/dev/shm/carrot-jetlink-model.json')
HOST_LABELS = {'jetson': 'jetSON', 'mac': 'MAC'}


def update_badge(value):
  if not isinstance(value, dict):
    value = {}
  state = value.get('state')
  if state == 'waiting_internet':
    return 'Jetson 업데이트 필요 · 인터넷 연결 대기', 'loading'
  if state == 'downloading':
    fraction = value.get('fraction')
    percent = f' {int(fraction * 100)}%' if isinstance(fraction, (int, float)) and 0 <= fraction <= 1 else ''
    return f'Jetson 업데이트 다운로드 중{percent}', 'loading'
  if state == 'verifying':
    return 'Jetson 업데이트 검증·적용 중', 'loading'
  if state == 'failed':
    return 'Jetson 업데이트 실패 · 재시도 대기', 'error'
  return 'Jetson 업데이트 확인 중', 'loading'


def _read(path):
  try:
    value = json.loads(path.read_text())
    return value if isinstance(value, dict) else {}
  except (OSError, ValueError):
    return {}


def host_label(peer, mode='usb'):
  if not isinstance(peer, dict):
    return 'Jetlink'
  if mode == 'auto':
    mode = classify_auto_peer(peer, 'usb') or 'auto'
  if mode in ('ios', 'android') and may_provision(peer, mode):
    return 'iOS' if mode == 'ios' else 'Android'
  host = peer.get('carrot_host')
  if isinstance(host, str) and host in HOST_LABELS:
    return HOST_LABELS[host]
  # Compatibility with the already-installed server, before host metadata.
  device = str(peer.get('device', '')).lower()
  if peer.get('backend') == 'trt' and 'orin' in device:
    return 'jetSON'
  if mode == 'usb' and is_mac_peer(peer):
    return 'MAC'
  return 'Jetlink'


def _fresh(path, now=None, *, handshake=False):
  try:
    value = _read(path)
    # Sample after the read: a concurrent atomic replacement can carry a
    # timestamp newer than the time at which this reader started.
    if now is None:
      now = time.monotonic()
    # HELLO blocks for 3s in auto probing, or 5s in the normal path. A 3s
    # display lease falsely declares a dead daemon during that bounded wait.
    # Cover HELLO + the 2s reconnect pause; all other reports still expire at 3s.
    limit = 8 if handshake and value.get('state') == 'connecting' else 3
    if handshake and value.get('state') == 'connecting':
      # Root setup has a 15s subprocess bound; NCM creation adds up to 5s.
      # These explicit phases must outlive those operations, plus reconnect.
      phase = (value.get('preparation') or {}).get('stage')
      if phase in ('usb-setup', 'network-setup'):
        limit = 22
    if isinstance(value, dict) and 0 <= now - value['updated'] < limit:
      return value
  except (OSError, ValueError, KeyError, TypeError):
    pass
  return {}


def preparation_text(link, model):
  if model.get('active'):
    return ''
  phase = (link.get('preparation') or {}).get('stage')
  if link.get('state') == 'connecting':
    return {'usb-setup': 'USB 연결 준비 중', 'network-setup': 'USB 통신 준비 중',
            'runtime-handoff': '실행 프로그램 시작 중',
            'waiting-host': '응답 대기 중', 'usb-probe': '응답 확인 중',
            'transport-selection': '연결 장치 확인 중'}.get(phase, '연결 대기')
  if link.get('state') == 'loading':
    return '모델 준비 중'
  if link.get('state') == 'ready' and model:
    return '콤마 영상 준비 중' if model.get('warp_preparing') else '모델 전환 대기'
  return ''


def diagnostics():
  """Only current telemetry can report health or an address; HELLO is identity."""
  saved = _read(LINK_STATUS)
  link = _fresh(LINK_STATUS, handshake=True)
  model = _fresh(MODEL_STATUS)
  now = time.monotonic()
  if not saved.get('peer') and saved.get('state') not in ('connecting', 'loading', 'retrying', 'blocked') and not model.get('active'):
    return None
  result = {'label': host_label(saved.get('peer'), saved.get('transport', 'usb')), 'state': link.get('state', 'disconnected'),
            'severity': 'unknown', 'reason': preparation_text(link, model), 'addresses': [], 'temp_c': None,
            'active': bool(model.get('active')), 'fresh': False}
  if link.get('state') == 'updating' and result['label'] == 'jetSON':
    text, style = update_badge(link.get('host_update') or {})
    result.update(severity='error' if style == 'error' else 'warning', reason=text, fresh=True, active=False)
    return result
  model_error = str(model.get('error') or '')[:240] if not model.get('active') else ''
  if model_error:
    result.update(severity='error', reason=model_error)
  # A current waiting report confirms the optional host is absent, including
  # startup before modeld's first report. A remembered HELLO is not a fault.
  # Keep current model failures/active-session conflicts and stale link state
  # visible; only explicit, fresh absence is quiet.
  if link.get('state') == 'waiting' and not model.get('active') and not model_error:
    result.update(reason='Host not connected')
    return result
  if result['state'] in ('retrying', 'stopped', 'disconnected', 'waiting', 'blocked'):
    result.update(severity='error', reason=str(link.get('error') or 'Host connection unavailable')[:240])
    return result
  telemetry = link.get('telemetry') or {}
  health = telemetry.get('carrot_health') if isinstance(telemetry, dict) else None
  try:
    age = now - float(link['telemetry_updated']) + float(health['age_s'])
    if not 0 <= age < 3:
      return result
  except (KeyError, TypeError, ValueError):
    return result
  result.update(fresh=True, severity=health.get('severity', 'unknown'), reason=str(health.get('reason', ''))[:240])
  if result['severity'] not in ('ok', 'warning', 'error', 'unknown'):
    result['severity'] = 'unknown'
  temperature = health.get('temp_c')
  if isinstance(temperature, (int, float)) and math.isfinite(temperature) and -20 <= temperature <= 150:
    result['temp_c'] = temperature
  entries = health.get('addresses')
  for entry in (entries[:8] if isinstance(entries, list) else []):
    try:
      address = ipaddress.ip_address(entry['address'])
      if not address.is_loopback and not address.is_unspecified and not address.is_link_local:
        result['addresses'].append(str(address))
    except (KeyError, TypeError, ValueError):
      continue
  if model_error:
    result.update(severity='error', reason=model_error)
  elif result['severity'] == 'ok' and not result['active']:
    result['reason'] = preparation_text(link, model) or result['reason']
  return result


def badge():
  link = _fresh(LINK_STATUS, handshake=True)
  model = _fresh(MODEL_STATUS)
  label = host_label(link.get('peer'), link.get('transport', 'usb'))
  if link.get('state') == 'updating' and label == 'jetSON':
    return update_badge(link.get('host_update') or {})
  health = diagnostics()
  if health:
    label = health['label']
    if health['state'] == 'waiting' and health['severity'] == 'unknown':
      return None
    if health['severity'] == 'error':
      return f'{label} ERROR', 'error'
    if health['severity'] == 'warning':
      return f'{label} HOT', 'loading'
    if label == 'jetSON' and link.get('state') == 'ready' and (not health['fresh'] or health['severity'] == 'unknown'):
      return f'{label} DATA?', 'loading'
  if model.get('active'):
    return (f'{label} 사용 중' if label == 'jetSON' else label), 'active'
  progress = preparation_text(link, model)
  if progress:
    return f'{label} {progress}', 'loading'
  state = link.get('state')
  if state == 'ready':
    return f'{label} READY', 'ready'
  if state == 'connecting':
    return f'{label} 연결 대기', 'loading'
  if state == 'loading':
    return f'{label} 모델 준비 중', 'loading'
  if state == 'retrying':
    return f'{label} RETRY', 'error'
  return None
