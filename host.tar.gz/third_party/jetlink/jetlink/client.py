"""
Copyright (c) 2026-, Zeph Leggett.

This file is part of jetlink and is licensed under the MIT License.
See the LICENSE file in the root directory for more details.

The comma side of the link.

Knows nothing about openpilot: warped frame and packed scalars in, model output
out. The glue lives in the fork (sunnypilot/jetlink/), so any fork can import
this.

Every error is a LinkError, which modeld already catches and answers with the
small model. A frame blocks until the answer arrives, as it does on a chestnut;
only a stall past FRAME_TIMEOUT is a failure.
"""
from __future__ import annotations

import json
import logging
import math
import secrets
import sys
import time
from collections.abc import Callable
from pathlib import Path

import numpy as np

from jetlink import protocol as P
from jetlink import output_projection as projection
from jetlink.spec import CHUNK, DEFAULT_FRAME_SKIP, ModelSpec
from jetlink.transport.base import LinkError, LinkTimeout, Message, Transport


def _name(enum_cls, value) -> str:
  """Enum name for a value off the wire, which may be anything."""
  try:
    return enum_cls(value).name
  except ValueError:
    return f'unknown({value})'

log = logging.getLogger('jetlink.client')

ProgressFn = Callable[[str, float, str], None]

# Not a frame budget: a long frame is a dropped camera frame, which modeld
# tolerates as it does on a chestnut. This is chestnut's HCQDEV_WAIT_TIMEOUT_MS
# (3000) - past it the far end is gone, not slow.
FRAME_TIMEOUT = 3.0

StopFn = Callable[[], bool]


class EngineMissing(LinkError):
  """The server has no engine and this caller has no ONNX to upload.

  Raised in modeld, which never carries the file: the Jetson's cache was pruned,
  re-flashed or swapped since jetlinkd recorded it ready.
  """


def _default_name() -> str:
  """Something the Jetson's journal can tell one comma process from another by."""
  return (Path(sys.argv[0]).stem if sys.argv else '') or 'python'


def _transport_layers(transport):
  pending = [transport]
  seen = set()
  while pending:
    current = pending.pop(0)
    if current is None or id(current) in seen:
      continue
    seen.add(id(current))
    yield current
    for name in ('transport', 'inner', 'wrapped', '_transport', 't'):
      nested = getattr(current, name, None)
      if nested is not None:
        pending.append(nested)


class JetlinkClient:
  def __init__(self, transport: Transport, deadline: float = FRAME_TIMEOUT,
               name: str | None = None, *, allow_block_compression: bool = False,
               allow_output_projection: bool = False, allow_request_chunks: bool = True):
    self.t = transport
    self.deadline = deadline
    # Who the server logs this connection as. The nonce is per client object,
    # so two processes taking turns on one gadget, or one process reopening
    # the link, are separable in a journal whose clock is wrong anyway.
    self.name = name or _default_name()
    self.nonce = secrets.token_hex(4)
    self.seq = 0
    self.spec: ModelSpec | None = None
    self.progress_cb: ProgressFn | None = None
    self._engine_state: dict | None = None
    self._should_stop: StopFn = lambda: False
    self.dead = False
    self.last_timings = (0, 0, 0)  # gpu_us, queue_us, total_us, server-side
    self.last_state: dict | None = None  # most recent piggybacked telemetry
    self._infer_started = 0.0
    self._infer_frame_id: int | None = None
    self._infer_flags = 0
    self._stateful_v2 = False
    self._nav_u8 = False
    # Native comma measurements show LZ4 encoding costs more than USB savings.
    # Keep exact map packing; full-block compression requires an explicit trial.
    self._allow_block_compression = allow_block_compression
    self._lz4 = False
    self.last_request_bytes = 0
    self._allow_request_chunks = allow_request_chunks
    self._allow_output_projection = allow_output_projection
    self._projection_negotiated = False
    self._projection_spec = None
    self._projection_spec_ok = False
    # The IPC consumer opts in separately for each request. Raw/old consumers
    # keep the original full response even on a projection-capable connection.
    self.project_output = False

  @property
  def output_projection_available(self) -> bool:
    if self.spec is not self._projection_spec:
      self._projection_spec = self.spec
      self._projection_spec_ok = projection.eligible(self.spec)
    return self._projection_negotiated and self._projection_spec_ok

  # -- construction ---------------------------------------------------------

  @classmethod
  def open_usb(cls, **kw) -> JetlinkClient:
    """This end is the USB host (libusb)."""
    from jetlink.transport.usbbulk import UsbBulkTransport
    return cls(UsbBulkTransport.open(), **kw)

  @classmethod
  def open_ffs(cls, mount: str = '/dev/ffs-jetlink', gadget: str | None = None,
               udc: str | None = None, **kw) -> JetlinkClient:
    """This end is the USB gadget (FunctionFS).

    The roles follow what the two kernels support, not who is the client: AGNOS
    has F_FS built in, and a host needs no driver at all. See docs/transport.md.
    """
    from jetlink.transport.ffs import FfsTransport
    return cls(FfsTransport(mount, gadget=gadget, udc=udc), **kw)

  @classmethod
  def open_borrowed_ffs(cls, mount: str, udc: str, bounce=None, owner_gadget: str | None = None,
                        **kw) -> JetlinkClient:
    """This end is the USB gadget, over a gadget another process owns.

    The owner holds ep0 and the UDC bind for as long as the link is enabled,
    so a drive starting or ending is no longer an unplug the host has to
    recover from. See FfsTransport.borrowed.
    """
    from jetlink.transport.ffs import FfsTransport
    return cls(FfsTransport.borrowed(mount, udc, bounce=bounce, owner_gadget=owner_gadget), **kw)

  @classmethod
  def open_tcp(cls, host: str, port: int = 5599, **kw) -> JetlinkClient:
    from jetlink.transport.tcp import TcpTransport
    return cls(TcpTransport.connect(host, port), **kw)

  # -- plumbing -------------------------------------------------------------

  def _next_seq(self) -> int:
    self.seq = (self.seq + 1) & 0xFFFFFFFF
    return self.seq

  def _protocol_version(self) -> int:
    for transport in _transport_layers(self.t):
      version = getattr(transport, 'protocol_version', None)
      if version is not None:
        try:
          return P.validate_version(version)
        except ValueError as e:
          raise LinkError(str(e)) from e
    return P.VERSION

  def _link_info(self) -> dict:
    for transport in _transport_layers(self.t):
      info = getattr(transport, 'link_info', None)
      if not callable(info):
        continue
      try:
        link = info()
      except (OSError, AttributeError, ValueError) as e:
        log.warning("could not read Jetlink transport metadata: %s", e)
        continue
      if link:
        if not isinstance(link, dict):
          raise LinkError("transport link_info() must return a dictionary")
        return link
    return {}

  def _dispatch(self, msg: Message) -> None:
    """Handle the messages the server may send at any time."""
    if msg.msg_type == P.Msg.PROGRESS:
      p = json.loads(bytes(msg.payload))
      if self.progress_cb:
        self.progress_cb(p.get('stage', ''), float(p.get('frac', 0.0)), p.get('msg', ''))
    elif msg.msg_type == P.Msg.ENGINE_RESP:
      state = json.loads(bytes(msg.payload))
      # A build that finished for a model this client has moved off would
      # otherwise read as ready, and every frame after it as NOT_READY.
      wanted = (self._engine_state or {}).get('sha256')
      if wanted is not None and state.get('sha256') not in (None, wanted):
        log.warning("ignoring engine state for %s (we want %s)",
                    str(state.get('sha256'))[:16], wanted[:16])
      else:
        self._engine_state = state
    elif msg.msg_type == P.Msg.ERROR:
      e = json.loads(bytes(msg.payload))
      raise LinkError(f"server error: {e.get('error')}: {e.get('detail')}")

  def _expect(self, msg_type: int, seq: int, timeout: float | None) -> Message:
    """Wait for one specific reply, servicing anything unsolicited on the way."""
    end = None if timeout is None else time.monotonic() + timeout
    while True:
      remaining = None if end is None else end - time.monotonic()
      if remaining is not None and remaining <= 0:
        raise LinkTimeout(f'timed out waiting for message type={msg_type} seq={seq}')
      msg = self.t.recv(timeout=remaining)
      if msg.msg_type == msg_type and msg.seq == seq:
        return msg
      if msg.msg_type in (P.Msg.PROGRESS, P.Msg.ENGINE_RESP, P.Msg.ERROR):
        self._dispatch(msg)
        continue
      # A reply a caller gave up on. Drop it, or every frame reads one behind.
      log.warning("discarding stale %s seq=%d (waiting for %s seq=%d)",
                  _name(P.Msg, msg.msg_type), msg.seq, _name(P.Msg, msg_type), seq)

  # -- handshake ------------------------------------------------------------

  def hello(self, timeout: float = 5.0) -> dict:
    """Introduce this client. The server starts its session over on a hello,
    so this is also how a new owner of the gadget takes over one the server
    never saw end; see Session._greet."""
    self._stateful_v2 = False
    self._nav_u8 = False
    self._lz4 = False
    self._deferred_map = False
    self.map_sender = None
    for layer in _transport_layers(self.t):
      if hasattr(type(layer), '_send_bounded_request'):
        layer.request_chunks_enabled = False
    self._projection_negotiated = False
    self._projection_spec = None
    self._projection_spec_ok = False
    self.project_output = False
    seq = self._next_seq()
    version = self._protocol_version()
    client = {'nonce': self.nonce, 'name': self.name}
    from jetlink import deferred_map
    if version == 2:
      client[deferred_map.CAPABILITY] = deferred_map.descriptor()
    if version == 2 and self._allow_output_projection:
      client[projection.CAPABILITY] = projection.descriptor()
    if version == 3:
      link = self._link_info()
      if link:
        client['link'] = link
    self.t.send_json(P.Msg.HELLO_REQ, seq, {'client': client})
    response = json.loads(bytes(self._expect(P.Msg.HELLO_RESP, seq, timeout).payload))
    if not isinstance(response, dict):
      raise LinkError("hello response is not an object")
    selected = response.get('protocol')
    if type(selected) is not int:
      raise LinkError(f"server selected invalid protocol value {selected!r}")
    try:
      selected = P.validate_version(selected)
    except ValueError as e:
      raise LinkError(str(e)) from e
    if selected != version:
      raise LinkError(f"server selected protocol {selected!r}, transport speaks protocol {version}")
    self._stateful_v2 = selected == 2 and response.get('stateful_v2') is True
    self._projection_negotiated = (self._allow_output_projection and self._stateful_v2 and
                                  projection.matches(response.get(projection.CAPABILITY)))
    from jetlink.packed_codec import CAPABILITY
    self._nav_u8 = self._stateful_v2 and response.get(CAPABILITY) is True
    self._deferred_map = self._nav_u8 and deferred_map.matches(response.get(deferred_map.CAPABILITY))
    from jetlink.block_codec import CAPABILITY as LZ4_CAPABILITY, library
    self._lz4 = (self._allow_block_compression and self._stateful_v2 and
                 response.get(LZ4_CAPABILITY) is True and library() is not None)
    from jetlink import request_chunks
    enabled = (self._allow_request_chunks and selected == 2 and response.get('carrot_host') == 'jetson' and
               request_chunks.supported(response.get(request_chunks.CAPABILITY)))
    for layer in _transport_layers(self.t):
      if hasattr(type(layer), '_send_bounded_request'):
        layer.request_chunks_enabled = enabled and layer._prepare_bounded_requests()
    response['carrot_request_chunks_active'] = any(getattr(layer, 'request_chunks_enabled', False) for layer in _transport_layers(self.t))
    response['carrot_tx_completion_deferred'] = any(
      getattr(getattr(layer, '_request_writer', None), 'deferred', False) for layer in _transport_layers(self.t))
    response['carrot_tx_write_bytes'] = next((layer._request_writer.quantum for layer in _transport_layers(self.t)
      if getattr(layer, '_request_writer', None) is not None), 0)
    return response

  def state(self, timeout: float = 2.0) -> dict:
    seq = self._next_seq()
    self.t.send_json(P.Msg.STATE_REQ, seq, {})
    return json.loads(bytes(self._expect(P.Msg.STATE_RESP, seq, timeout).payload))

  def ping(self, timeout: float = 1.0) -> float:
    seq = self._next_seq()
    t0 = time.perf_counter()
    self.t.send(P.Msg.PING, seq)
    self._expect(P.Msg.PONG, seq, timeout)
    return time.perf_counter() - t0

  def shutdown(self, reason: str = '', timeout: float = 5.0) -> dict:
    """Ask the Jetson to power off, not sleep: only a DC cycle or the button
    brings it back, so this is for the comma's low-battery shutdown alone. The
    reply comes before the box goes down."""
    seq = self._next_seq()
    self.t.send_json(P.Msg.SHUTDOWN_REQ, seq, {'reason': reason})
    return json.loads(bytes(self._expect(P.Msg.SHUTDOWN_RESP, seq, timeout).payload))

  # -- model provisioning ---------------------------------------------------

  def ensure_engine(self, sha256: str, nbytes: int, onnx_path: str | Path | None = None,
                    frame_skip: int = DEFAULT_FRAME_SKIP,
                    progress: ProgressFn | None = None,
                    build_timeout: float = 900.0,
                    should_stop: StopFn | None = None) -> ModelSpec:
    """Make the server ready to run this model, uploading and building if needed.

    Blocks until ready or the build fails, and returns the spec the server
    derived from the ONNX. Only the server parses the model, so a device whose
    parser rejects an export (tinygrad and the org.tinygrad domain) still runs.

    `onnx_path` None means the caller cannot upload (modeld) and a missing
    engine is EngineMissing. `progress(stage, frac, msg)` has stage in
    upload/patch/parse/build/load. `should_stop` is polled during long waits.
    A zero `nbytes` asks the server to use its cached or resident engine and
    never supplies an upload size.
    """
    if type(nbytes) is not int or nbytes < 0:
      raise LinkError("nbytes must be a non-negative integer")
    if type(frame_skip) is not int or frame_skip <= 0:
      raise LinkError("frame_skip must be a positive integer")
    self.progress_cb = progress
    self._should_stop = should_stop or (lambda: False)
    self.spec = None
    self._engine_state = None

    seq = self._next_seq()
    self.t.send_json(P.Msg.ENGINE_REQ, seq, {'sha256': sha256, 'nbytes': nbytes, 'frame_skip': frame_skip})
    resp = json.loads(bytes(self._expect(P.Msg.ENGINE_RESP, seq, 60.0).payload))
    if not isinstance(resp, dict):
      raise LinkError("engine response is not an object")
    self._engine_state = resp
    log.info("server engine state: %s (%s)", resp.get('state', 'unknown'), resp.get('detail', ''))

    if resp['state'] == 'need_upload':
      if nbytes == 0:
        raise EngineMissing(f"server has no cached engine for {sha256[:16]} ({resp.get('detail', '')})")
      if onnx_path is None:
        raise EngineMissing(f"server has no engine for {sha256[:16]} ({resp.get('detail', '')})")
      self._upload(Path(onnx_path), nbytes, int(resp.get('chunk') or CHUNK))

    self._await_ready(build_timeout)
    spec = self._engine_spec(sha256, frame_skip, expected_nbytes=nbytes if nbytes else None)
    self.spec = spec
    return spec

  def _engine_spec(self, sha256: str, frame_skip: int,
                   expected_nbytes: int | None = None) -> ModelSpec:
    state = self._engine_state or {}
    raw_spec = state.get('spec')
    if not isinstance(raw_spec, dict):
      raise LinkError("server reported ready without a model spec")
    try:
      spec = ModelSpec.from_dict(raw_spec)
    except (KeyError, TypeError, ValueError) as e:
      raise LinkError(f"server returned an invalid model spec: {e}") from e
    if spec.sha256 != sha256:
      raise LinkError(f"server answered for {spec.sha256[:16]}, we asked for {sha256[:16]}")
    if type(spec.nbytes) is not int or spec.nbytes <= 0:
      raise LinkError(f"server returned invalid model size {spec.nbytes!r}")
    if type(spec.frame_skip) is not int or spec.frame_skip != frame_skip:
      raise LinkError(f"server returned frame_skip {spec.frame_skip!r}, requested {frame_skip}")
    if expected_nbytes is not None and spec.nbytes != expected_nbytes:
      raise LinkError(f"server returned nbytes {spec.nbytes}, requested {expected_nbytes}")
    return spec

  def _stopped(self) -> None:
    if self._should_stop():
      raise LinkError("stopped while waiting for the engine")

  def _upload(self, onnx_path: Path, nbytes: int, chunk: int) -> None:
    log.info("uploading %s (%d MB)", onnx_path.name, nbytes >> 20)
    t0 = time.time()
    sent = 0
    with open(onnx_path, 'rb') as f:
      while data := f.read(chunk):
        self._stopped()
        self.t.send(P.Msg.UPLOAD_CHUNK, self._next_seq(),
                    (sent.to_bytes(8, 'little'), data))
        sent += len(data)
        if self.progress_cb:
          self.progress_cb('upload', sent / nbytes, f'{sent >> 20}/{nbytes >> 20} MB')
    seq = self._next_seq()
    self.t.send_json(P.Msg.UPLOAD_DONE, seq, {})
    resp = json.loads(bytes(self._expect(P.Msg.ENGINE_RESP, seq, 300.0).payload))
    self._engine_state = resp
    rate = sent / max(1e-6, time.time() - t0) / 1e6
    log.info("uploaded %d MB at %.1f MB/s -> %s", sent >> 20, rate, resp['state'])
    if resp['state'] == 'failed':
      raise LinkError(f"upload rejected: {resp.get('detail')}")

  def _await_ready(self, timeout: float) -> None:
    end = time.monotonic() + timeout
    while True:
      st = (self._engine_state or {}).get('state')
      if st == 'ready':
        if 'spec' not in (self._engine_state or {}):
          raise LinkError("server reported ready without a model spec")
        return
      if st == 'failed':
        raise LinkError(f"engine build failed: {self._engine_state.get('detail')}")
      if time.monotonic() > end:
        raise LinkTimeout(f"engine not ready after {timeout:.0f}s (state={st})")
      self._stopped()
      try:
        self._dispatch(self.t.recv(timeout=min(1.0, max(0.1, end - time.monotonic()))))
      except LinkTimeout:
        continue

  @property
  def deferred_map_available(self):
    return bool(getattr(self, '_deferred_map', False) and projection.eligible(self.spec))

  def flush_map(self):
    sender = getattr(self, 'map_sender', None)
    if sender is None:
      return 0
    remaining = self.deadline - (time.monotonic() - self._infer_started)
    if remaining <= 0:
      raise LinkTimeout('frame deadline elapsed before map staging')
    try:
      return sender.flush(self._next_seq, self.t.send, remaining)
    except (ValueError, LinkError) as exc:
      self.dead = True
      raise LinkError('map staging failed; link abandoned') from exc

  # -- inference ------------------------------------------------------------

  def infer_begin(self, warped: np.ndarray, packed: np.ndarray, frame_id: int = 0,
                  reset: bool = False, want_state: bool = False, deadline: float | None = None,
                  nav_metadata=None) -> int:
    """Send a frame and return immediately with its sequence number.

    Split from infer_end so the caller can work while the Jetson is busy;
    openpilot publishes chestnutState in that window.
    """
    if self.spec is None:
      raise LinkError("ensure_engine() first")
    if self.dead:
      raise LinkError("link previously failed")
    version = self._protocol_version()
    if self.spec.stateful and version == 2 and not self._stateful_v2:
      raise LinkError("stateful models require protocol 3 or explicit stateful_v2 host support")
    warped = _as_bytes(warped, self.spec.warped_nbytes, 'warped')
    packed = _as_bytes(packed, self.spec.packed_nbytes, 'packed')
    if version == 3:
      packed = _protocol3_packed(self.spec, packed)
    seq = self._next_seq()
    flags = (P.Flag.RESET_QUEUES if reset else 0) | (P.Flag.WANT_STATE if want_state else 0)
    if self.project_output:
      if version != 2 or not self.output_projection_available:
        raise LinkError('driving-output projection was not negotiated for this model')
      flags |= projection.FLAG
    if version == 3:
      flags |= P.Flag.WANT_HIDDEN
    try:
      self._infer_started = time.monotonic()
      self._infer_frame_id = frame_id
      self.last_map_used = False
      if nav_metadata is not None:
        from jetlink.deferred_map import Sender
        if not self.deferred_map_available or version != 2:
          raise LinkError('deferred map was not negotiated')
        if getattr(self, 'map_sender', None) is None:
          self.map_sender = Sender(self.spec)
        packed, map_flags = self.map_sender.prepare(packed, frame_id, reset, nav_metadata)
        flags |= map_flags
        self.last_map_used = self.map_sender.used
      else:
        self.map_sender = None
      if nav_metadata is None and version == 2 and self._nav_u8 and 'nav_map' in self.spec.packed_shapes:
        from jetlink.packed_codec import encode, FLAG
        packed, compressed = encode(packed, self.spec)
        if compressed:
          flags |= FLAG
      parts = (warped, packed)
      if version == 2 and self.spec.stateful and self._lz4 and not flags & 64:
        from jetlink.block_codec import encode as encode_block, FLAG as LZ4_FLAG
        block = encode_block(parts)
        if block is not None:
          flags |= LZ4_FLAG
          parts = (block,)
      self._infer_flags = flags
      self.last_request_bytes = P.INFER_REQ_SIZE + sum(memoryview(p).nbytes for p in parts)
      self.t.send(P.Msg.INFER_REQ, seq, (P.pack_infer_req(frame_id, flags), *parts),
                  timeout=self.deadline if deadline is None else deadline)
    except LinkError:
      self.dead = True
      raise
    return seq

  def infer_end(self, seq: int, deadline: float | None = None) -> np.ndarray:
    """Block for the frame's output, as modeld blocks on a chestnut.

    A long frame is a dropped camera frame, which modeld tolerates. Only a stall
    past `deadline` is a failure, and then the link is done.
    """
    try:
      budget = self.deadline if deadline is None else deadline
      remaining = budget - (time.monotonic() - self._infer_started)
      if remaining <= 0:
        raise LinkTimeout('frame deadline elapsed during send')
      msg = self._expect(P.Msg.INFER_RESP, seq, remaining)
    except LinkTimeout as e:
      self.dead = True
      raise LinkError(f"no answer for frame in {self.deadline:.1f}s; link abandoned") from e
    except LinkError:
      self.dead = True
      raise
    if msg.payload.nbytes < P.INFER_RESP_SIZE:
      self.dead = True
      raise LinkError('inference response is missing its header')
    fid, status, gpu_us, queue_us, total_us = P.unpack_infer_resp(msg.payload)
    self.last_timings = (gpu_us, queue_us, total_us)
    if status != P.Status.OK:
      self.dead = True
      raise LinkError(f"inference failed: {_name(P.Status, status)} (frame {fid})")
    if fid != self._infer_frame_id:
      self.dead = True
      raise LinkError(f'inference response frame {fid}, expected {self._infer_frame_id}')
    projected = bool(self._infer_flags & projection.FLAG)
    if bool(msg.flags & projection.FLAG) != projected:
      self.dead = True
      raise LinkError('inference response projection marker mismatch')
    if projected and msg.flags & ~(projection.FLAG | int(P.Flag.PADDED)):
      self.dead = True
      raise LinkError('invalid projected response flags')
    count = projection.COUNT if projected else self.spec.output_nelem
    end = P.INFER_RESP_SIZE + count * 4
    if msg.payload.nbytes < end:
      self.dead = True
      raise LinkError('inference response is missing model outputs')
    if msg.payload.nbytes > end:
      if not (self._infer_flags & P.Flag.WANT_STATE):
        self.dead = True
        raise LinkError(f'inference response is {msg.payload.nbytes} bytes, expected {end}')
      try:
        state = json.loads(bytes(msg.payload[end:]))
      except ValueError as e:
        self.dead = True
        raise LinkError('inference response has invalid telemetry') from e
      if not isinstance(state, dict):
        self.dead = True
        raise LinkError('inference response telemetry is not an object')
      self.last_state = state
    receive = getattr(self.t, 'last_receive', None)
    if receive is not None and time.monotonic() - self._infer_started > 0.05:
      log.warning('frame %d receive maxima: prepare %.1f read_wait %.1f handoff %.1f ms; '
                  'server gpu %.1f queue %.1f total %.1f ms', fid,
                  receive['prepare'] * 1e3, receive['read_wait'] * 1e3, receive['handoff'] * 1e3,
                  gpu_us / 1e3, queue_us / 1e3, total_us / 1e3)
    # copy: the payload is a view into the transport's reusable receive buffer.
    output = np.frombuffer(msg.payload, np.float32, count, P.INFER_RESP_SIZE).copy()
    if not np.all(np.isfinite(output)):
      self.dead = True
      raise LinkError('inference response contains non-finite model outputs')
    return output

  def infer(self, warped: np.ndarray, packed: np.ndarray, frame_id: int = 0,
            reset: bool = False, deadline: float | None = None,
            want_state: bool = False) -> np.ndarray:
    """One frame. Returns the model output as float32, shaped (n,).

    `warped` is (2, 6, H, W) uint8 off openpilot's warp, `packed` the float32
    packed_npy_inputs. Either may be any buffer, so a tinygrad Tensor.data()
    memoryview reaches the wire with no numpy round trip.
    """
    return self.infer_end(self.infer_begin(warped, packed, frame_id, reset, want_state, deadline), deadline)

  @property
  def lendable(self) -> bool:
    """Could another process take the IO over from this link? See
    FfsTransport.lendable."""
    return self.t.lendable

  def rebind(self) -> bool:
    """Make the peer see the link arrive again, where that is a thing this
    transport can do. See FfsTransport.rebind; False everywhere else."""
    return self.t.rebind()

  def release_endpoints(self) -> bool:
    """Give the endpoints up without giving the gadget up. See
    FfsTransport.release_endpoints; False everywhere else."""
    return self.t.release_endpoints()

  def close(self) -> None:
    self.t.close()


def _as_bytes(buf, expect: int, name: str) -> memoryview:
  """Byte view over a numpy array or any buffer, size-checked.

  Bytes rather than shape, so the caller can pass whatever it has and a
  mismatch fails here instead of misparsing on the far end.
  """
  mv = memoryview(buf)
  if not mv.contiguous:
    raise LinkError(f"{name} must be contiguous")
  mv = mv.cast('B')
  if mv.nbytes != expect:
    raise LinkError(f"{name} is {mv.nbytes} bytes, expected {expect}")
  return mv


def _protocol3_packed(spec: ModelSpec, packed: memoryview) -> memoryview:
  """Drop the legacy caller-owned prev_feat tail; protocol 3 keeps it server-side."""
  fields = list(spec.packed_shapes.items())
  if spec.stateful:
    if any(name == 'prev_feat' for name, _ in fields):
      raise LinkError("stateful protocol 3 packed layout must not contain prev_feat")
    if packed.nbytes != spec.packed_nbytes:
      raise LinkError("protocol 3 stateful packed layout does not match its spec")
    return packed
  if not fields or fields[-1][0] != 'prev_feat':
    raise LinkError("protocol 3 requires prev_feat to be the last packed field")
  scalar_nelem = sum(math.prod(shape) for _, shape in fields[:-1])
  legacy_nelem = scalar_nelem + math.prod(fields[-1][1])
  if legacy_nelem * 4 != spec.packed_nbytes or packed.nbytes != legacy_nelem * 4:
    raise LinkError("protocol 3 packed layout does not match the legacy spec")
  return packed[:scalar_nelem * 4]
