"""Read-only display snapshots over a negotiated Jetlink extension."""
import base64
import json
from pathlib import Path
import struct
import socket
import subprocess
import sys
import time

HUD_MESSAGE = 0x4000
HUD_CAPABILITY = 'carrot_hud_v1'
MAX_HUD_BYTES = 512 * 1024
HUD_PACKET = Path('/dev/shm/carrot-jetlink-hud.packet')
HEADER = struct.Struct('<d')
SERVICES = ('carState', 'carParams', 'modelV2', 'radarState', 'liveTracks', 'longitudinalPlan',
            'lateralPlan', 'controlsState', 'selfdriveState', 'carControl', 'carOutput', 'deviceState',
            'roadCameraState', 'cameraOdometry', 'liveCalibration', 'livePose', 'drivingModelData',
            'liveDelay', 'liveParameters', 'liveTorqueParameters', 'navInstruction', 'navInstructionCarrot',
            'navRoute', 'carrotMan', 'carrotNavi', 'wideRoadCameraState')
PARAMS = ('ClusterHud', 'ClusterHudDebug', 'ClusterHudBrightness', 'ClusterHudOrientation',
          'ClusterHudMirror', 'ClusterHudTheme', 'ClusterHudRadarInfo', 'ClusterHudRadarDisplay',
          'ClusterHudRadarSourceColor', 'ClusterHudCameraViewMode', 'ClusterHudPanelLayout',
          'ClusterHudScreenMode', 'ShowPlotMode', 'LanguageSetting', 'IsMetric', 'ShowDateTime',
          'IsOnroad', 'CarParams', 'CalibrationParams', 'CustomSteerRatio', 'SteerActuatorDelay',
          'LateralAccelerationFactor', 'UsbGpuActive',
          # The K9 HUD (대감님 HUD) reads these on the vehicle; without them a Jetson panel falls back
          # to defaults (K9 D cards/Navdy/season switches, the five lat lines above the TPMS car).
          'ClusterHudK9Style', 'K9HudNavdy', 'K9MeterSeason', 'CustomSR', 'SteerRatioRate',
          'LateralTorqueCustom', 'LateralTorqueAccelFactor', 'LateralTorqueFriction',
          'LiveDelay', 'LiveTorqueParameters', 'LiveParameters', 'LiveParametersV2', 'UsbGpuLoading')


class Publisher:
  """Keep cereal decoding, JSON and preview work outside the USB owner's GIL."""
  def __init__(self, navi=False, nav_map=False):
    import os
    self.media_socket = self.media_process = None
    if navi:
      self.media_socket, child = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
      self.media_socket.setblocking(False)
      try:
        self.media_process = subprocess.Popen(['chrt', '--other', '0', sys.executable,
          str(Path(__file__).with_name('hud_navi.py')), str(child.fileno())], pass_fds=(child.fileno(),),
          stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
      finally:
        child.close()
    self.path = Path(f'/dev/shm/carrot-jetlink-display-{os.getpid()}.packet')
    self.last_sent = 0.
    self.process = subprocess.Popen(['chrt', '--other', '0', sys.executable,
                                    str(Path(__file__).with_name('hud_publisher.py')), str(self.path),
                                    *(['--nav-map'] if nav_map else [])],
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

  def media_packet(self):
    if self.media_socket is not None:
      from hud_navi import CHUNK, HEADER as MEDIA_HEADER
      try:
        return self.media_socket.recv(CHUNK + MEDIA_HEADER.size)
      except BlockingIOError:
        pass
    return None

  def packet(self):
    try:
      with self.path.open('rb') as f:
        data = f.read(96 * 1024 + HEADER.size + 1)
      if not HEADER.size < len(data) <= 96 * 1024 + HEADER.size:
        return None
      stamp, = HEADER.unpack_from(data)
      if stamp == self.last_sent or not 0 <= time.monotonic() - stamp < .3:
        return None
      self.last_sent = stamp
      return data[HEADER.size:]
    except (OSError, struct.error):
      return None

  def close(self):
    if self.media_process is not None:
      self.media_process.terminate()
      try:
        self.media_process.wait(timeout=1)
      except subprocess.TimeoutExpired:
        self.media_process.kill()
        self.media_process.wait(timeout=1)
      self.media_socket.close()
    self.process.terminate()
    try:
      self.process.wait(timeout=2)
    except subprocess.TimeoutExpired:
      self.process.kill()
      self.process.wait(timeout=1)
    self.path.unlink(missing_ok=True)
    self.path.with_suffix('.tmp').unlink(missing_ok=True)


class SnapshotBuilder:
  def __init__(self, nav_map=False):
    from openpilot.cereal import messaging
    from openpilot.common.params import Params
    self.sm = messaging.SubMaster(list(SERVICES))
    self.params = Params()
    self.cached = {}
    self.settings = {}
    self.next_params = self.next_send = 0.
    self.host_release = None
    release_file = Path(__file__).resolve().parents[2] / 'openpilot/selfdrive/modeld/jetlink/host_release.json'
    from openpilot.common.jetson_model import selected_release
    self.host_release = selected_release(release_file)
    self.camera = None
    from hud_nav_map import NavPreviewPublisher
    self.nav_map = NavPreviewPublisher() if nav_map else None
    from openpilot.selfdrive.carrot.cluster.cluster_system_monitor import NetworkAddressProvider
    self.network = NetworkAddressProvider()

  def close(self):
    if self.camera is not None:
      self.camera.close()
    self.network.close()

  def camera_previews(self):
    from openpilot.common.jetlink_status import LINK_STATUS, _fresh, host_label
    now = time.monotonic()
    link = _fresh(LINK_STATUS, now)
    try:
      host_display = (host_label(link.get('peer')) == 'jetSON' and
                      0 <= now - float(link['telemetry_updated']) < 3 and
                      link['telemetry'].get('carrot_hud_connected') is True)
    except (KeyError, TypeError, ValueError):
      host_display = False
    # A host panel can start rendering without a camera preview. Only its
    # fresh output heartbeat starts this worker; no panel means no allocation.
    enabled = ((host_display or self.params.get_int('ClusterHud') == 1) and
               (self.params.get_bool('IsOnroad') or self.params.get_int('ClusterHudDebug') >= 1))
    if enabled and self.camera is None:
      from hud_camera import CameraPublisher
      self.camera = CameraPublisher()
    elif not enabled and self.camera is not None:
      self.camera.close()
      self.camera = None
    return self.camera.latest if self.camera is not None else {}

  def packet(self):
    from openpilot.cereal import log
    from openpilot.common.jetlink_status import badge
    now = time.monotonic()
    if now < self.next_send:
      return None
    self.next_send = now + .1 if now - self.next_send > .2 else self.next_send + .1
    self.sm.update(0)
    for name in SERVICES:
      if self.sm.updated[name]:
        event = log.Event.new_message(logMonoTime=self.sm.logMonoTime[name], valid=self.sm.valid[name])
        setattr(event, name, self.sm[name])
        self.cached[name] = base64.b64encode(event.to_bytes()).decode()
    if now >= self.next_params:
      self.settings = {}
      for key in PARAMS:
        try:
          value = self.params.get(key)
          if value is not None:
            if isinstance(value, bool):
              value = b'1' if value else b'0'
            self.settings[key] = base64.b64encode(value if isinstance(value, bytes) else str(value).encode()).decode()
        except Exception:
          pass
      self.next_params = now + 1
    device_badge = badge()
    record = {'version': 1, 'sent': now, 'events': self.cached, 'params': self.settings,
              **({'jetson_release': self.host_release} if self.host_release is not None else {}),
              'vehicle_network_address': self.network.address(),
              'external_compute_label': device_badge[0] if device_badge and device_badge[1] == 'active' else '',
              'received': self.sm.recv_time, 'mono': self.sm.logMonoTime,
              'valid': self.sm.valid, 'alive': self.sm.alive, 'cameras': self.camera_previews()}
    from hud_signal import signal_packet
    record['signal_display'] = signal_packet(now)
    from openpilot.common.indicator_display import current
    record['indicator_display'] = current()
    if self.nav_map is not None:
      preview = self.nav_map.packet(self.settings.get('ClusterHudScreenMode') == 'Nw==')
      if preview is not None:
        record['nav_map_preview'] = preview
    return encode_snapshot(record)


def encode_snapshot(record):
  indicator = record.get('indicator_display')
  if indicator and indicator.get('origin') == 'manual_turn':
    # Older HUD bundles know the driver-indicator origin and turning reason.
    record = dict(record, indicator_display=dict(indicator, origin='manual'))
  data = json.dumps(record, separators=(',', ':')).encode()
  if len(data) > 96 * 1024:
    # Optional signal metadata must not evict an existing camera or NAV image.
    record.pop('indicator_display', None)
    record.pop('signal_display', None)
    data = json.dumps(record, separators=(',', ':')).encode()
  if len(data) > 96 * 1024:
    record['cameras'] = {}
    data = json.dumps(record, separators=(',', ':')).encode()
  if len(data) > 96 * 1024:
    record.pop('nav_map_preview', None)
    data = json.dumps(record, separators=(',', ':')).encode()
  if len(data) > 96 * 1024:
    record['events'] = {k:v for k,v in record['events'].items() if k != 'navRoute'}
    data = json.dumps(record, separators=(',', ':')).encode()
  if len(data) > 96 * 1024:
    raise ValueError('HUD snapshot exceeds bounded display allocation')
  return data


_cached_snapshot = None
_next_snapshot_read = 0.


def read_snapshot():
  global _cached_snapshot, _next_snapshot_read
  now = time.monotonic()
  if now < _next_snapshot_read:
    return _cached_snapshot
  _next_snapshot_read = now + .02
  _cached_snapshot = None
  try:
    with HUD_PACKET.open('rb') as f:
      data = f.read(MAX_HUD_BYTES + HEADER.size + 1)
    if len(data) > MAX_HUD_BYTES + HEADER.size:
      return None
    received, = HEADER.unpack_from(data)
    if not 0 <= time.monotonic() - received < .5:
      return None
    value = json.loads(data[HEADER.size:])
    if value.get('version') == 1:
      _cached_snapshot = received, value
      return _cached_snapshot
  except (OSError, ValueError, struct.error):
    pass
  return None
